<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.0.0 – operating-system layer.
 * - Clean tariff navigation
 * - client staffing cockpit
 * - timesheet approval bridge
 * - encrypted XRechnung export / secure delivery
 * - Stripe customer portal + operator subscription console
 */

/* -------------------------------------------------------------------------
 * Upgrade / self-healing
 * ---------------------------------------------------------------------- */
function pw_v500_upgrade(){
    if(get_option('pw_version_500','')==='5.0.0') return;
    if(function_exists('pw_install_theme')) pw_install_theme();
    if(get_option('pw_launch_promo_limit',null)===null) update_option('pw_launch_promo_limit',20,false);
    if(get_option('pw_launch_promo_months',null)===null) update_option('pw_launch_promo_months',6,false);
    update_option('pw_version_500','5.0.0',false);
    flush_rewrite_rules(false);
}
add_action('init','pw_v500_upgrade',800);

/* -------------------------------------------------------------------------
 * Sidebar – same visual grammar as the normal navigation
 * ---------------------------------------------------------------------- */
function pw_v500_sidebar_plan_panel($uid=0){
    if(!$uid) $uid=get_current_user_id();
    if(!$uid || pw_user_role($uid)!=='agency') return '';
    $plan=pw_current_plan($uid);
    $automations_on=0;
    foreach(['match_digest','followups','pool_health','risk_watch','timesheet_approval','billing_ready','invoice_due','hot_leads','compliance_watch'] as $key){
        if(pw_user_meta($uid,'pw_auto_'.$key,'0')==='1') $automations_on++;
    }
    $items=[
        ['assist_ai','spark',pw_t('Pure Assist','Pure Assist'),'assist'],
        ['automations','spark',pw_t('Automationen','Automations'),pw_page_url('automations')],
        ['timesheets','check',pw_t('Stunden & Freigaben','Hours & approvals'),pw_page_url('timesheets')],
        ['invoicing','receipt',pw_t('Abrechnung & E-Rechnung','Billing & e-invoicing'),pw_page_url('invoices')],
        ['rate_calculator','calculator',pw_t('Kalkulation & Marge','Rate & margin'),pw_page_url('invoices').'#calculator'],
        ['leads_targets','target',pw_t('Zielkunden-Radar','Target account radar'),pw_page_url('market_live',['tab'=>'targets'])],
        ['advanced_insights','chart',pw_t('Performance-Cockpit','Performance cockpit'),pw_page_url('dashboard',['panel'=>'insights'])],
    ];
    ob_start(); ?>
      <div class="pw-nav-divider pw-v500-plan-divider"><span><?php echo esc_html(pw_t('MEIN TARIF','MY PLAN')); ?></span></div>
      <div class="pw-v500-plan-summary">
        <a href="<?php echo esc_url(pw_page_url('account',['tab'=>'billing'])); ?>">
          <span class="pw-v500-plan-symbol"><?php echo pw_icon('spark'); ?></span>
          <span><small><?php echo esc_html(pw_t('Aktiver Tarif','Active plan')); ?></small><b><?php echo esc_html(pw_plan_public_label($plan)); ?></b></span>
          <?php echo pw_icon('arrow'); ?>
        </a>
      </div>
      <nav class="pw-nav pw-v500-plan-nav" aria-label="<?php echo esc_attr(pw_t('Tariffunktionen','Plan features')); ?>">
        <?php foreach($items as $item):
          [$feature,$icon,$label,$url]=$item;$open=pw_can($feature,$uid);$needed=pw_plan_required_for($feature);
          $is_assist=$url==='assist';
          if($is_assist)$open=true;
          $sub='';
          if($is_assist && !pw_can('assist_ai',$uid)) $sub=pw_t('Hilfe aktiv · Datenhilfe ab Pro','Help active · data guidance from Pro');
          elseif($feature==='automations' && $open) $sub=$automations_on.' '.pw_t('aktiv','active');
          elseif($open) $sub=pw_t('enthalten','included');
          else $sub=pw_t('ab ','from ').pw_plan_public_label($needed);
          if($is_assist): ?>
            <button type="button" class="pw-nav-item pw-v500-plan-item <?php echo $open?'':'is-locked'; ?>" data-pw-copilot-open>
              <?php echo pw_icon($open?$icon:'lock'); ?><span><?php echo esc_html($label); ?><small><?php echo esc_html($sub); ?></small></span><em><?php echo $open?'':'+'; ?></em>
            </button>
          <?php else: ?>
            <a class="pw-nav-item pw-v500-plan-item <?php echo $open?'':'is-locked'; ?>" href="<?php echo esc_url($open?$url:pw_page_url('account',['tab'=>'billing'])); ?>">
              <?php echo pw_icon($open?$icon:'lock'); ?><span><?php echo esc_html($label); ?><small><?php echo esc_html($sub); ?></small></span><?php if(!$open):?><em>+</em><?php endif;?>
            </a>
          <?php endif;
        endforeach; ?>
      </nav>
    <?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Client cockpit – clearer bridge from demand to placement
 * ---------------------------------------------------------------------- */
function pw_v500_client_job_stage($vacancy_id){
    $subs=get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_vacancy_id','value'=>(int)$vacancy_id]]]);
    $accepted=0;$short=0;$new=0;
    foreach($subs as $sid){
        $st=pw_meta($sid,'pw_status','submitted');
        if(in_array($st,['accepted','identity_released','confirmed','planned'],true)) $accepted++;
        elseif(in_array($st,['shortlisted','on_hold','requested'],true)) $short++;
        else $new++;
    }
    if($accepted) return ['score'=>100,'stage'=>pw_t('Besetzung bestätigt','Placement confirmed'),'tone'=>'success','profiles'=>count($subs),'accepted'=>$accepted];
    if($short) return ['score'=>75,'stage'=>pw_t('Auswahl läuft','Selection in progress'),'tone'=>'brand','profiles'=>count($subs),'accepted'=>0];
    if(count($subs)) return ['score'=>50,'stage'=>pw_t('Profile prüfen','Review profiles'),'tone'=>'warning','profiles'=>count($subs),'accepted'=>0];
    return ['score'=>25,'stage'=>pw_t('Veröffentlicht','Published'),'tone'=>'muted','profiles'=>0,'accepted'=>0];
}

function pw_v500_client_staffing_monitor($uid){
    $jobs=get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>5,'orderby'=>'modified','order'=>'DESC','meta_query'=>[['key'=>'pw_status','value'=>'open']]]);
    ob_start(); ?>
    <section class="pw-card pw-v500-staffing-monitor">
      <div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('BESETZUNGSMONITOR','STAFFING MONITOR')); ?></span><h2><?php echo esc_html(pw_t('Wo steht jeder Personalbedarf?','Where does each staffing request stand?')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Nicht suchen: Der nächste Schritt steht direkt am Auftrag.','No searching: the next step sits directly on the job.')); ?></p></div><a href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><?php echo esc_html(pw_t('Alle Aufträge','All jobs')); ?> <?php echo pw_icon('arrow'); ?></a></div>
      <div class="pw-v500-monitor-list">
      <?php if(!$jobs): ?>
        <div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch kein offener Auftrag. Starte mit einem klaren Personalbedarf.','No open job yet. Start with a clear staffing request.')); ?></p><a class="pw-btn primary small" href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1])); ?>"><?php echo esc_html(pw_t('Bedarf anlegen','Create demand')); ?></a></div>
      <?php else: foreach($jobs as $job): $v=pw_vacancy_fields($job->ID);$stage=pw_v500_client_job_stage($job->ID); ?>
        <a href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$job->ID])); ?>" class="pw-v500-monitor-row">
          <span class="pw-v500-monitor-code"><?php echo esc_html($v['public_id']); ?></span>
          <div class="pw-v500-monitor-main"><b><?php echo esc_html($v['title']); ?></b><small><?php echo esc_html($v['location'].' · '.(int)$v['qty'].'×'); ?></small><div class="pw-v500-progress"><i style="width:<?php echo (int)$stage['score']; ?>%"></i></div></div>
          <div class="pw-v500-monitor-status"><strong><?php echo esc_html($stage['stage']); ?></strong><small><?php echo (int)$stage['profiles']; ?> <?php echo esc_html(pw_t('Profile','profiles')); ?></small></div><?php echo pw_icon('arrow'); ?>
        </a>
      <?php endforeach; endif; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

function pw_v500_client_demand_starter(){
    $templates=[
        ['users',pw_t('Produktion & Lager','Production & warehouse'),pw_t('Schneller Mehrbedarf','Fast extra staffing'),'lager'],
        ['settings',pw_t('Technik & Handwerk','Technical & trades'),pw_t('Qualifikation im Fokus','Qualifications first'),'technik'],
        ['building',pw_t('Kaufmännisch','Commercial'),pw_t('Büro & Verwaltung','Office & administration'),'office'],
    ];
    ob_start(); ?>
    <section class="pw-card pw-v500-demand-starter"><div class="pw-card-head"><div><span class="pw-kicker">PURE ASSIST</span><h2><?php echo esc_html(pw_t('Bedarf in 60 Sekunden starten','Start a staffing request in 60 seconds')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Wähle einen Ausgangspunkt. Pflichtfelder und typische Angaben werden im Formular vorbereitet.','Choose a starting point. Required fields and common details are prepared in the form.')); ?></p></div><?php echo pw_icon('spark'); ?></div><div class="pw-v500-demand-options"><?php foreach($templates as $t):?><a href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1,'template'=>$t[3]])); ?>"><span><?php echo pw_icon($t[0]); ?></span><div><b><?php echo esc_html($t[1]); ?></b><small><?php echo esc_html($t[2]); ?></small></div><?php echo pw_icon('arrow'); ?></a><?php endforeach;?></div></section>
    <?php return ob_get_clean();
}

function pw_v500_pending_timesheet_count($client_id){
    return (int)pw_v498_count_posts(['post_type'=>'pw_timesheet','post_status'=>'publish','meta_query'=>[['key'=>'pw_ts_client_id','value'=>(int)$client_id],['key'=>'pw_ts_status','value'=>'submitted']]]);
}

function pw_shortcode_dashboard_v500(){
    if(!is_user_logged_in()) return pw_require_login_html();
    $uid=get_current_user_id();$role=pw_user_role($uid);$user=wp_get_current_user();$name=pw_user_meta($uid,'pw_contact',$user->display_name);$company=pw_user_meta($uid,'pw_company','');
    if($role==='agency') return pw_shortcode_dashboard_v499();
    ob_start();echo pw_portal_shell_start(pw_t('Start','Home'),pw_t('Personalbedarf, Profile, Freigaben und Einsätze in einem Arbeitsfluss.','Demand, profiles, approvals and assignments in one workflow.'));echo pw_flash_messages();
    if(isset($_GET['panel'])&&$_GET['panel']==='notifications'){echo pw_dashboard_notifications_panel();echo pw_portal_shell_end();return ob_get_clean();}
    $verify=pw_verification_state($uid);if(!$verify['ready']) echo '<div class="pw-onboarding-banner compact"><div>'.pw_icon('lock').'<div><span class="pw-kicker">'.esc_html(pw_t('VERIFIZIERUNG','VERIFICATION')).'</span><h3>'.esc_html(pw_t('Unternehmensfreigabe noch offen','Company approval still pending')).'</h3><p>'.esc_html(pw_t('Nach der Prüfung sind alle sensiblen Marktplatzfunktionen verfügbar.','After approval all sensitive marketplace features are available.')).'</p></div></div><a class="pw-btn white small" href="'.esc_url(pw_page_url('account',['tab'=>'verification'])).'">'.esc_html(pw_t('Status öffnen','Open status')).'</a></div>';
    $s=pw_v498_client_snapshot($uid);$pending=pw_v500_pending_timesheet_count($uid);
    echo '<section class="pw-v499-hero pw-v500-client-hero"><div><span class="pw-kicker">'.esc_html(pw_t('DEIN PURE WORK','YOUR PURE WORK')).'</span><h1>'.esc_html($company?:$name).'</h1><p>'.esc_html(pw_t('Personalbedarf einstellen, Vorschläge entscheiden, Stunden freigeben und Einsätze verfolgen – ohne E-Mail-Ketten.','Publish demand, decide on profiles, approve hours and track assignments without email chains.')).'</p></div><div class="pw-v499-hero-actions"><a class="pw-btn primary" href="'.esc_url(pw_page_url('vacancies',['new'=>1])).'">'.pw_icon('plus').' '.esc_html(pw_t('Personalbedarf anlegen','Create staffing request')).'</a><button type="button" class="pw-btn ghost" data-pw-copilot-open>'.pw_icon('spark').' Pure Assist</button></div></section>';
    echo '<div class="pw-v499-kpi-row">'.pw_metric($s['open'],pw_t('offene Aufträge','open jobs'),$s['jobs'].' '.pw_t('gesamt','total'),'brand').pw_metric($s['new'],pw_t('Profile brauchen Entscheidung','profiles need a decision'),pw_t('jetzt prüfen','review now'),$s['new']?'warning':'').pw_metric($pending,pw_t('Stundenfreigaben offen','timesheets awaiting approval'),pw_t('von Partnern','from partners'),$pending?'warning':'').pw_metric($s['messages'],pw_t('Nachrichten offen','messages open'),pw_t('Abstimmungen','coordination'),$s['messages']?'warning':'').'</div>';
    echo '<div class="pw-v500-client-grid">'.pw_v498_action_center($uid,$role).pw_v500_client_demand_starter().'</div>';
    echo pw_v500_client_staffing_monitor($uid);
    echo '<div class="pw-v500-client-grid">'.pw_v500_client_approval_center($uid).pw_v498_client_help_card().'</div>';
    echo pw_portal_shell_end();return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Shared timesheets / approvals
 * ---------------------------------------------------------------------- */
function pw_v500_register_timesheet_type(){
    register_post_type('pw_timesheet',['labels'=>['name'=>'Pure Work Stundenfreigaben','singular_name'=>'Stundenfreigabe'],'public'=>false,'show_ui'=>current_user_can('manage_options'),'show_in_menu'=>false,'supports'=>['title','author']]);
}
add_action('init','pw_v500_register_timesheet_type',18);

function pw_v500_timesheet_meta($id,$key,$default=''){return pw_meta($id,'pw_ts_'.$key,$default);}
function pw_v500_timesheet_access($id,$uid=0){
    if(!$uid)$uid=get_current_user_id();if(!$id||get_post_type($id)!=='pw_timesheet')return false;
    return user_can($uid,'manage_options')||(int)pw_v500_timesheet_meta($id,'agency_id',0)===(int)$uid||(int)pw_v500_timesheet_meta($id,'client_id',0)===(int)$uid;
}
function pw_v500_timesheets_for_user($uid,$role){
    $key=$role==='agency'?'pw_ts_agency_id':'pw_ts_client_id';
    return get_posts(['post_type'=>'pw_timesheet','post_status'=>'publish','posts_per_page'=>100,'orderby'=>'date','order'=>'DESC','meta_query'=>[['key'=>$key,'value'=>(int)$uid]]]);
}
function pw_v500_latest_approved_timesheet($submission_id){
    $ids=get_posts(['post_type'=>'pw_timesheet','post_status'=>'publish','posts_per_page'=>1,'orderby'=>'date','order'=>'DESC','fields'=>'ids','meta_query'=>[['key'=>'pw_ts_submission_id','value'=>(int)$submission_id],['key'=>'pw_ts_status','value'=>'approved']]]);
    return $ids?(int)$ids[0]:0;
}
function pw_handle_v500_timesheet_save(){
    if(!is_user_logged_in()||pw_user_role()!=='agency'||!pw_can('timesheets'))wp_die('Keine Berechtigung.');check_admin_referer('pw_v500_timesheet_save');$uid=get_current_user_id();$sid=(int)($_POST['submission_id']??0);
    [$agency,$client]=pw_submission_parties($sid);if($agency!==$uid||!$client)wp_die('Vorgang nicht verfügbar.');
    $from=sanitize_text_field(wp_unslash($_POST['period_from']??''));$to=sanitize_text_field(wp_unslash($_POST['period_to']??''));$hours=max(0,pw_v499_decimal($_POST['hours']??0));$note=sanitize_textarea_field(wp_unslash($_POST['note']??''));if(!$from||!$to||$hours<=0)wp_die('Pflichtangaben fehlen.');
    $vid=(int)pw_meta($sid,'pw_vacancy_id',0);$wid=(int)pw_meta($sid,'pw_worker_id',0);$v=pw_vacancy_fields($vid);$w=pw_worker_fields($wid);$id=wp_insert_post(['post_type'=>'pw_timesheet','post_status'=>'publish','post_author'=>$uid,'post_title'=>pw_vacancy_public_id($vid).' · '.$w['code'].' · '.$from.'–'.$to],true);if(is_wp_error($id))wp_die('Speichern fehlgeschlagen.');
    foreach(['submission_id'=>$sid,'agency_id'=>$agency,'client_id'=>$client,'vacancy_id'=>$vid,'worker_id'=>$wid,'period_from'=>$from,'period_to'=>$to,'hours'=>$hours,'note'=>$note,'status'=>'submitted'] as $k=>$val)update_post_meta($id,'pw_ts_'.$k,$val);
    pw_create_notice($client,pw_t('Stundenfreigabe wartet','Timesheet approval waiting'),sprintf(pw_t('%s Stunden für %s wurden zur Freigabe eingereicht.','%s hours for %s were submitted for approval'),number_format_i18n($hours,2),$v['title']),pw_page_url('timesheets'));
    wp_safe_redirect(pw_page_url('timesheets',['saved'=>1]));exit;
}
add_action('admin_post_pw_v500_timesheet_save','pw_handle_v500_timesheet_save');

function pw_handle_v500_timesheet_decision(){
    if(!is_user_logged_in()||pw_user_role()!=='client')wp_die('Keine Berechtigung.');$uid=get_current_user_id();$id=(int)($_GET['id']??0);check_admin_referer('pw_v500_timesheet_decision_'.$id);if(!pw_v500_timesheet_access($id,$uid)||(int)pw_v500_timesheet_meta($id,'client_id',0)!==$uid)wp_die('Kein Zugriff.');$decision=sanitize_key($_GET['decision']??'');if(!in_array($decision,['approved','rejected'],true))wp_die('Ungültig.');update_post_meta($id,'pw_ts_status',$decision);update_post_meta($id,'pw_ts_decided_at',time());
    $agency=(int)pw_v500_timesheet_meta($id,'agency_id',0);$sid=(int)pw_v500_timesheet_meta($id,'submission_id',0);pw_create_notice($agency,$decision==='approved'?pw_t('Stunden freigegeben','Hours approved'):pw_t('Stunden zurückgewiesen','Hours rejected'),$decision==='approved'?pw_t('Der Auftraggeber hat die Stunden freigegeben. Die Abrechnung kann vorbereitet werden.','The client approved the hours. Billing can be prepared.'):pw_t('Der Auftraggeber hat die Stunden zurückgewiesen. Bitte abstimmen.','The client rejected the hours. Please coordinate.'),$decision==='approved'?pw_page_url('invoices',['new'=>1,'submission'=>$sid]):pw_page_url('timesheets'));
    wp_safe_redirect(pw_page_url('timesheets',['decision'=>$decision]));exit;
}
add_action('admin_post_pw_v500_timesheet_decision','pw_handle_v500_timesheet_decision');

function pw_v500_client_approval_center($uid){
    $items=get_posts(['post_type'=>'pw_timesheet','post_status'=>'publish','posts_per_page'=>4,'orderby'=>'date','order'=>'DESC','meta_query'=>[['key'=>'pw_ts_client_id','value'=>$uid],['key'=>'pw_ts_status','value'=>'submitted']]]);
    ob_start();?><section class="pw-card pw-v500-approval-center"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('FREIGABEN','APPROVALS')); ?></span><h2><?php echo esc_html(pw_t('Stunden mit einem Klick entscheiden','Approve hours with one click')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Freigegebene Stunden können vom Personaldienstleister direkt in die Abrechnung übernommen werden.','Approved hours can flow directly into the staffing provider’s billing.')); ?></p></div><a href="<?php echo esc_url(pw_page_url('timesheets')); ?>"><?php echo esc_html(pw_t('Alle Freigaben','All approvals')); ?> <?php echo pw_icon('arrow'); ?></a></div><div class="pw-v500-approval-list"><?php if(!$items):?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Aktuell wartet keine Stundenfreigabe.','No timesheet is awaiting approval right now.')); ?></p></div><?php else:foreach($items as $ts):$sid=(int)pw_v500_timesheet_meta($ts->ID,'submission_id');$vid=(int)pw_v500_timesheet_meta($ts->ID,'vacancy_id');$v=pw_vacancy_fields($vid);?><a href="<?php echo esc_url(pw_page_url('timesheets',['view'=>$ts->ID])); ?>"><span><?php echo pw_icon('clock'); ?></span><div><b><?php echo esc_html($v['title']); ?></b><small><?php echo esc_html(pw_v500_timesheet_meta($ts->ID,'hours')).' h · '.esc_html(pw_format_date(pw_v500_timesheet_meta($ts->ID,'period_from'))).'–'.esc_html(pw_format_date(pw_v500_timesheet_meta($ts->ID,'period_to'))); ?></small></div><em><?php echo esc_html(pw_t('prüfen','review')); ?></em></a><?php endforeach;endif;?></div></section><?php return ob_get_clean();
}

function pw_shortcode_timesheets(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();$role=pw_user_role($uid);ob_start();echo pw_portal_shell_start(pw_t('Stunden & Freigaben','Hours & approvals'),pw_t('Arbeitszeit gemeinsam bestätigen – danach ohne Doppelerfassung abrechnen.','Confirm working time together, then bill without duplicate entry.'));echo pw_flash_messages();
    if($role==='agency'&&!pw_can('timesheets',$uid)){echo pw_plan_gate('timesheets');echo pw_portal_shell_end();return ob_get_clean();}
    $view=(int)($_GET['view']??0);if($view&&pw_v500_timesheet_access($view,$uid)){echo pw_v500_timesheet_detail($view,$uid,$role);echo pw_portal_shell_end();return ob_get_clean();}
    $items=pw_v500_timesheets_for_user($uid,$role);?>
    <section class="pw-v499-board-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('GEMEINSAME FREIGABE','SHARED APPROVAL')); ?></span><h1><?php echo esc_html(pw_t('Stunden einmal erfassen. Gemeinsam bestätigen.','Enter hours once. Confirm together.')); ?></h1><p><?php echo esc_html(pw_t('Der Status ist für beide Seiten identisch sichtbar. Freigegebene Stunden können direkt zur Rechnungsgrundlage werden.','Both sides see the same status. Approved hours can become the invoice basis directly.')); ?></p></div></section>
    <?php if($role==='agency'): $assignments=pw_v499_active_assignments($uid); ?>
      <section class="pw-card pw-v500-timesheet-create"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('NEUE STUNDENFREIGABE','NEW TIMESHEET')); ?></span><h2><?php echo esc_html(pw_t('Einsatz auswählen und Stunden einreichen','Choose assignment and submit hours')); ?></h2></div></div>
      <?php if(!$assignments):?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch kein bestätigter Einsatz vorhanden.','No confirmed assignment exists yet.')); ?></p><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('assignments')); ?>"><?php echo esc_html(pw_t('Einsatzboard öffnen','Open assignment board')); ?></a></div><?php else:?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-form-grid two"><input type="hidden" name="action" value="pw_v500_timesheet_save"><?php wp_nonce_field('pw_v500_timesheet_save');?><label class="full"><?php echo esc_html(pw_t('Einsatz','Assignment')); ?><select name="submission_id" required><option value=""><?php echo esc_html(pw_t('Bitte wählen','Choose')); ?></option><?php foreach($assignments as $sid):$vid=(int)pw_meta($sid,'pw_vacancy_id',0);$wid=(int)pw_meta($sid,'pw_worker_id',0);$v=pw_vacancy_fields($vid);$w=pw_worker_fields($wid);?><option value="<?php echo (int)$sid; ?>"><?php echo esc_html($v['title'].' · '.$w['code'].' · '.pw_vacancy_client_label($vid,$uid)); ?></option><?php endforeach;?></select></label><label><?php echo esc_html(pw_t('Von','From')); ?><input type="date" name="period_from" required></label><label><?php echo esc_html(pw_t('Bis','To')); ?><input type="date" name="period_to" required></label><label><?php echo esc_html(pw_t('Gesamtstunden','Total hours')); ?><input type="number" min="0.25" step="0.25" name="hours" required></label><label><?php echo esc_html(pw_t('Hinweis','Note')); ?><input name="note" placeholder="<?php echo esc_attr(pw_t('optional','optional')); ?>"></label><div class="full pw-form-actions"><button class="pw-btn primary"><?php echo pw_icon('check'); ?> <?php echo esc_html(pw_t('Zur Freigabe senden','Send for approval')); ?></button></div></form><?php endif;?></section>
    <?php endif; ?>
    <section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('VERLAUF','HISTORY')); ?></span><h2><?php echo count($items); ?> <?php echo esc_html(pw_t('Stundenvorgänge','timesheet records')); ?></h2></div></div><div class="pw-v500-timesheet-list"><?php if(!$items):?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch keine Stundenfreigaben.','No timesheet approvals yet.')); ?></p></div><?php else:foreach($items as $ts):$st=pw_v500_timesheet_meta($ts->ID,'status','submitted');$vid=(int)pw_v500_timesheet_meta($ts->ID,'vacancy_id');$v=pw_vacancy_fields($vid);$labels=['submitted'=>pw_t('wartet auf Freigabe','awaiting approval'),'approved'=>pw_t('freigegeben','approved'),'rejected'=>pw_t('zurückgewiesen','rejected')];?><a href="<?php echo esc_url(pw_page_url('timesheets',['view'=>$ts->ID])); ?>"><span class="pw-v500-ts-status <?php echo esc_attr($st); ?>"><?php echo pw_icon($st==='approved'?'check':($st==='rejected'?'alert':'clock')); ?></span><div><b><?php echo esc_html($v['title']); ?></b><small><?php echo esc_html(pw_v500_timesheet_meta($ts->ID,'hours')).' h · '.esc_html($labels[$st]??$st); ?></small></div><strong><?php echo esc_html(pw_format_date(pw_v500_timesheet_meta($ts->ID,'period_from'))); ?>–<?php echo esc_html(pw_format_date(pw_v500_timesheet_meta($ts->ID,'period_to'))); ?></strong><?php echo pw_icon('arrow'); ?></a><?php endforeach;endif;?></div></section>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

function pw_v500_timesheet_detail($id,$uid,$role){
    $sid=(int)pw_v500_timesheet_meta($id,'submission_id');$vid=(int)pw_v500_timesheet_meta($id,'vacancy_id');$wid=(int)pw_v500_timesheet_meta($id,'worker_id');$v=pw_vacancy_fields($vid);$w=pw_worker_fields($wid);$st=pw_v500_timesheet_meta($id,'status','submitted');$labels=['submitted'=>pw_t('Wartet auf Freigabe','Awaiting approval'),'approved'=>pw_t('Freigegeben','Approved'),'rejected'=>pw_t('Zurückgewiesen','Rejected')];ob_start();?>
    <div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('timesheets')); ?>">← <?php echo esc_html(pw_t('Stunden & Freigaben','Hours & approvals')); ?></a><h2><?php echo esc_html($v['title']); ?></h2><p><?php echo esc_html($w['code'].' · '.pw_v500_timesheet_meta($id,'hours').' h'); ?></p></div><span class="pw-badge <?php echo $st==='approved'?'success':($st==='rejected'?'danger':'warning'); ?>"><?php echo esc_html($labels[$st]??$st); ?></span></div>
    <section class="pw-card pw-v500-ts-detail"><div class="pw-v500-ts-facts"><span><small><?php echo esc_html(pw_t('Zeitraum','Period')); ?></small><b><?php echo esc_html(pw_format_date(pw_v500_timesheet_meta($id,'period_from'))); ?> – <?php echo esc_html(pw_format_date(pw_v500_timesheet_meta($id,'period_to'))); ?></b></span><span><small><?php echo esc_html(pw_t('Gesamtstunden','Total hours')); ?></small><b><?php echo esc_html(pw_v500_timesheet_meta($id,'hours')); ?> h</b></span><span><small><?php echo esc_html(pw_t('Hinweis','Note')); ?></small><b><?php echo esc_html(pw_v500_timesheet_meta($id,'note','–')?:'–'); ?></b></span></div>
    <?php if($role==='client'&&$st==='submitted'):?><div class="pw-v500-decision-bar"><a class="pw-btn primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_timesheet_decision&id='.$id.'&decision=approved'),'pw_v500_timesheet_decision_'.$id)); ?>"><?php echo pw_icon('check'); ?> <?php echo esc_html(pw_t('Stunden freigeben','Approve hours')); ?></a><a class="pw-btn danger-ghost" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_timesheet_decision&id='.$id.'&decision=rejected'),'pw_v500_timesheet_decision_'.$id)); ?>"><?php echo esc_html(pw_t('Zurückweisen','Reject')); ?></a></div><?php elseif($role==='agency'&&$st==='approved'&&pw_can('invoicing',$uid)): $existing_invoice=(int)pw_v500_timesheet_meta($id,'invoice_id',0); ?><div class="pw-v500-decision-bar"><?php if($existing_invoice&&pw_v499_invoice_access($existing_invoice,$uid)):?><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('invoices',['view'=>$existing_invoice])); ?>"><?php echo pw_icon('receipt'); ?> <?php echo esc_html(pw_t('Zugehörige Rechnung öffnen','Open linked invoice')); ?></a><span class="pw-badge success"><?php echo esc_html(pw_t('bereits abgerechnet','already billed')); ?></span><?php else:?><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('invoices',['new'=>1,'submission'=>$sid,'timesheet'=>$id])); ?>"><?php echo pw_icon('receipt'); ?> <?php echo esc_html(pw_t('Rechnung vorbereiten','Prepare invoice')); ?></a><?php endif;?></div><?php endif;?></section><?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * XRechnung 3.0.2-compatible UBL export and secure delivery
 * ---------------------------------------------------------------------- */
function pw_v500_xml_escape($v){return htmlspecialchars((string)$v,ENT_XML1|ENT_COMPAT,'UTF-8');}
function pw_v500_decimal_xml($v){return number_format((float)$v,2,'.','');}

function pw_v500_invoice_required($id){
    $bp=pw_v500_billing_profile((int)get_post_field('post_author',$id));
    $required=[
        'sender_company'=>$bp['company']??'', 'sender_street'=>$bp['street']??'', 'sender_zip'=>$bp['zip']??'', 'sender_city'=>$bp['city']??'',
        'sender_email'=>$bp['email']??'', 'sender_vat_id'=>$bp['vat_id']??'', 'iban'=>$bp['iban']??'',
        'customer'=>pw_v499_invoice_meta($id,'customer'), 'customer_street'=>pw_v499_invoice_meta($id,'customer_street'),
        'customer_zip'=>pw_v499_invoice_meta($id,'customer_zip'),'customer_city'=>pw_v499_invoice_meta($id,'customer_city'),
        'customer_email'=>pw_v499_invoice_meta($id,'customer_email'),'description'=>pw_v499_invoice_meta($id,'description'),
        'service_from'=>pw_v499_invoice_meta($id,'service_from'),'service_to'=>pw_v499_invoice_meta($id,'service_to'),
    ];
    if(pw_user_meta((int)get_post_field('post_author',$id),'pw_invoice_standard','xrechnung_b2b')==='xrechnung_b2g')$required['buyer_reference']=pw_v499_invoice_meta($id,'buyer_reference');$missing=[];foreach($required as $k=>$v)if(trim((string)$v)==='')$missing[]=$k;
    return ['ready'=>!$missing,'missing'=>$missing,'score'=>(int)round((count($required)-count($missing))*100/max(1,count($required)))];
}

function pw_v500_xrechnung_xml($id){
    if(!pw_v499_invoice_access($id,(int)get_post_field('post_author',$id)) && !current_user_can('manage_options')) return new WP_Error('access','Invoice unavailable');
    $ready=pw_v500_invoice_required($id);if(!$ready['ready'])return new WP_Error('missing','Pflichtfelder für die E-Rechnung fehlen: '.implode(', ',$ready['missing']));
    $uid=(int)get_post_field('post_author',$id);$bp=pw_v500_billing_profile($uid);$e='pw_v500_xml_escape';
    $no=pw_v499_invoice_meta($id,'no');$issue=pw_v499_invoice_meta($id,'date');$due=pw_v499_invoice_meta($id,'due');$customer=pw_v499_invoice_meta($id,'customer');$custEmail=pw_v499_invoice_meta($id,'customer_email');
    $hours=(float)pw_v499_invoice_meta($id,'hours');$rate=(float)pw_v499_invoice_meta($id,'rate');$vat=(float)pw_v499_invoice_meta($id,'vat');$net=(float)pw_v499_invoice_meta($id,'net');$tax=(float)pw_v499_invoice_meta($id,'tax');$gross=(float)pw_v499_invoice_meta($id,'gross');
    $buyerRef=trim((string)pw_v499_invoice_meta($id,'buyer_reference',''));if($buyerRef==='')$buyerRef=$no;
    $xml='<?xml version="1.0" encoding="UTF-8"?>\n';
    $xml.='<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">\n';
    $xml.='  <cbc:CustomizationID>urn:cen.eu:en16931:2017#compliant#urn:xeinkauf.de:kosit:xrechnung_3.0</cbc:CustomizationID>\n';
    $xml.='  <cbc:ProfileID>urn:fdc:peppol.eu:2017:poacc:billing:01:1.0</cbc:ProfileID>\n';
    $xml.='  <cbc:ID>'.$e($no).'</cbc:ID>\n  <cbc:IssueDate>'.$e($issue).'</cbc:IssueDate>\n  <cbc:DueDate>'.$e($due).'</cbc:DueDate>\n  <cbc:InvoiceTypeCode>380</cbc:InvoiceTypeCode>\n  <cbc:DocumentCurrencyCode>EUR</cbc:DocumentCurrencyCode>\n  <cbc:BuyerReference>'.$e($buyerRef).'</cbc:BuyerReference>\n';
    $xml.='  <cac:InvoicePeriod><cbc:StartDate>'.$e(pw_v499_invoice_meta($id,'service_from')).'</cbc:StartDate><cbc:EndDate>'.$e(pw_v499_invoice_meta($id,'service_to')).'</cbc:EndDate></cac:InvoicePeriod>\n';
    $xml.='  <cac:AccountingSupplierParty><cac:Party><cbc:EndpointID schemeID="EM">'.$e($bp['email']).'</cbc:EndpointID><cac:PartyName><cbc:Name>'.$e($bp['company']).'</cbc:Name></cac:PartyName><cac:PostalAddress><cbc:StreetName>'.$e($bp['street']).'</cbc:StreetName><cbc:CityName>'.$e($bp['city']).'</cbc:CityName><cbc:PostalZone>'.$e($bp['zip']).'</cbc:PostalZone><cac:Country><cbc:IdentificationCode>DE</cbc:IdentificationCode></cac:Country></cac:PostalAddress><cac:PartyTaxScheme><cbc:CompanyID>'.$e($bp['vat_id']).'</cbc:CompanyID><cac:TaxScheme><cbc:ID>VAT</cbc:ID></cac:TaxScheme></cac:PartyTaxScheme><cac:PartyLegalEntity><cbc:RegistrationName>'.$e($bp['company']).'</cbc:RegistrationName></cac:PartyLegalEntity></cac:Party></cac:AccountingSupplierParty>\n';
    $xml.='  <cac:AccountingCustomerParty><cac:Party><cbc:EndpointID schemeID="EM">'.$e($custEmail).'</cbc:EndpointID><cac:PartyName><cbc:Name>'.$e($customer).'</cbc:Name></cac:PartyName><cac:PostalAddress><cbc:StreetName>'.$e(pw_v499_invoice_meta($id,'customer_street')).'</cbc:StreetName><cbc:CityName>'.$e(pw_v499_invoice_meta($id,'customer_city')).'</cbc:CityName><cbc:PostalZone>'.$e(pw_v499_invoice_meta($id,'customer_zip')).'</cbc:PostalZone><cac:Country><cbc:IdentificationCode>'. $e(pw_v499_invoice_meta($id,'customer_country','DE')).'</cbc:IdentificationCode></cac:Country></cac:PostalAddress><cac:PartyLegalEntity><cbc:RegistrationName>'.$e($customer).'</cbc:RegistrationName></cac:PartyLegalEntity></cac:Party></cac:AccountingCustomerParty>\n';
    $xml.='  <cac:PaymentMeans><cbc:PaymentMeansCode>58</cbc:PaymentMeansCode><cbc:PaymentID>'.$e($no).'</cbc:PaymentID><cac:PayeeFinancialAccount><cbc:ID>'.$e(preg_replace('/\s+/','',$bp['iban'])).'</cbc:ID></cac:PayeeFinancialAccount></cac:PaymentMeans>\n';
    $xml.='  <cac:TaxTotal><cbc:TaxAmount currencyID="EUR">'.pw_v500_decimal_xml($tax).'</cbc:TaxAmount><cac:TaxSubtotal><cbc:TaxableAmount currencyID="EUR">'.pw_v500_decimal_xml($net).'</cbc:TaxableAmount><cbc:TaxAmount currencyID="EUR">'.pw_v500_decimal_xml($tax).'</cbc:TaxAmount><cac:TaxCategory><cbc:ID>S</cbc:ID><cbc:Percent>'.pw_v500_decimal_xml($vat).'</cbc:Percent><cac:TaxScheme><cbc:ID>VAT</cbc:ID></cac:TaxScheme></cac:TaxCategory></cac:TaxSubtotal></cac:TaxTotal>\n';
    $xml.='  <cac:LegalMonetaryTotal><cbc:LineExtensionAmount currencyID="EUR">'.pw_v500_decimal_xml($net).'</cbc:LineExtensionAmount><cbc:TaxExclusiveAmount currencyID="EUR">'.pw_v500_decimal_xml($net).'</cbc:TaxExclusiveAmount><cbc:TaxInclusiveAmount currencyID="EUR">'.pw_v500_decimal_xml($gross).'</cbc:TaxInclusiveAmount><cbc:PayableAmount currencyID="EUR">'.pw_v500_decimal_xml($gross).'</cbc:PayableAmount></cac:LegalMonetaryTotal>\n';
    $xml.='  <cac:InvoiceLine><cbc:ID>1</cbc:ID><cbc:InvoicedQuantity unitCode="HUR">'.pw_v500_decimal_xml($hours).'</cbc:InvoicedQuantity><cbc:LineExtensionAmount currencyID="EUR">'.pw_v500_decimal_xml($net).'</cbc:LineExtensionAmount><cac:Item><cbc:Name>'.$e(pw_v499_invoice_meta($id,'description')).'</cbc:Name><cac:ClassifiedTaxCategory><cbc:ID>S</cbc:ID><cbc:Percent>'.pw_v500_decimal_xml($vat).'</cbc:Percent><cac:TaxScheme><cbc:ID>VAT</cbc:ID></cac:TaxScheme></cac:ClassifiedTaxCategory></cac:Item><cac:Price><cbc:PriceAmount currencyID="EUR">'.pw_v500_decimal_xml($rate).'</cbc:PriceAmount></cac:Price></cac:InvoiceLine>\n';
    $xml.='</Invoice>';
    $xml=str_replace('\\n',"\n",$xml);
    update_post_meta($id,'pw_inv_xml_enc',pw_encrypt_sensitive($xml));update_post_meta($id,'pw_inv_xml_generated_at',time());update_post_meta($id,'pw_inv_xrechnung_profile','3.0.2 / UBL 2.1');
    return $xml;
}
function pw_v500_invoice_xml_cached($id){$enc=get_post_meta($id,'pw_inv_xml_enc',true);if($enc){$xml=pw_decrypt_sensitive($enc);if($xml)return $xml;}return pw_v500_xrechnung_xml($id);}
function pw_v500_invoice_download_response($id,$xml){
    nocache_headers();header('Content-Type: application/xml; charset=UTF-8');header('X-Content-Type-Options: nosniff');header('Content-Disposition: attachment; filename="'.sanitize_file_name(pw_v499_invoice_meta($id,'no','rechnung')).'-xrechnung.xml"');echo $xml;exit;
}
function pw_handle_v500_invoice_xml(){
    if(!is_user_logged_in())wp_die('Anmeldung erforderlich.');$uid=get_current_user_id();$id=(int)($_GET['id']??0);check_admin_referer('pw_v500_invoice_xml_'.$id);if(!pw_v499_invoice_access($id,$uid))wp_die('Kein Zugriff.');$xml=pw_v500_invoice_xml_cached($id);if(is_wp_error($xml))wp_die(esc_html($xml->get_error_message()));pw_v500_invoice_download_response($id,$xml);
}
add_action('admin_post_pw_v500_invoice_xml','pw_handle_v500_invoice_xml');
function pw_v500_invoice_share_token($id,$exp){return hash_hmac('sha256',(int)$id.'|'.(int)$exp.'|'.pw_v499_invoice_meta($id,'customer_email',''),wp_salt('secure_auth'));}
function pw_v500_invoice_secure_url($id,$days=7){$exp=time()+max(1,(int)$days)*DAY_IN_SECONDS;return add_query_arg(['action'=>'pw_v500_public_invoice','id'=>$id,'exp'=>$exp,'token'=>pw_v500_invoice_share_token($id,$exp)],admin_url('admin-post.php'));}
function pw_handle_v500_public_invoice(){
    $id=(int)($_GET['id']??0);$exp=(int)($_GET['exp']??0);$token=sanitize_text_field(wp_unslash($_GET['token']??''));if(!$id||$exp<time()||!hash_equals(pw_v500_invoice_share_token($id,$exp),$token))wp_die('Dieser sichere Rechnungslink ist ungültig oder abgelaufen.',403);$xml=pw_v500_invoice_xml_cached($id);if(is_wp_error($xml))wp_die('E-Rechnung nicht verfügbar.',400);pw_v500_invoice_download_response($id,$xml);
}
add_action('admin_post_nopriv_pw_v500_public_invoice','pw_handle_v500_public_invoice');add_action('admin_post_pw_v500_public_invoice','pw_handle_v500_public_invoice');
function pw_handle_v500_invoice_send(){
    if(!is_user_logged_in()||pw_user_role()!=='agency'||!pw_can('einvoice'))wp_die('Keine Berechtigung.');$uid=get_current_user_id();$id=(int)($_GET['id']??0);check_admin_referer('pw_v500_invoice_send_'.$id);if(!pw_v499_invoice_access($id,$uid))wp_die('Kein Zugriff.');$email=sanitize_email(pw_v499_invoice_meta($id,'customer_email',''));if(!$email)wp_die('Empfänger-E-Mail fehlt.');$xml=pw_v500_xrechnung_xml($id);if(is_wp_error($xml))wp_die(esc_html($xml->get_error_message()));$url=pw_v500_invoice_secure_url($id,7);$subject=pw_t('E-Rechnung ','E-invoice ').pw_v499_invoice_meta($id,'no');$headline=pw_t('Ihre E-Rechnung steht sicher bereit','Your e-invoice is ready securely');$body=pw_t('Die strukturierte E-Rechnung wurde in Pure Work erstellt. Der Download-Link ist 7 Tage gültig.','The structured e-invoice was created in Pure Work. The download link is valid for 7 days.');$ok=pw_send_mail($email,$subject,$headline,$body,pw_t('E-Rechnung herunterladen','Download e-invoice'),$url);if($ok){update_post_meta($id,'pw_inv_status','sent');update_post_meta($id,'pw_inv_sent_at',time());update_post_meta($id,'pw_inv_secure_delivery','1');}wp_safe_redirect(pw_page_url('invoices',['view'=>$id,'mail'=>$ok?'sent':'failed']));exit;
}
add_action('admin_post_pw_v500_invoice_send','pw_handle_v500_invoice_send');

function pw_v500_invoice_assist_card($data=[]){
    ob_start();?><aside class="pw-card pw-v500-invoice-assist" data-pw-invoice-assist><div class="pw-v500-assist-head"><span class="pw-assist-orb"><?php echo pw_icon('spark'); ?></span><div><span class="pw-kicker">PURE ASSIST</span><h3><?php echo esc_html(pw_t('E-Rechnungs-Helfer','E-invoice assistant')); ?></h3></div></div><div class="pw-v500-readiness"><div><span><?php echo esc_html(pw_t('E-Rechnungs-Bereitschaft','E-invoice readiness')); ?></span><strong data-invoice-score>0%</strong></div><i><b data-invoice-bar></b></i></div><ul data-invoice-checks></ul><div class="pw-v500-assist-tip"><b><?php echo esc_html(pw_t('Was Pure Assist prüft','What Pure Assist checks')); ?></b><p><?php echo esc_html(pw_t('Absender, Empfänger, Leistungszeitraum, Steuerdaten, Zahlungsdaten und strukturierte XRechnung-Felder.','Sender, recipient, service period, tax data, payment data and structured XRechnung fields.')); ?></p></div><button type="button" class="pw-btn ghost full small" data-pw-invoice-focus><?php echo pw_icon('spark'); ?> <?php echo esc_html(pw_t('Fehlende Angaben zeigen','Show missing information')); ?></button></aside><?php return ob_get_clean();
}

function pw_v500_invoice_actions($id,$uid){
    if(!pw_v499_invoice_access($id,$uid)||!pw_can('einvoice',$uid))return '';$ready=pw_v500_invoice_required($id);ob_start();?><section class="pw-card pw-v500-einvoice-actions"><div><span class="pw-kicker"><?php echo esc_html(pw_t('E-RECHNUNG','E-INVOICE')); ?> · XRECHNUNG 3.0.2</span><h3><?php echo $ready['ready']?esc_html(pw_t('Strukturierte Rechnung bereit','Structured invoice ready')):esc_html(pw_t('Noch Angaben ergänzen','Complete missing data')); ?></h3><p><?php echo $ready['ready']?esc_html(pw_t('XML wird verschlüsselt im Portal gespeichert. Beim Versand erhält der Empfänger einen zeitlich begrenzten sicheren Download-Link.','XML is stored encrypted in the portal. On delivery the recipient receives a time-limited secure download link.')):esc_html(sprintf(pw_t('%d%% vollständig. Bitte Pflichtangaben ergänzen.','%d%% complete. Please add required information.'),$ready['score'])); ?></p></div><div class="pw-v500-einvoice-buttons"><?php if($ready['ready']):?><a class="pw-btn ghost" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_invoice_xml&id='.$id),'pw_v500_invoice_xml_'.$id)); ?>"><?php echo pw_icon('document'); ?> <?php echo esc_html(pw_t('XRechnung XML','XRechnung XML')); ?></a><a class="pw-btn primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_invoice_send&id='.$id),'pw_v500_invoice_send_'.$id)); ?>"><?php echo pw_icon('lock'); ?> <?php echo esc_html(pw_t('Sicher senden','Send securely')); ?></a><?php else:?><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('invoices',['new'=>1,'edit'=>$id])); ?>"><?php echo esc_html(pw_t('Daten ergänzen','Complete data')); ?></a><?php endif;?></div></section><?php return ob_get_clean();
}


function pw_v500_subscription_status_label($status){
    $map=[
        'promo'=>pw_t('KOSTENFREI','FREE'),
        'active'=>pw_t('AKTIV','ACTIVE'),
        'payment_required'=>pw_t('ZAHLUNG NÖTIG','PAYMENT REQUIRED'),
        'past_due'=>pw_t('ZAHLUNG ÜBERFÄLLIG','PAYMENT OVERDUE'),
        'canceled'=>pw_t('GEKÜNDIGT','CANCELED'),
        'trialing'=>pw_t('TESTPHASE','TRIAL'),
    ];
    return $map[$status]??strtoupper(str_replace('_',' ',(string)$status));
}

/* -------------------------------------------------------------------------
 * Stripe customer portal and launch quota
 * ---------------------------------------------------------------------- */
function pw_v500_stripe_customer_portal_session($uid){
    $customer=trim((string)pw_user_meta($uid,'pw_stripe_customer_id',''));if(!$customer)return new WP_Error('customer','Noch kein Stripe-Kunde vorhanden.');
    $params=['customer'=>$customer,'return_url'=>pw_page_url('account',['tab'=>'billing']),'locale'=>function_exists('pw_current_lang')&&pw_current_lang()==='en'?'en':'de'];
    $config=trim((string)get_option('pw_stripe_portal_configuration',''));if($config)$params['configuration']=$config;
    return pw_stripe_api_post('billing_portal/sessions',$params);
}
function pw_handle_v500_customer_portal(){
    if(!is_user_logged_in()||pw_user_role()!=='agency')wp_die('Keine Berechtigung.');check_admin_referer('pw_v500_customer_portal');$s=pw_v500_stripe_customer_portal_session(get_current_user_id());if(!is_wp_error($s)&&!empty($s['url'])){wp_redirect(esc_url_raw($s['url']));exit;}wp_safe_redirect(pw_page_url('account',['tab'=>'billing','portal'=>'unavailable']));exit;
}
add_action('admin_post_pw_v500_customer_portal','pw_handle_v500_customer_portal');
function pw_v500_billing_manage_card($uid){
    $state=pw_subscription_state($uid);$claimed=count(pw_launch_promo_claimed_ids());$limit=max(0,(int)get_option('pw_launch_promo_limit',20));$customer=trim((string)pw_user_meta($uid,'pw_stripe_customer_id',''));ob_start();?><section class="pw-card pw-v500-billing-manage"><div><span class="pw-kicker"><?php echo esc_html(pw_t('ZAHLUNG & ABO','PAYMENT & SUBSCRIPTION')); ?></span><h3><?php echo esc_html(pw_t('Dein Zugang ist transparent verwaltbar','Your access is transparently manageable')); ?></h3><p><?php if($state['status']==='promo'):echo esc_html(sprintf(pw_t('Kostenfreier Startplatz %d/%d · bis %s. Du kannst Zahlungsdaten schon jetzt hinterlegen.','Free launch slot %d/%d · until %s. You can add payment details now.'),min($claimed,$limit),$limit,wp_date('d.m.Y',$state['until'])));else:echo esc_html(pw_t('Tarif, Zahlungsstatus und Stripe-Verknüpfung bleiben an einem Ort.','Plan, payment status and Stripe connection stay in one place.'));endif;?></p></div><div><?php if($customer&&pw_stripe_ready()):?><a class="pw-btn ghost" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_customer_portal'),'pw_v500_customer_portal')); ?>"><?php echo pw_icon('settings'); ?> <?php echo esc_html(pw_t('Zahlungsdaten & Abo verwalten','Manage payment & subscription')); ?></a><?php else:?><span class="pw-badge muted"><?php echo esc_html(pw_t('Noch keine Zahlungsdaten','No payment details yet')); ?></span><?php endif;?></div></section><?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * WordPress operator console for plans / subscriptions
 * ---------------------------------------------------------------------- */
function pw_v500_admin_menu(){add_submenu_page('pure-work','Pure Work Abos & Zahlungen','Abos & Zahlungen','manage_options','pure-work-billing','pw_v500_admin_billing_page');}
add_action('admin_menu','pw_v500_admin_menu',30);
function pw_v500_admin_billing_page(){
    if(!current_user_can('manage_options'))return;$users=get_users(['role'=>'pw_agency','orderby'=>'registered','order'=>'ASC']);$claimed=count(pw_launch_promo_claimed_ids());$limit=max(0,(int)get_option('pw_launch_promo_limit',20));$months=max(1,(int)get_option('pw_launch_promo_months',6));?>
    <div class="wrap"><h1>Pure Work – Abos &amp; Zahlungen</h1><p>Tarife, kostenfreie Startplätze und Zahlungsstatus zentral verwalten.</p>
      <div style="display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:12px;max-width:1000px;margin:18px 0"><div class="card"><b><?php echo count($users); ?></b><p>Zeitarbeitsfirmen</p></div><div class="card"><b><?php echo min($claimed,$limit); ?>/<?php echo $limit; ?></b><p>kostenfreie Startplätze</p></div><div class="card"><b><?php echo $months; ?> Monate</b><p>kostenfreie Phase</p></div><div class="card"><b><?php echo pw_stripe_ready()?'✓':'–'; ?></b><p>Stripe <?php echo pw_stripe_ready()?'konfiguriert':'noch offen'; ?></p></div></div>
      <?php if(function_exists('pw_v502_admin_stripe_setup_card')) echo pw_v502_admin_stripe_setup_card(); ?>
      <table class="widefat striped"><thead><tr><th>Unternehmen</th><th>Tarif</th><th>Status</th><th>Kostenfrei bis</th><th>Stripe</th><th>Steuerung</th></tr></thead><tbody><?php if(!$users):?><tr><td colspan="6">Noch keine Zeitarbeitsfirmen.</td></tr><?php else:foreach($users as $u):$st=pw_subscription_state($u->ID);?><tr><td><strong><?php echo esc_html(pw_user_meta($u->ID,'pw_company',$u->display_name)); ?></strong><br><small><?php echo esc_html($u->user_email); ?></small></td><td><?php echo esc_html(pw_plan_public_label($st['plan'])); ?></td><td><strong><?php echo esc_html(pw_v500_subscription_status_label($st['status'])); ?></strong></td><td><?php echo $st['until']?esc_html(wp_date('d.m.Y',$st['until'])):'–'; ?></td><td><?php echo pw_user_meta($u->ID,'pw_stripe_customer_id','')?'✓ verbunden':'–'; ?></td><td><div style="display:flex;gap:4px;flex-wrap:wrap"><?php foreach(['basic'=>'Basic','professional'=>'Pro','enterprise'=>'Max'] as $plan=>$label):?><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_admin_subscription&user='.$u->ID.'&plan='.$plan.'&status='.$st['status']),'pw_v500_admin_subscription_'.$u->ID)); ?>"><?php echo esc_html($label); ?></a><?php endforeach;?><a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_admin_subscription&user='.$u->ID.'&plan='.$st['plan'].'&status=active'),'pw_v500_admin_subscription_'.$u->ID)); ?>">aktiv</a><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_admin_subscription&user='.$u->ID.'&plan='.$st['plan'].'&status=promo'),'pw_v500_admin_subscription_'.$u->ID)); ?>">+<?php echo $months; ?> Mon. frei</a><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_admin_subscription&user='.$u->ID.'&plan='.$st['plan'].'&status=payment_required'),'pw_v500_admin_subscription_'.$u->ID)); ?>">Zahlung nötig</a></div></td></tr><?php endforeach;endif;?></tbody></table>
      <p style="margin-top:20px"><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=pure-work&tab=settings')); ?>">Stripe, Preise &amp; Freiplätze konfigurieren</a></p>
    </div><?php
}
function pw_handle_v500_admin_subscription(){
    if(!current_user_can('manage_options'))wp_die('Keine Berechtigung.');$uid=(int)($_GET['user']??0);check_admin_referer('pw_v500_admin_subscription_'.$uid);if(!get_userdata($uid))wp_die('Benutzer fehlt.');$plan=sanitize_key($_GET['plan']??'professional');if(!in_array($plan,['basic','professional','enterprise'],true))$plan='professional';$status=sanitize_key($_GET['status']??'active');if(!in_array($status,['active','promo','payment_required','canceled'],true))$status='active';update_user_meta($uid,'pw_plan',$plan);update_user_meta($uid,'pw_subscription_status',$status);if($status==='promo'){update_user_meta($uid,'pw_launch_promo','1');update_user_meta($uid,'pw_promo_started_at',time());update_user_meta($uid,'pw_promo_until',strtotime('+'.max(1,(int)get_option('pw_launch_promo_months',6)).' months'));$claimed=pw_launch_promo_claimed_ids();if(!in_array($uid,$claimed,true)){$claimed[]=$uid;update_option('pw_launch_promo_claimed_users',$claimed,false);}}wp_safe_redirect(admin_url('admin.php?page=pure-work-billing&updated=1'));exit;
}
add_action('admin_post_pw_v500_admin_subscription','pw_handle_v500_admin_subscription');

/* -------------------------------------------------------------------------
 * Language polish and front-end helpers
 * ---------------------------------------------------------------------- */
function pw_v500_frontend_data(){
    if(!wp_script_is('pw-app','enqueued'))return;$data=[
        'lang'=>pw_current_lang(),
        'invoice'=>[
            'missing'=>pw_t('fehlt','missing'),'ready'=>pw_t('bereit','ready'),
            'fields'=>[
                'customer'=>pw_t('Kunde','Customer'),'customer_email'=>pw_t('Empfänger-E-Mail','Recipient email'),'customer_street'=>pw_t('Kundenstraße','Customer street'),'customer_zip'=>pw_t('Kunden-PLZ','Customer postal code'),'customer_city'=>pw_t('Kundenort','Customer city'),'service_from'=>pw_t('Leistungsbeginn','Service start'),'service_to'=>pw_t('Leistungsende','Service end'),'description'=>pw_t('Leistung','Service'),'hours'=>pw_t('Stunden','Hours'),'rate'=>pw_t('Verrechnungssatz','Bill rate')
            ]
        ],
        'ui'=> pw_current_lang()==='de' ? [
            'PURE BILLING'=>'PURE ABRECHNUNG','PURE CALCULATOR'=>'PURE KALKULATION','PURE FLOW'=>'PURE ABLAUF','PURE ASSIGNMENTS'=>'PURE EINSÄTZE','PURE AUTOMATIONS'=>'PURE AUTOMATIONEN','MY PLAN'=>'MEIN TARIF','Billing'=>'Abrechnung','Bill'=>'Abrechnen','Assignment board'=>'Einsatzboard','Automations'=>'Automationen'
        ] : [
            'PURE ABRECHNUNG'=>'PURE BILLING','PURE KALKULATION'=>'PURE CALCULATOR','PURE ABLAUF'=>'PURE FLOW','PURE EINSÄTZE'=>'PURE ASSIGNMENTS','PURE AUTOMATIONEN'=>'PURE AUTOMATIONS','MEIN TARIF'=>'MY PLAN','Abrechnung'=>'Billing','Abrechnen'=>'Bill','Einsatzboard'=>'Assignment board','Automationen'=>'Automations'
        ]
    ];wp_add_inline_script('pw-app','window.PW_V500='.wp_json_encode($data).';','before');
}
add_action('wp_enqueue_scripts','pw_v500_frontend_data',30);

/* -------------------------------------------------------------------------
 * Current shortcodes, registered last
 * ---------------------------------------------------------------------- */
function pw_v500_register_shortcodes(){
    remove_shortcode('pw_dashboard');add_shortcode('pw_dashboard','pw_shortcode_dashboard_v500');
    add_shortcode('pw_timesheets','pw_shortcode_timesheets');
}
add_action('init','pw_v500_register_shortcodes',900);

/* -------------------------------------------------------------------------
 * 5.0 billing UI – structured e-invoice workspace
 * ---------------------------------------------------------------------- */
function pw_v500_billing_profile($uid){
    $b=pw_v499_billing_profile($uid);$u=get_userdata($uid);$b['email']=pw_user_meta($uid,'pw_invoice_email',$u?$u->user_email:'');return $b;
}
function pw_handle_v500_billing_profile_save(){
    if(!is_user_logged_in()||pw_user_role()!=='agency'||!pw_can('invoicing'))wp_die('Keine Berechtigung.');check_admin_referer('pw_v500_billing_profile');$uid=get_current_user_id();$map=['company'=>'pw_invoice_company','street'=>'pw_invoice_street','zip'=>'pw_invoice_zip','city'=>'pw_invoice_city','vat_id'=>'pw_invoice_vat_id','tax_id'=>'pw_invoice_tax_id','iban'=>'pw_invoice_iban','bic'=>'pw_invoice_bic','email'=>'pw_invoice_email'];foreach($map as $field=>$meta){$val=$field==='email'?sanitize_email(wp_unslash($_POST[$field]??'')):sanitize_text_field(wp_unslash($_POST[$field]??''));update_user_meta($uid,$meta,$val);}update_user_meta($uid,'pw_invoice_payment_days',max(1,min(120,(int)($_POST['payment_days']??14))));wp_safe_redirect(pw_page_url('invoices',['profile_saved'=>1]));exit;
}
add_action('admin_post_pw_v500_billing_profile_save','pw_handle_v500_billing_profile_save');
function pw_v500_billing_profile_card($uid){$b=pw_v500_billing_profile($uid);$complete=$b['company']&&$b['street']&&$b['zip']&&$b['city']&&$b['email']&&$b['vat_id']&&$b['iban'];ob_start();?>
<section class="pw-card pw-v500-billing-profile"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('RECHNUNGSSTAMMDATEN','INVOICE MASTER DATA')); ?></span><h2><?php echo esc_html(pw_t('Einmal sauber hinterlegen','Set up once, use everywhere')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Diese Daten werden für Rechnungsansicht und XRechnung verwendet.','These details are used for invoice view and XRechnung.')); ?></p></div><span class="pw-badge <?php echo $complete?'success':'warning'; ?>"><?php echo esc_html($complete?pw_t('bereit','ready'):pw_t('ergänzen','complete')); ?></span></div><details <?php echo $complete?'':'open';?>><summary><?php echo pw_icon('building'); ?><span><?php echo esc_html(pw_t('Absender- & Zahlungsdaten bearbeiten','Edit sender & payment details')); ?></span><?php echo pw_icon('arrow'); ?></summary><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-form-grid two"><input type="hidden" name="action" value="pw_v500_billing_profile_save"><?php wp_nonce_field('pw_v500_billing_profile');?><label class="full"><?php echo esc_html(pw_t('Firma','Company')); ?><input name="company" required value="<?php echo esc_attr($b['company']); ?>"></label><label class="full"><?php echo esc_html(pw_t('Straße & Hausnummer','Street & number')); ?><input name="street" required value="<?php echo esc_attr($b['street']); ?>"></label><label><?php echo esc_html(pw_t('PLZ','Postal code')); ?><input name="zip" required value="<?php echo esc_attr($b['zip']); ?>"></label><label><?php echo esc_html(pw_t('Ort','City')); ?><input name="city" required value="<?php echo esc_attr($b['city']); ?>"></label><label><?php echo esc_html(pw_t('Rechnungs-E-Mail','Invoice email')); ?><input type="email" name="email" required value="<?php echo esc_attr($b['email']); ?>"></label><label><?php echo esc_html(pw_t('USt-IdNr.','VAT ID')); ?><input name="vat_id" required value="<?php echo esc_attr($b['vat_id']); ?>"></label><label><?php echo esc_html(pw_t('Steuernummer','Tax number')); ?><input name="tax_id" value="<?php echo esc_attr($b['tax_id']); ?>"></label><label><?php echo esc_html(pw_t('IBAN','IBAN')); ?><input name="iban" required value="<?php echo esc_attr($b['iban']); ?>"></label><label><?php echo esc_html(pw_t('BIC','BIC')); ?><input name="bic" value="<?php echo esc_attr($b['bic']); ?>"></label><label><?php echo esc_html(pw_t('Zahlungsziel in Tagen','Payment term in days')); ?><input type="number" min="1" max="120" name="payment_days" value="<?php echo (int)$b['payment_days']; ?>"></label><div class="full pw-form-actions"><button class="pw-btn primary small"><?php echo esc_html(pw_t('Stammdaten speichern','Save master data')); ?></button></div></form></details></section><?php return ob_get_clean();}

function pw_v500_invoice_prefill($uid,$sid=0,$edit=0){
    $b=pw_v500_billing_profile($uid);$d=['invoice_id'=>$edit,'submission_id'=>$sid,'timesheet_id'=>0,'customer'=>'','customer_email'=>'','customer_street'=>'','customer_zip'=>'','customer_city'=>'','customer_country'=>'DE','buyer_reference'=>pw_user_meta($uid,'pw_invoice_buyer_reference',''),'description'=>pw_t('Arbeitnehmerüberlassung / Personaleinsatz','Temporary staffing / personnel assignment'),'service_from'=>wp_date('Y-m-01'),'service_to'=>wp_date('Y-m-d'),'hours'=>'160','rate'=>sanitize_text_field(wp_unslash($_GET['rate']??'')),'vat'=>'19'];
    if($edit&&pw_v499_invoice_access($edit,$uid)){foreach(['submission_id','timesheet_id','customer','customer_email','customer_street','customer_zip','customer_city','customer_country','buyer_reference','description','service_from','service_to','hours','rate','vat'] as $k)$d[$k]=pw_v499_invoice_meta($edit,$k,$d[$k]);return $d;}
    if($sid&&pw_can_access_submission($sid)){$vid=(int)pw_meta($sid,'pw_vacancy_id',0);$v=pw_vacancy_fields($vid);$c=function_exists('pw_vacancy_client_contact')?pw_vacancy_client_contact($vid,$uid):[];$d['customer']=$c['company']??pw_vacancy_client_label($vid,$uid);$d['customer_email']=$c['email']??'';$d['customer_street']=$c['address']??'';$d['customer_zip']=$c['zip']??'';$d['customer_city']=$c['city']??'';$d['description']=$v['title']?:$d['description'];$d['service_from']=$v['start_date']?:$d['service_from'];$d['service_to']=$v['start_date']?:$d['service_to'];$d['rate']=preg_replace('/[^0-9,\.]/','',(string)pw_meta($sid,'pw_rate',''));$ts=(int)($_GET['timesheet']??0);if(!$ts)$ts=pw_v500_latest_approved_timesheet($sid);if($ts&&pw_v500_timesheet_meta($ts,'status')==='approved'){$d['timesheet_id']=$ts;$d['hours']=pw_v500_timesheet_meta($ts,'hours');$d['service_from']=pw_v500_timesheet_meta($ts,'period_from');$d['service_to']=pw_v500_timesheet_meta($ts,'period_to');}}
    return $d;
}
function pw_handle_v500_invoice_save(){
    if(!is_user_logged_in()||pw_user_role()!=='agency'||!pw_can('invoicing'))wp_die('Keine Berechtigung.');check_admin_referer('pw_v500_invoice_save');$uid=get_current_user_id();$edit=(int)($_POST['invoice_id']??0);if($edit&&!pw_v499_invoice_access($edit,$uid))wp_die('Kein Zugriff.');$sid=(int)($_POST['submission_id']??0);$timesheet_id=(int)($_POST['timesheet_id']??0);if(!$edit&&$timesheet_id){$linked=(int)pw_v500_timesheet_meta($timesheet_id,'invoice_id',0);if($linked&&pw_v499_invoice_access($linked,$uid)){wp_safe_redirect(pw_page_url('invoices',['view'=>$linked,'duplicate_prevented'=>1]));exit;}}
    $fields=['customer','customer_street','customer_zip','customer_city','customer_country','buyer_reference','description','service_from','service_to'];$vals=[];foreach($fields as $f)$vals[$f]=sanitize_text_field(wp_unslash($_POST[$f]??''));$vals['customer_email']=sanitize_email(wp_unslash($_POST['customer_email']??''));$hours=max(0,pw_v499_decimal($_POST['hours']??0));$rate=max(0,pw_v499_decimal($_POST['rate']??0));$vat=max(0,min(100,pw_v499_decimal($_POST['vat']??19)));if(!$vals['customer']||!$vals['description']||$hours<=0||$rate<=0){wp_safe_redirect(pw_page_url('invoices',['new'=>1,'error'=>'fields']));exit;}$net=round($hours*$rate,2);$tax=round($net*$vat/100,2);$gross=$net+$tax;$bp=pw_v500_billing_profile($uid);$no=$edit?pw_v499_invoice_meta($edit,'no'):pw_v499_invoice_no($uid);$date=$edit?pw_v499_invoice_meta($edit,'date',wp_date('Y-m-d')):wp_date('Y-m-d');$due=wp_date('Y-m-d',strtotime($date.' +'.max(1,(int)$bp['payment_days']).' days'));
    $id=$edit?:wp_insert_post(['post_type'=>'pw_invoice','post_status'=>'publish','post_author'=>$uid,'post_title'=>$no.' · '.$vals['customer']],true);if(is_wp_error($id))wp_die('Speichern fehlgeschlagen.');if($edit)wp_update_post(['ID'=>$id,'post_title'=>$no.' · '.$vals['customer']]);$all=array_merge($vals,['no'=>$no,'date'=>$date,'due'=>$due,'hours'=>$hours,'rate'=>$rate,'vat'=>$vat,'net'=>$net,'tax'=>$tax,'gross'=>$gross,'submission_id'=>$sid,'timesheet_id'=>$timesheet_id,'status'=>$edit?pw_v499_invoice_meta($edit,'status','draft'):'draft']);foreach($all as $k=>$v)update_post_meta($id,'pw_inv_'.$k,$v);delete_post_meta($id,'pw_inv_xml_enc');delete_post_meta($id,'pw_inv_xml_generated_at');if($timesheet_id&&pw_v500_timesheet_access($timesheet_id,$uid)&&pw_v500_timesheet_meta($timesheet_id,'status')==='approved')update_post_meta($timesheet_id,'pw_ts_invoice_id',$id);wp_safe_redirect(pw_page_url('invoices',['view'=>$id,'saved'=>1]));exit;
}
add_action('admin_post_pw_v500_invoice_save','pw_handle_v500_invoice_save');

function pw_v500_rate_calculator(){
    ob_start();?><section class="pw-card pw-v499-rate-calc pw-v500-rate-calc" id="calculator" data-pw-rate-calc><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE KALKULATION','PURE CALCULATOR')); ?></span><h2><?php echo esc_html(pw_t('Verrechnungssatz & Marge','Bill rate & margin')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Aus Lohnkosten wird ein nachvollziehbarer Ziel-Verrechnungssatz.','Turn wage costs into a transparent target bill rate.')); ?></p></div><?php echo pw_icon('calculator'); ?></div><div class="pw-v499-rate-grid"><label><?php echo esc_html(pw_t('Bruttolohn / Std.','Gross wage / hr')); ?><input type="number" min="0" step="0.01" value="16.50" data-rate-wage></label><label><?php echo esc_html(pw_t('Arbeitgeberfaktor','Employer factor')); ?><input type="number" min="1" step="0.01" value="1.75" data-rate-factor></label><label><?php echo esc_html(pw_t('Gemeinkosten / Std.','Overhead / hr')); ?><input type="number" min="0" step="0.01" value="3.50" data-rate-overhead></label><label><?php echo esc_html(pw_t('Zielmarge','Target margin')); ?> %<input type="number" min="0" max="80" step="0.5" value="18" data-rate-margin></label></div><div class="pw-v499-rate-result"><div><span><?php echo esc_html(pw_t('Kostenbasis','Cost base')); ?></span><b data-rate-cost>–</b></div><div class="primary"><span><?php echo esc_html(pw_t('Empfohlener Satz','Recommended rate')); ?></span><strong data-rate-bill data-rate-result>–</strong></div><div><span><?php echo esc_html(pw_t('Deckungsbeitrag','Contribution')); ?></span><b data-rate-contribution data-rate-profit>–</b></div></div><button type="button" class="pw-btn ghost small" data-pw-rate-to-invoice><?php echo pw_icon('arrow'); ?> <?php echo esc_html(pw_t('Satz in Rechnung übernehmen','Use rate in invoice')); ?></button></section><?php return ob_get_clean();
}

function pw_v500_invoice_form($uid,$sid=0,$edit=0){$d=pw_v500_invoice_prefill($uid,$sid,$edit);$bp=pw_v500_billing_profile($uid);ob_start();?>
<section class="pw-v500-invoice-compose"><div class="pw-v500-compose-main"><section class="pw-card pw-v500-invoice-form"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html($edit?pw_t('RECHNUNG BEARBEITEN','EDIT INVOICE'):pw_t('NEUE E-RECHNUNG','NEW E-INVOICE')); ?></span><h2><?php echo esc_html(pw_t('Rechnung mit Pure Assist vorbereiten','Prepare invoice with Pure Assist')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Aus Einsatz und freigegebenen Stunden werden Rechnung, XRechnung-XML und sicherer Versand.','Assignment and approved hours become invoice, XRechnung XML and secure delivery.')); ?></p></div><span class="pw-v500-xbadge">XRechnung 3.0.2</span></div><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-form-grid two" data-pw-einvoice-form data-sender-ready="<?php echo ($bp['street']&&$bp['vat_id']&&$bp['iban']&&$bp['email'])?'1':'0'; ?>"><input type="hidden" name="action" value="pw_v500_invoice_save"><input type="hidden" name="invoice_id" value="<?php echo (int)$edit; ?>"><input type="hidden" name="submission_id" value="<?php echo (int)$d['submission_id']; ?>"><input type="hidden" name="timesheet_id" value="<?php echo (int)$d['timesheet_id']; ?>"><?php wp_nonce_field('pw_v500_invoice_save');?><div class="full pw-v500-form-section"><span>01</span><div><b><?php echo esc_html(pw_t('Empfänger','Recipient')); ?></b><small><?php echo esc_html(pw_t('Strukturierte Daten statt Freitext-Adresse','Structured data instead of a free-text address')); ?></small></div></div><label class="full"><?php echo esc_html(pw_t('Kunde / Firma','Customer / company')); ?><input name="customer" data-invoice-field="customer" required value="<?php echo esc_attr($d['customer']); ?>"></label><label class="full"><?php echo esc_html(pw_t('Rechnungs-E-Mail des Kunden','Customer invoice email')); ?><input type="email" name="customer_email" data-invoice-field="customer_email" required value="<?php echo esc_attr($d['customer_email']); ?>"></label><label class="full"><?php echo esc_html(pw_t('Straße & Hausnummer','Street & number')); ?><input name="customer_street" data-invoice-field="customer_street" required value="<?php echo esc_attr($d['customer_street']); ?>"></label><label><?php echo esc_html(pw_t('PLZ','Postal code')); ?><input name="customer_zip" data-invoice-field="customer_zip" required value="<?php echo esc_attr($d['customer_zip']); ?>"></label><label><?php echo esc_html(pw_t('Ort','City')); ?><input name="customer_city" data-invoice-field="customer_city" required value="<?php echo esc_attr($d['customer_city']); ?>"></label><input type="hidden" name="customer_country" value="DE"><label class="full"><?php echo esc_html(pw_t('Bestellreferenz / Leitweg-ID (B2G)','Buyer reference / routing ID (B2G)')); ?><input name="buyer_reference" value="<?php echo esc_attr($d['buyer_reference']); ?>" placeholder="<?php echo esc_attr(pw_t('bei B2B optional','optional for B2B')); ?>"></label><div class="full pw-v500-form-section"><span>02</span><div><b><?php echo esc_html(pw_t('Leistung','Service')); ?></b><small><?php echo esc_html(pw_t('Zeitraum, Stunden und Verrechnungssatz','Period, hours and bill rate')); ?></small></div></div><label class="full"><?php echo esc_html(pw_t('Leistungsbeschreibung','Service description')); ?><input name="description" data-invoice-field="description" required value="<?php echo esc_attr($d['description']); ?>"></label><label><?php echo esc_html(pw_t('Leistungsbeginn','Service start')); ?><input type="date" name="service_from" data-invoice-field="service_from" required value="<?php echo esc_attr($d['service_from']); ?>"></label><label><?php echo esc_html(pw_t('Leistungsende','Service end')); ?><input type="date" name="service_to" data-invoice-field="service_to" required value="<?php echo esc_attr($d['service_to']); ?>"></label><label><?php echo esc_html(pw_t('Stunden','Hours')); ?><input type="number" name="hours" data-invoice-field="hours" min="0.01" step="0.01" required value="<?php echo esc_attr($d['hours']); ?>"></label><label><?php echo esc_html(pw_t('Verrechnungssatz netto','Net bill rate')); ?><input type="number" name="rate" data-invoice-field="rate" min="0.01" step="0.01" required value="<?php echo esc_attr(str_replace(',','.',$d['rate'])); ?>"></label><label><?php echo esc_html(pw_t('Umsatzsteuer %','VAT %')); ?><input type="number" name="vat" min="0" max="100" step="0.1" value="<?php echo esc_attr($d['vat']); ?>"></label><div class="full pw-v500-sender-check <?php echo ($bp['street']&&$bp['vat_id']&&$bp['iban']&&$bp['email'])?'ready':'warning'; ?>"><?php echo pw_icon(($bp['street']&&$bp['vat_id']&&$bp['iban']&&$bp['email'])?'check':'alert'); ?><div><b><?php echo esc_html(pw_t('Eigene Rechnungsdaten','Your invoice details')); ?></b><small><?php echo esc_html(($bp['street']&&$bp['vat_id']&&$bp['iban']&&$bp['email'])?pw_t('Stammdaten vollständig','Master data complete'):pw_t('Bitte oben in den Rechnungsstammdaten vervollständigen','Please complete the invoice master data above')); ?></small></div></div><div class="full pw-form-actions"><button class="pw-btn primary" type="submit"><?php echo pw_icon('receipt'); ?> <?php echo esc_html($edit?pw_t('Änderungen speichern','Save changes'):pw_t('Rechnung erstellen','Create invoice')); ?></button><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('invoices')); ?>"><?php echo esc_html(pw_t('Abbrechen','Cancel')); ?></a></div></form></section></div><?php echo pw_v500_invoice_assist_card($d);?></section><?php return ob_get_clean();}

function pw_v500_invoice_view($id,$uid){if(!pw_v499_invoice_access($id,$uid))return '<div class="pw-alert danger">'.esc_html(pw_t('Rechnung nicht gefunden.','Invoice not found.')).'</div>';$bp=pw_v500_billing_profile($uid);$status=pw_v499_invoice_meta($id,'status','draft');$labels=['draft'=>pw_t('Entwurf','Draft'),'sent'=>pw_t('Versendet','Sent'),'paid'=>pw_t('Bezahlt','Paid')];ob_start();?>
<div class="pw-page-head-inline pw-no-print"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('invoices')); ?>">← <?php echo esc_html(pw_t('Abrechnung','Billing')); ?></a><h2><?php echo esc_html(pw_v499_invoice_meta($id,'no')); ?></h2><p><?php echo esc_html(pw_v499_invoice_meta($id,'customer')); ?></p></div><div class="pw-head-actions"><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('invoices',['new'=>1,'edit'=>$id])); ?>"><?php echo esc_html(pw_t('Bearbeiten','Edit')); ?></a><button class="pw-btn ghost small" type="button" onclick="window.print()"><?php echo pw_icon('document'); ?> <?php echo esc_html(pw_t('Drucken / PDF','Print / PDF')); ?></button><?php if($status==='sent'):?><a class="pw-btn primary small" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v499_invoice_status&id='.$id.'&status=paid'),'pw_invoice_status_'.$id)); ?>"><?php echo esc_html(pw_t('Als bezahlt markieren','Mark paid')); ?></a><?php endif;?></div></div>
<?php echo pw_v500_invoice_actions($id,$uid); ?>
<article class="pw-v499-invoice-sheet pw-v500-invoice-sheet"><header><div><span class="pw-kicker"><?php echo esc_html(pw_t('RECHNUNG','INVOICE')); ?></span><h1><?php echo esc_html(pw_v499_invoice_meta($id,'no')); ?></h1></div><span class="pw-v499-invoice-status <?php echo esc_attr($status); ?>"><?php echo esc_html($labels[$status]??$status); ?></span></header><div class="pw-v499-invoice-parties"><div><small><?php echo esc_html(pw_t('VON','FROM')); ?></small><b><?php echo esc_html($bp['company']); ?></b><p><?php echo esc_html($bp['street']); ?><br><?php echo esc_html(trim($bp['zip'].' '.$bp['city'])); ?><br><?php echo esc_html($bp['email']); ?><br><?php echo esc_html(pw_t('USt-ID: ','VAT ID: ').$bp['vat_id']); ?></p></div><div><small><?php echo esc_html(pw_t('AN','TO')); ?></small><b><?php echo esc_html(pw_v499_invoice_meta($id,'customer')); ?></b><p><?php echo esc_html(pw_v499_invoice_meta($id,'customer_street')); ?><br><?php echo esc_html(trim(pw_v499_invoice_meta($id,'customer_zip').' '.pw_v499_invoice_meta($id,'customer_city'))); ?><br><?php echo esc_html(pw_v499_invoice_meta($id,'customer_email')); ?></p></div></div><div class="pw-v499-invoice-meta"><span><small><?php echo esc_html(pw_t('Rechnungsdatum','Invoice date')); ?></small><b><?php echo esc_html(pw_format_date(pw_v499_invoice_meta($id,'date'))); ?></b></span><span><small><?php echo esc_html(pw_t('Fällig','Due')); ?></small><b><?php echo esc_html(pw_format_date(pw_v499_invoice_meta($id,'due'))); ?></b></span><span><small><?php echo esc_html(pw_t('Leistungszeitraum','Service period')); ?></small><b><?php echo esc_html(pw_format_date(pw_v499_invoice_meta($id,'service_from'))); ?>–<?php echo esc_html(pw_format_date(pw_v499_invoice_meta($id,'service_to'))); ?></b></span></div><table><thead><tr><th><?php echo esc_html(pw_t('Leistung','Service')); ?></th><th><?php echo esc_html(pw_t('Stunden','Hours')); ?></th><th><?php echo esc_html(pw_t('Satz','Rate')); ?></th><th><?php echo esc_html(pw_t('Betrag','Amount')); ?></th></tr></thead><tbody><tr><td><?php echo esc_html(pw_v499_invoice_meta($id,'description')); ?></td><td><?php echo esc_html(pw_v499_invoice_meta($id,'hours')); ?></td><td><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'rate'))); ?></td><td><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'net'))); ?></td></tr></tbody></table><div class="pw-v499-invoice-total"><span><small><?php echo esc_html(pw_t('Netto','Net')); ?></small><b><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'net'))); ?></b></span><span><small><?php echo esc_html(pw_t('USt.','VAT')); ?> <?php echo esc_html(pw_v499_invoice_meta($id,'vat')); ?>%</small><b><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'tax'))); ?></b></span><span class="gross"><small><?php echo esc_html(pw_t('Gesamt','Total')); ?></small><b><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'gross'))); ?></b></span></div><div class="pw-v499-invoice-bank"><b><?php echo esc_html(pw_t('Zahlung','Payment')); ?></b><span>IBAN <?php echo esc_html($bp['iban']); ?><?php if($bp['bic']): ?> · BIC <?php echo esc_html($bp['bic']); ?><?php endif; ?></span></div><footer><?php echo esc_html(pw_t('Strukturierte E-Rechnung: XRechnung-XML kann separat erzeugt und über einen zeitlich begrenzten sicheren Link bereitgestellt werden.','Structured e-invoice: XRechnung XML can be generated separately and shared via a time-limited secure link.')); ?></footer></article><?php return ob_get_clean();}

function pw_v500_ready_timesheets_count($uid){
    $items=get_posts(['post_type'=>'pw_timesheet','post_status'=>'publish','posts_per_page'=>200,'fields'=>'ids','meta_query'=>[['key'=>'pw_ts_agency_id','value'=>(int)$uid],['key'=>'pw_ts_status','value'=>'approved']]]);$count=0;
    foreach($items as $id)if(!(int)pw_v500_timesheet_meta($id,'invoice_id',0))$count++;
    return $count;
}
function pw_shortcode_invoices_v500(){if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();ob_start();echo pw_portal_shell_start(pw_t('Abrechnung & E-Rechnung','Billing & e-invoicing'),pw_t('Freigegebene Stunden, Kalkulation und strukturierte Rechnung in einem Arbeitsbereich.','Approved hours, costing and structured invoicing in one workspace.'));echo pw_flash_messages();if(pw_user_role($uid)!=='agency'){echo '<section class="pw-card pw-empty"><h2>'.esc_html(pw_t('Abrechnung ist für Zeitarbeitsfirmen vorgesehen.','Billing is designed for staffing agencies.')).'</h2></section>';echo pw_portal_shell_end();return ob_get_clean();}if(!pw_can('invoicing',$uid)){echo pw_plan_gate('invoicing');echo pw_portal_shell_end();return ob_get_clean();}$view=(int)($_GET['view']??0);if($view){echo pw_v500_invoice_view($view,$uid);echo pw_portal_shell_end();return ob_get_clean();}$edit=(int)($_GET['edit']??0);if(!empty($_GET['new'])){echo pw_v500_billing_profile_card($uid);echo pw_v500_invoice_form($uid,(int)($_GET['submission']??0),$edit);echo pw_portal_shell_end();return ob_get_clean();}$invoices=get_posts(['post_type'=>'pw_invoice','post_status'=>'publish','author'=>$uid,'posts_per_page'=>100,'orderby'=>'date','order'=>'DESC']);$overdue=pw_v499_overdue_invoices($uid);?>
<section class="pw-v499-board-head pw-v500-billing-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE ABRECHNUNG','PURE BILLING')); ?></span><h1><?php echo esc_html(pw_t('Von freigegebenen Stunden zur E-Rechnung','From approved hours to e-invoice')); ?></h1><p><?php echo esc_html(pw_t('Rechnung vorbereiten, XRechnung erzeugen, sicher bereitstellen und Zahlung verfolgen.','Prepare invoice, generate XRechnung, deliver securely and track payment.')); ?></p></div><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('invoices',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?> <?php echo esc_html(pw_t('Neue Rechnung','New invoice')); ?></a></section>
<div class="pw-v500-billing-kpis"><?php echo pw_metric(count($invoices),pw_t('Rechnungen','invoices'),pw_t('gesamt','total'),'brand');echo pw_metric(count($overdue),pw_t('überfällig','overdue'),pw_t('Zahlungsziel erreicht','payment due'),$overdue?'warning':'');$approved=pw_v500_ready_timesheets_count($uid);echo pw_metric($approved,pw_t('Stundenfreigaben','approved timesheets'),pw_t('bereit zur Abrechnung','ready to bill'),'success');echo pw_metric(pw_can('einvoice',$uid)?'✓':'–',pw_t('E-Rechnung','e-invoicing'),pw_can('einvoice',$uid)?pw_t('XRechnung aktiviert','XRechnung enabled'):pw_t('nicht enthalten','not included'));?></div>
<?php echo pw_v500_billing_profile_card($uid); ?><div class="pw-v500-billing-layout"><section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('RECHNUNGEN','INVOICES')); ?></span><h2><?php echo esc_html(pw_t('Offen, versendet, bezahlt','Draft, sent, paid')); ?></h2></div></div><div class="pw-v499-invoice-list"><?php if(!$invoices):?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch keine Rechnung. Am schnellsten startest du aus einer freigegebenen Stundenmeldung.','No invoice yet. The fastest route starts from an approved timesheet.')); ?></p><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('timesheets')); ?>"><?php echo esc_html(pw_t('Stunden & Freigaben öffnen','Open hours & approvals')); ?></a></div><?php else:foreach($invoices as $inv):$st=pw_v499_invoice_meta($inv->ID,'status','draft');$labels=['draft'=>pw_t('Entwurf','Draft'),'sent'=>pw_t('Versendet','Sent'),'paid'=>pw_t('Bezahlt','Paid')];?><a href="<?php echo esc_url(pw_page_url('invoices',['view'=>$inv->ID])); ?>"><span class="pw-v499-invoice-icon"><?php echo pw_icon('receipt'); ?></span><div><b><?php echo esc_html(pw_v499_invoice_meta($inv->ID,'no')); ?> · <?php echo esc_html(pw_v499_invoice_meta($inv->ID,'customer')); ?></b><small><?php echo esc_html(pw_format_date(pw_v499_invoice_meta($inv->ID,'date'))); ?> · <?php echo esc_html($labels[$st]??$st); ?></small></div><strong><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($inv->ID,'gross'))); ?></strong><?php echo pw_icon('arrow'); ?></a><?php endforeach;endif;?></div></section><?php echo pw_v500_rate_calculator();?></div>
<?php echo pw_portal_shell_end();return ob_get_clean();}
function pw_v500_register_invoice_shortcode(){remove_shortcode('pw_invoices');add_shortcode('pw_invoices','pw_shortcode_invoices_v500');}
add_action('init','pw_v500_register_invoice_shortcode',950);


function pw_v500_language_attributes($output){
    $target=pw_current_lang()==='en'?'en-US':'de-DE';
    if(preg_match('/lang=("|\')[^"\']+("|\')/i',$output))return preg_replace('/lang=("|\')[^"\']+("|\')/i','lang="'.$target.'"',$output,1);
    return 'lang="'.$target.'" '.$output;
}
add_filter('language_attributes','pw_v500_language_attributes',20);
