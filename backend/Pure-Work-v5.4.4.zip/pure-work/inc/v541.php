<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.4.1 – usability & workflow bridge.
 *
 * Goals:
 * - same mental model for staffing agencies and clients
 * - calm dashboard: 4 numbers, 3 next actions, one visible workflow
 * - client vacancy creation gets the same guided quality as worker creation
 * - branded system mail and meaningful reminders
 * - no new navigation clutter
 */

function pw_v541_upgrade(){
    if(get_option('pw_version_541','')==='5.4.1') return;
    if(function_exists('pw_install_theme')) pw_install_theme();
    update_option('pw_version_541','5.4.1',false);
    update_option('pw_version','5.4.1',false);
    flush_rewrite_rules(false);
}
add_action('init','pw_v541_upgrade',4000);

function pw_v541_metric($value,$label,$hint,$icon='chart',$tone=''){
    return '<div class="pw541-metric '.esc_attr($tone).'"><span>'.pw_icon($icon).'</span><div><strong>'.esc_html((string)$value).'</strong><b>'.esc_html($label).'</b><small>'.esc_html($hint).'</small></div></div>';
}

function pw_v541_action_row($item,$index){
    $level=$item['level']??'brand';
    return '<a class="pw541-action '.esc_attr($level).'" href="'.esc_url($item['url']).'"><span class="pw541-action-no">'.sprintf('%02d',(int)$index).'</span><span class="pw541-action-icon">'.pw_icon($item['icon']??'arrow').'</span><div><b>'.esc_html($item['title']).'</b><small>'.esc_html($item['text']).'</small></div><em>'.esc_html($item['cta']).' '.pw_icon('arrow').'</em></a>';
}

function pw_v541_flow($role,$uid){
    if($role==='agency'){
        $s=pw_v498_agency_snapshot($uid);
        $steps=[
            ['briefcase',pw_t('Bedarf','Demand'),$s['open_jobs'],pw_page_url('vacancies')],
            ['users',pw_t('Profil','Profile'),$s['available'],pw_page_url('workers')],
            ['spark',pw_t('Zuordnung','Submission'),$s['submissions'],pw_page_url('matches')],
            ['message',pw_t('Abstimmung','Conversation'),$s['messages'],pw_page_url('messages')],
            ['calendar',pw_t('Einsatz','Assignment'),$s['accepted'],pw_page_url('assignments')],
        ];
    } else {
        $s=pw_v498_client_snapshot($uid);
        $steps=[
            ['briefcase',pw_t('Bedarf','Demand'),$s['open'],pw_page_url('vacancies')],
            ['users',pw_t('Profile','Profiles'),$s['new'],pw_page_url('matches')],
            ['check',pw_t('Entscheidung','Decision'),$s['short'],pw_page_url('matches')],
            ['message',pw_t('Abstimmung','Conversation'),$s['messages'],pw_page_url('messages')],
            ['calendar',pw_t('Einsatz','Assignment'),$s['accepted'],pw_page_url('assignments')],
        ];
    }
    ob_start(); ?>
    <section class="pw-card pw541-flow-card">
      <div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('GEMEINSAMER VORGANG','SHARED WORKFLOW')); ?></span><h2><?php echo esc_html(pw_t('Ein Prozess. Beide Seiten sehen den nächsten Schritt.','One process. Both sides see the next step.')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Bedarf, Profil, Entscheidung, Chat und Einsatz hängen direkt zusammen.','Demand, profile, decision, chat and assignment stay connected.')); ?></p></div></div>
      <div class="pw541-flow">
        <?php foreach($steps as $i=>$st): ?>
          <a href="<?php echo esc_url($st[3]); ?>"><span><?php echo pw_icon($st[0]); ?></span><div><small><?php echo sprintf('%02d',$i+1); ?></small><b><?php echo esc_html($st[1]); ?></b><em><?php echo (int)$st[2]; ?></em></div></a>
          <?php if($i<count($steps)-1): ?><i class="pw541-flow-arrow">→</i><?php endif; ?>
        <?php endforeach; ?>
      </div>
    </section><?php return ob_get_clean();
}

function pw_v541_quick_actions($role){
    if($role==='agency') $items=[
        ['plus',pw_t('Mitarbeiter anlegen','Add employee'),pw_page_url('workers',['new'=>1])],
        ['briefcase',pw_t('Ausschreibungen prüfen','Review jobs'),pw_page_url('vacancies')],
        ['handshake',pw_t('Meine Kunden','My customers'),pw_page_url('crm')],
        ['message',pw_t('Nachrichten','Messages'),pw_page_url('messages')],
    ]; else $items=[
        ['plus',pw_t('Personalbedarf anlegen','Create staffing need'),pw_page_url('vacancies',['new'=>1])],
        ['users',pw_t('Profile prüfen','Review profiles'),pw_page_url('matches')],
        ['message',pw_t('Nachrichten','Messages'),pw_page_url('messages')],
        ['calendar',pw_t('Einsätze','Assignments'),pw_page_url('assignments')],
    ];
    ob_start(); ?><section class="pw-card pw541-quick"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('SCHNELL STARTEN','QUICK START')); ?></span><h2><?php echo esc_html(pw_t('Direkt dahin, wo du arbeiten willst','Go straight to the task')); ?></h2></div></div><div class="pw541-quick-grid"><?php foreach($items as $it): ?><a href="<?php echo esc_url($it[2]); ?>"><span><?php echo pw_icon($it[0]); ?></span><b><?php echo esc_html($it[1]); ?></b><?php echo pw_icon('arrow'); ?></a><?php endforeach; ?></div></section><?php return ob_get_clean();
}

function pw_v541_dashboard(){
    if(!is_user_logged_in()) return pw_require_login_html();
    $uid=get_current_user_id(); $role=pw_user_role($uid); if(!in_array($role,['agency','client'],true)) return pw_shortcode_dashboard_v512();
    $u=wp_get_current_user(); $name=pw_user_meta($uid,'pw_contact',$u->display_name); $company=pw_user_meta($uid,'pw_company',$u->display_name);
    $actions=pw_v498_today_actions($uid,$role,3);
    ob_start();
    echo pw_portal_shell_start(pw_t('Start','Home'),$role==='agency'?pw_t('Disposition, Kunden und Einsätze – auf einen Blick.','Dispatch, customers and assignments at a glance.'):pw_t('Personalbedarf, Profile und Einsätze – auf einen Blick.','Staffing needs, profiles and assignments at a glance.'));
    echo pw_flash_messages();
    if(isset($_GET['panel'])&&$_GET['panel']==='notifications'){echo pw_dashboard_notifications_panel(); echo pw_portal_shell_end(); return ob_get_clean();}
    if(isset($_GET['panel'])&&$_GET['panel']==='insights' && function_exists('pw_v501_scale_insights')){echo pw_v501_scale_insights($uid);echo pw_portal_shell_end();return ob_get_clean();}
    $verify=pw_verification_state($uid);
    if(!$verify['ready']) echo '<div class="pw-onboarding-banner compact"><div>'.pw_icon('lock').'<div><span class="pw-kicker">'.esc_html(pw_t('VERIFIZIERUNG','VERIFICATION')).'</span><h3>'.esc_html(pw_t('Noch nicht vollständig freigeschaltet','Not fully unlocked yet')).'</h3><p>'.esc_html(pw_t('Schließe E-Mail-, Unternehmens- und gegebenenfalls AÜG-Prüfung ab.','Complete e-mail, company and, where applicable, AÜG verification.')).'</p></div></div><a class="pw-btn white small" href="'.esc_url(pw_page_url('account',['tab'=>'verification'])).'">'.esc_html(pw_t('Status öffnen','Open status')).'</a></div>';

    if($role==='agency'){
        $s=pw_v498_agency_snapshot($uid);
        echo '<section class="pw541-hero"><div><span class="pw-kicker">'.esc_html(pw_t('HEUTE','TODAY')).'</span><h1>'.esc_html(pw_t('Guten Tag','Hello')).', '.esc_html($name).'.</h1><p>'.esc_html(pw_t('Drei Dinge zuerst. Alles andere bleibt im Hintergrund, bis du es brauchst.','Three things first. Everything else stays in the background until you need it.')).'</p></div><div><a class="pw-btn primary" href="'.esc_url(pw_page_url('workers',['new'=>1])).'">'.pw_icon('plus').' '.esc_html(pw_t('Mitarbeiter anlegen','Add employee')).'</a><button type="button" class="pw-btn ghost" data-pw-copilot-open>'.pw_icon('spark').' Pure Assist</button></div></section>';
        echo '<div class="pw541-metrics">'.pw_v541_metric($s['available'],pw_t('sofort verfügbar','available now'),$s['workers'].' '.pw_t('Mitarbeiter im Pool','employees in pool'),'users','brand').pw_v541_metric($s['open_jobs'],pw_t('offene Ausschreibungen','open jobs'),pw_t('aktuell im Marktplatz','currently in marketplace'),'briefcase').pw_v541_metric($s['requested'],pw_t('Reaktion nötig','action needed'),pw_t('aktive Anfragen','active requests'),'bell',$s['requested']?'warning':'').pw_v541_metric($s['messages'],pw_t('ungelesen','unread'),pw_t('Nachrichten','messages'),'message',$s['messages']?'warning':'').'</div>';
    } else {
        $s=pw_v498_client_snapshot($uid);
        echo '<section class="pw541-hero client"><div><span class="pw-kicker">'.esc_html(pw_t('PERSONAL IM BLICK','WORKFORCE AT A GLANCE')).'</span><h1>'.esc_html($company).'</h1><p>'.esc_html(pw_t('Bedarf einstellen, Profile entscheiden und Einsätze steuern – ohne Umwege.','Create demand, decide on profiles and manage assignments without detours.')).'</p></div><div><a class="pw-btn primary" href="'.esc_url(pw_page_url('vacancies',['new'=>1])).'">'.pw_icon('plus').' '.esc_html(pw_t('Personalbedarf anlegen','Create staffing need')).'</a><button type="button" class="pw-btn ghost" data-pw-copilot-open>'.pw_icon('spark').' Pure Assist</button></div></section>';
        echo '<div class="pw541-metrics">'.pw_v541_metric($s['open'],pw_t('offene Bedarfe','open needs'),$s['jobs'].' '.pw_t('insgesamt','total'),'briefcase','brand').pw_v541_metric($s['new'],pw_t('neue Profile','new profiles'),pw_t('bitte entscheiden','please decide'),'users',$s['new']?'warning':'').pw_v541_metric($s['accepted'],pw_t('bestätigte Besetzungen','confirmed placements'),pw_t('laufend / geplant','active / planned'),'check','success').pw_v541_metric($s['messages'],pw_t('ungelesen','unread'),pw_t('Nachrichten','messages'),'message',$s['messages']?'warning':'').'</div>';
    }

    echo '<div class="pw541-main-grid"><section class="pw-card pw541-today"><div class="pw-card-head"><div><span class="pw-kicker">'.esc_html(pw_t('JETZT WICHTIG','IMPORTANT NOW')).'</span><h2>'.esc_html(pw_t('Deine nächsten Schritte','Your next steps')).'</h2><p class="pw-card-sub">'.esc_html(pw_t('Nach Dringlichkeit sortiert. Ein Klick bringt dich direkt zum Vorgang.','Sorted by urgency. One click takes you to the task.')).'</p></div><span class="pw-focus-count">'.count($actions).'</span></div><div class="pw541-actions">';
    foreach($actions as $i=>$it) echo pw_v541_action_row($it,$i+1);
    echo '</div></section>'.pw_v541_quick_actions($role).'</div>';
    echo pw_v541_flow($role,$uid);

    if($role==='agency'){
        echo '<div class="pw541-main-grid">'.pw_v498_compact_jobs($uid,5).pw_v48_activity_feed($uid,$role).'</div>';
        if(function_exists('pw_v511_power_center')) echo pw_v511_power_center($uid);
    } else {
        echo '<div class="pw541-main-grid">'.pw_v498_client_jobs($uid,5).pw_v48_activity_feed($uid,$role).'</div>';
    }
    echo pw_portal_shell_end(); return ob_get_clean();
}
function pw_v541_register_dashboard(){remove_shortcode('pw_dashboard');add_shortcode('pw_dashboard','pw_v541_dashboard');}
add_action('init','pw_v541_register_dashboard',5000);

/* -------------------------------------------------------------------------
 * Client vacancy wizard
 * ---------------------------------------------------------------------- */
function pw_vacancy_form_v541($vacancy_id=0){
    $v=$vacancy_id?pw_vacancy_fields($vacancy_id):['id'=>0,'title'=>'','description'=>'','qty'=>1,'location'=>'','start_date'=>'','duration'=>'','hours'=>'','shift'=>'','industry'=>'','must_quals'=>[],'nice_quals'=>[],'language'=>'','driver'=>'0','rate_max'=>'','deadline'=>'','status'=>'open','public_id'=>'','partner_code'=>'','target_mode'=>'all','target_agencies'=>[]];
    if($vacancy_id && (int)get_post_field('post_author',$vacancy_id)!==get_current_user_id() && !current_user_can('manage_options')) return '<div class="pw-alert danger">'.esc_html(pw_t('Kein Zugriff.','No access.')).'</div>';
    $agencies=get_users(['role'=>'pw_agency','orderby'=>'display_name']);
    ob_start(); ?>
    <div class="pw541-vacancy" data-pw541-vacancy>
      <div class="pw541-vacancy-head"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('vacancies')); ?>">← <?php echo esc_html(pw_t('Zurück','Back')); ?></a><span class="pw-kicker"><?php echo esc_html($vacancy_id?pw_t('BEDARF BEARBEITEN','EDIT DEMAND'):pw_t('NEUER PERSONALBEDARF','NEW STAFFING NEED')); ?></span><h2><?php echo esc_html($vacancy_id?pw_t('Bedarf aktualisieren','Update staffing need'):pw_t('In drei Schritten veröffentlichen','Publish in three steps')); ?></h2><p><?php echo esc_html(pw_t('Nur das Nötige zuerst. Pure Work baut daraus automatisch eine klare Anfrage für passende Zeitarbeitsfirmen.','Start with the essentials. Pure Work turns it into a clear request for matching staffing agencies.')); ?></p></div></div>
      <div class="pw541-template-row" data-pw541-presets>
        <button type="button" data-preset="lager"><?php echo pw_icon('briefcase'); ?><span><b><?php echo esc_html(pw_t('Lager & Logistik','Warehouse & logistics')); ?></b><small><?php echo esc_html(pw_t('Schnell vorbelegen','Quick prefill')); ?></small></span></button>
        <button type="button" data-preset="produktion"><?php echo pw_icon('settings'); ?><span><b><?php echo esc_html(pw_t('Produktion','Production')); ?></b><small><?php echo esc_html(pw_t('Schnell vorbelegen','Quick prefill')); ?></small></span></button>
        <button type="button" data-preset="technik"><?php echo pw_icon('spark'); ?><span><b><?php echo esc_html(pw_t('Technik','Technical')); ?></b><small><?php echo esc_html(pw_t('Schnell vorbelegen','Quick prefill')); ?></small></span></button>
        <button type="button" data-preset="office"><?php echo pw_icon('document'); ?><span><b><?php echo esc_html(pw_t('Kaufmännisch','Commercial')); ?></b><small><?php echo esc_html(pw_t('Schnell vorbelegen','Quick prefill')); ?></small></span></button>
      </div>
      <ol class="pw541-steps"><li class="active" data-step-tab="1"><i>1</i><span><b><?php echo esc_html(pw_t('Bedarf','Demand')); ?></b><small><?php echo esc_html(pw_t('Wer, wo, wann?','Who, where, when?')); ?></small></span></li><li data-step-tab="2"><i>2</i><span><b><?php echo esc_html(pw_t('Anforderungen','Requirements')); ?></b><small><?php echo esc_html(pw_t('Was muss passen?','What must fit?')); ?></small></span></li><li data-step-tab="3"><i>3</i><span><b><?php echo esc_html(pw_t('Veröffentlichen','Publish')); ?></b><small><?php echo esc_html(pw_t('Zielgruppe & Frist','Audience & deadline')); ?></small></span></li></ol>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" data-pw541-vacancy-form><input type="hidden" name="action" value="pw_vacancy_save"><input type="hidden" name="vacancy_id" value="<?php echo (int)$v['id']; ?>"><?php wp_nonce_field('pw_vacancy_save'); ?>
        <div class="pw541-vacancy-body"><div class="pw541-vacancy-main">
          <section class="pw-card pw541-step active" data-step="1"><div class="pw541-step-head"><span>01</span><div><h3><?php echo esc_html(pw_t('Was wird gebraucht?','What do you need?')); ?></h3><p><?php echo esc_html(pw_t('Diese vier Angaben reichen für den Start.','These four details are enough to start.')); ?></p></div></div><div class="pw-form-grid two"><label class="full"><?php echo esc_html(pw_t('Tätigkeit / Berufsbezeichnung','Role / job title')); ?><input name="title" list="pw-roles" required value="<?php echo esc_attr($v['title']); ?>" data-v541-preview="title" placeholder="<?php echo esc_attr(pw_t('z. B. Lagerhelfer','e.g. warehouse worker')); ?>"></label><label><?php echo esc_html(pw_t('Anzahl','Quantity')); ?><input type="number" min="1" name="qty" required value="<?php echo esc_attr($v['qty']); ?>" data-v541-preview="qty"></label><label><?php echo esc_html(pw_t('Einsatzort','Location')); ?><input name="location" list="pw-locations" required value="<?php echo esc_attr($v['location']); ?>" data-v541-preview="location" placeholder="68161 Mannheim"></label><label><?php echo esc_html(pw_t('Start','Start')); ?><input type="date" name="start_date" value="<?php echo esc_attr($v['start_date']); ?>" data-v541-preview="start"></label><label><?php echo esc_html(pw_t('Dauer','Duration')); ?><input name="duration" value="<?php echo esc_attr($v['duration']); ?>" data-v541-preview="duration" placeholder="<?php echo esc_attr(pw_t('z. B. 3 Monate','e.g. 3 months')); ?>"></label><label><?php echo esc_html(pw_t('Wochenstunden','Hours / week')); ?><input name="hours" value="<?php echo esc_attr($v['hours']); ?>" placeholder="35"></label><label><?php echo esc_html(pw_t('Schicht','Shift')); ?><input name="shift" list="pw-shifts" value="<?php echo esc_attr($v['shift']); ?>"></label><label><?php echo esc_html(pw_t('Branche','Industry')); ?><input name="industry" list="pw-industries" value="<?php echo esc_attr($v['industry']); ?>"></label></div></section>
          <section class="pw-card pw541-step" data-step="2"><div class="pw541-step-head"><span>02</span><div><h3><?php echo esc_html(pw_t('Was ist wirklich wichtig?','What really matters?')); ?></h3><p><?php echo esc_html(pw_t('Muss-Kriterien zuerst. Alles andere ist optional.','Must-have criteria first. Everything else is optional.')); ?></p></div></div><div class="pw-form-grid two"><label class="full pw-smart-description-field"><span class="pw-label-row"><span><?php echo esc_html(pw_t('Tätigkeitsbeschreibung','Job description')); ?></span><button type="button" class="pw-assist-button" data-pw-smart-description><?php echo pw_icon('spark'); ?> Pure Assist</button></span><textarea name="description" rows="5" placeholder="<?php echo esc_attr(pw_t('Aufgaben, Arbeitsumfeld, Besonderheiten…','Tasks, work environment, special details…')); ?>"><?php echo esc_textarea($v['description']); ?></textarea></label><label><?php echo esc_html(pw_t('Muss-Qualifikationen','Required qualifications')); ?><input name="must_quals" list="pw-qualifications" value="<?php echo esc_attr(pw_list_string($v['must_quals'])); ?>"></label><label><?php echo esc_html(pw_t('Kann-Qualifikationen','Nice-to-have qualifications')); ?><input name="nice_quals" list="pw-qualifications" value="<?php echo esc_attr(pw_list_string($v['nice_quals'])); ?>"></label><label><?php echo esc_html(pw_t('Sprachkenntnisse','Language skills')); ?><input name="language" list="pw-languages" value="<?php echo esc_attr($v['language']); ?>"></label><label class="pw-toggle-label"><input type="checkbox" name="driver" value="1" <?php checked($v['driver'],'1'); ?>><span></span><?php echo esc_html(pw_t('Führerschein erforderlich','Driving licence required')); ?></label><label><?php echo esc_html(pw_t('Max. Verrechnungssatz (optional)','Max. charge rate (optional)')); ?><input name="rate_max" value="<?php echo esc_attr($v['rate_max']); ?>" placeholder="31,50 €"></label></div></section>
          <section class="pw-card pw541-step" data-step="3"><div class="pw541-step-head"><span>03</span><div><h3><?php echo esc_html(pw_t('Wer soll den Bedarf sehen?','Who should see the demand?')); ?></h3><p><?php echo esc_html(pw_t('Standard: alle passenden, geprüften Personaldienstleister.','Default: all matching verified staffing agencies.')); ?></p></div></div><div class="pw-form-grid two"><label><?php echo esc_html(pw_t('Frist für Profilabgabe','Profile submission deadline')); ?><input type="date" name="deadline" value="<?php echo esc_attr($v['deadline']); ?>"></label><label><?php echo esc_html(pw_t('Status','Status')); ?><select name="status"><option value="open" <?php selected($v['status'],'open'); ?>><?php echo esc_html(pw_t('Offen','Open')); ?></option><option value="paused" <?php selected($v['status'],'paused'); ?>><?php echo esc_html(pw_t('Pausiert','Paused')); ?></option><option value="filled" <?php selected($v['status'],'filled'); ?>><?php echo esc_html(pw_t('Besetzt','Filled')); ?></option></select></label><label class="full"><?php echo esc_html(pw_t('Sichtbarkeit','Visibility')); ?><select name="target_mode" class="pw-target-mode"><option value="all" <?php selected($v['target_mode'],'all'); ?>><?php echo esc_html(pw_t('Alle passenden Personaldienstleister','All matching staffing agencies')); ?></option><option value="favorites" <?php selected($v['target_mode'],'favorites'); ?>><?php echo esc_html(pw_t('Nur meine Favoriten','My favourites only')); ?></option><option value="selected" <?php selected($v['target_mode'],'selected'); ?>><?php echo esc_html(pw_t('Gezielt ausgewählte','Selected agencies')); ?></option></select></label><div class="full pw-target-agencies"><span class="pw-field-label"><?php echo esc_html(pw_t('Ausgewählte Personaldienstleister','Selected staffing agencies')); ?></span><div class="pw-checkbox-grid"><?php foreach($agencies as $a): if(!pw_account_active($a->ID))continue; ?><label class="pw-choice"><input type="checkbox" name="target_agencies[]" value="<?php echo (int)$a->ID; ?>" <?php checked(in_array($a->ID,(array)$v['target_agencies'],true)); ?>><span><b><?php echo esc_html(pw_company_alias($a->ID)); ?></b><small><?php echo esc_html(pw_user_meta($a->ID,'pw_city','')); ?> · <?php echo get_user_meta($a->ID,'pw_aug_verified',true)?esc_html(pw_t('AÜG geprüft','AÜG verified')):esc_html(pw_t('in Prüfung','under review')); ?></small></span></label><?php endforeach; ?></div></div></div></section>
        </div><aside class="pw541-vacancy-preview"><div class="pw541-preview-inner"><span class="pw-kicker"><?php echo esc_html(pw_t('SO SEHEN ES PARTNER','WHAT PARTNERS SEE')); ?></span><div class="pw541-demand-card"><span class="pw-job-id">LIVE</span><h3 data-v541-out="title"><?php echo esc_html($v['title']?:pw_t('Tätigkeit fehlt noch','Role still missing')); ?></h3><div><span><?php echo pw_icon('map'); ?><b data-v541-out="location"><?php echo esc_html($v['location']?:'—'); ?></b></span><span><?php echo pw_icon('users'); ?><b><em data-v541-out="qty"><?php echo (int)($v['qty']?:1); ?></em>×</b></span><span><?php echo pw_icon('calendar'); ?><b data-v541-out="start"><?php echo esc_html($v['start_date']?pw_format_date($v['start_date']):pw_t('offen','open')); ?></b></span></div><p data-v541-out="duration"><?php echo esc_html($v['duration']?:pw_t('Dauer noch offen','Duration open')); ?></p></div><div class="pw541-preview-note"><?php echo pw_icon('spark'); ?><p><b><?php echo esc_html(pw_t('Besseres Matching','Better matching')); ?></b><span><?php echo esc_html(pw_t('Je klarer Tätigkeit, Ort und Muss-Kriterien sind, desto weniger unpassende Profile bekommst du.','Clear role, location and must-haves mean fewer irrelevant profiles.')); ?></span></p></div></div></aside></div>
        <div class="pw541-wizard-nav"><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><?php echo esc_html(pw_t('Abbrechen','Cancel')); ?></a><div><button type="button" class="pw-btn ghost" data-v541-back hidden><?php echo esc_html(pw_t('Zurück','Back')); ?></button><button type="button" class="pw-btn primary" data-v541-next><?php echo esc_html(pw_t('Weiter','Next')); ?> <?php echo pw_icon('arrow'); ?></button><button type="submit" class="pw-btn primary" data-v541-save hidden><?php echo pw_icon('check'); ?> <?php echo esc_html($vacancy_id?pw_t('Änderungen speichern','Save changes'):pw_t('Personalbedarf veröffentlichen','Publish staffing need')); ?></button></div></div>
      </form>
    </div><?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Useful reminders – once per day, not mail spam.
 * ---------------------------------------------------------------------- */
function pw_v541_daily_reminders(){
    $day=wp_date('Y-m-d');
    foreach(get_users(['role'=>'pw_client','fields'=>'ID']) as $uid){
        $uid=(int)$uid; if(pw_user_meta($uid,'pw_v541_decision_reminder','')===$day) continue;
        $subs=pw_client_submissions($uid); $waiting=[];
        foreach($subs as $s){$st=pw_meta($s->ID,'pw_status','submitted');$age=(time()-get_post_time('U',true,$s))/HOUR_IN_SECONDS;if(in_array($st,['submitted','viewed'],true)&&$age>=24)$waiting[]=$s;}
        if($waiting){$u=get_userdata($uid);$n=count($waiting);$title=sprintf(pw_t('%d Profile warten auf deine Entscheidung','%d profiles are waiting for your decision'),$n);pw_create_notice($uid,$title,pw_t('Eine schnelle Entscheidung hilft deinem Personaldienstleister bei der Einsatzplanung.','A quick decision helps your staffing partner plan the assignment.'),pw_page_url('matches'));if($u)pw_send_mail($u->user_email,'Pure Work – '.$title,$title,pw_t('In deinem Pure Work Konto warten neue Mitarbeiterprofile länger als 24 Stunden auf eine Entscheidung. Prüfe die Profile kurz und entscheide: annehmen, zurückstellen oder ablehnen.','Employee profiles in your Pure Work account have been waiting for a decision for more than 24 hours. Review them and decide: accept, hold or reject.'),pw_t('Profile prüfen','Review profiles'),pw_page_url('matches'));update_user_meta($uid,'pw_v541_decision_reminder',$day);}
    }
}
add_action('pw_daily_digest_event','pw_v541_daily_reminders',60);
