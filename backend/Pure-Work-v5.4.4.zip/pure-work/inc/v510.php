<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.1.0 – Product maturity / UX reset.
 *
 * Principles:
 * - one obvious next step per screen
 * - core workflow is complete on Basic
 * - Pro sells time savings; Max sells growth/steering
 * - no new navigation clutter for features that belong inside an existing flow
 * - chat updates without a page refresh
 */

function pw_v510_upgrade(){
    if(get_option('pw_version_510','')==='5.1.0') return;
    if(function_exists('pw_install_theme')) pw_install_theme();
    update_option('pw_version_510','5.1.0',false);
    update_option('pw_version','5.1.0',false);
    flush_rewrite_rules(false);
}
add_action('init','pw_v510_upgrade',1600);

/* -------------------------------------------------------------------------
 * Small UI helpers
 * ---------------------------------------------------------------------- */
function pw_v510_status_icon($level){
    return $level==='danger'?'alert':($level==='warning'?'clock':($level==='success'?'check':'arrow'));
}

function pw_v510_focus_list($uid,$role,$limit=3){
    $items=function_exists('pw_v498_today_actions')?pw_v498_today_actions($uid,$role,8):[];
    // v5.1 only shows what requires an action. Generic discovery cards come last.
    usort($items,function($a,$b){
        $rank=['danger'=>0,'warning'=>1,'success'=>2,'info'=>3,'brand'=>4];
        return ($rank[$a['level']]??5)<=>($rank[$b['level']]??5);
    });
    return array_slice($items,0,$limit);
}

function pw_v510_focus_card($item,$number){
    $level=$item['level']??'brand';
    ob_start(); ?>
    <a class="pw-v510-focus-item <?php echo esc_attr($level); ?>" href="<?php echo esc_url($item['url']); ?>">
      <span class="pw-v510-focus-no"><?php echo sprintf('%02d',(int)$number); ?></span>
      <span class="pw-v510-focus-icon"><?php echo pw_icon($item['icon']??pw_v510_status_icon($level)); ?></span>
      <div><b><?php echo esc_html($item['title']); ?></b><p><?php echo esc_html($item['text']); ?></p></div>
      <em><?php echo esc_html($item['cta']); ?> <?php echo pw_icon('arrow'); ?></em>
    </a><?php return ob_get_clean();
}

function pw_v510_workflow_strip($uid,$role){
    if($role==='agency'){
        $steps=[
            ['vacancies','briefcase',pw_t('Bedarf finden','Find demand'),pw_t('Offene Ausschreibungen','Open jobs')],
            ['workers','users',pw_t('Profil zuordnen','Match profile'),pw_t('Mitarbeiter auswählen','Choose employee')],
            ['messages','message',pw_t('Abstimmen','Coordinate'),pw_t('Chat & Konditionen','Chat & terms')],
            ['assignments','calendar',pw_t('Einsatz steuern','Run assignment'),pw_t('Start & Stunden','Start & hours')],
        ];
    } else {
        $steps=[
            ['vacancies','plus',pw_t('Bedarf einstellen','Create demand'),pw_t('Was wird gebraucht?','What is needed?')],
            ['matches','users',pw_t('Profile prüfen','Review profiles'),pw_t('Annehmen oder ablehnen','Accept or reject')],
            ['messages','message',pw_t('Abstimmen','Coordinate'),pw_t('Start & Konditionen','Start & terms')],
            ['assignments','calendar',pw_t('Einsatz verfolgen','Track assignment'),pw_t('Stunden freigeben','Approve hours')],
        ];
    }
    ob_start(); ?><section class="pw-card pw-v510-flow"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('DEIN ABLAUF','YOUR WORKFLOW')); ?></span><h2><?php echo esc_html(pw_t('Vier Schritte. Kein Suchen.','Four steps. No hunting.')); ?></h2></div></div><div class="pw-v510-flow-row"><?php foreach($steps as $i=>$s): ?><a href="<?php echo esc_url(pw_page_url($s[0])); ?>"><span><?php echo pw_icon($s[1]); ?></span><div><small><?php echo sprintf('%02d',$i+1); ?></small><b><?php echo esc_html($s[2]); ?></b><em><?php echo esc_html($s[3]); ?></em></div><?php echo pw_icon('arrow'); ?></a><?php endforeach; ?></div></section><?php return ob_get_clean();
}

function pw_v510_plan_value_card($uid){
    $plan=pw_current_plan($uid); if($plan==='client'||$plan==='') return '';
    if($plan==='basic'){
        $title=pw_t('Pro spart dir die Handarbeit','Pro removes manual work');
        $items=[[pw_t('CV-Assistent','CV assistant'),'document'],[pw_t('Smart-Matching','Smart matching'),'spark'],[pw_t('Automationen','Automations'),'clock'],[pw_t('Kalkulation & Marge','Costing & margin'),'calculator']];
        $cta=pw_t('Pro ansehen','View Pro');
    } elseif($plan==='professional'){
        $title=pw_t('Max macht Vertrieb & Steuerung stärker','Max strengthens sales & steering');
        $items=[[pw_t('Qualitäts-Leads','Quality leads'),'target'],[pw_t('Performance','Performance'),'chart'],[pw_t('Kapazitätsvorschau','Capacity forecast'),'calendar'],[pw_t('Kundentempo','Client response'),'clock']];
        $cta=pw_t('Max ansehen','View Max');
    } else {
        $title=pw_t('Max ist vollständig freigeschaltet','Max is fully unlocked');
        $items=[[pw_t('Wachstum','Growth'),'target'],[pw_t('Performance','Performance'),'chart'],[pw_t('Automationen','Automations'),'spark'],[pw_t('Kapazität','Capacity'),'users']];
        $cta=pw_t('Tarif verwalten','Manage plan');
    }
    ob_start(); ?><section class="pw-card pw-v510-plan-value"><div><span class="pw-kicker"><?php echo esc_html(pw_t('DEIN TARIF','YOUR PLAN')); ?></span><h2><?php echo esc_html($title); ?></h2><div class="pw-v510-plan-benefits"><?php foreach($items as $it): ?><span><?php echo pw_icon($it[1]); ?><b><?php echo esc_html($it[0]); ?></b></span><?php endforeach; ?></div></div><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('account',['tab'=>'billing'])); ?>"><?php echo esc_html($cta); ?> <?php echo pw_icon('arrow'); ?></a></section><?php return ob_get_clean();
}


/* Guided setup appears only while the workflow is still new. It disappears by itself. */
function pw_v510_getting_started($uid,$role){
    if($role==='agency'){
        $workers=count(get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']));
        $customers=count(pw_crm_get_leads($uid,[]));
        $subs=count(get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_agency_id','value'=>$uid]]]));
        $steps=[
          [$workers>0,'users',pw_t('Ersten Mitarbeiter anlegen','Add your first employee'),pw_page_url('workers',['new'=>1])],
          [$customers>0,'handshake',pw_t('Ersten Kunden speichern','Save your first customer'),pw_page_url('crm',['new'=>1])],
          [$subs>0,'spark',pw_t('Erstes Profil zuordnen','Submit your first profile'),pw_page_url('vacancies')],
        ];
    }else{
        $vac=count(get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']));
        $subs=[];foreach(get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']) as $vid){$subs=array_merge($subs,get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_key'=>'pw_vacancy_id','meta_value'=>$vid]));}
        $accepted=0;foreach($subs as $sid)if(in_array(pw_meta($sid,'pw_status','submitted'),['accepted','identity_released','confirmed','planned'],true))$accepted++;
        $steps=[
          [$vac>0,'briefcase',pw_t('Ersten Personalbedarf anlegen','Create your first staffing request'),pw_page_url('vacancies',['new'=>1])],
          [count($subs)>0,'users',pw_t('Erstes Profil prüfen','Review your first profile'),pw_page_url('matches')],
          [$accepted>0,'message',pw_t('Erste Zusammenarbeit starten','Start your first collaboration'),pw_page_url('matches')],
        ];
    }
    $done=count(array_filter(array_column($steps,0)));if($done===count($steps))return '';
    ob_start(); ?><section class="pw-card pw-v510-setup"><div class="pw-v510-setup-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('ERSTE SCHRITTE','GETTING STARTED')); ?></span><h2><?php echo esc_html(pw_t('In wenigen Minuten startklar','Ready in a few minutes')); ?></h2><p><?php echo esc_html(pw_t('Diese Hilfe verschwindet automatisch, sobald die Grundlagen erledigt sind.','This guide disappears automatically once the basics are done.')); ?></p></div><strong><?php echo $done; ?>/<?php echo count($steps); ?></strong></div><div class="pw-v510-setup-steps"><?php foreach($steps as $i=>$st): ?><a class="<?php echo $st[0]?'done':''; ?>" href="<?php echo esc_url($st[3]); ?>"><span><?php echo $st[0]?pw_icon('check'):pw_icon($st[1]); ?></span><div><small><?php echo sprintf('%02d',$i+1); ?></small><b><?php echo esc_html($st[2]); ?></b></div><?php if(!$st[0])echo pw_icon('arrow'); ?></a><?php endforeach; ?></div></section><?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Dashboard 5.1 – deliberately smaller
 * ---------------------------------------------------------------------- */
function pw_v510_dashboard_agency($uid){
    $user=wp_get_current_user();$name=pw_user_meta($uid,'pw_contact',$user->display_name);$s=pw_v498_agency_snapshot($uid);$focus=pw_v510_focus_list($uid,'agency',3);$plan=pw_current_plan($uid);
    ob_start();
    echo pw_portal_shell_start(pw_t('Start','Home'),pw_t('Die nächsten Schritte – nicht die nächste Statistik.','Next steps, not another wall of statistics.'));echo pw_flash_messages();
    if(isset($_GET['panel'])&&$_GET['panel']==='notifications'){echo pw_dashboard_notifications_panel();echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['panel'])&&$_GET['panel']==='insights'){
        echo pw_can('advanced_insights',$uid)?(function_exists('pw_v501_scale_insights')?pw_v501_scale_insights($uid):pw_v498_scale_insights($uid)):pw_plan_gate('advanced_insights');
        echo pw_portal_shell_end();return ob_get_clean();
    }
    ?>
    <section class="pw-v510-hero"><div><span class="pw-kicker"><?php echo esc_html(pw_t('HEUTE IN PURE WORK','TODAY IN PURE WORK')); ?></span><h1><?php echo esc_html(pw_dashboard_greeting().', '.$name); ?>.</h1><p><?php echo esc_html(pw_t('Du musst nicht wissen, wo eine Funktion liegt. Starte mit dem nächsten Schritt – Pure Work führt dich durch den Prozess.','You do not need to know where a feature lives. Start with the next step and Pure Work guides you through the process.')); ?></p></div><div class="pw-v510-hero-actions"><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><?php echo pw_icon('briefcase'); ?> <?php echo esc_html(pw_t('Ausschreibungen öffnen','Open jobs')); ?></a><button class="pw-btn ghost" type="button" data-pw-copilot-open><?php echo pw_icon('spark'); ?> Pure Assist</button></div></section>
    <div class="pw-v510-statusbar"><a href="<?php echo esc_url(pw_page_url('workers')); ?>"><b><?php echo (int)$s['available']; ?></b><span><?php echo esc_html(pw_t('verfügbar','available')); ?></span></a><a href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><b><?php echo (int)$s['open_jobs']; ?></b><span><?php echo esc_html(pw_t('offene Bedarfe','open needs')); ?></span></a><a href="<?php echo esc_url(pw_page_url('crm')); ?>"><b><?php echo (int)$s['crm']['due']; ?></b><span><?php echo esc_html(pw_t('Wiedervorlagen','follow-ups')); ?></span></a><a href="<?php echo esc_url(pw_page_url('messages')); ?>"><b><?php echo (int)$s['messages']; ?></b><span><?php echo esc_html(pw_t('ungelesen','unread')); ?></span></a></div>
    <?php echo pw_v510_getting_started($uid,'agency'); ?>
    <section class="pw-card pw-v510-focus"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('JETZT','NOW')); ?></span><h2><?php echo esc_html(pw_t('Das solltest du als Nächstes tun','Do this next')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Maximal drei Punkte. Wenn etwas erledigt ist, rückt der nächste Schritt nach.','A maximum of three items. When one is done, the next moves up.')); ?></p></div></div><div class="pw-v510-focus-list"><?php if(!$focus): ?><div class="pw-empty compact"><?php echo pw_icon('check'); ?><p><?php echo esc_html(pw_t('Alles Wichtige ist erledigt.','Everything important is done.')); ?></p></div><?php else: foreach($focus as $i=>$item) echo pw_v510_focus_card($item,$i+1); endif; ?></div></section>
    <?php echo pw_v510_workflow_strip($uid,'agency'); ?>
    <div class="pw-v510-dashboard-grid"><section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('SCHNELLSTART','QUICK START')); ?></span><h2><?php echo esc_html(pw_t('Häufige Aufgaben','Common tasks')); ?></h2></div></div><div class="pw-v510-quick-grid"><a href="<?php echo esc_url(pw_page_url('workers',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?><b><?php echo esc_html(pw_t('Mitarbeiter anlegen','Add employee')); ?></b><small><?php echo esc_html(pw_t('Profil & Personalakte','Profile & file')); ?></small></a><a href="<?php echo esc_url(pw_page_url('crm',['new'=>1])); ?>"><?php echo pw_icon('handshake'); ?><b><?php echo esc_html(pw_t('Kunde anlegen','Add customer')); ?></b><small><?php echo esc_html(pw_t('in unter einer Minute','in under a minute')); ?></small></a><a href="<?php echo esc_url(pw_page_url('market_live')); ?>"><?php echo pw_icon('target'); ?><b><?php echo esc_html(pw_t('Leads prüfen','Review leads')); ?></b><small><?php echo esc_html(pw_t('nur priorisierte Kontakte','prioritised contacts only')); ?></small></a><a href="<?php echo esc_url(pw_page_url('calculator')); ?>"><?php echo pw_icon('calculator'); ?><b><?php echo esc_html(pw_t('Satz kalkulieren','Calculate rate')); ?></b><small><?php echo esc_html(pw_t('Marge direkt sehen','see margin instantly')); ?></small></a></div></section><?php echo pw_v510_plan_value_card($uid); ?></div>
    <?php if($plan==='enterprise') echo pw_v510_capacity_forecast($uid,true); ?>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

function pw_v510_dashboard_client($uid){
    $s=pw_v498_client_snapshot($uid);$company=pw_user_meta($uid,'pw_company',wp_get_current_user()->display_name);$focus=pw_v510_focus_list($uid,'client',3);$pending=function_exists('pw_v500_pending_timesheet_count')?pw_v500_pending_timesheet_count($uid):0;
    ob_start();echo pw_portal_shell_start(pw_t('Start','Home'),pw_t('Personalbedarf in wenigen klaren Schritten steuern.','Manage staffing needs in a few clear steps.'));echo pw_flash_messages();
    if(isset($_GET['panel'])&&$_GET['panel']==='notifications'){echo pw_dashboard_notifications_panel();echo pw_portal_shell_end();return ob_get_clean();}
    ?>
    <section class="pw-v510-hero client"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PERSONALBESCHAFFUNG','STAFFING')); ?></span><h1><?php echo esc_html($company); ?></h1><p><?php echo esc_html(pw_t('Bedarf einstellen, Profile entscheiden, Start abstimmen. Pure Work zeigt nur den nächsten sinnvollen Schritt.','Create demand, decide on profiles and coordinate the start. Pure Work only shows the next useful step.')); ?></p></div><div class="pw-v510-hero-actions"><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?> <?php echo esc_html(pw_t('Personalbedarf anlegen','Create staffing request')); ?></a><button class="pw-btn ghost" type="button" data-pw-copilot-open><?php echo pw_icon('spark'); ?> Pure Assist</button></div></section>
    <div class="pw-v510-statusbar"><a href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><b><?php echo (int)$s['open']; ?></b><span><?php echo esc_html(pw_t('offene Bedarfe','open needs')); ?></span></a><a href="<?php echo esc_url(pw_page_url('matches')); ?>"><b><?php echo (int)$s['new']; ?></b><span><?php echo esc_html(pw_t('Profile zu prüfen','profiles to review')); ?></span></a><a href="<?php echo esc_url(pw_page_url('timesheets')); ?>"><b><?php echo (int)$pending; ?></b><span><?php echo esc_html(pw_t('Stunden offen','hours pending')); ?></span></a><a href="<?php echo esc_url(pw_page_url('messages')); ?>"><b><?php echo (int)$s['messages']; ?></b><span><?php echo esc_html(pw_t('ungelesen','unread')); ?></span></a></div>
    <?php echo pw_v510_getting_started($uid,'client'); ?>
    <section class="pw-card pw-v510-focus"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('JETZT','NOW')); ?></span><h2><?php echo esc_html(pw_t('Was braucht deine Entscheidung?','What needs your decision?')); ?></h2></div></div><div class="pw-v510-focus-list"><?php if(!$focus): ?><div class="pw-empty compact"><?php echo pw_icon('check'); ?><p><?php echo esc_html(pw_t('Aktuell ist nichts offen.','Nothing is open right now.')); ?></p></div><?php else:foreach($focus as $i=>$item)echo pw_v510_focus_card($item,$i+1);endif;?></div></section>
    <?php echo pw_v510_workflow_strip($uid,'client'); ?>
    <section class="pw-card pw-v510-client-start"><div><span class="pw-kicker"><?php echo esc_html(pw_t('SCHNELLER BEDARF','QUICK REQUEST')); ?></span><h2><?php echo esc_html(pw_t('Nicht jedes Mal bei null anfangen','Do not start from zero every time')); ?></h2><p><?php echo esc_html(pw_t('Starte mit einer Vorlage und ändere nur Rolle, Anzahl, Ort und Start.','Start from a template and only change role, quantity, location and start.')); ?></p></div><div class="pw-v510-template-row"><a href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1,'template'=>'lager'])); ?>"><?php echo pw_icon('grid'); ?><b><?php echo esc_html(pw_t('Lager & Produktion','Warehouse & production')); ?></b></a><a href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1,'template'=>'technik'])); ?>"><?php echo pw_icon('tool'); ?><b><?php echo esc_html(pw_t('Technik','Technical')); ?></b></a><a href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1,'template'=>'office'])); ?>"><?php echo pw_icon('briefcase'); ?><b><?php echo esc_html(pw_t('Kaufmännisch','Commercial')); ?></b></a></div></section>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

function pw_shortcode_dashboard_v510(){
    if(!is_user_logged_in()) return pw_require_login_html();$uid=get_current_user_id();$role=pw_user_role($uid);
    return $role==='agency'?pw_v510_dashboard_agency($uid):pw_v510_dashboard_client($uid);
}

/* -------------------------------------------------------------------------
 * Employee pool – list first, detail second; profile completeness visible
 * ---------------------------------------------------------------------- */
function pw_v510_worker_completeness($w){
    $checks=[
        'role'=>!empty($w['role']),'location'=>!empty($w['location']),'available'=>!empty($w['available_from']),
        'quals'=>!empty($w['qualifications']),'contact'=>!empty($w['full_name'])&&(!empty($w['email'])||!empty($w['phone'])),
        'cv'=>!empty($w['cv_file'])||!empty($w['public_cv_file']),
    ];
    $done=count(array_filter($checks));$score=(int)round(($done/count($checks))*100);$missing=[];
    $labels=['role'=>pw_t('Tätigkeit','Role'),'location'=>pw_t('Ort','Location'),'available'=>pw_t('Verfügbarkeit','Availability'),'quals'=>pw_t('Qualifikationen','Qualifications'),'contact'=>pw_t('Kontakt','Contact'),'cv'=>pw_t('Lebenslauf','CV')];
    foreach($checks as $k=>$ok)if(!$ok)$missing[]=$labels[$k];
    return [$score,$missing];
}

function pw_v510_worker_best_jobs($worker_id,$uid,$limit=3){
    $jobs=get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','posts_per_page'=>60,'meta_query'=>[['key'=>'pw_status','value'=>'open']]]);$out=[];
    foreach($jobs as $p){if(!pw_agency_can_see_vacancy($uid,$p->ID))continue;$m=pw_match_worker_to_vacancy($worker_id,$p->ID);$out[]=['id'=>$p->ID,'m'=>$m,'v'=>pw_vacancy_fields($p->ID)];}
    usort($out,fn($a,$b)=>(int)($b['m']['score']??0)<=>(int)($a['m']['score']??0));return array_slice($out,0,$limit);
}

function pw_v510_worker_detail($id,$uid){
    if((int)get_post_field('post_author',$id)!==$uid&&!current_user_can('manage_options'))return '<div class="pw-alert danger">'.esc_html(pw_t('Kein Zugriff.','No access.')).'</div>';
    $w=pw_worker_fields($id);[$score,$missing]=pw_v510_worker_completeness($w);$matches=pw_v510_worker_best_jobs($id,$uid,3);
    $subs=get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>12,'orderby'=>'date','order'=>'DESC','meta_query'=>[['key'=>'pw_worker_id','value'=>$id],['key'=>'pw_agency_id','value'=>$uid]]]);
    $statusMap=['available'=>pw_t('Verfügbar','Available'),'reserved'=>pw_t('Reserviert','Reserved'),'assigned'=>pw_t('Im Einsatz','Assigned'),'inactive'=>pw_t('Inaktiv','Inactive')];
    ob_start(); ?>
    <div class="pw-page-head-inline pw-v510-worker-head"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('workers')); ?>">← <?php echo esc_html(pw_t('Mitarbeiter','Employees')); ?></a><span class="pw-kicker"><?php echo esc_html($w['code']); ?></span><h2><?php echo esc_html($w['full_name']?:$w['role']); ?></h2><p><?php echo esc_html($w['role'].' · '.($w['location']?:'–')); ?></p></div><div class="pw-head-actions"><span class="pw-badge <?php echo $w['status']==='available'?'success':'muted'; ?>"><?php echo esc_html($statusMap[$w['status']]??$w['status']); ?></span><a class="pw-btn primary small" href="<?php echo esc_url(pw_page_url('workers',['edit'=>$id])); ?>"><?php echo esc_html(pw_t('Bearbeiten','Edit')); ?></a></div></div>
    <div class="pw-v510-worker-summary"><div><span><?php echo pw_icon('check'); ?></span><b><?php echo $score; ?>%</b><small><?php echo esc_html(pw_t('Profil vollständig','profile complete')); ?></small></div><div><span><?php echo pw_icon('calendar'); ?></span><b><?php echo esc_html($w['available_from']?pw_format_date($w['available_from']):'–'); ?></b><small><?php echo esc_html(pw_t('verfügbar ab','available from')); ?></small></div><div><span><?php echo pw_icon('document'); ?></span><b><?php echo ($w['cv_file']||$w['public_cv_file'])?'✓':'–'; ?></b><small><?php echo esc_html(pw_t('Lebenslauf','CV')); ?></small></div><div><span><?php echo pw_icon('briefcase'); ?></span><b><?php echo count($subs); ?></b><small><?php echo esc_html(pw_t('Zuordnungen','submissions')); ?></small></div></div>
    <?php if($missing): ?><div class="pw-v510-completion-hint"><span><?php echo pw_icon('spark'); ?></span><div><b><?php echo esc_html(pw_t('Für bessere Matches ergänzen','Complete for better matches')); ?></b><p><?php echo esc_html(implode(' · ',$missing)); ?></p></div><a href="<?php echo esc_url(pw_page_url('workers',['edit'=>$id])); ?>"><?php echo esc_html(pw_t('Jetzt ergänzen','Complete now')); ?></a></div><?php endif; ?>
    <div class="pw-v510-worker-grid"><section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PERSONALAKTE','EMPLOYEE FILE')); ?></span><h2><?php echo esc_html(pw_t('Intern & geschützt','Internal & protected')); ?></h2></div><span class="pw-private-chip"><?php echo pw_icon('lock'); ?> <?php echo esc_html(pw_t('privat','private')); ?></span></div><div class="pw-v510-file-facts"><div><span><?php echo esc_html(pw_t('Name','Name')); ?></span><b><?php echo esc_html($w['full_name']?:'–'); ?></b></div><div><span><?php echo esc_html(pw_t('E-Mail','E-mail')); ?></span><b><?php echo esc_html($w['email']?:'–'); ?></b></div><div><span><?php echo esc_html(pw_t('Telefon','Phone')); ?></span><b><?php echo esc_html($w['phone']?:'–'); ?></b></div><div><span><?php echo esc_html(pw_t('Anschrift','Address')); ?></span><b><?php echo esc_html($w['address']?:'–'); ?></b></div></div><div class="pw-v510-doc-row"><a class="<?php echo $w['cv_file']?'ready':'missing'; ?>" <?php if($w['cv_file']): ?>href="<?php echo esc_url(pw_file_download_url((int)$w['cv_file'])); ?>"<?php endif; ?>><?php echo pw_icon('document'); ?><span><b><?php echo esc_html(pw_t('Original-Lebenslauf','Original CV')); ?></b><small><?php echo esc_html($w['cv_file']?pw_t('vorhanden','available'):pw_t('fehlt','missing')); ?></small></span></a><a class="<?php echo $w['public_cv_file']?'ready':'missing'; ?>" <?php if($w['public_cv_file']): ?>href="<?php echo esc_url(pw_file_download_url((int)$w['public_cv_file'])); ?>"<?php endif; ?>><?php echo pw_icon('lock'); ?><span><b><?php echo esc_html(pw_t('Anonymisierte Version','Anonymised version')); ?></b><small><?php echo esc_html($w['public_cv_file']?pw_t('marktplatzbereit','marketplace ready'):pw_t('optional','optional')); ?></small></span></a><a class="<?php echo $w['docs_file']?'ready':'missing'; ?>" <?php if($w['docs_file']): ?>href="<?php echo esc_url(pw_file_download_url((int)$w['docs_file'])); ?>"<?php endif; ?>><?php echo pw_icon('check'); ?><span><b><?php echo esc_html(pw_t('Nachweise','Certificates')); ?></b><small><?php echo esc_html($w['docs_file']?pw_t('vorhanden','available'):pw_t('noch keine','none yet')); ?></small></span></a></div></section>
    <section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('MATCHINGPROFIL','MATCH PROFILE')); ?></span><h2><?php echo esc_html($w['role']); ?></h2></div></div><div class="pw-side-facts"><div><span><?php echo esc_html(pw_t('Erfahrung','Experience')); ?></span><b><?php echo (int)$w['experience']; ?> <?php echo esc_html(pw_t('Jahre','years')); ?></b></div><div><span><?php echo esc_html(pw_t('Ort','Location')); ?></span><b><?php echo esc_html($w['location']?:'–'); ?></b></div><div><span><?php echo esc_html(pw_t('Qualifikationen','Qualifications')); ?></span><b><?php echo esc_html(pw_list_string($w['qualifications'])?:'–'); ?></b></div><div><span><?php echo esc_html(pw_t('Schichten','Shifts')); ?></span><b><?php echo esc_html(pw_list_string($w['shifts'])?:'–'); ?></b></div></div></section></div>
    <section class="pw-card pw-v510-worker-matches"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PASSENDE AUSSCHREIBUNGEN','MATCHING JOBS')); ?></span><h2><?php echo esc_html(pw_can('smart_matching',$uid)?pw_t('Beste Chancen für dieses Profil','Best opportunities for this profile'):pw_t('Matching-Vorschau','Matching preview')); ?></h2></div><?php if(!pw_can('smart_matching',$uid)): ?><a href="<?php echo esc_url(pw_page_url('account',['tab'=>'billing'])); ?>">Pro <?php echo pw_icon('arrow'); ?></a><?php endif; ?></div><div class="pw-v510-match-list"><?php if(!$matches): ?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Aktuell keine passende offene Ausschreibung.','No matching open job right now.')); ?></p></div><?php else:foreach($matches as $m): ?><a href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$m['id']])); ?>"><span class="pw-v510-score <?php echo (int)$m['m']['score']>=80?'high':''; ?>"><?php echo (int)$m['m']['score']; ?>%</span><div><b><?php echo esc_html($m['v']['title']); ?></b><small><?php echo esc_html($m['v']['location'].' · '.$m['v']['public_id']); ?></small></div><?php echo pw_icon('arrow'); ?></a><?php endforeach;endif; ?></div></section>
    <?php return ob_get_clean();
}

function pw_shortcode_workers_v510(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();
    ob_start();echo pw_portal_shell_start(pw_t('Mitarbeiter','Employees'),pw_t('Verfügbarkeit, Personalakte und passende Einsätze auf einen Blick.','Availability, employee file and matching assignments at a glance.'));echo pw_flash_messages();
    if(pw_user_role($uid)!=='agency'){echo '<section class="pw-card pw-empty"><p>'.esc_html(pw_t('Dieser Bereich ist für Zeitarbeitsfirmen.','This area is for staffing agencies.')).'</p></section>';echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['new'])||isset($_GET['edit'])){$wf=isset($_GET['edit'])?(int)$_GET['edit']:0;echo function_exists('pw_worker_form_v540')?pw_worker_form_v540($wf):pw_worker_form($wf);echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['view'])){echo pw_v510_worker_detail((int)$_GET['view'],$uid);echo pw_portal_shell_end();return ob_get_clean();}
    $q=sanitize_text_field(wp_unslash($_GET['q']??''));$status=sanitize_key(wp_unslash($_GET['status']??''));$posts=get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>200,'orderby'=>'modified','order'=>'DESC']);$rows=[];
    foreach($posts as $p){$w=pw_worker_fields($p->ID);$hay=pw_lower(($w['full_name']??'').' '.($w['role']??'').' '.($w['location']??'').' '.($w['code']??''));if($q&&!pw_contains($hay,pw_lower($q)))continue;if($status&&$status!==($w['status']??''))continue;$rows[]=[$p,$w];}
    $available=0;$incomplete=0;foreach($posts as $p){$w=pw_worker_fields($p->ID);if(($w['status']??'')==='available')$available++;[$sc]=pw_v510_worker_completeness($w);if($sc<80)$incomplete++;}
    ?>
    <section class="pw-v510-page-intro"><div><span class="pw-kicker"><?php echo esc_html(pw_t('MITARBEITER-POOL','EMPLOYEE POOL')); ?></span><h2><?php echo esc_html(pw_t('Wer ist verfügbar – und was fehlt noch?','Who is available and what is still missing?')); ?></h2><p><?php echo esc_html(pw_t('Keine Tabellenwand. Öffne ein Profil für Personalakte, Dokumente, Matches und Verlauf.','No wall of tables. Open a profile for file, documents, matches and history.')); ?></p></div><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('workers',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?> <?php echo esc_html(pw_t('Mitarbeiter anlegen','Add employee')); ?></a></section>
    <div class="pw-v510-mini-kpis"><span><b><?php echo count($posts); ?></b><?php echo esc_html(pw_t('Profile','profiles')); ?></span><span><b><?php echo $available; ?></b><?php echo esc_html(pw_t('verfügbar','available')); ?></span><span class="<?php echo $incomplete?'warning':''; ?>"><b><?php echo $incomplete; ?></b><?php echo esc_html(pw_t('zu ergänzen','to complete')); ?></span></div>
    <form method="get" class="pw-v510-filterbar"><label><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($q); ?>" placeholder="<?php echo esc_attr(pw_t('Name, Tätigkeit, Ort oder Profil-ID','Name, role, location or profile ID')); ?>"></label><select name="status"><option value=""><?php echo esc_html(pw_t('Alle Status','All statuses')); ?></option><option value="available" <?php selected($status,'available'); ?>><?php echo esc_html(pw_t('Verfügbar','Available')); ?></option><option value="reserved" <?php selected($status,'reserved'); ?>><?php echo esc_html(pw_t('Reserviert','Reserved')); ?></option><option value="assigned" <?php selected($status,'assigned'); ?>><?php echo esc_html(pw_t('Im Einsatz','Assigned')); ?></option></select><button class="pw-btn ghost small"><?php echo esc_html(pw_t('Filtern','Filter')); ?></button></form>
    <div class="pw-v510-worker-list"><?php if(!$rows): ?><section class="pw-card pw-empty"><?php echo pw_icon('users'); ?><h3><?php echo esc_html(pw_t('Keine Profile gefunden','No profiles found')); ?></h3><p><?php echo esc_html(pw_t('Filter zurücksetzen oder einen Mitarbeiter anlegen.','Reset filters or add an employee.')); ?></p></section><?php else:foreach($rows as [$p,$w]):[$sc,$missing]=pw_v510_worker_completeness($w); ?><a href="<?php echo esc_url(pw_page_url('workers',['view'=>$p->ID])); ?>" class="pw-v510-worker-row"><span class="pw-profile-code"><?php echo esc_html(pw_initials($w['role'])); ?></span><div class="pw-v510-worker-name"><b><?php echo esc_html($w['full_name']?:$w['code']); ?></b><small><?php echo esc_html($w['role'].' · '.($w['location']?:'–')); ?></small></div><div class="pw-v510-worker-availability"><span class="pw-dot <?php echo esc_attr($w['status']); ?>"></span><b><?php echo esc_html($w['status']==='available'?pw_t('Verfügbar','Available'):($w['status']==='assigned'?pw_t('Im Einsatz','Assigned'):pw_t('Reserviert','Reserved'))); ?></b><small><?php echo esc_html($w['available_from']?pw_format_date($w['available_from']):'–'); ?></small></div><div class="pw-v510-complete"><span><i style="width:<?php echo $sc; ?>%"></i></span><b><?php echo $sc; ?>%</b><small><?php echo esc_html($missing?pw_t('Profil ergänzen','complete profile'):pw_t('vollständig','complete')); ?></small></div><?php echo pw_icon('arrow'); ?></a><?php endforeach;endif; ?></div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * CRM – simple customer list by default, advanced pipeline only on demand
 * ---------------------------------------------------------------------- */
function pw_v510_crm_new_form(){
    ob_start(); ?><div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('crm')); ?>">← <?php echo esc_html(pw_t('Kunden','Customers')); ?></a><span class="pw-kicker"><?php echo esc_html(pw_t('SCHNELL ANLEGEN','QUICK ADD')); ?></span><h2><?php echo esc_html(pw_t('Kunde in unter einer Minute','Add a customer in under a minute')); ?></h2><p><?php echo esc_html(pw_t('Nur Unternehmen ist Pflicht. Alles Weitere kannst du später ergänzen.','Only the company is required. Everything else can be added later.')); ?></p></div></div>
    <form class="pw-form-stack pw-v510-crm-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_crm_save"><?php wp_nonce_field('pw_crm_save'); ?><section class="pw-form-card"><div class="pw-form-section-title"><span>01</span><div><h3><?php echo esc_html(pw_t('Wer ist der Kunde?','Who is the customer?')); ?></h3><p><?php echo esc_html(pw_t('Die vier Felder reichen für den Start.','These four fields are enough to start.')); ?></p></div></div><div class="pw-form-grid two"><label><?php echo esc_html(pw_t('Unternehmen','Company')); ?><input required autofocus name="company"></label><label><?php echo esc_html(pw_t('Ansprechpartner','Contact')); ?><input name="contact"></label><label><?php echo esc_html(pw_t('Telefon','Phone')); ?><input name="phone"></label><label><?php echo esc_html(pw_t('E-Mail','E-mail')); ?><input type="email" name="email"></label><label><?php echo esc_html(pw_t('Nächster Kontakt','Next contact')); ?><input type="date" name="next_followup"></label><label><?php echo esc_html(pw_t('Aktueller Bedarf','Current need')); ?><input name="job_title" placeholder="<?php echo esc_attr(pw_t('z. B. 4 Produktionshelfer','e.g. 4 production workers')); ?>"></label></div></section><details class="pw-form-card pw-v510-advanced"><summary><?php echo pw_icon('plus'); ?> <?php echo esc_html(pw_t('Weitere Angaben','More details')); ?></summary><div class="pw-form-grid two"><label><?php echo esc_html(pw_t('Ort','Location')); ?><input name="city"></label><label><?php echo esc_html(pw_t('Branche','Industry')); ?><input name="industry" list="pw-industries"></label><label><?php echo esc_html(pw_t('Status','Stage')); ?><select name="stage"><?php foreach(pw_crm_stages() as $k=>$l): ?><option value="<?php echo esc_attr($k); ?>"><?php echo esc_html(pw_t($l[0],$l[1])); ?></option><?php endforeach; ?></select></label><label><?php echo esc_html(pw_t('Priorität','Priority')); ?><select name="priority"><option value="warm"><?php echo esc_html(pw_t('Normal','Normal')); ?></option><option value="hot"><?php echo esc_html(pw_t('Hoch','High')); ?></option><option value="cold"><?php echo esc_html(pw_t('Niedrig','Low')); ?></option></select></label><label class="full"><?php echo esc_html(pw_t('Notiz','Note')); ?><textarea name="notes" rows="3"></textarea></label></div></details><div class="pw-form-actions"><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('crm')); ?>"><?php echo esc_html(pw_t('Abbrechen','Cancel')); ?></a><button class="pw-btn primary"><?php echo esc_html(pw_t('Kunde speichern','Save customer')); ?> <?php echo pw_icon('arrow'); ?></button></div></form><?php return ob_get_clean();
}

function pw_v510_crm_detail($id,$uid){
    $l=pw_crm_lead_fields($id);if(!$l||!pw_crm_can_access($id,$uid))return '<div class="pw-alert danger">'.esc_html(pw_t('Kein Zugriff.','No access.')).'</div>';$acts=pw_crm_activities($id,$uid);$hint=function_exists('pw_crm_ai_hint')?pw_crm_ai_hint($l):'';
    ob_start(); ?><div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('crm')); ?>">← <?php echo esc_html(pw_t('Kunden','Customers')); ?></a><span class="pw-kicker"><?php echo esc_html(pw_t('KUNDENAKTE','CUSTOMER FILE')); ?></span><h2><?php echo esc_html($l['company']); ?></h2><p><?php echo esc_html(trim(($l['contact']?:pw_t('kein Ansprechpartner','no contact')).($l['city']?' · '.$l['city']:''))); ?></p></div><span class="pw-badge brand"><?php echo esc_html(pw_crm_stage_label($l['stage'])); ?></span></div>
    <?php if($hint): ?><div class="pw-v510-assist-hint"><span><?php echo pw_icon('spark'); ?></span><div><b>Pure Assist</b><p><?php echo esc_html($hint); ?></p></div></div><?php endif; ?>
    <div class="pw-v510-crm-detail-grid"><section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('KONTAKT','CONTACT')); ?></span><h2><?php echo esc_html(pw_t('Alles für den nächsten Schritt','Everything for the next step')); ?></h2></div></div><div class="pw-v510-contact-card"><div><span><?php echo esc_html(pw_t('Ansprechpartner','Contact')); ?></span><b><?php echo esc_html($l['contact']?:'–'); ?></b></div><div><span><?php echo esc_html(pw_t('Telefon','Phone')); ?></span><b><?php echo esc_html($l['phone']?:'–'); ?></b></div><div><span><?php echo esc_html(pw_t('E-Mail','E-mail')); ?></span><b><?php echo esc_html($l['email']?:'–'); ?></b></div><div><span><?php echo esc_html(pw_t('Bedarf','Need')); ?></span><b><?php echo esc_html($l['job_title']?:'–'); ?></b></div></div><div class="pw-v510-contact-actions"><?php if($l['phone']): ?><a class="pw-btn primary small" href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$l['phone'])); ?>"><?php echo pw_icon('phone'); ?> <?php echo esc_html(pw_t('Anrufen','Call')); ?></a><?php endif; ?><?php if($l['email']): ?><a class="pw-btn ghost small" href="mailto:<?php echo esc_attr($l['email']); ?>"><?php echo pw_icon('message'); ?> <?php echo esc_html(pw_t('E-Mail','E-mail')); ?></a><?php endif; ?></div></section>
    <section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('NÄCHSTER SCHRITT','NEXT STEP')); ?></span><h2><?php echo esc_html(pw_t('Status & Wiedervorlage','Stage & follow-up')); ?></h2></div></div><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-v510-stage-form"><input type="hidden" name="action" value="pw_crm_stage"><input type="hidden" name="lead_id" value="<?php echo (int)$id; ?>"><?php wp_nonce_field('pw_crm_stage'); ?><label><?php echo esc_html(pw_t('Status','Stage')); ?><select name="stage"><?php foreach(pw_crm_stages() as $k=>$labs): ?><option value="<?php echo esc_attr($k); ?>" <?php selected($l['stage'],$k); ?>><?php echo esc_html(pw_t($labs[0],$labs[1])); ?></option><?php endforeach; ?></select></label><button class="pw-btn ghost small"><?php echo esc_html(pw_t('Status speichern','Save stage')); ?></button></form><hr><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-v510-note-form"><input type="hidden" name="action" value="pw_crm_activity"><input type="hidden" name="lead_id" value="<?php echo (int)$id; ?>"><?php wp_nonce_field('pw_crm_activity'); ?><input type="hidden" name="activity_type" value="note"><label><?php echo esc_html(pw_t('Wiedervorlage','Follow-up')); ?><input type="date" name="due" value="<?php echo esc_attr($l['next_followup']); ?>"></label><label><?php echo esc_html(pw_t('Kurze Notiz','Short note')); ?><textarea name="activity_text" rows="3" required placeholder="<?php echo esc_attr(pw_t('Was wurde besprochen? Was passiert als Nächstes?','What was discussed? What happens next?')); ?>"></textarea></label><button class="pw-btn primary small"><?php echo esc_html(pw_t('Notiz & Wiedervorlage speichern','Save note & follow-up')); ?></button></form></section></div>
    <section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('VERLAUF','HISTORY')); ?></span><h2><?php echo esc_html(pw_t('Was bisher passiert ist','What has happened')); ?></h2></div></div><div class="pw-v510-timeline"><?php if(!$acts): ?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch keine Aktivität.','No activity yet.')); ?></p></div><?php else:foreach(array_slice($acts,0,20) as $a): ?><div><i></i><div><b><?php echo esc_html(ucfirst(pw_meta($a->ID,'pw_crm_type',pw_t('Notiz','Note')))); ?></b><p><?php echo nl2br(esc_html($a->post_content)); ?></p><small><?php echo esc_html(wp_date('d.m.Y · H:i',get_post_time('U',true,$a))); ?></small></div></div><?php endforeach;endif; ?></div></section>
    <?php return ob_get_clean();
}

function pw_shortcode_crm_v510(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();ob_start();echo pw_portal_shell_start(pw_t('Kunden','Customers'),pw_t('Kontakte, Wiedervorlagen und Chancen – ohne CRM-Komplexität.','Contacts, follow-ups and opportunities without CRM complexity.'));echo pw_flash_messages();
    if(!pw_can('crm',$uid)){echo pw_plan_gate('crm');echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['lead'])){echo pw_v510_crm_detail((int)$_GET['lead'],$uid);echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['new'])){echo pw_v510_crm_new_form();echo pw_portal_shell_end();return ob_get_clean();}
    $q=sanitize_text_field(wp_unslash($_GET['q']??''));$posts=pw_crm_get_leads($uid,['search'=>$q]);$m=pw_crm_dashboard_metrics($uid);$today=wp_date('Y-m-d');$due=[];$rest=[];
    foreach($posts as $p){$l=pw_crm_lead_fields($p->ID);if($l['next_followup']&&$l['next_followup']<=$today&&!in_array($l['stage'],['won','lost'],true))$due[]=$p;else$rest[]=$p;}
    ?>
    <section class="pw-v510-page-intro"><div><span class="pw-kicker"><?php echo esc_html(pw_t('MEINE KUNDEN','MY CUSTOMERS')); ?></span><h2><?php echo esc_html(pw_t('Wen muss ich heute kontaktieren?','Who do I need to contact today?')); ?></h2><p><?php echo esc_html(pw_t('Pure Work stellt fällige Kontakte nach oben. Pipeline-Details bleiben verfügbar, aber nicht im Weg.','Pure Work puts due contacts first. Pipeline details remain available without getting in the way.')); ?></p></div><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('crm',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?> <?php echo esc_html(pw_t('Kunde anlegen','Add customer')); ?></a></section>
    <div class="pw-v510-mini-kpis"><span><b><?php echo (int)$m['total']; ?></b><?php echo esc_html(pw_t('Kunden & Leads','customers & leads')); ?></span><span class="<?php echo $m['due']?'warning':''; ?>"><b><?php echo (int)$m['due']; ?></b><?php echo esc_html(pw_t('heute fällig','due today')); ?></span><span><b><?php echo (int)$m['won']; ?></b><?php echo esc_html(pw_t('gewonnen','won')); ?></span></div>
    <?php if($due): ?><section class="pw-card pw-v510-due"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('HEUTE NACHFASSEN','FOLLOW UP TODAY')); ?></span><h2><?php echo count($due); ?> <?php echo esc_html(pw_t('Kontakte warten','contacts are waiting')); ?></h2></div></div><div class="pw-v510-customer-list compact"><?php foreach(array_slice($due,0,6) as $p):$l=pw_crm_lead_fields($p->ID); ?><a href="<?php echo esc_url(pw_page_url('crm',['lead'=>$p->ID])); ?>"><span class="pw-company-logo small"><?php echo esc_html(pw_initials($l['company'])); ?></span><div><b><?php echo esc_html($l['company']); ?></b><small><?php echo esc_html(($l['contact']?:pw_t('Ansprechpartner ergänzen','add contact')).($l['job_title']?' · '.$l['job_title']:'')); ?></small></div><em><?php echo esc_html(pw_format_date($l['next_followup'])); ?></em><?php echo pw_icon('arrow'); ?></a><?php endforeach; ?></div></section><?php endif; ?>
    <form method="get" class="pw-v510-filterbar"><label><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($q); ?>" placeholder="<?php echo esc_attr(pw_t('Unternehmen, Ansprechpartner oder Bedarf suchen','Search company, contact or need')); ?>"></label><button class="pw-btn ghost small"><?php echo esc_html(pw_t('Suchen','Search')); ?></button></form>
    <section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('ALLE KUNDEN','ALL CUSTOMERS')); ?></span><h2><?php echo count($posts); ?> <?php echo esc_html(pw_t('Einträge','entries')); ?></h2></div><details class="pw-v510-view-help"><summary><?php echo esc_html(pw_t('Was bedeuten die Status?','What do the stages mean?')); ?></summary><p><?php echo esc_html(pw_t('Neu → qualifiziert → kontaktiert → Termin → Angebot → gewonnen. Du musst nicht jeden Status nutzen.','New → qualified → contacted → meeting → offer → won. You do not need to use every stage.')); ?></p></details></div><div class="pw-v510-customer-list"><?php if(!$posts): ?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch kein Kunde. Lege den ersten in unter einer Minute an.','No customer yet. Add the first one in under a minute.')); ?></p></div><?php else:foreach($posts as $p):$l=pw_crm_lead_fields($p->ID); ?><a href="<?php echo esc_url(pw_page_url('crm',['lead'=>$p->ID])); ?>"><span class="pw-company-logo small"><?php echo esc_html(pw_initials($l['company'])); ?></span><div><b><?php echo esc_html($l['company']); ?></b><small><?php echo esc_html(trim(($l['contact']?:pw_t('kein Ansprechpartner','no contact')).($l['job_title']?' · '.$l['job_title']:''))); ?></small></div><span class="pw-badge muted"><?php echo esc_html(pw_crm_stage_label($l['stage'])); ?></span><?php if($l['next_followup']): ?><em><?php echo esc_html(pw_format_date($l['next_followup'])); ?></em><?php endif; ?><?php echo pw_icon('arrow'); ?></a><?php endforeach;endif; ?></div></section>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Leads – quality before volume, target accounts only on Max
 * ---------------------------------------------------------------------- */
function pw_v510_lead_simple_card($e,$uid){
    $class=$e['class'][0];$evidence=pw_lead_evidence_label($e['evidence']??'none');$canCapture=$class!=='C'||pw_can('leads_targets',$uid);
    $demand=function_exists('pw_v540_rate_contact')?pw_v540_rate_contact($e):null;
    ob_start(); ?><article class="pw-card pw-v510-lead-card tier-<?php echo esc_attr(pw_lower($class)); ?>"><?php if($demand): ?><span class="pw-v540-demand" title="<?php echo esc_attr($demand['why']); ?>"><i style="--v:<?php echo (int)$demand['score']; ?>%"></i><?php echo esc_html($demand['label']); ?></span><?php endif; ?><header><span class="pw-company-logo small"><?php echo esc_html(pw_initials($e['company'])); ?></span><div><h3><?php echo esc_html($e['company']); ?></h3><p><?php echo esc_html(trim($e['city'].($e['sector']?' · '.$e['sector']:''))); ?></p></div><span class="pw-v510-lead-score"><?php echo (int)$e['score']; ?><small>/100</small></span></header><div class="pw-v510-lead-proof"><span class="<?php echo esc_attr($evidence[1]); ?>"><i></i><?php echo esc_html($evidence[0]); ?></span><span><?php echo esc_html(pw_t('Kontaktstufe ','Contact tier ').$class); ?></span></div><?php if($e['signals']): ?><div class="pw-chip-list"><?php foreach(array_slice($e['signals'],0,3) as $sig): ?><span><?php echo esc_html($sig); ?></span><?php endforeach; ?></div><?php endif; ?><div class="pw-v510-lead-contact"><div><small><?php echo esc_html(pw_t('Kontakt','Contact')); ?></small><b><?php echo esc_html(trim(($e['contact_name']?:$e['contact_role'])?:pw_t('Fachbereich recherchieren','research department'))); ?></b></div><div><small><?php echo esc_html(pw_t('Direkter Weg','Direct route')); ?></small><b><?php echo esc_html($e['phone']?:($e['email']?:'–')); ?></b></div></div><footer><?php if($canCapture): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_lead_research_capture"><input type="hidden" name="lead_type" value="<?php echo esc_attr($e['type']); ?>"><input type="hidden" name="lead_ref" value="<?php echo esc_attr($e['id']); ?>"><?php wp_nonce_field('pw_lead_research_capture'); ?><button class="pw-btn primary small"><?php echo pw_icon('handshake'); ?> <?php echo esc_html(pw_t('In Kundenliste übernehmen','Add to customers')); ?></button></form><?php else: ?><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('account',['tab'=>'billing'])); ?>"><?php echo pw_icon('lock'); ?> Max</a><?php endif; ?><?php if($e['source_url']): ?><a class="pw-text-link" href="<?php echo esc_url($e['source_url']); ?>" target="_blank" rel="noopener"><?php echo esc_html(pw_t('Quelle prüfen','Check source')); ?> <?php echo pw_icon('arrow'); ?></a><?php endif; ?></footer></article><?php return ob_get_clean();
}

function pw_shortcode_market_v510(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();ob_start();echo pw_portal_shell_start(pw_t('Leads','Leads'),pw_t('Wenige gute Kontakte statt einer unübersichtlichen Adresswand.','A few good contacts instead of a wall of addresses.'));echo pw_flash_messages();
    if(pw_user_role($uid)!=='agency'){echo '<section class="pw-card pw-empty"><p>'.esc_html(pw_t('Leads sind für Zeitarbeitsfirmen vorgesehen.','Leads are for staffing agencies.')).'</p></section>';echo pw_portal_shell_end();return ob_get_clean();}
    $q=sanitize_text_field(wp_unslash($_GET['q']??''));$where=sanitize_text_field(wp_unslash($_GET['where']??''));$pool=pw_lead_pool(['q'=>$q,'where'=>$where]);$quality=[];$targets=[];
    foreach($pool as $e){if(in_array($e['class'][0],['A','B'],true)&&($e['evidence']??'none')!=='none'&&$e['score']>=60)$quality[]=$e;elseif($e['class'][0]==='C'&&($e['evidence']??'none')!=='none')$targets[]=$e;}
    $limit=pw_can('leads_unlimited',$uid)?60:5;$showTargets=pw_can('leads_targets',$uid)&&sanitize_key($_GET['view']??'')==='targets';$rows=$showTargets?$targets:array_slice($quality,0,$limit);
    ?>
    <section class="pw-v510-page-intro"><div><span class="pw-kicker"><?php echo esc_html(pw_t('QUALITÄT VOR MENGE','QUALITY OVER QUANTITY')); ?></span><h2><?php echo esc_html(pw_t('Kontakte, bei denen ein Bedarf belegbar ist','Contacts with evidenced demand')); ?></h2><p><?php echo esc_html(pw_t('Standardmäßig siehst du nur Stufe A/B mit aktuellem Zeitarbeits- oder Beschaffungsnachweis. Zentralen ohne klaren Ansprechpartner stehen nicht mehr im Weg.','By default you only see tier A/B with current staffing or procurement evidence. Switchboards without a clear contact no longer get in the way.')); ?></p></div><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('crm')); ?>"><?php echo pw_icon('handshake'); ?> <?php echo esc_html(pw_t('Meine Kunden','My customers')); ?></a></section>
    <div class="pw-v510-lead-tabs"><a class="<?php echo !$showTargets?'active':''; ?>" href="<?php echo esc_url(pw_page_url('market_live')); ?>"><?php echo pw_icon('check'); ?><span><b><?php echo esc_html(pw_t('Direktkontakte','Direct contacts')); ?></b><small><?php echo count($quality); ?> <?php echo esc_html(pw_t('qualifiziert','qualified')); ?></small></span></a><a class="<?php echo $showTargets?'active':''; ?> <?php echo pw_can('leads_targets',$uid)?'':'locked'; ?>" href="<?php echo esc_url(pw_can('leads_targets',$uid)?pw_page_url('market_live',['view'=>'targets']):pw_page_url('account',['tab'=>'billing'])); ?>"><?php echo pw_icon(pw_can('leads_targets',$uid)?'target':'lock'); ?><span><b><?php echo esc_html(pw_t('Zielkunden','Target accounts')); ?></b><small><?php echo esc_html(pw_can('leads_targets',$uid)?pw_t('Max Priorisierung','Max prioritisation'):pw_t('ab Max','from Max')); ?></small></span></a></div>
    <form class="pw-v510-filterbar" method="get"><label><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($q); ?>" placeholder="<?php echo esc_attr(pw_t('Rolle, Branche oder Unternehmen','Role, industry or company')); ?>"></label><label><?php echo pw_icon('map'); ?><input name="where" value="<?php echo esc_attr($where); ?>" placeholder="<?php echo esc_attr(pw_t('Ort oder Region','Location or region')); ?>"></label><?php if($showTargets): ?><input type="hidden" name="view" value="targets"><?php endif; ?><button class="pw-btn ghost small"><?php echo esc_html(pw_t('Filtern','Filter')); ?></button></form>
    <?php if(!pw_can('leads_unlimited',$uid)&&count($quality)>$limit&&!$showTargets): ?><div class="pw-v510-upgrade-strip"><span><?php echo pw_icon('spark'); ?></span><div><b><?php echo esc_html(pw_t('Basic zeigt die 5 stärksten Kontakte','Basic shows the 5 strongest contacts')); ?></b><p><?php echo esc_html(pw_t('Pro schaltet alle qualifizierten Direktkontakte frei.','Pro unlocks all qualified direct contacts.')); ?></p></div><a href="<?php echo esc_url(pw_page_url('account',['tab'=>'billing'])); ?>"><?php echo esc_html(pw_t('Pro ansehen','View Pro')); ?></a></div><?php endif; ?>
    <div class="pw-v510-lead-grid"><?php if(!$rows): ?><section class="pw-card pw-empty"><p><?php echo esc_html(pw_t('Mit diesen Filtern ist aktuell kein qualifizierter Kontakt vorhanden.','No qualified contact is currently available with these filters.')); ?></p></section><?php else:foreach($rows as $e)echo pw_v510_lead_simple_card($e,$uid);endif; ?></div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Automations – only rules with a clear operational outcome
 * ---------------------------------------------------------------------- */
function pw_v510_automation_defs(){
    $defs = [
        'match_digest'=>['feature'=>'automations','icon'=>'spark','title'=>pw_t('Match-Alarm','Match alert'),'text'=>pw_t('Meldet neue Ausschreibungen, sobald dein Pool einen starken Treffer hat.','Alerts you to new jobs as soon as your pool has a strong match.')],
        'pool_health'=>['feature'=>'pool_health','icon'=>'users','title'=>pw_t('Verfügbarkeits-Check','Availability check'),'text'=>pw_t('Erinnert an unvollständige oder veraltete Mitarbeiterprofile.','Reminds you about incomplete or stale employee profiles.')],
        'followups'=>['feature'=>'automations','icon'=>'handshake','title'=>pw_t('Kunden-Wiedervorlage','Customer follow-up'),'text'=>pw_t('Hebt fällige Kundenkontakte automatisch auf Start hervor.','Automatically brings due customer contacts to Home.')],
        'risk_watch'=>['feature'=>'risk_watch','icon'=>'alert','title'=>pw_t('Besetzungsrisiko','Placement risk'),'text'=>pw_t('Warnt, wenn ein Start näher rückt und noch keine Besetzung final ist.','Warns when a start approaches and no placement is final.')],
        'timesheet_approval'=>['feature'=>'timesheets','icon'=>'check','title'=>pw_t('Stundenfreigabe-Wächter','Timesheet approval watchdog'),'text'=>pw_t('Erinnert, wenn ein Auftraggeber eine Stundenmeldung länger als zwei Tage nicht entschieden hat.','Reminds you when a client has not decided on a timesheet for more than two days.')],
        'hot_leads'=>['feature'=>'hot_lead_automation','icon'=>'target','title'=>pw_t('Max Lead-Priorisierung','Max lead prioritisation'),'text'=>pw_t('Priorisiert neue Zielkunden mit belegtem Bedarf und hohem Kontaktscore.','Prioritises new target accounts with evidenced demand and a high contact score.')],
    ];
    /* 5.4.0: weitere Regeln koennen sich anhaengen, ohne diese Liste zu ersetzen. */
    return apply_filters('pw_automation_defs', $defs);
}

function pw_shortcode_automations_v510(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();ob_start();echo pw_portal_shell_start(pw_t('Automationen','Automations'),pw_t('Nur Regeln, die dir eine konkrete Kontrolle abnehmen.','Only rules that remove a concrete manual check.'));echo pw_flash_messages();
    if(pw_user_role($uid)!=='agency'){echo '<section class="pw-card pw-empty"><p>'.esc_html(pw_t('Automationen sind für Zeitarbeitsfirmen.','Automations are for staffing agencies.')).'</p></section>';echo pw_portal_shell_end();return ob_get_clean();}
    if(!pw_can('automations',$uid)){echo pw_plan_gate('automations');echo pw_portal_shell_end();return ob_get_clean();}
    $defs=pw_v510_automation_defs();$active=0;foreach($defs as $k=>$d)if(pw_can($d['feature'],$uid)&&pw_user_meta($uid,'pw_auto_'.$k,'0')==='1')$active++;
    ?>
    <section class="pw-v510-page-intro"><div><span class="pw-kicker"><?php echo esc_html(pw_t('AUTOMATISIEREN OHNE BLACKBOX','AUTOMATE WITHOUT A BLACK BOX')); ?></span><h2><?php echo esc_html(pw_t('Einschalten. Pure Work passt auf.','Switch it on. Pure Work watches.')); ?></h2><p><?php echo esc_html(pw_t('Keine automatische Kundenansprache. Jede Regel erzeugt nur eine klare Aufgabe oder Warnung im richtigen Moment.','No automatic customer outreach. Each rule only creates a clear task or warning at the right time.')); ?></p></div><span class="pw-v510-active-count"><b><?php echo $active; ?></b><?php echo esc_html(pw_t('aktiv','active')); ?></span></section>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-v510-auto-form"><input type="hidden" name="action" value="pw_v510_automation_save"><?php wp_nonce_field('pw_v510_automation_save'); ?><div class="pw-v510-auto-list"><?php foreach($defs as $key=>$d):$allowed=pw_can($d['feature'],$uid);$checked=$allowed&&pw_user_meta($uid,'pw_auto_'.$key,'0')==='1'; ?><label class="<?php echo $allowed?'':'locked'; ?>"><input type="checkbox" name="auto_<?php echo esc_attr($key); ?>" value="1" <?php checked($checked); ?> <?php disabled(!$allowed); ?>><span class="pw-v510-auto-icon"><?php echo pw_icon($allowed?$d['icon']:'lock'); ?></span><div><b><?php echo esc_html($d['title']); ?></b><p><?php echo esc_html($d['text']); ?></p><small><?php echo esc_html($allowed?pw_t('Kann sofort aktiviert werden','Can be enabled now'):pw_t('verfügbar ab ','available from ').pw_plan_public_label(pw_plan_required_for($d['feature']))); ?></small></div><i class="pw-switch"></i></label><?php endforeach; ?></div><div class="pw-form-actions"><button class="pw-btn primary"><?php echo esc_html(pw_t('Automationen speichern','Save automations')); ?></button></div></form>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

function pw_handle_v510_automation_save(){
    if(!is_user_logged_in()||pw_user_role()!=='agency')wp_die('Keine Berechtigung.');check_admin_referer('pw_v510_automation_save');$uid=get_current_user_id();
    $visible=pw_v510_automation_defs();foreach($visible as $key=>$d)update_user_meta($uid,'pw_auto_'.$key,(pw_can($d['feature'],$uid)&&!empty($_POST['auto_'.$key]))?'1':'0');
    wp_safe_redirect(pw_page_url('automations',['saved'=>1]));exit;
}
add_action('admin_post_pw_v510_automation_save','pw_handle_v510_automation_save');

/* -------------------------------------------------------------------------
 * Smart matching Pro – bulk submit selected profiles from one vacancy
 * ---------------------------------------------------------------------- */
function pw_handle_v510_bulk_submit(){
    if(!is_user_logged_in()||pw_user_role()!=='agency'||!pw_can('smart_matching'))wp_die('Keine Berechtigung.');check_admin_referer('pw_v510_bulk_submit');$uid=get_current_user_id();$vid=(int)($_POST['vacancy_id']??0);$ids=array_values(array_unique(array_map('intval',(array)($_POST['worker_ids']??[]))));$done=0;
    if(!$vid||!pw_agency_can_see_vacancy($uid,$vid))wp_die('Ungültige Ausschreibung.');
    foreach(array_slice($ids,0,5) as $wid){if((int)get_post_field('post_author',$wid)!==$uid||pw_submission_exists($vid,$wid))continue;$w=pw_worker_fields($wid);$r=pw_create_submission($vid,$wid,'',$w['available_from']??'','');if(!is_wp_error($r))$done++;}
    wp_safe_redirect(pw_page_url('vacancies',['view'=>$vid,'bulk_submitted'=>$done]));exit;
}
add_action('admin_post_pw_v510_bulk_submit','pw_handle_v510_bulk_submit');

function pw_v510_smart_match_panel($vid,$uid){
    if(!pw_can('smart_matching',$uid))return '';$pool=get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>100]);$rows=[];
    foreach($pool as $p){$w=pw_worker_fields($p->ID);if(($w['status']??'')==='inactive'||pw_submission_exists($vid,$p->ID))continue;$m=pw_match_worker_to_vacancy($p->ID,$vid);$rows[]=['id'=>$p->ID,'w'=>$w,'m'=>$m];}
    usort($rows,fn($a,$b)=>(int)$b['m']['score']<=>(int)$a['m']['score']);$rows=array_slice($rows,0,5);if(!$rows)return '';
    ob_start(); ?><section class="pw-card pw-v510-smart-match"><div class="pw-card-head"><div><span class="pw-kicker">PRO · <?php echo esc_html(pw_t('SMART-MATCHING','SMART MATCHING')); ?></span><h2><?php echo esc_html(pw_t('Die besten Profile in einem Schritt','The best profiles in one step')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Bis zu fünf passende Mitarbeiter auswählen und gemeinsam zuordnen. Namen bleiben intern.','Select up to five matching employees and submit them together. Names remain internal.')); ?></p></div></div><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_v510_bulk_submit"><input type="hidden" name="vacancy_id" value="<?php echo (int)$vid; ?>"><?php wp_nonce_field('pw_v510_bulk_submit'); ?><div class="pw-v510-smart-list"><?php foreach($rows as $r): ?><label><input type="checkbox" name="worker_ids[]" value="<?php echo (int)$r['id']; ?>"><span class="pw-profile-code small"><?php echo esc_html(pw_initials($r['w']['role'])); ?></span><div><b><?php echo esc_html($r['w']['full_name']?:$r['w']['code']); ?></b><small><?php echo esc_html($r['w']['role'].' · '.$r['w']['location']); ?></small><p><?php echo esc_html(implode(' · ',array_slice((array)($r['m']['reasons']??[]),0,2))); ?></p></div><strong><?php echo (int)$r['m']['score']; ?>%</strong></label><?php endforeach; ?></div><button class="pw-btn primary small"><?php echo pw_icon('spark'); ?> <?php echo esc_html(pw_t('Ausgewählte Profile zuordnen','Submit selected profiles')); ?></button></form></section><?php return ob_get_clean();
}

/* Insert Smart Match before the existing vacancy pool on agency detail. */
function pw_v510_inject_smart_match($html){
    return $html;
}

/* -------------------------------------------------------------------------
 * Max capacity forecast – internal data, no pseudo-AI
 * ---------------------------------------------------------------------- */
function pw_v510_capacity_forecast($uid,$compact=false){
    if(!pw_can('capacity_forecast',$uid))return '';$workers=get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']);$today=wp_date('Y-m-d');$d7=wp_date('Y-m-d',time()+7*DAY_IN_SECONDS);$d30=wp_date('Y-m-d',time()+30*DAY_IN_SECONDS);$now=$week=$month=$assigned=0;
    foreach($workers as $id){$w=pw_worker_fields($id);$from=$w['available_from']?:$today;if($w['status']==='assigned'){$assigned++;continue;}if($w['status']!=='available')continue;if($from<=$today)$now++;elseif($from<=$d7)$week++;elseif($from<=$d30)$month++;}
    $demand=pw_v498_count_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','meta_query'=>[['key'=>'pw_status','value'=>'open']]]);$gap=max(0,$demand-($now+$week));
    ob_start(); ?><section class="pw-card pw-v510-forecast <?php echo $compact?'compact':''; ?>"><div class="pw-card-head"><div><span class="pw-kicker">MAX · <?php echo esc_html(pw_t('KAPAZITÄTSVORSCHAU','CAPACITY FORECAST')); ?></span><h2><?php echo esc_html(pw_t('Was wird in den nächsten 30 Tagen frei?','What becomes available in the next 30 days?')); ?></h2></div><span class="pw-v510-forecast-signal <?php echo $gap?'warning':'success'; ?>"><?php echo $gap?esc_html(pw_t('Engpass möglich','Possible gap')):esc_html(pw_t('Kapazität gut','Capacity healthy')); ?></span></div><div class="pw-v510-forecast-bars"><div><span><?php echo esc_html(pw_t('Jetzt frei','Free now')); ?></span><b><?php echo $now; ?></b><i style="--v:<?php echo min(100,$now*10); ?>%"></i></div><div><span><?php echo esc_html(pw_t('in 7 Tagen','in 7 days')); ?></span><b><?php echo $week; ?></b><i style="--v:<?php echo min(100,$week*10); ?>%"></i></div><div><span><?php echo esc_html(pw_t('in 30 Tagen','in 30 days')); ?></span><b><?php echo $month; ?></b><i style="--v:<?php echo min(100,$month*10); ?>%"></i></div><div><span><?php echo esc_html(pw_t('im Einsatz','assigned')); ?></span><b><?php echo $assigned; ?></b><i style="--v:<?php echo min(100,$assigned*10); ?>%"></i></div></div></section><?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Live chat – poll only the open thread, return only new messages
 * ---------------------------------------------------------------------- */
function pw_ajax_v510_chat_updates(){
    pw_ajax_guard();$uid=get_current_user_id();$sid=(int)($_POST['submission_id']??0);$last=(int)($_POST['last_id']??0);if(!$sid||!pw_can_access_submission($sid,$uid)||!pw_submission_chat_open($sid))wp_send_json_error(['message'=>pw_t('Chat nicht verfügbar.','Chat unavailable.')],403);
    $posts=get_posts(['post_type'=>'pw_message','post_status'=>'publish','posts_per_page'=>80,'orderby'=>'ID','order'=>'ASC','meta_query'=>[['key'=>'pw_submission_id','value'=>$sid]]]);$items=[];$max=$last;
    foreach($posts as $m){if((int)$m->ID<=$last)continue;$mine=(int)$m->post_author===$uid;$items[]=['id'=>(int)$m->ID,'mine'=>$mine,'message'=>esc_html($m->post_content),'time'=>wp_date('d.m. · H:i',get_post_time('U',true,$m))];$max=max($max,(int)$m->ID);if(!$mine&&(int)pw_meta($m->ID,'pw_recipient',0)===$uid)update_post_meta($m->ID,'pw_read','1');}
    wp_send_json_success(['items'=>$items,'last_id'=>$max,'unread'=>pw_unread_message_count($uid),'server_time'=>wp_date('H:i:s')]);
}
add_action('wp_ajax_pw_v510_chat_updates','pw_ajax_v510_chat_updates');

/* -------------------------------------------------------------------------
 * Register current shortcodes after every older compatibility layer.
 * ---------------------------------------------------------------------- */
function pw_v510_register_shortcodes(){
    remove_shortcode('pw_dashboard');add_shortcode('pw_dashboard','pw_shortcode_dashboard_v510');
    remove_shortcode('pw_workers');add_shortcode('pw_workers','pw_shortcode_workers_v510');
    remove_shortcode('pw_crm');add_shortcode('pw_crm','pw_shortcode_crm_v510');
    remove_shortcode('pw_market_live');add_shortcode('pw_market_live','pw_shortcode_market_v510');
    remove_shortcode('pw_automations');add_shortcode('pw_automations','pw_shortcode_automations_v510');
}
add_action('init','pw_v510_register_shortcodes',1900);

/* Add Smart Match panel to agency vacancy detail by filtering final shortcode output. */
function pw_v510_vacancies_shortcode_wrapper($atts=[]){
    // Delegate to the established v4.8 workflow; only enhance details after render.
    $html=pw_shortcode_vacancies();
    if(pw_user_role()==='agency'&&!empty($_GET['view'])&&pw_can('smart_matching')){
        $panel=pw_v510_smart_match_panel((int)$_GET['view'],get_current_user_id());
        if($panel){
            $needle='</div></section>';
            // The detail already ends with the employee pool. Adding before the shell end is safer than rewriting business logic.
            $html=str_replace('</main></section></div>',$panel.'</main></section></div>',$html);
            if(strpos($html,$panel)===false)$html=$html.$panel;
        }
    }
    return $html;
}
function pw_v510_register_vacancies(){remove_shortcode('pw_vacancies');add_shortcode('pw_vacancies','pw_shortcode_vacancies');}
add_action('init','pw_v510_register_vacancies',1950);

/* Version-specific changelog note for operators. */
