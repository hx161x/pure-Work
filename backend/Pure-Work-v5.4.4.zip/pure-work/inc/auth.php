<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work authentication, email verification and SMTP transport.
 * Existing v1/v2 users without the pw_email_verified meta are treated as verified
 * so an update cannot lock out existing customers. Every new registration starts unverified and receives a confirmation link.
 */
function pw_email_is_verified($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    if (user_can($user_id, 'manage_options')) return true;
    $value = get_user_meta($user_id, 'pw_email_verified', true);
    if ($value === '') return true; // Legacy account migration.
    return $value === '1';
}

function pw_verification_token_hash($token) {
    return hash_hmac('sha256', (string)$token, wp_salt('auth'));
}

function pw_create_verification_token($user_id) {
    try {
        $token = bin2hex(random_bytes(24));
    } catch (Exception $e) {
        $token = wp_generate_password(48, false, false);
    }
    update_user_meta($user_id, 'pw_email_verify_hash', pw_verification_token_hash($token));
    update_user_meta($user_id, 'pw_email_verify_expires', time() + (2 * DAY_IN_SECONDS));
    return $token;
}

function pw_send_verification_email($user_id) {
    $user = get_userdata($user_id);
    if (!$user || !is_email($user->user_email)) return false;
    $token = pw_create_verification_token($user_id);
    $url = pw_page_url('verify', ['uid' => $user_id, 'token' => $token]);
    $company = pw_user_meta($user_id, 'pw_company', 'dein Unternehmen');
    $lang = pw_user_meta($user_id, 'pw_lang', function_exists('pw_current_lang') ? pw_current_lang() : 'de');
    if ($lang === 'en') {
        $body = 'Hello '.esc_html($user->display_name).",\n\nthanks for registering ".esc_html($company)." with Pure Work. Please confirm your business email address. Sign-in is enabled after confirmation. The link is valid for 48 hours.";
        return pw_send_mail($user->user_email,'Pure Work – Confirm your email','Confirm your email address',$body,'Confirm email',$url);
    }
    $body = 'Hallo '.esc_html($user->display_name).",\n\ndanke für die Registrierung von ".esc_html($company)." bei Pure Work. Bitte bestätige jetzt deine geschäftliche E-Mail-Adresse. Erst danach ist die Anmeldung freigeschaltet. Der Bestätigungslink ist 48 Stunden gültig.";
    return pw_send_mail($user->user_email,'Pure Work – E-Mail-Adresse bestätigen','E-Mail-Adresse bestätigen',$body,'E-Mail bestätigen',$url);
}

function pw_verify_email_token($user_id, $token) {
    $user_id = (int)$user_id;
    $token = (string)$token;
    if (!$user_id || !$token || !get_userdata($user_id)) return new WP_Error('invalid', 'Ungültiger Bestätigungslink.');
    if (pw_email_is_verified($user_id)) return true;
    $stored = (string)get_user_meta($user_id, 'pw_email_verify_hash', true);
    $expires = (int)get_user_meta($user_id, 'pw_email_verify_expires', true);
    if (!$stored || !$expires || $expires < time()) return new WP_Error('expired', 'Der Bestätigungslink ist abgelaufen.');
    if (!hash_equals($stored, pw_verification_token_hash($token))) return new WP_Error('invalid', 'Ungültiger Bestätigungslink.');

    update_user_meta($user_id, 'pw_email_verified', '1');
    update_user_meta($user_id, 'pw_email_verified_at', time());
    delete_user_meta($user_id, 'pw_email_verify_hash');
    delete_user_meta($user_id, 'pw_email_verify_expires');

    // Auftraggeber sollen möglichst reibungslos starten können. Personaldienstleister
    // bleiben wegen AÜG/Unternehmensprüfung im manuellen Prüfprozess.
    if (pw_user_role($user_id) === 'client' && get_option('pw_auto_verify_clients', '1') === '1') {
        update_user_meta($user_id, 'pw_company_verified', '1');
    }

    $user = get_userdata($user_id);
    if ($user) {
        $lang = pw_user_meta($user_id, 'pw_lang', 'de');
        if ($lang === 'en') {
            $body = pw_user_role($user_id) === 'client'
                ? 'Your email address has been confirmed. You can now sign in. Sensitive marketplace features become available after company verification.'
                : 'Your email address has been confirmed. You can now sign in. Full marketplace access follows after company and AÜG permit verification.';
            pw_send_mail($user->user_email,'Pure Work – Email confirmed','Your account is activated',$body,'Sign in now',pw_page_url('login'));
        } else {
            $body = pw_user_role($user_id) === 'client'
                ? 'Deine E-Mail-Adresse wurde bestätigt. Du kannst dich jetzt anmelden. Sensible Marktplatzfunktionen werden nach der Unternehmensprüfung freigeschaltet.'
                : 'Deine E-Mail-Adresse wurde bestätigt. Du kannst dich jetzt anmelden. Für den vollständigen Marktplatzzugang prüfen wir anschließend dein Unternehmen und deine AÜG-Unterlagen.';
            pw_send_mail($user->user_email,'Pure Work – E-Mail bestätigt','Dein Zugang ist aktiviert',$body,'Jetzt anmelden',pw_page_url('login'));
        }
    }
    return true;
}

function pw_auth_require_verified($user, $username, $password) {
    if (!($user instanceof WP_User)) return $user;
    if (user_can($user, 'manage_options')) return $user;
    if (!in_array(pw_user_role($user->ID), ['agency','client'], true)) return $user;
    if (get_option('pw_require_email_verification', '1') === '1' && !pw_email_is_verified($user->ID)) {
        return new WP_Error('pw_unverified', 'Bitte bestätige zuerst deine geschäftliche E-Mail-Adresse.');
    }
    return $user;
}
add_filter('authenticate', 'pw_auth_require_verified', 40, 3);

function pw_handle_resend_verification() {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), 'pw_resend_verification')) {
        wp_die('Sicherheitsprüfung fehlgeschlagen.');
    }
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $user = $email ? get_user_by('email', $email) : false;
    // Same public response regardless of whether the account exists.
    $sent = true;
    if ($user && in_array(pw_user_role($user->ID), ['agency', 'client'], true) && !pw_email_is_verified($user->ID)) {
        $sent = pw_send_verification_email($user->ID);
    }
    wp_safe_redirect(pw_page_url('login', ['resent' => 1, 'email' => $email, 'mail_error' => $sent ? 0 : 1]));
    exit;
}
add_action('admin_post_nopriv_pw_resend_verification', 'pw_handle_resend_verification');
add_action('admin_post_pw_resend_verification', 'pw_handle_resend_verification');

function pw_handle_verify_email_request() {
    if (!is_page()) return;
    $ids = (array)get_option('pw_page_ids', []);
    if (empty($ids['verify']) || get_queried_object_id() !== (int)$ids['verify']) return;
    $uid = (int)($_GET['uid'] ?? 0);
    $token = sanitize_text_field(wp_unslash($_GET['token'] ?? ''));
    if (!$uid || !$token) return;
    $result = pw_verify_email_token($uid, $token);
    if (is_wp_error($result)) {
        $code = $result->get_error_code() === 'expired' ? 'expired' : 'invalid';
        wp_safe_redirect(pw_page_url('verify', ['state' => $code, 'uid' => $uid]));
        exit;
    }
    $verified_user = get_userdata($uid);
    wp_safe_redirect(pw_page_url('login', ['verified' => 1, 'email' => $verified_user ? $verified_user->user_email : '']));
    exit;
}
add_action('template_redirect', 'pw_handle_verify_email_request', 2);

/** SMTP configuration. Uses WordPress' bundled PHPMailer; no external plugin required. */
/**
 * Pure Work 4.9.3: historically two different admin screens stored the SMTP
 * credentials under different option names (pw_smtp_username/pw_smtp_password
 * vs. pw_smtp_user/pw_smtp_pass). PHPMailer only ever read one pair, so a
 * correctly filled SMTP form still produced "mail could not be sent" and every
 * confirmation / password-reset mail silently failed. We now read both.
 */
function pw_smtp_username() {
    $value = trim((string)get_option('pw_smtp_username', ''));
    if ($value === '') $value = trim((string)get_option('pw_smtp_user', ''));
    return $value;
}

function pw_smtp_password() {
    $value = (string)get_option('pw_smtp_password', '');
    if ($value === '') $value = (string)get_option('pw_smtp_pass', '');
    return $value;
}

function pw_smtp_is_configured() {
    return get_option('pw_smtp_enabled', '0') === '1' && trim((string)get_option('pw_smtp_host', '')) !== '';
}

function pw_configure_phpmailer($phpmailer) {
    if (get_option('pw_smtp_enabled', '0') !== '1') return;
    $host = trim((string)get_option('pw_smtp_host', ''));
    if (!$host) return;
    $phpmailer->isSMTP();
    $phpmailer->Host = $host;
    $phpmailer->Port = max(1, (int)get_option('pw_smtp_port', 587));
    $enc = (string)get_option('pw_smtp_encryption', 'tls');
    $phpmailer->SMTPSecure = in_array($enc, ['tls', 'ssl'], true) ? $enc : '';
    $phpmailer->SMTPAutoTLS = $phpmailer->SMTPSecure === '' ? false : true;
    $phpmailer->Timeout = 20;
    $phpmailer->CharSet = 'UTF-8';
    $phpmailer->SMTPAuth = get_option('pw_smtp_auth', '1') === '1';
    if ($phpmailer->SMTPAuth) {
        $phpmailer->Username = pw_smtp_username();
        $phpmailer->Password = pw_smtp_password();
    }
    $from = sanitize_email((string)get_option('pw_mail_from', get_option('admin_email')));
    $from_name = sanitize_text_field((string)get_option('pw_mail_from_name', get_option('pw_company_name', 'Pure Work')));
    if ($from) $phpmailer->setFrom($from, $from_name ?: 'Pure Work', false);
}
add_action('phpmailer_init', 'pw_configure_phpmailer');

function pw_mail_from_filter($email) {
    $custom = sanitize_email((string)get_option('pw_mail_from', ''));
    return $custom ?: $email;
}
function pw_mail_from_name_filter($name) {
    $custom = sanitize_text_field((string)get_option('pw_mail_from_name', ''));
    return $custom ?: ($name ?: 'Pure Work');
}
add_filter('wp_mail_from', 'pw_mail_from_filter');
add_filter('wp_mail_from_name', 'pw_mail_from_name_filter');

function pw_mail_failed_log($error) {
    update_option('pw_last_mail_status', 'error', false);
    update_option('pw_last_mail_time', time(), false);
    if (is_wp_error($error)) update_option('pw_last_mail_error', $error->get_error_message(), false);
}
add_action('wp_mail_failed', 'pw_mail_failed_log');

function pw_mail_succeeded_log($mail_data) {
    update_option('pw_last_mail_status', 'success', false);
    update_option('pw_last_mail_time', time(), false);
    delete_option('pw_last_mail_error');
}
add_action('wp_mail_succeeded', 'pw_mail_succeeded_log');
