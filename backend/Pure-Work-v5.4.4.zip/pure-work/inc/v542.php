<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.4.2 – employee/customer experience + payment polish.
 * Keeps 5.4.1 dashboard/vacancy flow intact.
 */

function pw_v542_upgrade(){
    if(get_option('pw_version_542','')==='5.4.2') return;
    if(function_exists('pw_install_theme')) pw_install_theme();
    update_option('pw_version_542','5.4.2',false);
    update_option('pw_version','5.4.2',false);
    flush_rewrite_rules(false);
}
add_action('init','pw_v542_upgrade',5000);

function pw_v542_status_label($status){
    $map=[
        'available'=>pw_t('Verfügbar','Available'),
        'reserved'=>pw_t('Reserviert','Reserved'),
        'assigned'=>pw_t('Im Einsatz','Assigned'),
        'inactive'=>pw_t('Inaktiv','Inactive'),
    ];
    return $map[$status]??ucfirst((string)$status);
}

function pw_v542_worker_counts($posts){
    $out=['all'=>count($posts),'available'=>0,'reserved'=>0,'assigned'=>0,'inactive'=>0,'incomplete'=>0];
    foreach($posts as $p){
        $w=pw_worker_fields($p->ID);$st=$w['status']??'available';if(isset($out[$st]))$out[$st]++;
        [$score]=pw_v510_worker_completeness($w);if($score<80)$out['incomplete']++;
    }
    return $out;
}

function pw_v542_worker_card($p,$w){
    [$score,$missing]=pw_v510_worker_completeness($w);
    $status=$w['status']??'available';
    $quals=array_slice((array)($w['qualifications']??[]),0,3);
    ob_start(); ?>
    <article class="pw542-worker-card" data-worker-status="<?php echo esc_attr($status); ?>" data-worker-quality="<?php echo (int)$score; ?>">
      <a class="pw542-worker-main" href="<?php echo esc_url(pw_page_url('workers',['view'=>$p->ID])); ?>">
        <div class="pw542-worker-top">
          <span class="pw542-avatar"><?php echo esc_html(pw_initials($w['full_name']?:$w['role'])); ?></span>
          <div class="pw542-worker-ident"><b><?php echo esc_html($w['full_name']?:$w['code']); ?></b><small><?php echo esc_html($w['role']?:pw_t('Tätigkeit ergänzen','Add role')); ?></small></div>
          <span class="pw542-status <?php echo esc_attr($status); ?>"><i></i><?php echo esc_html(pw_v542_status_label($status)); ?></span>
        </div>
        <div class="pw542-worker-meta">
          <span><?php echo pw_icon('map'); ?><b><?php echo esc_html($w['location']?:'–'); ?></b><small><?php echo esc_html(pw_t('Einsatzgebiet','Region')); ?></small></span>
          <span><?php echo pw_icon('calendar'); ?><b><?php echo esc_html($w['available_from']?pw_format_date($w['available_from']):'–'); ?></b><small><?php echo esc_html(pw_t('Verfügbar ab','Available from')); ?></small></span>
          <span><?php echo pw_icon('briefcase'); ?><b><?php echo (int)($w['experience']??0); ?> <?php echo esc_html(pw_t('J.','yrs')); ?></b><small><?php echo esc_html(pw_t('Erfahrung','Experience')); ?></small></span>
        </div>
        <?php if($quals): ?><div class="pw542-worker-chips"><?php foreach($quals as $q): ?><span><?php echo esc_html($q); ?></span><?php endforeach; ?></div><?php endif; ?>
        <div class="pw542-worker-quality"><div><span><i style="width:<?php echo (int)$score; ?>%"></i></span><b><?php echo (int)$score; ?>%</b></div><small><?php echo esc_html($missing?pw_t('Profil kann noch stärker werden','Profile can be improved'):pw_t('Profil vollständig','Profile complete')); ?></small></div>
      </a>
      <footer><a href="<?php echo esc_url(pw_page_url('workers',['view'=>$p->ID])); ?>"><?php echo pw_icon('document'); ?><?php echo esc_html(pw_t('Profil öffnen','Open profile')); ?></a><a href="<?php echo esc_url(pw_page_url('workers',['edit'=>$p->ID])); ?>"><?php echo pw_icon('settings'); ?><?php echo esc_html(pw_t('Bearbeiten','Edit')); ?></a></footer>
    </article>
    <?php return ob_get_clean();
}

function pw_shortcode_workers_v542(){
    if(!is_user_logged_in()) return pw_require_login_html();
    $uid=get_current_user_id();
    ob_start();
    echo pw_portal_shell_start(pw_t('Mitarbeiter','Employees'),pw_t('Pool, Verfügbarkeit und Profile – klar an einem Ort.','Pool, availability and profiles in one clear workspace.'));
    echo pw_flash_messages();
    if(pw_user_role($uid)!=='agency'){
        echo '<section class="pw-card pw-empty"><p>'.esc_html(pw_t('Dieser Bereich ist für Zeitarbeitsfirmen.','This area is for staffing agencies.')).'</p></section>'.pw_portal_shell_end();
        return ob_get_clean();
    }
    if(isset($_GET['new'])||isset($_GET['edit'])){
        $wf=isset($_GET['edit'])?(int)$_GET['edit']:0;
        echo '<div class="pw542-form-shell">'.(function_exists('pw_worker_form_v540')?pw_worker_form_v540($wf):pw_worker_form($wf)).'</div>';
        echo pw_portal_shell_end();return ob_get_clean();
    }
    if(isset($_GET['import'])){
        if(!function_exists('pw_can')||!pw_can('worker_import',$uid)){echo pw_plan_gate('worker_import');echo pw_portal_shell_end();return ob_get_clean();}
        ?>
        <section class="pw542-import-page"><div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('workers')); ?>">← <?php echo esc_html(pw_t('Mitarbeiter','Employees')); ?></a><span class="pw-kicker">PRO · <?php echo esc_html(pw_t('CSV-IMPORT','CSV IMPORT')); ?></span><h2><?php echo esc_html(pw_t('Mehrere Mitarbeiter in einem Schritt','Add multiple employees in one step')); ?></h2><p><?php echo esc_html(pw_t('Bis zu 500 Profile importieren. Danach kannst du jedes Profil einzeln prüfen und vervollständigen.','Import up to 500 profiles, then review and complete each record individually.')); ?></p></div></div><section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('DATEI VORBEREITEN','PREPARE FILE')); ?></span><h2><?php echo esc_html(pw_t('CSV hochladen','Upload CSV')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Verwende die Beispielvorlage, damit Felder korrekt zugeordnet werden.','Use the sample template so fields are mapped correctly.')); ?></p></div><a class="pw-btn ghost small" href="<?php echo esc_url(PW_URI . '/assets/sample-import.csv'); ?>" download><?php echo pw_icon('document'); ?><?php echo esc_html(pw_t('Beispiel herunterladen','Download sample')); ?></a></div><form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw542-import-form"><input type="hidden" name="action" value="pw_worker_import"><?php wp_nonce_field('pw_worker_import'); ?><label><?php echo pw_icon('upload'); ?><div><b><?php echo esc_html(pw_t('CSV-Datei auswählen','Choose CSV file')); ?></b><small><?php echo esc_html(pw_t('CSV, maximal 500 Datensätze','CSV, up to 500 records')); ?></small></div><input type="file" name="csv_file" accept=".csv,text/csv" required></label><button class="pw-btn primary"><?php echo pw_icon('upload'); ?><?php echo esc_html(pw_t('Mitarbeiter importieren','Import employees')); ?></button></form></section></section>
        <?php echo pw_portal_shell_end();return ob_get_clean();
    }
    if(isset($_GET['view'])){
        $id=(int)$_GET['view'];
        echo '<div class="pw542-detail-shell">'.pw_v510_worker_detail($id,$uid).'</div>';
        if(function_exists('pw_v511_profile_studio')) echo pw_v511_profile_studio($id,$uid);
        echo pw_portal_shell_end();return ob_get_clean();
    }

    $q=sanitize_text_field(wp_unslash($_GET['q']??''));
    $status=sanitize_key(wp_unslash($_GET['status']??''));
    $posts=get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>300,'orderby'=>'modified','order'=>'DESC']);
    $counts=pw_v542_worker_counts($posts);$rows=[];
    foreach($posts as $p){
        $w=pw_worker_fields($p->ID);[$score]=pw_v510_worker_completeness($w);
        $hay=pw_lower(($w['full_name']??'').' '.($w['role']??'').' '.($w['location']??'').' '.($w['code']??'').' '.pw_list_string($w['qualifications']??[]));
        if($q&&!pw_contains($hay,pw_lower($q)))continue;
        if($status==='incomplete'&&$score>=80)continue;
        if($status&&$status!=='incomplete'&&$status!==($w['status']??''))continue;
        $rows[]=[$p,$w];
    }
    ?>
    <section class="pw542-people-hero">
      <div><span class="pw-kicker"><?php echo esc_html(pw_t('MITARBEITER-COCKPIT','EMPLOYEE COCKPIT')); ?></span><h1><?php echo esc_html(pw_t('Dein Pool. Sofort verständlich.','Your pool. Instantly clear.')); ?></h1><p><?php echo esc_html(pw_t('Verfügbarkeit, Profilqualität und Dokumente ohne Tabellenchaos. Ein Klick öffnet die komplette Mitarbeiterakte.','Availability, profile quality and documents without table clutter. One click opens the full employee record.')); ?></p></div>
      <div class="pw542-people-actions"><a class="pw-btn primary xl" href="<?php echo esc_url(pw_page_url('workers',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?><?php echo esc_html(pw_t('Mitarbeiter anlegen','Add employee')); ?></a><?php if(function_exists('pw_can')&&pw_can('worker_import',$uid)): ?><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('workers',['import'=>1])); ?>"><?php echo pw_icon('upload'); ?><?php echo esc_html(pw_t('CSV-Import','CSV import')); ?></a><?php endif; ?></div>
    </section>

    <div class="pw542-people-stats">
      <a class="<?php echo $status===''?'active':''; ?>" href="<?php echo esc_url(pw_page_url('workers')); ?>"><span><?php echo pw_icon('users'); ?></span><div><b><?php echo (int)$counts['all']; ?></b><small><?php echo esc_html(pw_t('Alle Profile','All profiles')); ?></small></div></a>
      <a class="<?php echo $status==='available'?'active':''; ?>" href="<?php echo esc_url(pw_page_url('workers',['status'=>'available'])); ?>"><span class="success"><?php echo pw_icon('check'); ?></span><div><b><?php echo (int)$counts['available']; ?></b><small><?php echo esc_html(pw_t('Verfügbar','Available')); ?></small></div></a>
      <a class="<?php echo $status==='assigned'?'active':''; ?>" href="<?php echo esc_url(pw_page_url('workers',['status'=>'assigned'])); ?>"><span class="brand"><?php echo pw_icon('briefcase'); ?></span><div><b><?php echo (int)$counts['assigned']; ?></b><small><?php echo esc_html(pw_t('Im Einsatz','Assigned')); ?></small></div></a>
      <a class="<?php echo $status==='incomplete'?'active':''; ?>" href="<?php echo esc_url(pw_page_url('workers',['status'=>'incomplete'])); ?>"><span class="warning"><?php echo pw_icon('alert'); ?></span><div><b><?php echo (int)$counts['incomplete']; ?></b><small><?php echo esc_html(pw_t('Zu ergänzen','To complete')); ?></small></div></a>
    </div>

    <?php if(function_exists('pw_v511_availability_strip')&&pw_v511_plan_rank($uid)>=2) echo '<div class="pw542-availability-wrap">'.pw_v511_availability_strip($uid).'</div>'; ?>

    <form method="get" class="pw542-people-toolbar"><label><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($q); ?>" placeholder="<?php echo esc_attr(pw_t('Mitarbeiter, Tätigkeit, Ort oder Qualifikation suchen','Search employee, role, location or qualification')); ?>"></label><?php if($status): ?><input type="hidden" name="status" value="<?php echo esc_attr($status); ?>"><?php endif; ?><button class="pw-btn ghost small"><?php echo esc_html(pw_t('Suchen','Search')); ?></button><span><?php echo count($rows); ?> <?php echo esc_html(pw_t('Treffer','results')); ?></span></form>

    <div class="pw542-worker-grid"><?php if(!$rows): ?><section class="pw-card pw-empty"><?php echo pw_icon('users'); ?><h3><?php echo esc_html(pw_t('Keine passenden Profile','No matching profiles')); ?></h3><p><?php echo esc_html(pw_t('Filter zurücksetzen oder direkt einen neuen Mitarbeiter anlegen.','Reset the filter or add a new employee.')); ?></p><a class="pw-btn primary small" href="<?php echo esc_url(pw_page_url('workers',['new'=>1])); ?>"><?php echo esc_html(pw_t('Mitarbeiter anlegen','Add employee')); ?></a></section><?php else: foreach($rows as [$p,$w]) echo pw_v542_worker_card($p,$w); endif; ?></div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

function pw_v542_customer_next_text($l){
    if(!empty($l['next_followup'])){
        $today=wp_date('Y-m-d');$date=$l['next_followup'];
        if($date<$today)return pw_t('Wiedervorlage überfällig','Follow-up overdue');
        if($date===$today)return pw_t('Heute nachfassen','Follow up today');
        return pw_t('Nächster Kontakt','Next contact').' '.pw_format_date($date);
    }
    if(empty($l['contact']))return pw_t('Ansprechpartner ergänzen','Add contact');
    if(empty($l['job_title']))return pw_t('Bedarf klären','Clarify demand');
    return pw_t('Nächsten Schritt festlegen','Set next step');
}

function pw_v542_customer_card($p,$l){
    $due=!empty($l['next_followup'])&&$l['next_followup']<=wp_date('Y-m-d')&&!in_array($l['stage'],['won','lost'],true);
    ob_start(); ?>
    <article class="pw542-customer-card <?php echo $due?'is-due':''; ?>">
      <a class="pw542-customer-main" href="<?php echo esc_url(pw_page_url('crm',['lead'=>$p->ID])); ?>">
        <header><span class="pw542-company-avatar"><?php echo esc_html(pw_initials($l['company'])); ?></span><div><h3><?php echo esc_html($l['company']); ?></h3><p><?php echo esc_html(trim(($l['city']?:'').($l['industry']?' · '.$l['industry']:''),' ·')); ?></p></div><span class="pw-badge muted"><?php echo esc_html(pw_crm_stage_label($l['stage'])); ?></span></header>
        <div class="pw542-customer-contact"><span><?php echo pw_icon('users'); ?><div><small><?php echo esc_html(pw_t('Ansprechpartner','Contact')); ?></small><b><?php echo esc_html($l['contact']?:pw_t('noch offen','not set')); ?></b></div></span><span><?php echo pw_icon('briefcase'); ?><div><small><?php echo esc_html(pw_t('Aktueller Bedarf','Current demand')); ?></small><b><?php echo esc_html($l['job_title']?:pw_t('noch offen','not set')); ?></b></div></span></div>
        <div class="pw542-next-step <?php echo $due?'warning':''; ?>"><span><?php echo pw_icon($due?'alert':'calendar'); ?></span><div><small><?php echo esc_html(pw_t('NÄCHSTER SCHRITT','NEXT STEP')); ?></small><b><?php echo esc_html(pw_v542_customer_next_text($l)); ?></b></div><?php echo pw_icon('arrow'); ?></div>
      </a>
      <footer><?php if($l['phone']): ?><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$l['phone'])); ?>" title="<?php echo esc_attr(pw_t('Anrufen','Call')); ?>"><?php echo pw_icon('phone'); ?><span><?php echo esc_html(pw_t('Anrufen','Call')); ?></span></a><?php endif; ?><?php if($l['email']): ?><a href="mailto:<?php echo esc_attr($l['email']); ?>" title="E-Mail"><?php echo pw_icon('message'); ?><span>E-Mail</span></a><?php endif; ?><a href="<?php echo esc_url(pw_page_url('crm',['lead'=>$p->ID])); ?>"><?php echo pw_icon('document'); ?><span><?php echo esc_html(pw_t('Kundenakte','Customer file')); ?></span></a></footer>
    </article>
    <?php return ob_get_clean();
}

function pw_shortcode_crm_v542(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();
    ob_start();echo pw_portal_shell_start(pw_t('Kunden','Customers'),pw_t('Kontakte, nächste Schritte und Chancen – ohne CRM-Ballast.','Contacts, next steps and opportunities without CRM clutter.'));echo pw_flash_messages();
    if(!pw_can('crm',$uid)){echo pw_plan_gate('crm');echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['lead'])){echo '<div class="pw542-detail-shell">'.pw_v510_crm_detail((int)$_GET['lead'],$uid).'</div>';echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['new'])){echo '<div class="pw542-form-shell">'.pw_v510_crm_new_form().'</div>';echo pw_portal_shell_end();return ob_get_clean();}
    $q=sanitize_text_field(wp_unslash($_GET['q']??''));$posts=pw_crm_get_leads($uid,['search'=>$q]);$m=pw_crm_dashboard_metrics($uid);$today=wp_date('Y-m-d');$due=[];
    foreach($posts as $p){$l=pw_crm_lead_fields($p->ID);if($l['next_followup']&&$l['next_followup']<=$today&&!in_array($l['stage'],['won','lost'],true))$due[]=$p;}
    ?>
    <section class="pw542-customer-hero"><div><span class="pw-kicker"><?php echo esc_html(pw_t('KUNDEN-COCKPIT','CUSTOMER COCKPIT')); ?></span><h1><?php echo esc_html(pw_t('Beziehungen statt CRM-Verwaltung.','Relationships instead of CRM administration.')); ?></h1><p><?php echo esc_html(pw_t('Du siehst sofort, wen du kontaktieren solltest, wo Bedarf besteht und was der nächste Schritt ist.','See immediately who to contact, where demand exists and what the next step is.')); ?></p></div><a class="pw-btn primary xl" href="<?php echo esc_url(pw_page_url('crm',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?><?php echo esc_html(pw_t('Kunde anlegen','Add customer')); ?></a></section>
    <div class="pw542-customer-stats"><div><span><?php echo pw_icon('building'); ?></span><b><?php echo (int)$m['total']; ?></b><small><?php echo esc_html(pw_t('Kunden & Leads','customers & leads')); ?></small></div><div class="<?php echo $m['due']?'warning':''; ?>"><span><?php echo pw_icon('bell'); ?></span><b><?php echo (int)$m['due']; ?></b><small><?php echo esc_html(pw_t('heute fällig','due today')); ?></small></div><div><span><?php echo pw_icon('check'); ?></span><b><?php echo (int)$m['won']; ?></b><small><?php echo esc_html(pw_t('gewonnen','won')); ?></small></div></div>
    <?php if($due): ?><section class="pw542-due-strip"><div><span><?php echo pw_icon('alert'); ?></span><div><b><?php echo esc_html(pw_t('Heute nachfassen','Follow up today')); ?></b><small><?php echo esc_html(sprintf(pw_t('%d Kontakte warten auf dich.','%d contacts are waiting.'),count($due))); ?></small></div></div><div><?php foreach(array_slice($due,0,4) as $p):$l=pw_crm_lead_fields($p->ID); ?><a href="<?php echo esc_url(pw_page_url('crm',['lead'=>$p->ID])); ?>"><span><?php echo esc_html(pw_initials($l['company'])); ?></span><b><?php echo esc_html($l['company']); ?></b></a><?php endforeach; ?></div></section><?php endif; ?>
    <form method="get" class="pw542-people-toolbar"><label><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($q); ?>" placeholder="<?php echo esc_attr(pw_t('Unternehmen, Ansprechpartner oder Bedarf suchen','Search company, contact or demand')); ?>"></label><button class="pw-btn ghost small"><?php echo esc_html(pw_t('Suchen','Search')); ?></button><span><?php echo count($posts); ?> <?php echo esc_html(pw_t('Einträge','entries')); ?></span></form>
    <div class="pw542-customer-grid"><?php if(!$posts): ?><section class="pw-card pw-empty"><h3><?php echo esc_html(pw_t('Noch keine Kunden','No customers yet')); ?></h3><p><?php echo esc_html(pw_t('Lege den ersten Kunden in weniger als einer Minute an.','Add your first customer in under a minute.')); ?></p><a class="pw-btn primary small" href="<?php echo esc_url(pw_page_url('crm',['new'=>1])); ?>"><?php echo esc_html(pw_t('Kunde anlegen','Add customer')); ?></a></section><?php else:foreach($posts as $p){$l=pw_crm_lead_fields($p->ID);echo pw_v542_customer_card($p,$l);}endif;?></div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

function pw_v542_chat_summary($uid){
    $threads=array_values(array_filter(pw_user_threads($uid),function($t){return pw_submission_chat_open($t->ID);}));$unread=0;$offers=0;
    foreach($threads as $t){$tm=pw_v520_thread_meta($t->ID,$uid);$unread+=$tm['unread'];foreach(pw_thread_messages($t->ID) as $m){$o=pw_v520_offer($m->ID);if($o&&($o['status']??'open')==='open')$offers++;}}
    return ['threads'=>count($threads),'unread'=>$unread,'offers'=>$offers];
}
function pw_shortcode_messages_v542(){
    $html=pw_shortcode_messages_v520();if(!is_user_logged_in())return $html;$s=pw_v542_chat_summary(get_current_user_id());
    ob_start();?><section class="pw542-chat-overview"><div><span class="pw542-live-dot"></span><div><b><?php echo esc_html(pw_t('Live verbunden','Live connected')); ?></b><small><?php echo esc_html(pw_t('Neue Nachrichten erscheinen automatisch.','New messages appear automatically.')); ?></small></div></div><span><b><?php echo (int)$s['threads']; ?></b><small><?php echo esc_html(pw_t('Unterhaltungen','conversations')); ?></small></span><span class="<?php echo $s['unread']?'warning':''; ?>"><b><?php echo (int)$s['unread']; ?></b><small><?php echo esc_html(pw_t('ungelesen','unread')); ?></small></span><span><b><?php echo (int)$s['offers']; ?></b><small><?php echo esc_html(pw_t('offene Angebote','open offers')); ?></small></span></section><?php $panel=ob_get_clean();
    return str_replace('<div class="pw-chat-layout pw-chat-v520"',$panel.'<div class="pw-chat-layout pw-chat-v520"',$html);
}

function pw_v542_assignment_summary($uid,$role){
    if($role==='agency')$ids=pw_v499_active_assignments($uid);else{$ids=[];foreach(pw_client_submissions($uid) as $s){$st=pw_meta($s->ID,'pw_status','submitted');if(in_array($st,['requested','accepted','identity_released','confirmed','planned'],true))$ids[]=$s->ID;}}
    $planned=$clarify=0;foreach($ids as $sid){$b=pw_v499_submission_bucket(pw_meta($sid,'pw_status','submitted'));if($b==='planned')$planned++;else $clarify++;}$risks=$role==='agency'&&function_exists('pw_v499_assignment_risks')?count(pw_v499_assignment_risks($uid,7)):0;
    ob_start();?><section class="pw542-assignment-summary"><div><span><?php echo pw_icon('calendar'); ?></span><div><b><?php echo count($ids); ?></b><small><?php echo esc_html(pw_t('aktive Vorgänge','active items')); ?></small></div></div><div><span><?php echo pw_icon('check'); ?></span><div><b><?php echo $planned; ?></b><small><?php echo esc_html(pw_t('geplant','planned')); ?></small></div></div><div class="<?php echo $clarify?'warning':''; ?>"><span><?php echo pw_icon('message'); ?></span><div><b><?php echo $clarify; ?></b><small><?php echo esc_html(pw_t('in Klärung','being clarified')); ?></small></div></div><?php if($role==='agency'):?><button type="button" class="pw542-risk-toggle <?php echo $risks?'has-risk':''; ?>" data-pw542-risk-toggle><?php echo pw_icon('alert'); ?><span><b><?php echo $risks; ?></b><small><?php echo esc_html(pw_t('Start in ≤ 7 Tagen','start in ≤ 7 days')); ?></small></span></button><?php endif;?></section><?php return ob_get_clean();
}
function pw_shortcode_assignments_v542(){
    $html=pw_shortcode_assignments();if(!is_user_logged_in())return $html;$uid=get_current_user_id();$role=pw_user_role($uid);$sum=pw_v542_assignment_summary($uid,$role);return str_replace('<section class="pw-v499-board-head">',$sum.'<section class="pw-v499-board-head">',$html);
}

function pw_v542_saved_payment_methods($uid){
    $customer=trim((string)pw_user_meta($uid,'pw_stripe_customer_id',''));if(!$customer||!function_exists('pw_v501_stripe_secret_ready')||!pw_v501_stripe_secret_ready())return [];$out=[];
    foreach(['card','sepa_debit'] as $type){$res=pw_stripe_api_get('payment_methods',['customer'=>$customer,'type'=>$type,'limit'=>5]);if(is_wp_error($res)||empty($res['data']))continue;foreach($res['data'] as $pm){if($type==='card')$label=ucfirst((string)($pm['card']['brand']??'Karte')).' •••• '.($pm['card']['last4']??'').' · '.($pm['card']['exp_month']??'').'/'.($pm['card']['exp_year']??'');else $label='SEPA •••• '.($pm['sepa_debit']['last4']??'');$out[]=['id'=>$pm['id']??'','type'=>$type,'label'=>$label];}}
    return $out;
}
function pw_v542_payment_methods_panel($uid){
    $methods=pw_v542_saved_payment_methods($uid);$secret=function_exists('pw_v501_stripe_secret_ready')&&pw_v501_stripe_secret_ready();$ready=function_exists('pw_stripe_ready')&&pw_stripe_ready();
    ob_start();?><section class="pw542-payment-panel"><div class="pw542-payment-copy"><span class="pw-kicker"><?php echo esc_html(pw_t('ZAHLUNGSMETHODEN','PAYMENT METHODS')); ?></span><h2><?php echo esc_html(pw_t('Zahlung einmal einrichten. Danach läuft das Abo automatisch.','Set up payment once. Subscription billing then runs automatically.')); ?></h2><p><?php echo esc_html(pw_t('Pure Work speichert keine Karten- oder Kontodaten. Die Zahlungsdaten werden sicher von Stripe verwaltet.','Pure Work does not store card or bank details. Payment data is securely managed by Stripe.')); ?></p></div><div class="pw542-payment-methods"><?php if($methods):foreach($methods as $m):?><div><span><?php echo pw_icon($m['type']==='card'?'card':'receipt'); ?></span><div><small><?php echo esc_html($m['type']==='card'?pw_t('KARTE','CARD'):'SEPA'); ?></small><b><?php echo esc_html($m['label']); ?></b></div><i><?php echo pw_icon('check'); ?></i></div><?php endforeach;else:?><div class="empty"><span><?php echo pw_icon('card'); ?></span><div><small><?php echo esc_html(pw_t('NOCH NICHT HINTERLEGT','NOT ADDED YET')); ?></small><b><?php echo esc_html(pw_t('Zahlungsmethode hinzufügen','Add payment method')); ?></b></div></div><?php endif;?></div><div class="pw542-payment-actions"><?php if($secret):?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_v501_payment_setup"><?php wp_nonce_field('pw_v501_payment_setup');?><button class="pw-btn primary"><?php echo pw_icon('plus'); ?><?php echo esc_html($methods?pw_t('Weitere Zahlungsart','Add another method'):pw_t('Zahlungsart hinterlegen','Add payment method')); ?></button></form><?php if($methods):?><a class="pw-btn ghost" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_customer_portal'),'pw_v500_customer_portal')); ?>"><?php echo pw_icon('settings'); ?><?php echo esc_html(pw_t('Zahlung & Abo verwalten','Manage payment & subscription')); ?></a><?php endif;?><?php else:?><span class="pw-source-note"><?php echo esc_html(pw_t('Stripe muss einmal durch den Administrator verbunden werden.','Stripe must be connected once by the administrator.')); ?></span><?php endif;?></div><?php if($secret&&!$ready):?><small class="pw542-payment-note"><?php echo esc_html(pw_t('Zahlungsmethoden können hinterlegt werden. Für kostenpflichtige Abos müssen zusätzlich die Stripe-Tarife synchronisiert sein.','Payment methods can be saved. Paid subscriptions additionally require synced Stripe plans.')); ?></small><?php endif;?></section><?php return ob_get_clean();
}
function pw_shortcode_account_v542(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();$role=pw_user_role();$tab=sanitize_key($_GET['tab']??'profile');if($tab!=='billing'||$role!=='agency')return pw_shortcode_account();
    ob_start();echo pw_portal_shell_start(pw_t('Konto & Einstellungen','Account & settings'),pw_t('Tarif, Zahlungsmethoden und Unternehmenszugang an einem Ort.','Plan, payment methods and company access in one place.'));echo pw_flash_messages();$tabs=['profile'=>pw_t('Unternehmen','Company'),'verification'=>pw_t('Verifizierung','Verification'),'notifications'=>pw_t('Benachrichtigungen','Notifications'),'billing'=>pw_t('Abo & Zahlung','Subscription & payment'),'security'=>pw_t('Sicherheit','Security')];echo '<nav class="pw-tabs">';foreach($tabs as $k=>$l)echo '<a class="'.($tab===$k?'active':'').'" href="'.esc_url(pw_page_url('account',['tab'=>$k])).'">'.esc_html($l).'</a>';echo '</nav>';echo pw_v542_payment_methods_panel($uid);echo pw_v502_subscription_workspace($uid);echo pw_v502_pricing_cards(true);if(!pw_stripe_ready())echo '<div class="pw-source-note"><b>'.esc_html(pw_t('Abo-Checkout noch nicht live','Subscription checkout not live yet')).':</b> '.esc_html(pw_t('Im Backend unter Pure Work → Abos & Zahlungen Stripe verbinden und Tarife synchronisieren. Zahlungsmethoden können bereits nach Verbindung des Stripe-Kontos hinterlegt werden.','In the backend connect Stripe under Pure Work → Subscriptions & Payments and sync plans. Payment methods can be added once the Stripe account is connected.')).'</div>';echo pw_portal_shell_end();return ob_get_clean();
}

function pw_v542_register(){
    remove_shortcode('pw_workers');add_shortcode('pw_workers','pw_shortcode_workers_v542');
    remove_shortcode('pw_crm');add_shortcode('pw_crm','pw_shortcode_crm_v542');
    remove_shortcode('pw_messages');add_shortcode('pw_messages','pw_shortcode_messages_v542');
    remove_shortcode('pw_assignments');add_shortcode('pw_assignments','pw_shortcode_assignments_v542');
    remove_shortcode('pw_account');add_shortcode('pw_account','pw_shortcode_account_v542');
}
add_action('init','pw_v542_register',5100);
