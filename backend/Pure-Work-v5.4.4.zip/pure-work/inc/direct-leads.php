<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9 – Verified Direct Staffing Leads
 * Only public business/procurement contacts that are explicitly tied to an
 * Arbeitnehmerüberlassung / temporary-staff procurement are shown as direct leads.
 * Generic job-ad recruiter contacts are intentionally excluded.
 */

function pw_direct_leads_seed_path() {
    return PW_DIR . '/assets/data/direct_staffing_leads_2026-08-16.csv';
}

function pw_direct_leads_parse_csv($path) {
    $rows = [];
    if (!is_readable($path)) return $rows;
    $h = fopen($path, 'r');
    if (!$h) return $rows;
    $headers = fgetcsv($h, 0, ';');
    if (!$headers) { fclose($h); return $rows; }
    $headers = array_map('trim', $headers);
    while (($row = fgetcsv($h, 0, ';')) !== false) {
        if (!array_filter($row, 'strlen')) continue;
        $row = array_pad($row, count($headers), '');
        $item = [];
        foreach ($headers as $i => $key) $item[$key] = isset($row[$i]) ? trim($row[$i]) : '';
        if (!empty($item['lead_id'])) $rows[$item['lead_id']] = $item;
    }
    fclose($h);
    return $rows;
}

function pw_direct_leads_all($include_expired = false) {
    static $seed = null;
    if ($seed === null) $seed = pw_direct_leads_parse_csv(pw_direct_leads_seed_path());
    $custom = get_option('pw_direct_leads_custom', []);
    if (!is_array($custom)) $custom = [];
    $all = $seed;
    foreach ($custom as $id => $lead) {
        if (!is_array($lead)) continue;
        $lead['lead_id'] = $lead['lead_id'] ?? $id;
        $all[$lead['lead_id']] = $lead;
    }
    /* 4.9.1: merge the official TED live cache. The procurement radar only
     * promotes notices that expose a published business contact in the notice. */
    $live = function_exists('pw_procurement_radar_cached_leads') ? pw_procurement_radar_cached_leads() : [];
    if (is_array($live)) {
        foreach ($live as $id => $lead) {
            if (!is_array($lead)) continue;
            $lead['lead_id'] = $lead['lead_id'] ?? $id;
            $all[$lead['lead_id']] = $lead;
        }
    }
    $today = wp_date('Y-m-d');
    if (!$include_expired) {
        $all = array_filter($all, function($lead) use ($today) {
            $deadline = (string)($lead['deadline'] ?? '');
            return !$deadline || $deadline >= $today;
        });
    }
    uasort($all, function($a, $b) {
        $ad = (string)($a['deadline'] ?? '9999-12-31');
        $bd = (string)($b['deadline'] ?? '9999-12-31');
        if ($ad === $bd) return (int)($b['quality'] ?? 0) <=> (int)($a['quality'] ?? 0);
        return strcmp($ad, $bd);
    });
    return $all;
}

function pw_direct_lead_get($lead_id, $include_expired = true) {
    $all = pw_direct_leads_all($include_expired);
    return $all[$lead_id] ?? null;
}

function pw_direct_lead_grade($lead) {
    $q = (int)($lead['quality'] ?? 0);
    if ($q >= 99) return ['A+', pw_t('direkt verifiziert','directly verified'), 'success'];
    if ($q >= 95) return ['A', pw_t('verifiziert','verified'), 'info'];
    return ['B', pw_t('geprüft','checked'), 'warning'];
}

function pw_direct_lead_search($args = []) {
    $q = pw_normalize_text((string)($args['q'] ?? ''));
    $where = pw_normalize_text((string)($args['where'] ?? ''));
    $sector = sanitize_text_field((string)($args['sector'] ?? ''));
    $all = pw_direct_leads_all(!empty($args['include_expired']));
    $out = [];
    foreach ($all as $lead) {
        $hay = pw_normalize_text(implode(' ', [
            $lead['company'] ?? '', $lead['title'] ?? '', $lead['city'] ?? '', $lead['region'] ?? '',
            $lead['sector'] ?? '', $lead['summary'] ?? '', $lead['keywords'] ?? '', $lead['contact_role'] ?? ''
        ]));
        if ($q && !pw_contains($hay, $q)) continue;
        if ($where) {
            $geo = pw_normalize_text(($lead['city'] ?? '') . ' ' . ($lead['region'] ?? ''));
            if (!pw_contains($geo, $where)) continue;
        }
        if ($sector && strcasecmp((string)($lead['sector'] ?? ''), $sector) !== 0) continue;
        $out[] = $lead;
    }
    return $out;
}

function pw_direct_lead_contact_name($lead) {
    $name = trim((string)($lead['contact_name'] ?? ''));
    return $name ?: trim((string)($lead['contact_role'] ?? pw_t('Vergabe-/Beschaffungsstelle','Procurement contact')));
}

function pw_direct_lead_card($lead, $compact = false) {
    $grade = pw_direct_lead_grade($lead);
    $deadline = (string)($lead['deadline'] ?? '');
    $email = sanitize_email((string)($lead['email'] ?? ''));
    $phone = trim((string)($lead['phone'] ?? ''));
    $contact = pw_direct_lead_contact_name($lead);
    $subject = 'Pure Work – Arbeitnehmerüberlassung · ' . (string)($lead['title'] ?? 'Anfrage');
    $body = "Guten Tag,\n\nwir sind auf Ihre Ausschreibung zur Arbeitnehmerüberlassung aufmerksam geworden und möchten gerne prüfen, ob wir den Bedarf mit passenden Mitarbeitenden abdecken können.\n\nVergabe/Referenz: " . (string)($lead['notice_id'] ?? '') . "\n\nFreundliche Grüße";
    ob_start(); ?>
    <article class="pw-direct-lead-card <?php echo $compact ? 'compact' : ''; ?>">
      <div class="pw-direct-lead-top">
        <div class="pw-direct-grade <?php echo esc_attr($grade[2]); ?>"><b><?php echo esc_html($grade[0]); ?></b><span><?php echo esc_html($grade[1]); ?></span></div>
        <div class="pw-direct-deadline"><small><?php echo pw_t('Frist','Deadline'); ?></small><b><?php echo $deadline ? esc_html(pw_format_date($deadline)) : '–'; ?></b></div>
      </div>
      <div class="pw-direct-company"><span class="pw-company-logo small"><?php echo esc_html(pw_initials((string)($lead['company'] ?? 'PW'))); ?></span><div><h3><?php echo esc_html((string)($lead['company'] ?? '')); ?></h3><p><?php echo esc_html((string)($lead['city'] ?? '') . (($lead['region'] ?? '') ? ' · ' . $lead['region'] : '')); ?></p></div></div>
      <h4><?php echo esc_html((string)($lead['title'] ?? '')); ?></h4>
      <?php if (!$compact && !empty($lead['summary'])): ?><p class="pw-direct-summary"><?php echo esc_html($lead['summary']); ?></p><?php endif; ?>
      <div class="pw-direct-tags"><span>AÜ / ANÜ</span><?php if(!empty($lead['sector'])):?><span><?php echo esc_html($lead['sector']); ?></span><?php endif;?><?php if(!empty($lead['cpv'])):?><span>CPV <?php echo esc_html($lead['cpv']); ?></span><?php endif;?></div>
      <div class="pw-direct-contact">
        <div class="pw-direct-contact-icon"><?php echo pw_icon('message'); ?></div>
        <div><small><?php echo pw_t('Zuständige Kontaktstelle für diesen AÜ-Bedarf','Responsible contact for this staffing procurement'); ?></small><b><?php echo esc_html($contact); ?></b><?php if(!empty($lead['contact_name']) && !empty($lead['contact_role'])):?><span><?php echo esc_html($lead['contact_role']); ?></span><?php endif;?></div>
        <span class="pw-contact-verified">✓ <?php echo pw_t('Quelle geprüft','source checked'); ?></span>
      </div>
      <div class="pw-direct-contact-lines">
        <?php if($email):?><a href="mailto:<?php echo esc_attr($email); ?>?subject=<?php echo rawurlencode($subject); ?>&body=<?php echo rawurlencode($body); ?>"><?php echo pw_icon('message'); ?><span><?php echo esc_html($email); ?></span></a><?php endif;?>
        <?php if($phone):?><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone)); ?>"><?php echo pw_icon('phone'); ?><span><?php echo esc_html($phone); ?></span></a><?php endif;?>
      </div>
      <div class="pw-direct-actions">
        <?php if(pw_user_role()==='agency' || current_user_can('manage_options')): ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_direct_lead_capture"><input type="hidden" name="lead_id" value="<?php echo esc_attr($lead['lead_id']); ?>"><?php wp_nonce_field('pw_direct_lead_capture'); ?><button class="pw-btn primary small" type="submit"><?php echo pw_icon('briefcase'); ?> <?php echo pw_t('Ins CRM übernehmen','Add to CRM'); ?></button></form>
        <?php endif; ?>
        <?php if(!empty($lead['source_url'])):?><a class="pw-btn ghost small" href="<?php echo esc_url($lead['source_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo pw_t('Originalquelle','Original source'); ?> <?php echo pw_icon('arrow'); ?></a><?php endif;?>
      </div>
      <footer><span><?php echo pw_t('Geprüft','Checked'); ?>: <?php echo esc_html(pw_format_date((string)($lead['verified_at'] ?? ''))); ?></span><?php if(!empty($lead['notice_id'])):?><span>ID <?php echo esc_html($lead['notice_id']); ?></span><?php endif;?></footer>
    </article>
    <?php return ob_get_clean();
}

function pw_direct_leads_stats($leads = null) {
    if ($leads === null) $leads = array_values(pw_direct_leads_all());
    $a_plus = 0; $named = 0; $next = '';
    foreach ($leads as $l) {
        if ((int)($l['quality'] ?? 0) >= 99) $a_plus++;
        if (!empty($l['contact_name'])) $named++;
        $d = (string)($l['deadline'] ?? '');
        if ($d && (!$next || $d < $next)) $next = $d;
    }
    return ['total'=>count($leads),'a_plus'=>$a_plus,'named'=>$named,'next'=>$next];
}

function pw_direct_leads_widget($uid = 0, $limit = 6, $context = 'dashboard') {
    if (!$uid) $uid = get_current_user_id();
    if (pw_user_role($uid) !== 'agency' && !current_user_can('manage_options')) return '';
    $city = pw_user_meta($uid, 'pw_city', '');
    $leads = pw_direct_lead_search(['where'=>$city]);
    if (!$leads) $leads = array_values(pw_direct_leads_all());
    $leads = array_slice($leads, 0, max(1,(int)$limit));
    ob_start(); ?>
    <section class="pw-card span2 pw-direct-widget">
      <div class="pw-card-head"><div><span class="pw-kicker">PURE WORK DIREKT-LEADS</span><h2><?php echo pw_t('AÜ-Bedarfe mit echter Kontaktstelle','Staffing demand with a real contact point'); ?></h2><p><?php echo pw_t('Keine beliebigen Stellenanzeigen: nur geprüfte AÜ-/ANÜ-Bedarfe mit öffentlich ausgewiesenem Vergabe- oder Beschaffungskontakt.','No generic job ads: only checked temporary-staff procurements with a published procurement contact.'); ?></p></div><a href="<?php echo esc_url(pw_page_url('market_live')); ?>"><?php echo pw_t('Alle Direkt-Leads','All direct leads'); ?></a></div>
      <div class="pw-direct-mini-grid"><?php foreach($leads as $lead) echo pw_direct_lead_card($lead,true); ?></div>
    </section>
    <?php return ob_get_clean();
}

function pw_public_direct_leads_preview() {
    $leads = array_slice(array_values(pw_direct_leads_all()), 0, 4);
    if (!$leads) return '';
    ob_start(); ?>
    <section class="pw-section pw-public-direct"><div class="pw-public-wrap">
      <div class="pw-section-head"><span class="pw-kicker">DIRECT PROCUREMENT SIGNALS</span><h2>Keine Jobbörse. Direkter an den Bedarf.</h2><p>Pure Work trennt allgemeine Stellenanzeigen von bestätigten Arbeitnehmerüberlassungs-Bedarfen. Im Portal sehen Personaldienstleister geprüfte öffentliche Kontaktstellen direkt am Vorgang.</p></div>
      <div class="pw-public-direct-grid"><?php foreach($leads as $l):?><article><div><span>AÜ / ANÜ</span><b><?php echo esc_html($l['company']); ?></b></div><h3><?php echo esc_html($l['title']); ?></h3><p><?php echo esc_html($l['city'].' · Frist '.pw_format_date($l['deadline'])); ?></p><small>Kontaktstelle im Portal verifiziert</small></article><?php endforeach;?></div>
      <div class="pw-public-market-actions"><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('register')); ?>">Kostenlos registrieren</a><span>Nach Login: Ansprechpartner, E-Mail/Telefon, Quelle und CRM-Übernahme.</span></div>
    </div></section>
    <?php return ob_get_clean();
}

function pw_shortcode_direct_leads() {
    if (!is_user_logged_in()) return pw_require_login_html();
    $uid = get_current_user_id();
    $role = pw_user_role($uid);
    ob_start();
    echo pw_portal_shell_start(pw_t('Direkt-Leads','Direct leads'), pw_t('Geprüfte Arbeitnehmerüberlassungs-Bedarfe mit zuständiger Kontaktstelle','Verified temporary-staff procurements with the responsible contact point'));
    echo pw_flash_messages();
    if ($role !== 'agency' && !current_user_can('manage_options')) {
        echo '<section class="pw-card pw-direct-client-info"><span class="pw-kicker">DIREKT-LEADS</span><h2>'.esc_html(pw_t('Vertriebsbereich für Personaldienstleister','Sales area for staffing agencies')).'</h2><p>'.esc_html(pw_t('Als Auftraggeber steuerst du deine eigenen Ausschreibungen unter „Aufträge“. Direkt-Leads ist für verifizierte Zeitarbeitsfirmen gedacht.','As a client, manage your own jobs under “Jobs”. Direct Leads is intended for verified staffing agencies.')).'</p><a class="pw-btn primary" href="'.esc_url(pw_page_url('vacancies')).'">'.esc_html(pw_t('Zu meinen Aufträgen','Go to my jobs')).'</a></section>';
        echo pw_portal_shell_end(); return ob_get_clean();
    }
    $gate = current_user_can('manage_options') ? '' : pw_verified_gate(pw_t('Direkt-Leads öffnen','Open direct leads'));
    if ($gate) { echo $gate; echo pw_portal_shell_end(); return ob_get_clean(); }

    // 4.9.4: der Bereich hat jetzt drei klar getrennte Aufgaben statt einer langen Seite.
    $tab = sanitize_key(wp_unslash($_GET['tab'] ?? 'verified'));
    if (!in_array($tab, ['verified','own','rules'], true)) $tab = 'verified';
    if (function_exists('pw_leads_tab_nav')) echo pw_leads_tab_nav($tab);
    if ($tab === 'own' && function_exists('pw_leads_own_panel')) { echo pw_leads_own_panel(); echo pw_portal_shell_end(); return ob_get_clean(); }
    if ($tab === 'rules' && function_exists('pw_leads_rules_panel')) { echo pw_leads_rules_panel(); echo pw_portal_shell_end(); return ob_get_clean(); }
    $q = sanitize_text_field(wp_unslash($_GET['q'] ?? ''));
    $where = sanitize_text_field(wp_unslash($_GET['where'] ?? ''));
    $sector = sanitize_text_field(wp_unslash($_GET['sector'] ?? ''));
    $leads = pw_direct_lead_search(['q'=>$q,'where'=>$where,'sector'=>$sector]);
    $stats = pw_direct_leads_stats(array_values(pw_direct_leads_all()));
    $sectors = [];
    foreach(pw_direct_leads_all() as $l) if(!empty($l['sector'])) $sectors[$l['sector']] = $l['sector'];
    ksort($sectors);
    ?>
    <section class="pw-direct-hero"><div><span class="pw-kicker">QUALITY FIRST</span><h2><?php echo pw_t('Nicht irgendein Recruiter. Die Stelle, die den Bedarf beauftragt.','Not just any recruiter. The office that commissions the demand.'); ?></h2><p><?php echo pw_t('Ein Lead erscheint hier nur, wenn Arbeitnehmerüberlassung ausdrücklich Gegenstand des Bedarfs ist und ein öffentlicher geschäftlicher Vergabe-/Beschaffungskontakt zur Quelle gehört.','A lead appears here only when temporary staffing is explicitly part of the procurement and a public business procurement contact is tied to the source.'); ?></p></div><div class="pw-direct-orbit"><span>PW</span><i></i><i></i><em>✓</em></div></section>
    <div class="pw-direct-stats"><div><b><?php echo (int)$stats['total']; ?></b><span><?php echo pw_t('aktive geprüfte Leads','active checked leads'); ?></span></div><div><b><?php echo (int)$stats['a_plus']; ?></b><span>A+ <?php echo pw_t('Kontaktqualität','contact quality'); ?></span></div><div><b><?php echo (int)$stats['named']; ?></b><span><?php echo pw_t('namentliche Ansprechpartner','named contacts'); ?></span></div><div><b><?php echo $stats['next']?esc_html(pw_format_date($stats['next'])):'–'; ?></b><span><?php echo pw_t('nächste Frist','next deadline'); ?></span></div></div>
    <form class="pw-direct-filter" method="get"><label><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($q); ?>" placeholder="<?php echo esc_attr(pw_t('Tätigkeit, Unternehmen, Skill…','Role, company, skill…')); ?>"></label><label><?php echo pw_icon('map'); ?><input name="where" value="<?php echo esc_attr($where); ?>" placeholder="<?php echo esc_attr(pw_t('Ort / Bundesland','City / region')); ?>"></label><label><select name="sector"><option value=""><?php echo pw_t('Alle Bereiche','All sectors'); ?></option><?php foreach($sectors as $s):?><option value="<?php echo esc_attr($s); ?>" <?php selected($sector,$s); ?>><?php echo esc_html($s); ?></option><?php endforeach;?></select></label><button class="pw-btn primary" type="submit"><?php echo pw_t('Leads filtern','Filter leads'); ?></button></form>
    <div class="pw-direct-result-head"><div><b><?php echo count($leads); ?></b><span><?php echo pw_t('passende Direkt-Leads','matching direct leads'); ?></span></div><small><?php echo pw_t('Nur öffentliche Geschäftskontakte aus dem jeweiligen AÜ-Vergabekontext. Keine geratenen Ansprechpartner.','Only public business contacts from the specific staffing procurement context. No guessed contacts.'); ?></small></div>
    <div class="pw-direct-grid"><?php if(!$leads):?><div class="pw-card pw-empty span-all"><h3><?php echo pw_t('Kein geprüfter Direkt-Lead für diesen Filter','No verified direct lead for this filter'); ?></h3><p><?php echo pw_t('Filter erweitern. Pure Work zeigt bewusst keine beliebigen Stellenanzeigen als vermeintliche AÜ-Leads an.','Broaden the filters. Pure Work intentionally does not present generic job ads as staffing leads.'); ?></p></div><?php else:foreach($leads as $lead)echo pw_direct_lead_card($lead);endif;?></div>
    <div class="pw-direct-trust"><div>✓</div><div><b><?php echo pw_t('Was „verifiziert“ hier bedeutet','What “verified” means here'); ?></b><p><?php echo pw_t('AÜ/ANÜ ist ausdrücklich Bestandteil der Ausschreibung. Unternehmen und geschäftlicher Kontakt stammen aus der veröffentlichten Vergabequelle. Die Quelle und das Prüfdatum bleiben am Lead sichtbar.','Temporary staffing is explicitly part of the procurement. Company and business contact come from the published procurement source. Source and verification date remain visible on the lead.'); ?></p></div></div>
    <?php echo pw_portal_shell_end(); return ob_get_clean();
}

function pw_handle_direct_lead_capture() {
    if (!is_user_logged_in() || (pw_user_role() !== 'agency' && !current_user_can('manage_options'))) wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_direct_lead_capture');
    $lead_id = sanitize_text_field(wp_unslash($_POST['lead_id'] ?? ''));
    $lead = pw_direct_lead_get($lead_id, true);
    if (!$lead) pw_form_redirect('market_live',['error'=>'lead']);
    $uid = get_current_user_id();
    $existing = get_posts(['post_type'=>'pw_crm_lead','post_status'=>'publish','author'=>$uid,'posts_per_page'=>1,'fields'=>'ids','meta_query'=>[['key'=>'pw_crm_direct_lead_id','value'=>$lead_id]]]);
    $crm_id = $existing ? (int)$existing[0] : 0;
    $notes = 'Verifizierter Pure Work Direkt-Lead. Arbeitnehmerüberlassung ist ausdrücklich Gegenstand der veröffentlichten Beschaffung. Kontaktquelle: '.($lead['source_name']??'').' · geprüft am '.($lead['verified_at']??'').'.';
    $data = [
        'company'=>$lead['company']??'', 'contact'=>$lead['contact_name']??'', 'contact_role'=>$lead['contact_role']??'',
        'email'=>$lead['email']??'', 'phone'=>$lead['phone']??'', 'city'=>$lead['city']??'', 'industry'=>$lead['sector']??'',
        'stage'=>'qualified','source'=>'Pure Work Direkt-Lead · AÜ verifiziert','source_url'=>$lead['source_url']??'',
        'job_title'=>$lead['title']??'', 'job_ref'=>$lead['notice_id']??'', 'priority'=>'hot',
        'next_followup'=>wp_date('Y-m-d', strtotime('+1 day')), 'notes'=>$notes, 'target_type'=>'direct_staffing',
        'market_published'=>$lead['published']??'', 'lead_quality'=>(string)($lead['quality']??''), 'verified_at'=>$lead['verified_at']??'',
        'deadline'=>$lead['deadline']??'', 'cpv'=>$lead['cpv']??'', 'notice_id'=>$lead['notice_id']??''
    ];
    $crm_id = pw_crm_create_or_update_lead($uid,$data,$crm_id);
    if (is_wp_error($crm_id)) pw_form_redirect('market_live',['error'=>'lead']);
    update_post_meta($crm_id,'pw_crm_direct_lead_id',$lead_id);
    pw_crm_add_activity($crm_id,$uid,'direct_lead','Verifizierte AÜ-Kontaktstelle aus Pure Work Direkt-Leads übernommen.');
    pw_form_redirect('crm',['lead'=>$crm_id,'saved'=>1]);
}
add_action('admin_post_pw_direct_lead_capture','pw_handle_direct_lead_capture');

/* Admin curation: lets the operator add only leads that have a source and direct business contact. */
function pw_direct_leads_admin_menu() {
    add_submenu_page('pure-work','Direkt-Leads','Direkt-Leads','manage_options','pure-work-direct-leads','pw_direct_leads_admin_page');
}
add_action('admin_menu','pw_direct_leads_admin_menu',30);

function pw_direct_leads_admin_page() {
    if (!current_user_can('manage_options')) return;
    $leads = pw_direct_leads_all(true);
    $sync = function_exists('pw_ted_staffing_sync_status') ? pw_ted_staffing_sync_status() : [];
    $live_count = function_exists('pw_procurement_radar_cached_leads') ? count(pw_procurement_radar_cached_leads()) : 0;
    ?>
    <div class="wrap"><h1>Pure Work Direkt-Leads</h1><p><strong>Qualitätsregel:</strong> Keine allgemeine Stellenanzeige wird als Direkt-Lead aufgenommen. Erforderlich sind ein ausdrücklich erkennbarer AÜ/ANÜ-Bedarf, eine öffentliche Quelle und eine geschäftliche Kontaktstelle, die zum Vergabe-/Beschaffungsprozess gehört.</p>
    <?php if(isset($_GET['updated'])):?><div class="notice notice-success"><p>Direkt-Lead gespeichert.</p></div><?php endif;?><?php if(isset($_GET['error'])):?><div class="notice notice-error"><p>Lead nicht gespeichert. Quelle sowie E-Mail oder Telefon sind Pflicht.</p></div><?php endif;?>
    <?php if(isset($_GET['ted_sync'])):?><div class="notice notice-success"><p>TED AÜ-Radar wurde synchronisiert. Aktuell <?php echo (int)$live_count;?> verifizierte Live-Treffer im Cache.</p></div><?php endif;?>
    <?php if(!empty($_GET['ted_error'])):?><div class="notice notice-warning"><p>TED-Sync: <?php echo esc_html(sanitize_text_field(wp_unslash($_GET['ted_error'])));?></p></div><?php endif;?>
    <div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px 18px;margin:18px 0;max-width:980px">
      <h2 style="margin-top:0">Offizieller TED AÜ-Radar</h2>
      <p>Pure Work durchsucht täglich offene deutsche TED-Vergaben nach einschlägigen Personaldienstleistungs-/Arbeitnehmerüberlassungs-CPV-Codes. Als Direkt-Lead wird ein Treffer nur übernommen, wenn im veröffentlichten Vergabedokument eine geschäftliche E-Mail oder Telefonnummer gefunden wird.</p>
      <p><strong>Letzter Sync:</strong> <?php echo !empty($sync['last_sync']) ? esc_html($sync['last_sync']).' UTC' : 'noch nicht ausgeführt';?> &nbsp; · &nbsp; <strong>Live-Cache:</strong> <?php echo (int)$live_count;?>
      <?php if(!empty($sync['error'])):?><br><span style="color:#9a3412"><strong>Hinweis:</strong> <?php echo esc_html($sync['error']);?></span><?php endif;?></p>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_ted_staffing_sync_now"><?php wp_nonce_field('pw_ted_staffing_sync_now');?><button class="button button-primary">TED AÜ-Radar jetzt synchronisieren</button></form>
    </div>
    <h2>Geprüfte Datenbank</h2><table class="widefat striped"><thead><tr><th>Unternehmen / Bedarf</th><th>Kontakt</th><th>Frist</th><th>Qualität</th><th>Quelle</th></tr></thead><tbody><?php foreach($leads as $l):$g=pw_direct_lead_grade($l);?><tr><td><strong><?php echo esc_html($l['company']); ?></strong><br><small><?php echo esc_html($l['title']); ?></small></td><td><?php echo esc_html(pw_direct_lead_contact_name($l)); ?><br><small><?php echo esc_html(($l['email']??'').' '.($l['phone']??'')); ?></small></td><td><?php echo esc_html(pw_format_date($l['deadline']??'')); ?></td><td><strong><?php echo esc_html($g[0]); ?></strong> · <?php echo esc_html($g[1]); ?></td><td><?php if(!empty($l['source_url'])):?><a href="<?php echo esc_url($l['source_url']); ?>" target="_blank" rel="noopener">prüfen</a><?php endif;?></td></tr><?php endforeach;?></tbody></table>
    <h2 style="margin-top:32px">Verifizierten Lead ergänzen</h2><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="max-width:900px;background:#fff;padding:20px;border:1px solid #ddd"><input type="hidden" name="action" value="pw_direct_lead_admin_add"><?php wp_nonce_field('pw_direct_lead_admin_add');?><table class="form-table"><tr><th>Unternehmen*</th><td><input class="regular-text" name="company" required></td></tr><tr><th>AÜ-Bedarf / Titel*</th><td><input class="large-text" name="title" required></td></tr><tr><th>Ort / Region</th><td><input name="city"> <input name="region"></td></tr><tr><th>Kontaktname</th><td><input class="regular-text" name="contact_name"></td></tr><tr><th>Kontaktrolle*</th><td><input class="regular-text" name="contact_role" required placeholder="z. B. Vergabestelle / Dienstleistungseinkauf"></td></tr><tr><th>E-Mail / Telefon*</th><td><input type="email" name="email"> <input name="phone"></td></tr><tr><th>Frist</th><td><input type="date" name="deadline"></td></tr><tr><th>CPV / Vergabe-ID</th><td><input name="cpv" value="79620000"> <input name="notice_id"></td></tr><tr><th>Originalquelle*</th><td><input class="large-text" type="url" name="source_url" required></td></tr><tr><th>Bereich / Kurzinfo</th><td><input name="sector"> <textarea class="large-text" name="summary" rows="3"></textarea></td></tr></table><p><button class="button button-primary">Als verifizierten Direkt-Lead speichern</button></p></form></div>
    <?php
}

function pw_handle_direct_lead_admin_add() {
    if (!current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    check_admin_referer('pw_direct_lead_admin_add');
    $company = sanitize_text_field(wp_unslash($_POST['company']??''));
    $title = sanitize_text_field(wp_unslash($_POST['title']??''));
    $url = esc_url_raw(wp_unslash($_POST['source_url']??''));
    $email = sanitize_email(wp_unslash($_POST['email']??''));
    $phone = sanitize_text_field(wp_unslash($_POST['phone']??''));
    if(!$company || !$title || !$url || (!$email && !$phone)) wp_safe_redirect(admin_url('admin.php?page=pure-work-direct-leads&error=1'));
    else {
        $id='PWDL-CUSTOM-'.strtoupper(substr(md5($company.$title.microtime(true)),0,10));
        $custom=get_option('pw_direct_leads_custom',[]);if(!is_array($custom))$custom=[];
        $custom[$id]=[
            'lead_id'=>$id,'company'=>$company,'title'=>$title,'city'=>sanitize_text_field(wp_unslash($_POST['city']??'')),'region'=>sanitize_text_field(wp_unslash($_POST['region']??'')),
            'deadline'=>sanitize_text_field(wp_unslash($_POST['deadline']??'')),'published'=>wp_date('Y-m-d'),'contact_name'=>sanitize_text_field(wp_unslash($_POST['contact_name']??'')),
            'contact_role'=>sanitize_text_field(wp_unslash($_POST['contact_role']??'')),'email'=>$email,'phone'=>$phone,'cpv'=>sanitize_text_field(wp_unslash($_POST['cpv']??'79620000')),
            'notice_id'=>sanitize_text_field(wp_unslash($_POST['notice_id']??'')),'source_name'=>'Admin-verifizierte Originalquelle','source_url'=>$url,'verified_at'=>wp_date('Y-m-d'),'quality'=>'98',
            'sector'=>sanitize_text_field(wp_unslash($_POST['sector']??'')),'summary'=>sanitize_textarea_field(wp_unslash($_POST['summary']??'')),'keywords'=>''
        ];
        update_option('pw_direct_leads_custom',$custom,false);
        wp_safe_redirect(admin_url('admin.php?page=pure-work-direct-leads&updated=1'));
    }
    exit;
}
add_action('admin_post_pw_direct_lead_admin_add','pw_handle_direct_lead_admin_add');

/* Replace the legacy generic Market Live shortcode after all previous modules loaded. */
function pw_direct_leads_register_shortcode() {
    remove_shortcode('pw_market_live');
    add_shortcode('pw_market_live','pw_shortcode_direct_leads');
}
add_action('init','pw_direct_leads_register_shortcode',99);


/* One-time 4.9 migration: keep the old page key/shortcode for update compatibility,
 * but rename the visible WordPress page from "Markt Live" to "Direkt-Leads". */
function pw_direct_leads_migrate_490() {
    if (get_option('pw_direct_leads_migrated_490')) return;
    $ids = get_option('pw_page_ids', []);
    $page_id = !empty($ids['market_live']) ? (int)$ids['market_live'] : 0;
    if ($page_id && get_post($page_id)) {
        wp_update_post(['ID'=>$page_id,'post_title'=>'Direkt-Leads','post_name'=>'direkt-leads']);
        flush_rewrite_rules(false);
    }
    update_option('pw_direct_leads_migrated_490', 1, false);
}
add_action('init','pw_direct_leads_migrate_490',20);
