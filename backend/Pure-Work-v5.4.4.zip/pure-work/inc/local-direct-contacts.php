<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9.2 – regional employer/contact intelligence.
 *
 * Important distinction:
 * - staffing_status=confirmed: public evidence for AÜ/ANÜ already exists in the Pure Work evidence layer.
 * - staffing_status=potential: verified public employer/location contact in a staffing-heavy sector. It is NOT presented as proof that the company currently buys temporary staffing.
 */
function pw_local_direct_contacts_path_492(){
    return PW_DIR.'/assets/data/regional_direct_contacts_2026-08-17.csv';
}

function pw_local_direct_contacts_all_492(){
    static $rows=null;
    if($rows!==null)return $rows;
    $rows=[];$path=pw_local_direct_contacts_path_492();
    if(!is_readable($path))return $rows;
    $h=fopen($path,'r');if(!$h)return $rows;
    $headers=fgetcsv($h,0,';');
    if($headers){
        $headers=array_map(function($v){return trim((string)$v,"\xEF\xBB\xBF \t\r\n");},$headers);
        while(($r=fgetcsv($h,0,';'))!==false){
            if(!array_filter($r,'strlen'))continue;
            $r=array_pad($r,count($headers),'');$item=[];
            foreach($headers as $i=>$k)$item[$k]=isset($r[$i])?trim((string)$r[$i]):'';
            if(!empty($item['lead_id']))$rows[$item['lead_id']]=$item;
        }
    }
    fclose($h);
    /* 5.4.0: eine einzige Stelle, an der ungeeignete Adressen ausgefiltert und
       nach tatsächlicher Zeitarbeitsnachfrage sortiert werden. */
    $rows = apply_filters('pw_direct_contacts', $rows);
    return $rows;
}

function pw_local_contact_key_terms_492($company){
    $s=pw_normalize_text((string)$company);
    $remove=[' gmbh',' ag',' se',' gmbh co kg',' gmbh & co kg',' deutschland',' mannheim',' ludwigshafen',' heidelberg',' viernheim',' weinheim',' schwetzingen',' hockenheim',' frankenthal',' speyer',' wiesloch',' walldorf',' lampertheim',' gruppe',' standort',' logistikzentrum',' niederlassung'];
    foreach($remove as $x)$s=str_replace($x,'',$s);
    $s=trim(preg_replace('/\s+/',' ',$s));
    return array_values(array_filter(array_unique([$s,pw_normalize_text((string)$company)]),function($v){return strlen($v)>=4;}));
}

/** Current public hiring hints; cached and deliberately used as a hint, not AÜ proof. */
function pw_local_contact_live_map_492(){
    $cached=get_transient('pw_local_contact_live_map_492');
    if(is_array($cached))return $cached;
    $map=[];
    if(!function_exists('pw_live_market_fetch'))return $map;
    $contacts=pw_local_direct_contacts_all_492();
    $feeds=[];
    foreach(['Mannheim','Ludwigshafen am Rhein','Heidelberg','Rhein-Neckar-Kreis'] as $where){
        $feed=pw_live_market_fetch('', $where, 30, 50, 1, true);
        foreach((array)($feed['items']??[]) as $item)$feeds[]=$item;
    }
    foreach($contacts as $id=>$c){
        $terms=pw_local_contact_key_terms_492($c['company']??'');
        foreach($feeds as $item){
            $hay=pw_normalize_text((string)($item['employer']??'').' '.(string)($item['title']??''));
            $hit=false;foreach($terms as $term){if($term&&pw_contains($hay,$term)){$hit=true;break;}}
            if(!$hit)continue;
            if(!isset($map[$id]))$map[$id]=[];
            $map[$id][]=['title'=>sanitize_text_field($item['title']??''),'place'=>sanitize_text_field($item['place']??''),'published'=>sanitize_text_field($item['published']??''),'url'=>esc_url_raw($item['url']??''),'source'=>!empty($item['snapshot'])?'BA Marktsnapshot':'BA Jobsuche'];
            if(count($map[$id])>=3)break;
        }
    }
    set_transient('pw_local_contact_live_map_492',$map,30*MINUTE_IN_SECONDS);
    return $map;
}

function pw_local_direct_contacts_search_492($args=[]){
    $q=pw_normalize_text((string)($args['q']??''));
    $where=pw_normalize_text((string)($args['where']??''));
    $sector=pw_normalize_text((string)($args['sector']??''));
    $proof=sanitize_key((string)($args['proof']??''));
    $rows=pw_local_direct_contacts_all_492();$live=pw_local_contact_live_map_492();$out=[];
    foreach($rows as $id=>$c){
        $c['live_roles']=$live[$id]??[];
        $hay=pw_normalize_text(($c['company']??'').' '.($c['city']??'').' '.($c['address']??'').' '.($c['sector']??'').' '.($c['keywords']??'').' '.implode(' ',array_column($c['live_roles'],'title')));
        if($q&&!pw_contains($hay,$q))continue;
        if($where&&!pw_contains(pw_normalize_text(($c['city']??'').' '.($c['address']??'').' '.($c['region']??'')),$where))continue;
        if($sector&&!pw_contains(pw_normalize_text(($c['sector']??'').' '.($c['keywords']??'')),$sector))continue;
        if($proof==='confirmed'&&($c['staffing_status']??'')!=='confirmed')continue;
        if($proof==='live'&&empty($c['live_roles']))continue;
        $out[$id]=$c;
    }
    uasort($out,function($a,$b){
        $aConf=($a['staffing_status']??'')==='confirmed'?1:0;$bConf=($b['staffing_status']??'')==='confirmed'?1:0;
        if($aConf!==$bConf)return $bConf<=>$aConf;
        $aLive=!empty($a['live_roles'])?1:0;$bLive=!empty($b['live_roles'])?1:0;
        if($aLive!==$bLive)return $bLive<=>$aLive;
        $aMA=stripos($a['city']??'','Mannheim')!==false?1:0;$bMA=stripos($b['city']??'','Mannheim')!==false?1:0;
        if($aMA!==$bMA)return $bMA<=>$aMA;
        return (int)($b['quality']??0)<=>(int)($a['quality']??0);
    });
    return $out;
}

function pw_local_direct_contacts_stats_492(){
    $rows=pw_local_direct_contacts_all_492();$live=pw_local_contact_live_map_492();$confirmed=0;$withPhone=0;$mannheim=0;
    foreach($rows as $id=>$r){if(($r['staffing_status']??'')==='confirmed')$confirmed++;if(!empty($r['phone']))$withPhone++;if(stripos($r['city']??'','Mannheim')!==false)$mannheim++;}
    return ['total'=>count($rows),'confirmed'=>$confirmed,'live'=>count($live),'phone'=>$withPhone,'mannheim'=>$mannheim];
}

function pw_local_contact_label_492($c){
    if(($c['staffing_status']??'')==='confirmed')return [pw_t('AÜ/ANÜ öffentlich belegt','Public staffing evidence'),'confirmed'];
    if(!empty($c['live_roles']))return [pw_t('Aktuelles Recruiting-Signal','Current hiring signal'),'live'];
    return [pw_t('Direkter regionaler Arbeitgeberkontakt','Direct regional employer contact'),'contact'];
}

function pw_local_direct_contact_card_492($c){
    $label=pw_local_contact_label_492($c);$phone=sanitize_text_field($c['phone']??'');$email=sanitize_email($c['email']??'');$url=esc_url($c['source_url']??'');
    $subject='Pure Work – Personal / Arbeitnehmerüberlassung';
    $body="Guten Tag,\n\nwir unterstützen Unternehmen in der Metropolregion Rhein-Neckar kurzfristig mit qualifiziertem Personal. Gerne würden wir mit der zuständigen Stelle für externes Personal bzw. Personaldienstleistungen sprechen.\n\nFreundliche Grüße";
    ob_start();?>
    <article class="pw-local-contact-card">
      <div class="pw-local-contact-top"><span class="pw-company-logo small"><?php echo esc_html(pw_initials($c['company']??''));?></span><div><h3><?php echo esc_html($c['company']??'');?></h3><p><?php echo esc_html(($c['city']??'').(!empty($c['sector'])?' · '.$c['sector']:''));?></p></div><span class="pw-local-score"><?php echo (int)($c['quality']??0);?><small>%</small></span></div>
      <div class="pw-local-status pw-local-<?php echo esc_attr($label[1]);?>"><i></i><?php echo esc_html($label[0]);?></div>
      <?php if(!empty($c['address'])):?><div class="pw-local-line"><?php echo pw_icon('map');?><span><?php echo esc_html($c['address']);?></span></div><?php endif;?>
      <div class="pw-local-line"><?php echo pw_icon('briefcase');?><span><?php echo esc_html($c['contact_role']?:pw_t('Standort / Zentrale','Location / head office'));?></span></div>
      <?php if(!empty($c['evidence_note'])):?><p class="pw-local-note"><?php echo esc_html($c['evidence_note']);?></p><?php endif;?>
      <?php if(!empty($c['live_roles'])):?><div class="pw-local-live"><b><span></span><?php echo pw_t('Aktuell öffentlich gesucht','Currently publicly hiring');?></b><?php foreach(array_slice($c['live_roles'],0,3) as $job):?><a href="<?php echo esc_url($job['url']);?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($job['title']);?></a><?php endforeach;?></div><?php endif;?>
      <div class="pw-local-contact-actions">
        <?php if($phone):?><a class="pw-local-phone" href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone));?>"><?php echo pw_icon('phone');?><span><small><?php echo pw_t('Direkt anrufen','Call direct');?></small><b><?php echo esc_html($phone);?></b></span></a><?php endif;?>
        <?php if($email):?><a class="pw-local-mail" href="mailto:<?php echo esc_attr($email);?>?subject=<?php echo rawurlencode($subject);?>&body=<?php echo rawurlencode($body);?>"><?php echo pw_icon('message');?><span><small><?php echo pw_t('E-Mail','Email');?></small><b><?php echo esc_html($email);?></b></span></a><?php endif;?>
      </div>
      <div class="pw-local-footer"><span>✓ <?php echo pw_t('öffentlicher Geschäftskontakt geprüft','public business contact checked');?> · <?php echo esc_html(pw_format_date($c['verified_at']??''));?></span><?php if($url):?><a href="<?php echo $url;?>" target="_blank" rel="noopener noreferrer"><?php echo pw_t('Quelle','Source');?> <?php echo pw_icon('arrow');?></a><?php endif;?></div>
      <div class="pw-direct-actions"><form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="pw_local_contact_capture_492"><input type="hidden" name="lead_id" value="<?php echo esc_attr($c['lead_id']);?>"><?php wp_nonce_field('pw_local_contact_capture_492');?><button class="pw-btn primary small" type="submit"><?php echo pw_icon('briefcase');?> <?php echo pw_t('Ins CRM + Wiedervorlage','CRM + follow-up');?></button></form><?php if($phone):?><a class="pw-btn ghost small" href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone));?>"><?php echo pw_t('Jetzt anrufen','Call now');?></a><?php endif;?></div>
    </article>
    <?php return ob_get_clean();
}

function pw_local_direct_contact_get_492($id){$rows=pw_local_direct_contacts_all_492();return $rows[$id]??null;}
function pw_handle_local_contact_capture_492(){
    if(!is_user_logged_in()||(pw_user_role()!=='agency'&&!current_user_can('manage_options')))wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_local_contact_capture_492');$id=sanitize_text_field(wp_unslash($_POST['lead_id']??''));$c=pw_local_direct_contact_get_492($id);if(!$c)pw_form_redirect('market_live',['error'=>'lead']);
    $uid=get_current_user_id();$existing=get_posts(['post_type'=>'pw_crm_lead','post_status'=>'publish','author'=>$uid,'posts_per_page'=>1,'fields'=>'ids','meta_query'=>[['key'=>'pw_crm_job_ref','value'=>$id]]]);$crm=$existing?(int)$existing[0]:0;
    $status=($c['staffing_status']??'')==='confirmed'?'AÜ/ANÜ-Nachweis vorhanden':'regionaler Arbeitgeber-/Standortkontakt; AÜ-Nutzung nicht behauptet';
    $data=['company'=>$c['company'],'contact'=>$c['contact_name'],'contact_role'=>$c['contact_role'],'email'=>$c['email'],'phone'=>$c['phone'],'city'=>$c['city'],'industry'=>$c['sector'],'stage'=>'qualified','source'=>'Pure Work Rhein-Neckar Direktkontakte','source_url'=>$c['source_url'],'job_title'=>$c['keywords'],'job_ref'=>$id,'priority'=>(int)$c['quality']>=94?'hot':'warm','next_followup'=>wp_date('Y-m-d',strtotime('+1 day')),'notes'=>'Pure Work 4.9.2. '.$status.'. '.$c['evidence_note'],'target_type'=>'regional_direct_contact','lead_quality'=>$c['quality'],'verified_at'=>$c['verified_at']];
    $crm=pw_crm_create_or_update_lead($uid,$data,$crm);if(is_wp_error($crm))pw_form_redirect('market_live',['error'=>'crm']);
    update_post_meta($crm,'pw_crm_local_contact_id',$id);update_post_meta($crm,'pw_crm_staffing_status',$c['staffing_status']);
    pw_crm_add_activity($crm,$uid,'lead_capture','Regionalen Direktkontakt übernommen. Nächster Schritt: zuständige Stelle für externes Personal / Personaldienstleistung identifizieren und Bedarf qualifizieren.',wp_date('Y-m-d',strtotime('+1 day')));
    pw_form_redirect('crm',['lead'=>$crm,'saved'=>1]);
}
add_action('admin_post_pw_local_contact_capture_492','pw_handle_local_contact_capture_492');
