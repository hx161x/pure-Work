<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.2.0 – Chat-Oberfläche.
 *
 * Aufgeräumter als vorher: links die Unterhaltungen mit ungelesen-Zähler und
 * Vorschautext, rechts der Verlauf. Alles, was ein Disponent im Gespräch
 * braucht, liegt direkt über dem Eingabefeld statt in einem anderen Menü.
 */

function pw_v520_thread_meta($tid, $uid) {
    $messages = pw_thread_messages($tid);
    $last = $messages ? end($messages) : null;
    $unread = 0;
    foreach ($messages as $m) {
        if ((int)pw_meta($m->ID, 'pw_recipient', 0) === $uid && get_post_meta($m->ID, 'pw_read', true) !== '1') $unread++;
    }
    return [
        'last'    => $last,
        'unread'  => $unread,
        'preview' => $last ? wp_trim_words((string)$last->post_content, 9, '…') : pw_t('Chat geöffnet – schreib die erste Nachricht.', 'Chat open – write the first message.'),
        'time'    => $last ? wp_date('d.m. · H:i', get_post_time('U', true, $last)) : '',
    ];
}

function pw_v520_render_message($m, $uid) {
    $mine   = (int)$m->post_author === $uid;
    $system = get_post_meta($m->ID, 'pw_system', true) === '1';
    $offer  = pw_v520_offer($m->ID);
    $att    = pw_v520_attachment($m->ID);
    $card   = function_exists('pw_v543_card_from_message') ? pw_v543_card_from_message($m->ID, $uid) : null;
    $read   = get_post_meta($m->ID, 'pw_read', true) === '1';
    $time   = wp_date('d.m. · H:i', get_post_time('U', true, $m));

    if ($system) {
        return '<div class="pw-chat-system" data-message-id="' . (int)$m->ID . '"><span>' . esc_html(pw_t('System', 'System')) . '</span><p>' . esc_html($m->post_content) . '</p></div>';
    }

    ob_start(); ?>
    <div class="pw-message <?php echo $mine ? 'mine' : 'theirs'; ?><?php echo $offer ? ' has-offer' : ''; ?><?php echo $card ? ' has-business-card' : ''; ?>" data-message-id="<?php echo (int)$m->ID; ?>">
      <div>
        <?php if ($card): ?>
          <?php echo pw_v543_card_html($card, $mine); ?>
        <?php elseif ($offer): ?>
          <div class="pw-offer-card pw-offer-<?php echo esc_attr($offer['status'] ?? 'open'); ?>" data-offer-message="<?php echo (int)$m->ID; ?>">
            <span class="pw-kicker"><?php echo esc_html(pw_t('VERBINDLICHES ANGEBOT', 'BINDING OFFER')); ?></span>
            <div class="pw-offer-facts">
              <?php if (!empty($offer['rate'])): ?><div><small><?php echo esc_html(pw_t('Verrechnungssatz', 'Charge rate')); ?></small><b><?php echo esc_html($offer['rate']); ?> €/h</b></div><?php endif; ?>
              <?php if (!empty($offer['start'])): ?><div><small><?php echo esc_html(pw_t('Start', 'Start')); ?></small><b><?php echo esc_html(pw_format_date($offer['start'])); ?></b></div><?php endif; ?>
              <?php if (!empty($offer['shift'])): ?><div><small><?php echo esc_html(pw_t('Schicht', 'Shift')); ?></small><b><?php echo esc_html($offer['shift']); ?></b></div><?php endif; ?>
              <?php if (!empty($offer['hours'])): ?><div><small><?php echo esc_html(pw_t('Std./Woche', 'Hrs/week')); ?></small><b><?php echo esc_html($offer['hours']); ?></b></div><?php endif; ?>
            </div>
            <?php if (!empty($offer['note'])): ?><p class="pw-offer-note"><?php echo esc_html($offer['note']); ?></p><?php endif; ?>
            <?php if (($offer['status'] ?? 'open') === 'open' && pw_user_role($uid) === 'client'): ?>
              <div class="pw-offer-actions">
                <button type="button" class="pw-btn primary small" data-offer-decide="accepted"><?php echo esc_html(pw_t('Annehmen', 'Accept')); ?></button>
                <button type="button" class="pw-btn ghost small" data-offer-decide="declined"><?php echo esc_html(pw_t('Ablehnen', 'Decline')); ?></button>
              </div>
            <?php else: ?>
              <span class="pw-offer-state"><?php
                $s = $offer['status'] ?? 'open';
                echo esc_html($s === 'accepted' ? pw_t('Angenommen', 'Accepted') : ($s === 'declined' ? pw_t('Abgelehnt', 'Declined') : pw_t('Wartet auf Entscheidung', 'Awaiting decision')));
              ?></span>
            <?php endif; ?>
          </div>
        <?php else: ?>
          <span><?php echo esc_html($m->post_content); ?></span>
        <?php endif; ?>

        <?php if ($att): ?>
          <a class="pw-chat-attachment" href="<?php echo esc_url($att['url']); ?>" target="_blank" rel="noopener noreferrer">
            <?php echo pw_icon('upload'); ?><span><b><?php echo esc_html($att['name']); ?></b><small><?php echo esc_html($att['size']); ?></small></span>
          </a>
        <?php endif; ?>

        <small class="pw-message-meta"><?php echo esc_html($time); ?><?php if ($mine): ?> <i class="pw-read-state<?php echo $read ? ' read' : ''; ?>"><?php echo $read ? '✓✓' : '✓'; ?></i><?php endif; ?></small>
      </div>
    </div>
    <?php return ob_get_clean();
}

function pw_shortcode_messages_v520() {
    if (!is_user_logged_in()) return pw_require_login_html();
    $uid  = get_current_user_id();
    $role = pw_user_role($uid);

    ob_start();
    echo pw_portal_shell_start(pw_t('Nachrichten', 'Messages'), pw_t('Jede Unterhaltung gehört zu genau einer Ausschreibung und einem Profil.', 'Every conversation belongs to exactly one job and one profile.'));
    echo pw_flash_messages();

    $gate = current_user_can('manage_options') ? '' : pw_verified_gate(pw_t('Nachrichten öffnen', 'open messages'));
    if ($gate) { echo $gate; echo pw_portal_shell_end(); return ob_get_clean(); }

    $all     = pw_user_threads($uid);
    $threads = array_values(array_filter($all, function ($t) { return pw_submission_chat_open($t->ID); }));
    $threadId = (int)($_GET['thread'] ?? ($threads ? $threads[0]->ID : 0));
    if ($threadId && !pw_v520_chat_can($threadId, $uid)) $threadId = 0;

    $totalUnread = 0;
    $meta = [];
    foreach ($threads as $t) { $meta[$t->ID] = pw_v520_thread_meta($t->ID, $uid); $totalUnread += $meta[$t->ID]['unread']; }
    ?>
    <div class="pw-chat-layout pw-chat-v520">
      <aside class="pw-chat-sidebar">
        <div class="pw-chat-sidebar-head">
          <b><?php echo esc_html(pw_t('Unterhaltungen', 'Conversations')); ?></b>
          <?php if ($totalUnread): ?><em data-pw-live-messages><?php echo (int)$totalUnread; ?></em><?php endif; ?>
        </div>
        <div class="pw-chat-search"><?php echo pw_icon('search'); ?><input placeholder="<?php echo esc_attr(pw_t('Unterhaltung suchen', 'Search conversations')); ?>" data-thread-filter></div>
        <div class="pw-thread-list">
          <?php if (!$threads): ?>
            <div class="pw-empty tiny"><p><?php echo esc_html(pw_t('Noch kein Chat. Sobald ein Auftraggeber ein Profil annimmt, öffnet sich hier automatisch eine Unterhaltung.', 'No chat yet. As soon as a client accepts a profile, a conversation opens here automatically.')); ?></p></div>
          <?php else: foreach ($threads as $t):
            $wid = (int)pw_meta($t->ID, 'pw_worker_id', 0);
            $vid = (int)pw_meta($t->ID, 'pw_vacancy_id', 0);
            $w   = pw_worker_fields($wid);
            $label = $role === 'agency' ? pw_vacancy_client_label($vid, $uid) : pw_company_alias((int)pw_meta($t->ID, 'pw_agency_id', 0));
            $tm  = $meta[$t->ID]; ?>
            <a class="pw-thread <?php echo $threadId === $t->ID ? 'active' : ''; ?> <?php echo $tm['unread'] ? 'unread' : ''; ?>" href="<?php echo esc_url(pw_page_url('messages', ['thread' => $t->ID])); ?>">
              <span class="pw-profile-code small"><?php echo esc_html(pw_initials($w['role'])); ?></span>
              <div>
                <b><?php echo esc_html($w['code'] . ' · ' . $w['role']); ?></b>
                <span><?php echo esc_html(pw_vacancy_public_id($vid) . ' · ' . $label); ?></span>
                <small><?php echo esc_html($tm['preview']); ?></small>
              </div>
              <u><?php echo esc_html($tm['time']); ?><?php if ($tm['unread']): ?><i><?php echo (int)$tm['unread']; ?></i><?php endif; ?></u>
            </a>
          <?php endforeach; endif; ?>
        </div>
      </aside>

      <section class="pw-chat-main">
        <?php if (!$threadId): ?>
          <div class="pw-empty chat-empty">
            <?php echo pw_icon('message'); ?>
            <h3><?php echo esc_html(pw_t('Noch keine aktive Unterhaltung', 'No active conversation')); ?></h3>
            <p><?php echo esc_html(pw_t('Ein Chat entsteht, sobald ein Auftraggeber ein anonymisiertes Profil annimmt. Abgelehnte oder pausierte Profile erzeugen keinen Chat.', 'A chat starts as soon as a client accepts an anonymised profile. Declined or paused profiles do not create a chat.')); ?></p>
            <a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><?php echo esc_html($role === 'agency' ? pw_t('Ausschreibungen ansehen', 'Browse jobs') : pw_t('Meine Aufträge öffnen', 'Open my jobs')); ?></a>
          </div>
        <?php else:
          $wid = (int)pw_meta($threadId, 'pw_worker_id', 0);
          $vid = (int)pw_meta($threadId, 'pw_vacancy_id', 0);
          $w   = pw_worker_fields($wid);
          $status = pw_meta($threadId, 'pw_status', 'accepted');
          $agreedRate = pw_meta($threadId, 'pw_agreed_rate', '');
          $counterLabel = $role === 'agency' ? pw_vacancy_client_label($vid, $uid) : pw_company_alias((int)pw_meta($threadId, 'pw_agency_id', 0));
          $messages = pw_thread_messages($threadId);
          $myCard = function_exists('pw_v543_business_card_for_user') ? pw_v543_business_card_for_user($uid, $threadId) : []; ?>

          <header class="pw-chat-head">
            <div>
              <span class="pw-profile-code small"><?php echo esc_html(pw_initials($w['role'])); ?></span>
              <div>
                <h3><?php echo esc_html($w['code'] . ' · ' . $w['role']); ?></h3>
                <p><?php echo esc_html(pw_vacancy_public_id($vid) . ' · ' . $counterLabel); ?></p>
              </div>
            </div>
            <div class="pw-chat-head-right">
              <?php if ($agreedRate): ?><span class="pw-agreed-rate"><?php echo pw_icon('check'); ?> <?php echo esc_html($agreedRate); ?> €/h</span><?php endif; ?>
              <?php echo pw_status_badge($status); ?>
            </div>
          </header>

          <div class="pw-chat-messages" data-thread="<?php echo (int)$threadId; ?>">
            <?php if (!$messages): ?>
              <div class="pw-chat-system"><span><?php echo esc_html(pw_t('Chat geöffnet', 'Chat opened')); ?></span><p><?php echo esc_html(pw_t('Der Auftraggeber hat das anonymisierte Profil angenommen. Klärt hier Verrechnungssatz, Start und Schicht.', 'The client accepted the anonymised profile. Clarify charge rate, start and shift here.')); ?></p></div>
            <?php else: foreach ($messages as $m) echo pw_v520_render_message($m, $uid); endif; ?>
          </div>

          <div class="pw-chat-dock">
          <div class="pw-typing-line" data-typing hidden><i></i><i></i><i></i><span><?php echo esc_html(sprintf(pw_t('%s tippt…', '%s is typing…'), $counterLabel)); ?></span></div>

          <?php if ($role === 'agency' && function_exists('pw_can') && !pw_can('chat_offers')): ?>
            <a class="pw-offer-locked" href="<?php echo esc_url(pw_page_url('account', ['tab' => 'billing'])); ?>"><?php echo pw_icon('lock'); ?> <span><b><?php echo esc_html(pw_t('Verbindliche Angebote ab Pro', 'Binding offers from Pro')); ?></b><small><?php echo esc_html(pw_t('Verrechnungssatz, Start und Schicht als Angebot senden, das der Auftraggeber mit einem Klick annimmt.', 'Send charge rate, start and shift as an offer the client accepts in one click.')); ?></small></span></a>
          <?php elseif ($role === 'agency'): ?>
            <details class="pw-offer-composer">
              <summary><?php echo pw_icon('spark'); ?> <?php echo esc_html(pw_t('Verbindliches Angebot senden', 'Send a binding offer')); ?></summary>
              <div class="pw-form-grid two" data-offer-form>
                <label><?php echo esc_html(pw_t('Verrechnungssatz €/h', 'Charge rate €/h')); ?><input type="text" inputmode="decimal" name="rate" placeholder="24,50" required></label>
                <label><?php echo esc_html(pw_t('Startdatum', 'Start date')); ?><input type="date" name="start" value="<?php echo esc_attr($w['available_from'] ?? ''); ?>"></label>
                <label><?php echo esc_html(pw_t('Schicht', 'Shift')); ?><input type="text" name="shift" placeholder="<?php echo esc_attr(pw_t('Frühschicht', 'Early shift')); ?>"></label>
                <label><?php echo esc_html(pw_t('Wochenstunden', 'Weekly hours')); ?><input type="number" name="hours" min="1" max="60" placeholder="35"></label>
                <label class="full"><?php echo esc_html(pw_t('Notiz (optional)', 'Note (optional)')); ?><input type="text" name="note" placeholder="<?php echo esc_attr(pw_t('Zuschläge, Einsatzdauer, Besonderheiten', 'Premiums, duration, specifics')); ?>"></label>
                <div class="full pw-form-actions">
                  <button type="button" class="pw-btn primary" data-offer-send><?php echo esc_html(pw_t('Angebot senden', 'Send offer')); ?></button>
                  <small><?php echo esc_html(pw_t('Der Auftraggeber kann direkt im Chat annehmen oder ablehnen.', 'The client can accept or decline right in the chat.')); ?></small>
                </div>
              </div>
            </details>
          <?php endif; ?>

          <div class="pw-quick-replies">
            <?php foreach (pw_v520_canned($uid) as $c): ?>
              <button type="button" data-quick-reply="<?php echo esc_attr($c); ?>"><?php echo esc_html(wp_trim_words($c, 6, '…')); ?></button>
            <?php endforeach; ?>
            <details class="pw-canned-editor">
              <summary><?php echo esc_html(pw_t('Bausteine bearbeiten', 'Edit snippets')); ?></summary>
              <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="pw_v520_canned_save">
                <input type="hidden" name="submission_id" value="<?php echo (int)$threadId; ?>">
                <?php wp_nonce_field('pw_v520_canned_save'); ?>
                <textarea name="canned" rows="5"><?php echo esc_textarea(implode("\n", pw_v520_canned($uid))); ?></textarea>
                <small><?php echo esc_html(pw_t('Eine Zeile pro Baustein, maximal zwölf.', 'One line per snippet, twelve maximum.')); ?></small>
                <button class="pw-btn small primary"><?php echo esc_html(pw_t('Speichern', 'Save')); ?></button>
              </form>
            </details>
          </div>

          <?php if ($myCard): ?>
          <div class="pw-v543-card-panel" data-pw-business-card-panel hidden>
            <div class="pw-v543-card-panel-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('DIGITALE VISITENKARTE','DIGITAL BUSINESS CARD')); ?></span><h4><?php echo esc_html(pw_t('Firmenkontakt direkt teilen','Share company contact directly')); ?></h4><p><?php echo esc_html(pw_t('Mit dem Senden gibst du diese Firmen- und Kontaktdaten freiwillig für diese Unterhaltung frei.','By sending, you voluntarily share these company and contact details in this conversation.')); ?></p></div><button type="button" class="pw-v543-card-close" data-pw-business-card-close aria-label="<?php echo esc_attr(pw_t('Schließen','Close')); ?>">×</button></div>
            <?php echo pw_v543_card_html(array_merge($myCard,['download_url'=>'']), true); ?>
            <div class="pw-v543-card-panel-actions"><a class="pw-text-link" href="<?php echo esc_url(pw_page_url('account',['tab'=>'profile'])); ?>"><?php echo esc_html(pw_t('Kontaktdaten bearbeiten','Edit contact details')); ?></a><button type="button" class="pw-btn primary small" data-pw-business-card-send><?php echo pw_icon('card'); ?> <?php echo esc_html(pw_t('Visitenkarte senden','Send business card')); ?></button></div>
          </div>
          <?php endif; ?>

          <form class="pw-chat-compose" data-chat-form enctype="multipart/form-data">
            <input type="hidden" name="submission_id" value="<?php echo (int)$threadId; ?>">
            <?php if ($myCard): ?><button type="button" class="pw-attach-btn pw-v543-card-toggle" data-pw-business-card-toggle title="<?php echo esc_attr(pw_t('Digitale Visitenkarte senden','Send digital business card')); ?>"><?php echo pw_icon('card'); ?></button><?php endif; ?>
            <?php if ($role !== 'agency' || !function_exists('pw_can') || pw_can('chat_attachments')): ?>
            <label class="pw-attach-btn" title="<?php echo esc_attr(pw_t('Datei anhängen (PDF, JPG, PNG, Word – max. 5 MB)', 'Attach a file (PDF, JPG, PNG, Word – max 5 MB)')); ?>">
              <?php echo pw_icon('upload'); ?>
              <input type="file" name="attachment" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" hidden>
            </label>
            <?php endif; ?>
            <textarea name="message" rows="1" placeholder="<?php echo esc_attr(pw_t('Nachricht schreiben… (Enter sendet, Umschalt+Enter macht einen Absatz)', 'Write a message… (Enter sends, Shift+Enter adds a line break)')); ?>"></textarea>
            <button class="pw-btn primary small" type="submit"><?php echo esc_html(pw_t('Senden', 'Send')); ?> <?php echo pw_icon('arrow'); ?></button>
          </form>
          <div class="pw-attach-preview" data-attach-preview hidden></div>
          </div>

          <?php if ($role === 'client' && $status === 'accepted' && !pw_submission_identity_released($threadId)): ?>
            <div class="pw-final-confirm">
              <div><?php echo pw_icon('check'); ?>
                <div>
                  <span class="pw-kicker"><?php echo esc_html(pw_t('2. BESTÄTIGUNG', 'SECOND CONFIRMATION')); ?></span>
                  <h3><?php echo esc_html(pw_t('Zusammenarbeit final bestätigen', 'Finally confirm cooperation')); ?></h3>
                  <p><?php echo esc_html(pw_t('Erst jetzt sieht die Zeitarbeitsfirma deinen Firmennamen und deine Kontaktdaten – ausschließlich für diese Job-ID.', 'Only now does the agency see your company name and contact details – for this job ID only.')); ?></p>
                </div>
              </div>
              <a class="pw-btn primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_finalize_match&submission=' . $threadId), 'pw_finalize_' . $threadId)); ?>"><?php echo esc_html(pw_t('Final bestätigen & Kontakt freigeben', 'Final confirm & reveal contact')); ?></a>
            </div>
          <?php endif; ?>

          <?php if ($role === 'agency' && pw_submission_identity_released($threadId)): $c = pw_vacancy_client_contact($vid, $uid); ?>
            <div class="pw-final-confirm done">
              <div><?php echo pw_icon('check'); ?>
                <div>
                  <span class="pw-kicker"><?php echo esc_html(pw_t('AUFTRAGGEBER FREIGEGEBEN', 'CLIENT REVEALED')); ?></span>
                  <h3><?php echo esc_html($c['company'] ?? ''); ?></h3>
                  <p><?php echo esc_html(trim(($c['contact'] ?? '') . ' · ' . ($c['email'] ?? '') . ' · ' . ($c['phone'] ?? ''), ' ·')); ?></p>
                </div>
              </div>
            </div>
          <?php endif; ?>
        <?php endif; ?>
      </section>
    </div>
    <?php
    echo pw_portal_shell_end();
    return ob_get_clean();
}

function pw_v520_register_messages() {
    remove_shortcode('pw_messages');
    add_shortcode('pw_messages', 'pw_shortcode_messages_v520');
}
add_action('init', 'pw_v520_register_messages', 2000);
