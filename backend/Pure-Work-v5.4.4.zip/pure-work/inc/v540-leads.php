<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.4.0 – Nur Firmen, die Zeitarbeit überhaupt einsetzen.
 *
 * Im Datenbestand standen Adressen, bei denen ein Anruf verbrannte Zeit ist.
 * Der auffälligste Fall: eine Berufsgenossenschaft, geführt als "confirmed".
 * Berufsgenossenschaften sind Träger der gesetzlichen Unfallversicherung –
 * öffentlich-rechtliche Körperschaften mit Tarifbindung und eigenen
 * Stellenverfahren. Die kaufen keine gewerbliche Arbeitnehmerüberlassung ein.
 *
 * Dieser Filter greift an genau einer Stelle: der zentralen Ladefunktion.
 * Damit verschwinden ungeeignete Adressen aus jeder Ansicht gleichzeitig –
 * Direktkontakte, Zielkunden, Radar und Statistik.
 */

/* --------------------------------------------------------------------------
 * 1. Was fliegt raus
 * ----------------------------------------------------------------------- */
function pw_v540_excluded_terms() {
    return [
        // Öffentlich-rechtlich / Selbstverwaltung: eigene Tarif- und Stellenverfahren
        'berufsgenossenschaft', 'bghw', 'unfallkasse', 'krankenkasse', 'sozialversicherung',
        'handwerkskammer', 'industrie- und handelskammer', 'ihk ', 'kammer',
        'stadtverwaltung', 'landratsamt', 'regierungspräsidium', 'bundesagentur',
        'arbeitsagentur', 'jobcenter', 'finanzamt', 'ministerium', 'behörde',
        // Interessenvertretung statt Betrieb
        'gewerkschaft', 'arbeitgeberverband', 'innung', 'verband der',
        // Wettbewerb: andere Personaldienstleister braucht niemand als Kunden
        'zeitarbeit', 'personaldienstleist', 'personalservice', 'arbeitnehmerüberlassung',
        'personalvermittlung', 'randstad', 'adecco', 'manpower', 'orizon', 'persona service',
        // Genossenschaftliches Wohnen / Verwaltung ohne eigene gewerbliche Belegschaft
        'baugenossenschaft', 'wohnungsgenossenschaft', 'wohnungsbaugesellschaft',
        'hausverwaltung', 'immobilienverwaltung',
    ];
}

function pw_v540_excluded_sectors() {
    return ['verwaltung', 'behörde', 'kammer', 'verband', 'versicherung', 'bank',
            'kanzlei', 'steuerberatung', 'wohnungswirtschaft'];
}

/* --------------------------------------------------------------------------
 * 2. Wie stark ein Sektor Zeitarbeit tatsächlich nachfragt
 *    Grundlage: Struktur der Arbeitnehmerüberlassung in Deutschland – der
 *    weitaus größte Teil der Einsätze entfällt auf Lager/Logistik, Produktion
 *    und Helfertätigkeiten, ein wachsender Teil auf Pflege.
 * ----------------------------------------------------------------------- */
function pw_v540_sector_demand() {
    return [
        'logistik'      => ['score' => 100, 'label' => pw_t('Sehr hohe Nachfrage', 'Very high demand'), 'why' => pw_t('Lager, Kommissionierung und Versand arbeiten mit starken Saisonspitzen und decken diese fast durchgängig über Zeitarbeit ab.', 'Warehousing and shipping have strong seasonal peaks that are almost always covered by temporary staff.')],
        'lager'         => ['score' => 100, 'label' => pw_t('Sehr hohe Nachfrage', 'Very high demand'), 'why' => pw_t('Lagerpersonal ist der größte Einzelbereich der Arbeitnehmerüberlassung.', 'Warehouse staff is the single largest area of temporary employment.')],
        'paket'         => ['score' => 100, 'label' => pw_t('Sehr hohe Nachfrage', 'Very high demand'), 'why' => pw_t('Paketdienste fahren das Jahresende fast vollständig mit Überlassung.', 'Parcel services run year-end volumes largely on temporary staff.')],
        'spedition'     => ['score' => 95,  'label' => pw_t('Sehr hohe Nachfrage', 'Very high demand'), 'why' => pw_t('Fahrer- und Umschlagpersonal wird kurzfristig zugekauft.', 'Drivers and handling staff are bought in at short notice.')],
        'e-commerce'    => ['score' => 95,  'label' => pw_t('Sehr hohe Nachfrage', 'Very high demand'), 'why' => pw_t('Versandzentren skalieren die Belegschaft wochenweise.', 'Fulfilment centres scale headcount week by week.')],
        'produktion'    => ['score' => 92,  'label' => pw_t('Hohe Nachfrage', 'High demand'), 'why' => pw_t('Schichtbetrieb mit schwankender Auslastung, klassischer Einsatzbereich.', 'Shift operations with fluctuating capacity – a classic use case.')],
        'industrie'     => ['score' => 90,  'label' => pw_t('Hohe Nachfrage', 'High demand'), 'why' => pw_t('Anlagenstillstände, Umbauten und Auftragsspitzen werden über Überlassung abgefedert.', 'Shutdowns, retooling and order peaks are cushioned with temporary staff.')],
        'automotive'    => ['score' => 90,  'label' => pw_t('Hohe Nachfrage', 'High demand'), 'why' => pw_t('Die Branche mit der längsten Tradition in der Arbeitnehmerüberlassung.', 'The industry with the longest tradition of temporary employment.')],
        'lebensmittel'  => ['score' => 88,  'label' => pw_t('Hohe Nachfrage', 'High demand'), 'why' => pw_t('Produktion und Kommissionierung mit Tages- und Saisonspitzen.', 'Production and picking with daily and seasonal peaks.')],
        'chemie'        => ['score' => 82,  'label' => pw_t('Hohe Nachfrage', 'High demand'), 'why' => pw_t('Revisionen und Projektphasen erzeugen planbaren Zusatzbedarf.', 'Turnarounds and project phases create predictable extra demand.')],
        'pharma'        => ['score' => 80,  'label' => pw_t('Hohe Nachfrage', 'High demand'), 'why' => pw_t('Chargenproduktion und Verpackung laufen mit flexibler Besetzung.', 'Batch production and packaging run with flexible staffing.')],
        'maschinenbau'  => ['score' => 80,  'label' => pw_t('Hohe Nachfrage', 'High demand'), 'why' => pw_t('Montage und Fertigung folgen dem Auftragseingang.', 'Assembly and manufacturing follow incoming orders.')],
        'baustoffe'     => ['score' => 78,  'label' => pw_t('Hohe Nachfrage', 'High demand'), 'why' => pw_t('Stark saisonabhängig, Spitzen werden zugekauft.', 'Highly seasonal – peaks are bought in.')],
        'pflege'        => ['score' => 76,  'label' => pw_t('Wachsende Nachfrage', 'Growing demand'), 'why' => pw_t('Ausfälle im Schichtdienst lassen sich intern kaum auffangen.', 'Shift absences can hardly be covered internally.')],
        'gesundheit'    => ['score' => 74,  'label' => pw_t('Wachsende Nachfrage', 'Growing demand'), 'why' => pw_t('Kliniken decken Engpässe im Pflegedienst über Überlassung ab.', 'Hospitals cover nursing shortages with temporary staff.')],
        'handel'        => ['score' => 70,  'label' => pw_t('Mittlere Nachfrage', 'Medium demand'), 'why' => pw_t('Inventuren, Umbauten und Aktionswochen erzeugen kurze Spitzen.', 'Stocktakes, refits and promotion weeks create short peaks.')],
        'baumarkt'      => ['score' => 70,  'label' => pw_t('Mittlere Nachfrage', 'Medium demand'), 'why' => pw_t('Saisonstart im Frühjahr und Inventur sind die typischen Anlässe.', 'The spring season start and stocktaking are the typical triggers.')],
        'großhandel'    => ['score' => 72,  'label' => pw_t('Mittlere Nachfrage', 'Medium demand'), 'why' => pw_t('Lagerumschlag schwankt mit dem Bestellverhalten der Kunden.', 'Warehouse turnover fluctuates with customer ordering.')],
        'hotel'         => ['score' => 66,  'label' => pw_t('Mittlere Nachfrage', 'Medium demand'), 'why' => pw_t('Messen, Tagungen und Saison erzeugen tageweise Bedarf.', 'Trade fairs, conferences and seasons create day-by-day demand.')],
        'gastronomie'   => ['score' => 64,  'label' => pw_t('Mittlere Nachfrage', 'Medium demand'), 'why' => pw_t('Veranstaltungsgeschäft mit kurzfristigem Personalbedarf.', 'Event business with short-notice staffing needs.')],
        'verpackung'    => ['score' => 78,  'label' => pw_t('Hohe Nachfrage', 'High demand'), 'why' => pw_t('Konfektionierung wird typischerweise flexibel besetzt.', 'Co-packing is typically staffed flexibly.')],
        'energie'       => ['score' => 58,  'label' => pw_t('Geringere Nachfrage', 'Lower demand'), 'why' => pw_t('Überwiegend Stammpersonal, Bedarf vor allem bei Projekten.', 'Mostly permanent staff; demand mainly during projects.')],
        'medizintechnik'=> ['score' => 68,  'label' => pw_t('Mittlere Nachfrage', 'Medium demand'), 'why' => pw_t('Fertigung und Reinraum werden bei Auftragsspitzen aufgestockt.', 'Manufacturing and cleanroom scale up during order peaks.')],
        'aerospace'     => ['score' => 70,  'label' => pw_t('Mittlere Nachfrage', 'Medium demand'), 'why' => pw_t('Programmphasen bestimmen den Personalbedarf.', 'Programme phases drive staffing needs.')],
    ];
}

/**
 * Bewertet einen Datensatz. Rückgabe: null bedeutet "gehört nicht in die Liste".
 */
function pw_v540_rate_contact($row) {
    $haystack = pw_normalize_text(($row['company'] ?? '') . ' ' . ($row['sector'] ?? '') . ' ' . ($row['contact_role'] ?? ''));

    foreach (pw_v540_excluded_terms() as $term) {
        if (strpos($haystack, pw_normalize_text($term)) !== false) return null;
    }
    $sectorNorm = pw_normalize_text($row['sector'] ?? '');
    foreach (pw_v540_excluded_sectors() as $bad) {
        if (strpos($sectorNorm, pw_normalize_text($bad)) !== false) return null;
    }

    $best = null;
    foreach (pw_v540_sector_demand() as $key => $def) {
        if (strpos($sectorNorm, pw_normalize_text($key)) !== false) {
            if (!$best || $def['score'] > $best['score']) $best = $def;
        }
    }
    // Kein bekannter Sektor: nicht raten, aber auch nicht wegwerfen –
    // als schwächster Eintrag führen, damit er unten in der Liste landet.
    if (!$best) {
        $best = ['score' => 40, 'label' => pw_t('Bedarf unklar', 'Demand unclear'),
                 'why' => pw_t('Der Sektor ist kein typischer Einsatzbereich der Arbeitnehmerüberlassung. Vor dem Anruf kurz prüfen.', 'This sector is not a typical area for temporary staffing. Check briefly before calling.')];
    }
    return $best;
}

/**
 * Zentraler Eingriff: reichert an, sortiert nach Nachfrage und wirft ungeeignete
 * Adressen weg.
 */
function pw_v540_filter_contacts($rows) {
    if (!is_array($rows)) return $rows;
    $out = [];
    foreach ($rows as $id => $row) {
        $rating = pw_v540_rate_contact($row);
        if ($rating === null) continue;
        $row['pw_demand_score'] = $rating['score'];
        $row['pw_demand_label'] = $rating['label'];
        $row['pw_demand_why']   = $rating['why'];
        $out[$id] = $row;
    }
    uasort($out, function ($a, $b) {
        return ($b['pw_demand_score'] ?? 0) <=> ($a['pw_demand_score'] ?? 0);
    });
    return $out;
}
add_filter('pw_direct_contacts', 'pw_v540_filter_contacts', 10);

/**
 * Für den Betreiber sichtbar machen, was der Filter tut.
 */
function pw_v540_contacts_report() {
    if (!function_exists('pw_local_direct_contacts_all_492')) return ['kept' => 0, 'removed' => 0];
    $all = pw_v540_raw_contacts();
    $kept = pw_v540_filter_contacts($all);
    return ['kept' => count($kept), 'removed' => count($all) - count($kept)];
}

function pw_v540_raw_contacts() {
    static $raw = null;
    if ($raw !== null) return $raw;
    remove_filter('pw_direct_contacts', 'pw_v540_filter_contacts', 10);
    $raw = pw_local_direct_contacts_all_492();
    add_filter('pw_direct_contacts', 'pw_v540_filter_contacts', 10);
    return $raw;
}
