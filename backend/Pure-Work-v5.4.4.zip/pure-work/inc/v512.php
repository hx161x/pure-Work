<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.1.2 – professional rebuild.
 * Keeps the strong 5.0.3 command-center dashboard and the useful 5.1.1
 * workflow/premium features. No extra status-ribbon or focus-mode layer.
 */
function pw_v512_upgrade(){
    if(get_option('pw_version_512','')==='5.1.2') return;
    update_option('pw_version_512','5.1.2',false);
    update_option('pw_version','5.1.2',false);
    flush_rewrite_rules(false);
}
add_action('init','pw_v512_upgrade',2600);

function pw_shortcode_dashboard_v512(){
    return pw_shortcode_dashboard_v511();
}

/** Keep the Pro availability overview where users expect it: above the pool. */
function pw_shortcode_workers_v512(){
    $html=pw_shortcode_workers_v510();
    if(!is_user_logged_in()||pw_user_role()!=='agency') return $html;
    $uid=get_current_user_id();
    if(!empty($_GET['view'])){
        $extra=pw_v511_profile_studio((int)$_GET['view'],$uid);
        if($extra)$html=str_replace('</main>',$extra.'</main>',$html);
        return $html;
    }
    if(empty($_GET['new'])&&empty($_GET['edit'])&&pw_v511_plan_rank($uid)>=2){
        $availability=pw_v511_availability_strip($uid);
        $needle='<section class="pw-v510-page-intro">';
        $pos=strpos($html,$needle);
        if($pos!==false)$html=substr_replace($html,$availability.$needle,$pos,0);
    }
    return $html;
}

function pw_v512_register(){
    remove_shortcode('pw_dashboard');add_shortcode('pw_dashboard','pw_shortcode_dashboard_v512');
    remove_shortcode('pw_workers');add_shortcode('pw_workers','pw_shortcode_workers_v512');
}
add_action('init','pw_v512_register',2700);
