<?php
if (!defined('ABSPATH')) exit;

/**
 * Encryption helpers for employee PII stored in post meta.
 * Uses AES-256-GCM when OpenSSL is available. The key is derived from the
 * WordPress auth salt and never stored in the database.
 */
function pw_crypto_key() {
    return hash_hmac('sha256', 'pure-work-worker-pii-v1', wp_salt('auth'), true);
}

function pw_is_encrypted_value($value) {
    return is_string($value) && (strpos($value, 'pwenc:v1:') === 0 || strpos($value, 'pwsod:v1:') === 0);
}

function pw_encrypt_sensitive($plain) {
    $plain = (string)$plain;
    if ($plain === '' || pw_is_encrypted_value($plain)) return $plain;
    if (function_exists('openssl_encrypt')) {
        try { $iv = random_bytes(12); } catch (Exception $e) { $iv = openssl_random_pseudo_bytes(12); }
        $tag = '';
        $cipher = openssl_encrypt($plain, 'aes-256-gcm', pw_crypto_key(), OPENSSL_RAW_DATA, $iv, $tag, '', 16);
        if ($cipher !== false) return 'pwenc:v1:' . base64_encode($iv . $tag . $cipher);
    }
    if (function_exists('sodium_crypto_secretbox')) {
        try { $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES); } catch (Exception $e) { return ''; }
        $cipher = sodium_crypto_secretbox($plain, $nonce, pw_crypto_key());
        return 'pwsod:v1:' . base64_encode($nonce . $cipher);
    }
    return '';
}

function pw_decrypt_sensitive($value) {
    $value = (string)$value;
    if (strpos($value, 'pwenc:b64:') === 0) {
        $decoded = base64_decode(substr($value, 10), true);
        return $decoded === false ? '' : $decoded;
    }
    if (strpos($value, 'pwsod:v1:') === 0) {
        $raw = base64_decode(substr($value, 9), true);
        if ($raw === false || !function_exists('sodium_crypto_secretbox_open') || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) return '';
        $nonce = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $cipher = substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $plain = sodium_crypto_secretbox_open($cipher, $nonce, pw_crypto_key());
        return $plain === false ? '' : $plain;
    }
    if (strpos($value, 'pwenc:v1:') !== 0) return $value;
    $raw = base64_decode(substr($value, 9), true);
    if ($raw === false || strlen($raw) < 29 || !function_exists('openssl_decrypt')) return '';
    $iv = substr($raw, 0, 12);
    $tag = substr($raw, 12, 16);
    $cipher = substr($raw, 28);
    $plain = openssl_decrypt($cipher, 'aes-256-gcm', pw_crypto_key(), OPENSSL_RAW_DATA, $iv, $tag, '');
    return $plain === false ? '' : $plain;
}

function pw_sensitive_post_meta($post_id, $key, $default = '') {
    $raw = get_post_meta($post_id, $key, true);
    if ($raw === '' || $raw === null) return $default;
    return pw_decrypt_sensitive($raw);
}

function pw_update_sensitive_post_meta($post_id, $key, $value) {
    $value = (string)$value;
    if ($value === '') return update_post_meta($post_id, $key, '');
    return update_post_meta($post_id, $key, pw_encrypt_sensitive($value));
}

function pw_encrypt_legacy_worker_pii() {
    if (get_option('pw_worker_pii_encrypted_480', '0') === '1') return;
    $ids = get_posts(['post_type'=>'pw_worker','post_status'=>'any','posts_per_page'=>-1,'fields'=>'ids']);
    $keys = ['pw_full_name','pw_birth_date','pw_email','pw_phone','pw_address'];
    foreach ($ids as $id) {
        foreach ($keys as $key) {
            $raw = get_post_meta($id, $key, true);
            if ($raw !== '' && !pw_is_encrypted_value($raw) && strpos((string)$raw, 'pwenc:b64:') !== 0) {
                update_post_meta($id, $key, pw_encrypt_sensitive((string)$raw));
            }
        }
    }
    update_option('pw_worker_pii_encrypted_480', '1', false);
}
