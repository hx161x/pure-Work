<?php
if (!defined('ABSPATH')) exit;

function pw_ajax_guard() {
    check_ajax_referer('pw_ajax','nonce');
    if (!is_user_logged_in()) wp_send_json_error(['message'=>'Nicht angemeldet.'],401);
    if (in_array(pw_user_role(), ['agency','client'], true) && !pw_account_active()) {
        wp_send_json_error(['message'=>'Dein Pure Work Konto ist nicht aktiv.'],403);
    }
}

function pw_ajax_submission_status_legacy47() {
    pw_ajax_guard();
    if (pw_user_role() !== 'client' && !current_user_can('manage_options')) wp_send_json_error(['message'=>'Keine Berechtigung.'],403);
    $sid=(int)($_POST['submission_id']??0);$status=sanitize_key(wp_unslash($_POST['status']??''));
    if(!pw_can_access_submission($sid))wp_send_json_error(['message'=>'Kein Zugriff.'],403);
    $allowed=['viewed','shortlisted','requested','confirmed','planned','rejected'];if(!in_array($status,$allowed,true))wp_send_json_error(['message'=>'Status ungültig.'],400);
    update_post_meta($sid,'pw_status',$status);update_post_meta($sid,'pw_status_changed_at',time());
    [$agency,$client]=pw_submission_parties($sid);$wid=(int)pw_meta($sid,'pw_worker_id',0);$vid=(int)pw_meta($sid,'pw_vacancy_id',0);$w=pw_worker_fields($wid);$label=pw_status_labels()[$status][0];
    $agencyUser=get_userdata($agency);pw_create_notice($agency,'Status geändert: '.$label,'Dein Profil '.$w['code'].' für „'.get_the_title($vid).'“ hat jetzt den Status „'.$label.'“.',pw_page_url('messages',['thread'=>$sid]));
    if($agencyUser && in_array($status,['shortlisted','requested','confirmed','planned','rejected'],true)) pw_send_mail($agencyUser->user_email,'Pure Work: '.$label,'Status deiner Profileinreichung geändert','Das Profil '.$w['code'].' für „'.get_the_title($vid).'“ steht jetzt auf „'.$label.'“.','Anfrage öffnen',pw_page_url('messages',['thread'=>$sid]));
    wp_send_json_success(['badge'=>pw_status_badge($status),'label'=>$label]);
}
add_action('wp_ajax_pw_submission_status','pw_ajax_submission_status');

function pw_ajax_send_message_legacy47() {
    pw_ajax_guard();
    $sid=(int)($_POST['submission_id']??0);$text=sanitize_textarea_field(wp_unslash($_POST['message']??''));
    if(!$sid||!$text||!pw_can_access_submission($sid))wp_send_json_error(['message'=>'Nachricht ungültig.'],400);
    [$agency,$client]=pw_submission_parties($sid);$uid=get_current_user_id();$recipient=$uid===$agency?$client:$agency;if(!$recipient)wp_send_json_error(['message'=>'Empfänger fehlt.'],400);
    $id=wp_insert_post(['post_type'=>'pw_message','post_status'=>'publish','post_author'=>$uid,'post_title'=>'Nachricht #'.$sid,'post_content'=>$text]);
    if(is_wp_error($id))wp_send_json_error(['message'=>'Speichern fehlgeschlagen.'],500);
    update_post_meta($id,'pw_submission_id',$sid);update_post_meta($id,'pw_recipient',$recipient);update_post_meta($id,'pw_read','0');
    $u=get_userdata($recipient);$vid=(int)pw_meta($sid,'pw_vacancy_id',0);pw_create_notice($recipient,'Neue Nachricht','Neue Nachricht zu „'.get_the_title($vid).'“.',pw_page_url('messages',['thread'=>$sid]));
    if($u && pw_user_meta($recipient,'pw_message_email','1')!=='0') pw_send_mail($u->user_email,'Neue Nachricht bei Pure Work','Du hast eine neue Nachricht',wp_trim_words($text,35,'…'),'Nachricht öffnen',pw_page_url('messages',['thread'=>$sid]));
    wp_send_json_success(['id'=>$id,'message'=>esc_html($text),'time'=>wp_date('d.m. · H:i')]);
}
add_action('wp_ajax_pw_send_message','pw_ajax_send_message');

function pw_ajax_toggle_favorite() {
    pw_ajax_guard();$uid=get_current_user_id();$company=(int)($_POST['company_id']??0);if(!$company||$company===$uid)wp_send_json_error(['message'=>'Ungültiges Unternehmen.'],400);
    $favs=array_map('intval',(array)pw_user_meta($uid,'pw_favorites',[]));$active=in_array($company,$favs,true);if($active)$favs=array_values(array_diff($favs,[$company]));else$favs[]=$company;update_user_meta($uid,'pw_favorites',array_values(array_unique($favs)));
    wp_send_json_success(['active'=>!$active,'label'=>!$active?'★ Favorit':'☆ Favorisieren']);
}
add_action('wp_ajax_pw_toggle_favorite','pw_ajax_toggle_favorite');

function pw_ajax_toggle_block() {
    pw_ajax_guard();$uid=get_current_user_id();$company=(int)($_POST['company_id']??0);if(!$company||$company===$uid)wp_send_json_error(['message'=>'Ungültiges Unternehmen.'],400);
    $blocked=array_map('intval',(array)pw_user_meta($uid,'pw_blocked_companies',[]));$active=in_array($company,$blocked,true);if($active)$blocked=array_values(array_diff($blocked,[$company]));else$blocked[]=$company;update_user_meta($uid,'pw_blocked_companies',array_values(array_unique($blocked)));
    wp_send_json_success(['active'=>!$active]);
}
add_action('wp_ajax_pw_toggle_block','pw_ajax_toggle_block');


function pw_ajax_occupation_search() {
    pw_ajax_guard();
    $q = sanitize_text_field(wp_unslash($_POST['q'] ?? ''));
    if (strlen($q) < 2) wp_send_json_success(['items'=>[]]);
    $items = pw_catalog_search_official_occupations($q, 24);
    wp_send_json_success(['items'=>$items]);
}
add_action('wp_ajax_pw_occupation_search','pw_ajax_occupation_search');
