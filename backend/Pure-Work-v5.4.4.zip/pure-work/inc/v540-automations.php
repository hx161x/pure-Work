<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.4.0 – vier zusätzliche Automationen.
 *
 * Bewusst keine Attrappen: jede Regel hier hat einen täglichen Durchlauf, der
 * echte Daten prüft und nur dann eine Aufgabe erzeugt, wenn wirklich etwas
 * ansteht. Eine Automation, die jeden Tag dieselbe Meldung schickt, schaltet
 * man nach einer Woche ab.
 */

function pw_v540_automation_defs() {
    return [
        'aug_expiry' => [
            'feature' => 'automations', 'icon' => 'alert',
            'title'   => pw_t('AÜG-Fristenwächter', 'AÜG permit watchdog'),
            'text'    => pw_t('Meldet die befristete Erlaubnis 90, 60 und 30 Tage vor Ablauf. Läuft sie aus, steht der Betrieb.', 'Reports a limited permit 90, 60 and 30 days before expiry. If it lapses, operations stop.'),
        ],
        'max_duration' => [
            'feature' => 'automations', 'icon' => 'clock',
            'title'   => pw_t('Überlassungshöchstdauer', 'Maximum assignment duration'),
            'text'    => pw_t('Warnt, bevor ein Mitarbeiter die 18-Monats-Grenze beim selben Auftraggeber erreicht.', 'Warns before an employee reaches the 18-month limit at the same client.'),
        ],
        'idle_pool' => [
            'feature' => 'pool_health', 'icon' => 'users',
            'title'   => pw_t('Leerlauf-Warnung', 'Idle capacity alert'),
            'text'    => pw_t('Meldet Mitarbeiter, die seit über 14 Tagen verfügbar sind, ohne einer Ausschreibung zugeordnet zu sein.', 'Reports employees available for more than 14 days without being submitted to any job.'),
        ],
        'quiet_clients' => [
            'feature' => 'hot_lead_automation', 'icon' => 'handshake',
            'title'   => pw_t('Max Stille-Kunden-Radar', 'Max dormant client radar'),
            'text'    => pw_t('Hebt Auftraggeber hervor, die früher gebucht haben und seit 60 Tagen nichts mehr angefragt haben.', 'Highlights clients who used to book and have not enquired for 60 days.'),
        ],
    ];
}

/* Die neuen Regeln an die bestehende Liste anhängen, ohne sie zu ersetzen. */
function pw_v540_extend_automations($defs) {
    return is_array($defs) ? array_merge($defs, pw_v540_automation_defs()) : $defs;
}
add_filter('pw_automation_defs', 'pw_v540_extend_automations');

/**
 * Täglicher Durchlauf. Hängt sich an dieselbe Cron-Aktion wie die bestehenden
 * Automationen, damit es genau einen Zeitpunkt pro Tag gibt.
 */
function pw_v540_daily_automations() {
    $today = wp_date('Y-m-d');
    foreach (get_users(['role' => 'pw_agency', 'fields' => 'ID']) as $uid) {
        $uid = (int)$uid;
        if (!get_userdata($uid)) continue;

        /* --- AÜG-Erlaubnis läuft ab ------------------------------------- */
        if (pw_v540_rule_on($uid, 'aug_expiry', 'automations')) {
            $expiry = pw_user_meta($uid, 'pw_aug_expiry', '');
            $type   = pw_user_meta($uid, 'pw_aug_type', 'limited');
            if ($type === 'limited' && $expiry) {
                $days = (int)floor((strtotime($expiry) - time()) / DAY_IN_SECONDS);
                foreach ([90, 60, 30, 14, 7] as $mark) {
                    if ($days === $mark && pw_user_meta($uid, 'pw_auto_aug_expiry_mark', '') !== (string)$mark) {
                        pw_create_notice($uid,
                            sprintf(pw_t('AÜG-Erlaubnis läuft in %d Tagen ab', 'AÜG permit expires in %d days'), $days),
                            pw_t('Die Verlängerung muss bei der zuständigen Agentur für Arbeit rechtzeitig beantragt werden. Ohne gültige Erlaubnis darf nicht überlassen werden.', 'The extension must be applied for at the responsible employment agency in good time. Without a valid permit, no staff may be assigned.'),
                            pw_page_url('account', ['tab' => 'profile']));
                        update_user_meta($uid, 'pw_auto_aug_expiry_mark', (string)$mark);
                    }
                }
            }
        }

        /* --- Überlassungshöchstdauer ------------------------------------ */
        if (pw_v540_rule_on($uid, 'max_duration', 'automations')
            && pw_user_meta($uid, 'pw_auto_max_duration_last', '') !== $today) {
            $warn = pw_v540_duration_warnings($uid);
            if ($warn) {
                pw_create_notice($uid,
                    pw_t('Überlassungsdauer im Blick behalten', 'Watch assignment duration'),
                    sprintf(pw_t('%d Einsätze nähern sich der Höchstüberlassungsdauer von 18 Monaten beim selben Auftraggeber.', '%d assignments are approaching the 18-month maximum at the same client.'), $warn),
                    pw_page_url('assignments'));
            }
            update_user_meta($uid, 'pw_auto_max_duration_last', $today);
        }

        /* --- Leerlauf im Pool ------------------------------------------- */
        if (pw_v540_rule_on($uid, 'idle_pool', 'pool_health')
            && pw_user_meta($uid, 'pw_auto_idle_pool_last', '') !== $today) {
            $idle = pw_v540_idle_workers($uid);
            if ($idle) {
                pw_create_notice($uid,
                    sprintf(pw_t('%d Mitarbeiter ohne Zuordnung', '%d employees without a submission'), $idle),
                    pw_t('Diese Mitarbeiter stehen seit über zwei Wochen als verfügbar im Pool, sind aber keiner Ausschreibung zugeordnet. Jeder Tag Leerlauf kostet.', 'These employees have been listed as available for over two weeks without being submitted to any job. Every idle day costs money.'),
                    pw_page_url('matches'));
            }
            update_user_meta($uid, 'pw_auto_idle_pool_last', $today);
        }

        /* --- Stille Kunden (Max) ---------------------------------------- */
        if (pw_v540_rule_on($uid, 'quiet_clients', 'hot_lead_automation')
            && pw_user_meta($uid, 'pw_auto_quiet_clients_last', '') !== $today) {
            $quiet = pw_v540_quiet_clients($uid);
            if ($quiet) {
                pw_create_notice($uid,
                    sprintf(pw_t('%d frühere Auftraggeber sind still geworden', '%d former clients have gone quiet'), $quiet),
                    pw_t('Sie haben schon einmal über Pure Work besetzt, aber seit 60 Tagen nichts mehr angefragt. Ein bestehender Kontakt ist deutlich leichter zu gewinnen als ein neuer.', 'They have placed staff through Pure Work before but have not enquired for 60 days. An existing contact is far easier to win back than a new one.'),
                    pw_page_url('crm'));
            }
            update_user_meta($uid, 'pw_auto_quiet_clients_last', $today);
        }
    }
}
add_action('pw_daily_digest_event', 'pw_v540_daily_automations', 20);

function pw_v540_rule_on($uid, $key, $feature) {
    return function_exists('pw_can') && pw_can($feature, $uid)
        && pw_user_meta($uid, 'pw_auto_' . $key, '0') === '1';
}

/* ---------------------------------------------------------------------------
 * Auswertungen
 * ------------------------------------------------------------------------ */
function pw_v540_duration_warnings($uid) {
    $subs = get_posts(['post_type' => 'pw_submission', 'post_status' => 'publish', 'posts_per_page' => 200,
        'meta_query' => [
            ['key' => 'pw_agency_id', 'value' => $uid],
            ['key' => 'pw_status', 'value' => ['planned', 'confirmed'], 'compare' => 'IN'],
        ]]);
    $count = 0;
    foreach ($subs as $s) {
        $start = pw_meta($s->ID, 'pw_agreed_start', '') ?: pw_meta($s->ID, 'pw_start_date', '');
        if (!$start) continue;
        $months = (time() - strtotime($start)) / (30.44 * DAY_IN_SECONDS);
        if ($months >= 15 && $months < 19) $count++;   // Vorwarnung ab dem 15. Monat
    }
    return $count;
}

function pw_v540_idle_workers($uid) {
    $workers = get_posts(['post_type' => 'pw_worker', 'post_status' => 'publish', 'author' => $uid,
        'posts_per_page' => 200, 'fields' => 'ids']);
    $cut = time() - 14 * DAY_IN_SECONDS;
    $idle = 0;
    foreach ($workers as $wid) {
        $w = pw_worker_fields($wid);
        if (($w['status'] ?? '') !== 'available') continue;
        if (strtotime(get_post_field('post_modified_gmt', $wid) . ' GMT') > $cut) continue;
        $has = get_posts(['post_type' => 'pw_submission', 'post_status' => 'publish', 'posts_per_page' => 1,
            'fields' => 'ids', 'meta_query' => [['key' => 'pw_worker_id', 'value' => (int)$wid]]]);
        if (!$has) $idle++;
    }
    return $idle;
}

function pw_v540_quiet_clients($uid) {
    $subs = get_posts(['post_type' => 'pw_submission', 'post_status' => 'publish', 'posts_per_page' => 300,
        'meta_query' => [['key' => 'pw_agency_id', 'value' => $uid]]]);
    $last = [];
    foreach ($subs as $s) {
        $vid = (int)pw_meta($s->ID, 'pw_vacancy_id', 0);
        if (!$vid) continue;
        $client = (int)get_post_field('post_author', $vid);
        if (!$client) continue;
        $t = strtotime($s->post_date_gmt . ' GMT');
        if (!isset($last[$client]) || $t > $last[$client]) $last[$client] = $t;
    }
    $cut = time() - 60 * DAY_IN_SECONDS;
    return count(array_filter($last, function ($t) use ($cut) { return $t < $cut; }));
}
