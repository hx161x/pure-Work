<?php
if (!defined('ABSPATH')) exit;

/** Pure Work 5.1.1 – visual calm + stronger premium value. */
function pw_v511_upgrade(){
    if(get_option('pw_version_511','')==='5.1.1') return;
    update_option('pw_version_511','5.1.1',false);
    update_option('pw_version','5.1.1',false);
    flush_rewrite_rules(false);
}
add_action('init','pw_v511_upgrade',2100);

function pw_v511_plan_rank($uid=0){
    $p=pw_current_plan($uid); return $p==='enterprise'?3:($p==='professional'?2:($p==='basic'?1:0));
}

/** Whole-pool reverse matching: a real Max feature. */
function pw_v511_placement_rows($uid,$limit=6){
    $workers=get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>120]);
    $jobs=get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','posts_per_page'=>100,'meta_query'=>[['key'=>'pw_status','value'=>'open']]]);
    $rows=[];
    foreach($workers as $wp){
        $w=pw_worker_fields($wp->ID);
        if(($w['status']??'')==='inactive'||($w['status']??'')==='assigned') continue;
        foreach($jobs as $jp){
            if(function_exists('pw_agency_can_see_vacancy')&&!pw_agency_can_see_vacancy($uid,$jp->ID)) continue;
            if(function_exists('pw_submission_exists')&&pw_submission_exists($jp->ID,$wp->ID)) continue;
            $m=pw_match_worker_to_vacancy($wp->ID,$jp->ID); $score=(int)($m['score']??0);
            if($score<55) continue;
            $rows[]=['worker_id'=>$wp->ID,'vacancy_id'=>$jp->ID,'w'=>$w,'v'=>pw_vacancy_fields($jp->ID),'m'=>$m,'score'=>$score];
        }
    }
    usort($rows,fn($a,$b)=>$b['score']<=>$a['score']);
    return array_slice($rows,0,$limit);
}

function pw_v511_placement_radar($uid){
    if(pw_current_plan($uid)!=='enterprise') return '';
    $rows=pw_v511_placement_rows($uid,6);
    ob_start(); ?>
    <section class="pw-card pw-v511-radar">
      <div class="pw-card-head"><div><span class="pw-kicker">MAX · <?php echo esc_html(pw_t('PLATZIERUNGSRADAR','PLACEMENT RADAR')); ?></span><h2><?php echo esc_html(pw_t('Wen kannst du heute am besten platzieren?','Who can you place best today?')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Pure Work vergleicht deinen verfügbaren Pool automatisch mit allen offenen, sichtbaren Bedarfen.','Pure Work automatically compares your available pool with all visible open demand.')); ?></p></div><span class="pw-v511-live"><i></i><?php echo esc_html(pw_t('LIVE AUS DEINEN DATEN','LIVE FROM YOUR DATA')); ?></span></div>
      <div class="pw-v511-radar-list">
      <?php if(!$rows): ?><div class="pw-empty compact"><?php echo pw_icon('target'); ?><p><?php echo esc_html(pw_t('Aktuell gibt es noch keine ausreichend starke Pool-zu-Auftrag-Kombination.','There is no sufficiently strong pool-to-job combination right now.')); ?></p></div>
      <?php else: foreach($rows as $i=>$r): ?>
        <a href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$r['vacancy_id']])); ?>">
          <span class="pw-v511-rank"><?php echo sprintf('%02d',$i+1); ?></span>
          <span class="pw-profile-code small"><?php echo esc_html(pw_initials($r['w']['role'])); ?></span>
          <div><b><?php echo esc_html($r['w']['full_name']?:$r['w']['code']); ?></b><small><?php echo esc_html(($r['w']['role']?:'–').' → '.($r['v']['title']?:'–')); ?></small><em><?php echo esc_html(implode(' · ',array_slice((array)($r['m']['reasons']??[]),0,2))); ?></em></div>
          <strong class="<?php echo $r['score']>=80?'high':''; ?>"><?php echo $r['score']; ?>%</strong><?php echo pw_icon('arrow'); ?>
        </a>
      <?php endforeach; endif; ?>
      </div>
    </section><?php return ob_get_clean();
}

function pw_v511_power_center($uid){
    $plan=pw_current_plan($uid); if(!in_array($plan,['professional','enterprise'],true)) return '';
    $isMax=$plan==='enterprise';
    $tools=[
      ['document',pw_t('Profilstudio','Profile studio'),pw_t('Anonymes Kundenprofil in Sekunden erstellen und kopieren.','Create and copy a client-ready anonymous profile in seconds.'),pw_page_url('workers')],
      ['spark',pw_t('Smart-Matching','Smart matching'),pw_t('Mehrere passende Mitarbeiter gleichzeitig zuordnen.','Submit several matching employees in one go.'),pw_page_url('vacancies')],
      ['calendar',pw_t('Verfügbarkeitsplaner','Availability planner'),pw_t('Freie und bald verfügbare Kapazität sofort erkennen.','See free and soon-available capacity instantly.'),pw_page_url('workers',['viewmode'=>'availability'])],
      ['calculator',pw_t('Kalkulation','Calculator'),pw_t('Verrechnungssatz und Marge vor dem Angebot prüfen.','Check bill rate and margin before quoting.'),pw_page_url('calculator')],
    ];
    if($isMax){
      $tools[]=['target',pw_t('Platzierungsradar','Placement radar'),pw_t('Den gesamten Pool automatisch gegen den Markt matchen.','Automatically match the entire pool against the market.'),'#pw-placement-radar'];
      $tools[]=['chart',pw_t('Performance','Performance'),pw_t('Besetzung, Reaktionszeiten und Wachstum steuern.','Manage placements, response times and growth.'),pw_page_url('dashboard',['panel'=>'insights'])];
      $tools[]=['target',pw_t('Zielkunden','Target accounts'),pw_t('Priorisierte Unternehmen mit belegtem Bedarf.','Prioritised companies with evidenced demand.'),pw_page_url('market_live',['view'=>'targets'])];
    }
    ob_start(); ?><section class="pw-card pw-v511-power"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('DEIN POWER-PAKET','YOUR POWER PACK')); ?> · <?php echo esc_html(pw_plan_public_label($plan)); ?></span><h2><?php echo esc_html($isMax?pw_t('Mehr platzieren. Besser steuern.','Place more. Steer better.'):pw_t('Weniger Handarbeit im Tagesgeschäft','Less manual work every day')); ?></h2><p class="pw-card-sub"><?php echo esc_html($isMax?pw_t('Max bündelt die Werkzeuge, die direkt auf Auslastung, Vertrieb und Geschwindigkeit wirken.','Max bundles tools that directly improve utilisation, sales and speed.'):pw_t('Pro beschleunigt genau die wiederkehrenden Schritte eines Disponenten.','Pro speeds up the recurring steps of a dispatcher.')); ?></p></div><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('account',['tab'=>'billing'])); ?>"><?php echo esc_html(pw_t('Tarif verwalten','Manage plan')); ?></a></div><div class="pw-v511-power-grid"><?php foreach($tools as $t): ?><a href="<?php echo esc_url($t[3]); ?>"><span><?php echo pw_icon($t[0]); ?></span><div><b><?php echo esc_html($t[1]); ?></b><small><?php echo esc_html($t[2]); ?></small></div><?php echo pw_icon('arrow'); ?></a><?php endforeach; ?></div></section><?php return ob_get_clean();
}

/** Restore the richer 5.0.3 dashboard structure and enrich it instead of replacing it. */
function pw_shortcode_dashboard_v511(){
    $html=pw_shortcode_dashboard_v503();
    if(is_user_logged_in() && pw_user_role()==='agency' && empty($_GET['panel'])){
        $uid=get_current_user_id();
        $extra=pw_v511_power_center($uid);
        if(pw_current_plan($uid)==='enterprise') $extra.='<div id="pw-placement-radar">'.pw_v511_placement_radar($uid).'</div>';
        if($extra) $html=str_replace('</main>',$extra.'</main>',$html);
    }
    return $html;
}

/** Pro profile studio attached to an existing employee record. */
function pw_v511_profile_studio($id,$uid){
    if(pw_v511_plan_rank($uid)<2) return '';
    if((int)get_post_field('post_author',$id)!==$uid&&!current_user_can('manage_options')) return '';
    $w=pw_worker_fields($id);
    $title=trim(($w['role']?:pw_t('Mitarbeiterprofil','Employee profile')).' · '.($w['location']?:''),' ·');
    $lines=[];
    $lines[]=pw_t('ANONYMES KANDIDATENPROFIL','ANONYMOUS CANDIDATE PROFILE');
    $lines[]=''; $lines[]=$title;
    if((int)$w['experience']>0)$lines[]=sprintf(pw_t('%d Jahre Berufserfahrung','%d years of professional experience'),(int)$w['experience']);
    if($w['qualifications'])$lines[]=pw_t('Qualifikationen: ','Qualifications: ').pw_list_string($w['qualifications']);
    if($w['languages'])$lines[]=pw_t('Sprachen: ','Languages: ').pw_list_string($w['languages']);
    if($w['shifts'])$lines[]=pw_t('Schichten: ','Shifts: ').pw_list_string($w['shifts']);
    if($w['industries'])$lines[]=pw_t('Branchen: ','Industries: ').pw_list_string($w['industries']);
    if($w['available_from'])$lines[]=pw_t('Verfügbar ab: ','Available from: ').pw_format_date($w['available_from']);
    $lines[]='';$lines[]=pw_t('Kontakt und Identität werden ausschließlich nach dem vorgesehenen Pure-Work-Freigabeprozess geteilt.','Contact and identity are shared only through the intended Pure Work release process.');
    $text=implode("\n",$lines);
    ob_start(); ?><section class="pw-card pw-v511-studio"><div class="pw-card-head"><div><span class="pw-kicker">PRO · <?php echo esc_html(pw_t('PROFILSTUDIO','PROFILE STUDIO')); ?></span><h2><?php echo esc_html(pw_t('Kundenprofil ohne Copy-Paste-Arbeit','Client-ready profile without copy-paste work')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Pure Work baut aus der Mitarbeiterakte ein sauberes, anonymes Kurzprofil für die Einreichung.','Pure Work turns the employee record into a clean anonymous profile for submission.')); ?></p></div></div><div class="pw-v511-studio-layout"><div class="pw-v511-profile-preview"><span><?php echo pw_icon('lock'); ?> <?php echo esc_html(pw_t('ANONYMISIERT','ANONYMISED')); ?></span><h3><?php echo esc_html($title); ?></h3><div class="pw-v511-profile-facts"><?php if((int)$w['experience']): ?><span><?php echo pw_icon('briefcase'); ?> <?php echo (int)$w['experience']; ?> <?php echo esc_html(pw_t('Jahre Erfahrung','years experience')); ?></span><?php endif; ?><?php if($w['available_from']): ?><span><?php echo pw_icon('calendar'); ?> <?php echo esc_html(pw_format_date($w['available_from'])); ?></span><?php endif; ?><?php if($w['location']): ?><span><?php echo pw_icon('map'); ?> <?php echo esc_html($w['location']); ?></span><?php endif; ?></div><div class="pw-chip-list"><?php foreach(array_slice((array)$w['qualifications'],0,6) as $q): ?><span><?php echo esc_html($q); ?></span><?php endforeach; ?></div></div><textarea id="pw-v511-profile-copy" readonly><?php echo esc_textarea($text); ?></textarea></div><div class="pw-form-actions"><button type="button" class="pw-btn primary small" data-copy-target="#pw-v511-profile-copy"><?php echo pw_icon('document'); ?> <?php echo esc_html(pw_t('Profil kopieren','Copy profile')); ?></button><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><?php echo pw_icon('spark'); ?> <?php echo esc_html(pw_t('Passenden Auftrag finden','Find matching job')); ?></a></div></section><?php return ob_get_clean();
}

function pw_v511_availability_strip($uid){
    if(pw_v511_plan_rank($uid)<2) return '';
    $ids=get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']);$today=wp_date('Y-m-d');$d7=wp_date('Y-m-d',time()+7*DAY_IN_SECONDS);$d30=wp_date('Y-m-d',time()+30*DAY_IN_SECONDS);$now=$week=$month=$assigned=0;
    foreach($ids as $id){$w=pw_worker_fields($id);if(($w['status']??'')==='assigned'){$assigned++;continue;}if(($w['status']??'')!=='available')continue;$from=$w['available_from']?:$today;if($from<=$today)$now++;elseif($from<=$d7)$week++;elseif($from<=$d30)$month++;}
    ob_start(); ?><section class="pw-card pw-v511-availability"><div><span class="pw-kicker">PRO · <?php echo esc_html(pw_t('VERFÜGBARKEITSPLANER','AVAILABILITY PLANNER')); ?></span><h2><?php echo esc_html(pw_t('Deine Kapazität auf einen Blick','Your capacity at a glance')); ?></h2></div><div class="pw-v511-availability-grid"><div><b><?php echo $now; ?></b><span><?php echo esc_html(pw_t('jetzt frei','free now')); ?></span></div><div><b><?php echo $week; ?></b><span><?php echo esc_html(pw_t('in 7 Tagen','in 7 days')); ?></span></div><div><b><?php echo $month; ?></b><span><?php echo esc_html(pw_t('in 30 Tagen','in 30 days')); ?></span></div><div><b><?php echo $assigned; ?></b><span><?php echo esc_html(pw_t('im Einsatz','assigned')); ?></span></div></div></section><?php return ob_get_clean();
}

function pw_shortcode_workers_v511(){
    $html=pw_shortcode_workers_v510();
    if(is_user_logged_in()&&pw_user_role()==='agency'){
        $uid=get_current_user_id();$extra='';
        if(!empty($_GET['view']))$extra.=pw_v511_profile_studio((int)$_GET['view'],$uid);
        elseif(empty($_GET['new'])&&empty($_GET['edit']))$extra.=pw_v511_availability_strip($uid);
        if($extra)$html=str_replace('</main>',$extra.'</main>',$html);
    }
    return $html;
}

function pw_v511_register(){
    remove_shortcode('pw_dashboard');add_shortcode('pw_dashboard','pw_shortcode_dashboard_v511');
    remove_shortcode('pw_workers');add_shortcode('pw_workers','pw_shortcode_workers_v511');
}
add_action('init','pw_v511_register',2300);
