<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9.8 – UX / Copilot / Automation layer.
 *
 * Goal: keep the visual identity, reduce cognitive load and make the product
 * self-explanatory. The layer intentionally uses the platform's own data and
 * existing matching/CRM/lead logic instead of pretending that an external AI
 * service is available.
 */

/* -------------------------------------------------------------------------
 * Dashboard data helpers
 * ---------------------------------------------------------------------- */
function pw_v498_count_posts($args) {
    $args = array_merge(['posts_per_page'=>1,'fields'=>'ids','no_found_rows'=>false], $args);
    $q = new WP_Query($args);
    return (int)$q->found_posts;
}

function pw_v498_agency_snapshot($uid) {
    $today = wp_date('Y-m-d');
    $workers = get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']);
    $available = 0; $stale = 0; $incomplete = 0;
    foreach ($workers as $id) {
        $w = pw_worker_fields($id);
        if (($w['status'] ?? 'available') === 'available') $available++;
        if (get_post_modified_time('U', true, $id) < time() - 30 * DAY_IN_SECONDS) $stale++;
        if (empty($w['role']) || empty($w['location']) || empty($w['qualifications'])) $incomplete++;
    }
    $open_jobs = pw_v498_count_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','meta_query'=>[['key'=>'pw_status','value'=>'open']]]);
    $submissions = pw_v498_count_posts(['post_type'=>'pw_submission','post_status'=>'publish','meta_query'=>[['key'=>'pw_agency_id','value'=>$uid]]]);
    $requested = pw_v498_count_posts(['post_type'=>'pw_submission','post_status'=>'publish','meta_query'=>[
        'relation'=>'AND', ['key'=>'pw_agency_id','value'=>$uid], ['key'=>'pw_status','value'=>'requested']
    ]]);
    $accepted = pw_v498_count_posts(['post_type'=>'pw_submission','post_status'=>'publish','meta_query'=>[
        'relation'=>'AND', ['key'=>'pw_agency_id','value'=>$uid], ['key'=>'pw_status','value'=>['accepted','identity_released','planned'],'compare'=>'IN']
    ]]);
    $crm = function_exists('pw_crm_dashboard_metrics') ? pw_crm_dashboard_metrics($uid) : ['total'=>0,'due'=>0,'won'=>0,'hot'=>0,'offer'=>0];
    $matches = function_exists('pw_best_vacancies_for_agency') ? pw_best_vacancies_for_agency($uid, 8) : [];
    return [
        'workers'=>count($workers),'available'=>$available,'stale'=>$stale,'incomplete'=>$incomplete,
        'open_jobs'=>$open_jobs,'submissions'=>$submissions,'requested'=>$requested,'accepted'=>$accepted,
        'messages'=>pw_unread_message_count($uid),'notices'=>pw_unread_notice_count($uid),'crm'=>$crm,
        'matches'=>$matches,'today'=>$today,
    ];
}

function pw_v498_client_snapshot($uid) {
    $jobs = get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']);
    $open = 0;
    foreach ($jobs as $id) if (pw_meta($id,'pw_status','open') === 'open') $open++;
    $subs = pw_client_submissions($uid); $new = 0; $short = 0; $accepted = 0;
    foreach ($subs as $s) {
        $st = pw_meta($s->ID,'pw_status','submitted');
        if (in_array($st,['submitted','viewed'],true)) $new++;
        if (in_array($st,['shortlisted','on_hold','requested'],true)) $short++;
        if (in_array($st,['accepted','identity_released','planned'],true)) $accepted++;
    }
    return ['jobs'=>count($jobs),'open'=>$open,'profiles'=>count($subs),'new'=>$new,'short'=>$short,'accepted'=>$accepted,'messages'=>pw_unread_message_count($uid)];
}

function pw_v498_today_actions($uid, $role, $limit = 4) {
    $items = [];
    $verify = pw_verification_state($uid);
    if (!$verify['email'] || !$verify['company'] || ($role === 'agency' && !$verify['aug'])) {
        $items[] = ['level'=>'warning','icon'=>'lock','title'=>pw_t('Verifizierung abschließen','Complete verification'),'text'=>pw_t('Damit alle Marktplatzfunktionen freigeschaltet sind.','Unlock all marketplace functions.'),'url'=>pw_page_url('account',['tab'=>'verification']),'cta'=>pw_t('Status öffnen','Open status')];
    }
    if ($role === 'agency') {
        $s = pw_v498_agency_snapshot($uid);
        if ($s['requested'] > 0) $items[] = ['level'=>'danger','icon'=>'bell','title'=>sprintf(pw_t('%d Mitarbeiter angefragt','%d employees requested'),$s['requested']),'text'=>pw_t('Hier wartet ein Auftraggeber auf deine Reaktion.','A client is waiting for your response.'),'url'=>pw_page_url('vacancies'),'cta'=>pw_t('Jetzt reagieren','Respond now')];
        if ($s['messages'] > 0) $items[] = ['level'=>'warning','icon'=>'message','title'=>sprintf(pw_t('%d ungelesene Nachrichten','%d unread messages'),$s['messages']),'text'=>pw_t('Offene Kommunikation zuerst erledigen.','Handle open communication first.'),'url'=>pw_page_url('messages'),'cta'=>pw_t('Nachrichten öffnen','Open messages')];
        if ((int)$s['crm']['due'] > 0 && pw_can('crm',$uid)) $items[] = ['level'=>'warning','icon'=>'clock','title'=>sprintf(pw_t('%d Wiedervorlagen sind fällig','%d follow-ups are due'),(int)$s['crm']['due']),'text'=>pw_t('Kontakte mit Termin heute oder überfällig.','Contacts due today or overdue.'),'url'=>pw_page_url('crm'),'cta'=>pw_t('Wiedervorlagen öffnen','Open follow-ups')];
        if (!$s['workers']) $items[] = ['level'=>'brand','icon'=>'users','title'=>pw_t('Ersten Mitarbeiter anlegen','Add your first employee'),'text'=>pw_t('Ohne Pool kann Pure Work keine passenden Chancen berechnen.','Without a pool Pure Work cannot calculate matching opportunities.'),'url'=>pw_page_url('workers',['new'=>1]),'cta'=>pw_t('Mitarbeiter anlegen','Add employee')];
        elseif ($s['incomplete'] > 0) $items[] = ['level'=>'info','icon'=>'check','title'=>sprintf(pw_t('%d Profile vervollständigen','Complete %d profiles'),$s['incomplete']),'text'=>pw_t('Rolle, Ort und Qualifikationen erhöhen die Match-Qualität.','Role, city and qualifications improve match quality.'),'url'=>pw_page_url('workers'),'cta'=>pw_t('Pool prüfen','Review pool')];
        elseif ($s['stale'] > 0) $items[] = ['level'=>'info','icon'=>'clock','title'=>sprintf(pw_t('%d Profile sind älter als 30 Tage','%d profiles are older than 30 days'),$s['stale']),'text'=>pw_t('Verfügbarkeit kurz bestätigen, damit der Pool aktuell bleibt.','Confirm availability so the pool stays current.'),'url'=>pw_page_url('workers'),'cta'=>pw_t('Aktualisieren','Update')];
        if ($s['matches']) {
            $best = $s['matches'][0];
            $v = pw_vacancy_fields($best['vacancy']->ID);
            $items[] = ['level'=>'success','icon'=>'spark','title'=>sprintf(pw_t('Beste Chance: %s','Best opportunity: %s'),$v['title']),'text'=>sprintf(pw_t('Dein bester aktueller Treffer liegt bei %d%%.','Your best current match is %d%%.'),(int)$best['best_score']),'url'=>pw_page_url('vacancies',['view'=>$v['id']]),'cta'=>pw_t('Treffer prüfen','Review match')];
        } elseif ($s['open_jobs'] > 0) {
            $items[] = ['level'=>'brand','icon'=>'briefcase','title'=>pw_t('Neue Ausschreibungen prüfen','Review new jobs'),'text'=>pw_t('Es gibt offene Bedarfe im Marktplatz.','There are open staffing needs in the marketplace.'),'url'=>pw_page_url('vacancies'),'cta'=>pw_t('Ausschreibungen öffnen','Open jobs')];
        }
        if (!$items || count($items) < 2) $items[] = ['level'=>'brand','icon'=>'target','title'=>pw_t('Vertriebspotenzial prüfen','Review sales potential'),'text'=>pw_t('Direktkontakte, Zielkunden und deine Pipeline sind im Vertriebsbereich gebündelt.','Direct contacts, target accounts and your pipeline are grouped in Sales.'),'url'=>pw_page_url('sales'),'cta'=>pw_t('Vertrieb öffnen','Open sales')];
    } else {
        $s = pw_v498_client_snapshot($uid);
        if ($s['new'] > 0) $items[] = ['level'=>'success','icon'=>'users','title'=>sprintf(pw_t('%d neue Profile warten','%d new profiles are waiting'),$s['new']),'text'=>pw_t('Neue Einreichungen zuerst prüfen.','Review new submissions first.'),'url'=>pw_page_url('vacancies'),'cta'=>pw_t('Profile prüfen','Review profiles')];
        if ($s['messages'] > 0) $items[] = ['level'=>'warning','icon'=>'message','title'=>sprintf(pw_t('%d ungelesene Nachrichten','%d unread messages'),$s['messages']),'text'=>pw_t('Offene Abstimmungen direkt erledigen.','Handle open conversations now.'),'url'=>pw_page_url('messages'),'cta'=>pw_t('Nachrichten öffnen','Open messages')];
        if (!$s['open']) $items[] = ['level'=>'brand','icon'=>'plus','title'=>pw_t('Personalbedarf veröffentlichen','Publish staffing demand'),'text'=>pw_t('In wenigen Schritten einen neuen Auftrag anlegen.','Create a new job in a few steps.'),'url'=>pw_page_url('vacancies',['new'=>1]),'cta'=>pw_t('Auftrag anlegen','Create job')];
        elseif (!$s['profiles']) $items[] = ['level'=>'info','icon'=>'clock','title'=>pw_t('Auf erste Profile warten','Wait for first profiles'),'text'=>pw_t('Deine offenen Aufträge sind veröffentlicht. Passende Dienstleister können Profile zuordnen.','Your open jobs are live. Matching agencies can submit profiles.'),'url'=>pw_page_url('vacancies'),'cta'=>pw_t('Aufträge ansehen','View jobs')];
    }
    return array_slice($items,0,$limit);
}

function pw_v498_action_center($uid,$role) {
    $items = pw_v498_today_actions($uid,$role,4);
    ob_start(); ?>
    <section class="pw-card pw-v498-focus">
      <div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('HEUTE','TODAY')); ?></span><h2><?php echo esc_html(pw_t('Was jetzt wichtig ist','What matters now')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Nach Dringlichkeit sortiert – damit du nicht suchen musst.','Sorted by urgency so you do not have to search.')); ?></p></div><span class="pw-focus-count"><?php echo count($items); ?></span></div>
      <div class="pw-v498-action-list">
        <?php foreach($items as $i): ?>
          <a class="<?php echo esc_attr($i['level']); ?>" href="<?php echo esc_url($i['url']); ?>"><span class="pw-v498-action-icon"><?php echo pw_icon($i['icon']); ?></span><div><b><?php echo esc_html($i['title']); ?></b><small><?php echo esc_html($i['text']); ?></small></div><em><?php echo esc_html($i['cta']); ?> <?php echo pw_icon('arrow'); ?></em></a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

function pw_v498_plan_launcher($uid) {
    if (pw_user_role($uid)!=='agency') return '';
    $plan = pw_current_plan($uid);
    $features = [
        ['vacancies','briefcase',pw_t('Ausschreibungen','Jobs'),pw_page_url('vacancies')],
        ['workers','users',pw_t('Mitarbeiter-Pool','Employee pool'),pw_page_url('workers')],
        ['assist_ai','spark','Pure Assist',pw_page_url('workers',['new'=>1])],
        ['crm','handshake',pw_t('Kunden-Pipeline','Customer pipeline'),pw_page_url('crm')],
        ['automations','bell',pw_t('Automationen','Automations'),pw_page_url('automations')],
        ['leads_targets','target',pw_t('Zielkunden-Radar','Target account radar'),pw_page_url('market_live',['tab'=>'targets'])],
        ['advanced_insights','grid',pw_t('Performance-Cockpit','Performance cockpit'),pw_page_url('dashboard',['panel'=>'insights'])],
    ];
    ob_start(); ?>
    <section class="pw-v498-launcher">
      <div class="pw-v498-launcher-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('DEIN TARIF','YOUR PLAN')); ?></span><h2><?php echo esc_html(pw_plan_public_label($plan)); ?></h2></div><a href="<?php echo esc_url(pw_page_url('account',['tab'=>'billing'])); ?>"><?php echo esc_html(pw_t('Tarif & Funktionen','Plan & features')); ?> <?php echo pw_icon('arrow'); ?></a></div>
      <div class="pw-v498-feature-row">
        <?php foreach($features as $f): $open=pw_can($f[0],$uid); $needed=pw_plan_required_for($f[0]); ?>
          <a class="<?php echo $open?'is-open':'is-locked'; ?>" href="<?php echo esc_url($open?$f[3]:pw_page_url('account',['tab'=>'billing'])); ?>"><span><?php echo pw_icon($open?$f[1]:'lock'); ?></span><b><?php echo esc_html($f[2]); ?></b><small><?php echo $open?esc_html(pw_t('Enthalten','Included')):esc_html(pw_t('ab ','from ').pw_plan_public_label($needed)); ?></small></a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

function pw_v498_scale_insights($uid) {
    if (!pw_can('advanced_insights',$uid)) return '';
    $s = pw_v498_agency_snapshot($uid);
    $conversion = $s['submissions'] ? (int)round(($s['accepted'] / $s['submissions']) * 100) : 0;
    $pool_health = $s['workers'] ? (int)round((($s['workers']-$s['stale']-$s['incomplete'])/$s['workers'])*100) : 0;
    $pool_health = max(0,min(100,$pool_health));
    ob_start(); ?>
    <section class="pw-card pw-v498-insights">
      <div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('MAX AUSWERTUNG','MAX INSIGHTS')); ?></span><h2><?php echo esc_html(pw_t('Performance auf einen Blick','Performance at a glance')); ?></h2></div><span class="pw-badge success">MAX</span></div>
      <div class="pw-v498-insight-grid"><div><b><?php echo (int)$conversion; ?>%</b><span><?php echo esc_html(pw_t('Einreichung → Einsatz','submission → assignment')); ?></span></div><div><b><?php echo (int)$pool_health; ?>%</b><span><?php echo esc_html(pw_t('Pool-Qualität','pool quality')); ?></span></div><div><b><?php echo (int)$s['crm']['hot']; ?></b><span><?php echo esc_html(pw_t('heiße Kundenchancen','hot customer opportunities')); ?></span></div><div><b><?php echo (int)$s['crm']['won']; ?></b><span><?php echo esc_html(pw_t('gewonnene Kunden','won customers')); ?></span></div></div>
    </section>
    <?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Dashboard 4.9.8
 * ---------------------------------------------------------------------- */
function pw_shortcode_dashboard_v498() {
    if (!is_user_logged_in()) return pw_require_login_html();
    $uid=get_current_user_id(); $role=pw_user_role(); $user=wp_get_current_user();
    $name=pw_user_meta($uid,'pw_contact',$user->display_name); $company=pw_user_meta($uid,'pw_company','');
    $title=pw_t('Start','Home');
    $subtitle=$role==='agency' ? pw_t('Heute erledigen, was Umsatz und Besetzung voranbringt.','Do today what moves revenue and staffing forward.') : pw_t('Personalbedarf und eingehende Profile ohne Umwege steuern.','Manage staffing demand and incoming profiles without detours.');
    ob_start(); echo pw_portal_shell_start($title,$subtitle); echo pw_flash_messages();
    if (isset($_GET['panel']) && $_GET['panel']==='notifications') { echo pw_dashboard_notifications_panel(); echo pw_portal_shell_end(); return ob_get_clean(); }
    if (isset($_GET['panel']) && $_GET['panel']==='insights' && $role==='agency') {
        echo pw_can('advanced_insights',$uid) ? pw_v498_scale_insights($uid) : pw_plan_gate('advanced_insights');
        echo pw_portal_shell_end(); return ob_get_clean();
    }

    $verify=pw_verification_state($uid);
    if (!$verify['ready']) echo '<div class="pw-onboarding-banner compact"><div>'.pw_icon('lock').'<div><span class="pw-kicker">'.esc_html(pw_t('VERIFIZIERUNG','VERIFICATION')).'</span><h3>'.esc_html(pw_t('Noch nicht vollständig freigeschaltet','Not fully unlocked yet')).'</h3><p>'.esc_html(pw_t('Prüfe E-Mail, Unternehmen und AÜG-Status.','Check e-mail, company and AÜG status.')).'</p></div></div><a class="pw-btn white small" href="'.esc_url(pw_page_url('account',['tab'=>'verification'])).'">'.esc_html(pw_t('Status','Status')).'</a></div>';

    if ($role==='agency') {
        $s=pw_v498_agency_snapshot($uid); $plan=pw_current_plan($uid);
        echo '<section class="pw-v498-welcome"><div><span class="pw-kicker">'.esc_html(pw_t('DEIN ARBEITSTAG','YOUR WORKDAY')).'</span><h1>'.esc_html(pw_dashboard_greeting()).', '.esc_html($name).'.</h1><p>'.esc_html(pw_t('Pure Work zeigt dir zuerst die Dinge, bei denen heute eine Entscheidung oder Aktion nötig ist.','Pure Work shows the items that need a decision or action today first.')).'</p></div><div class="pw-v498-welcome-actions"><span class="pw-v498-plan-pill">'.esc_html(pw_plan_public_label($plan)).'</span><a class="pw-btn primary" href="'.esc_url(pw_page_url('workers',['new'=>1])).'">'.pw_icon('plus').' '.esc_html(pw_t('Mitarbeiter anlegen','Add employee')).'</a><a class="pw-btn ghost" href="'.esc_url(pw_page_url('vacancies')).'">'.pw_icon('search').' '.esc_html(pw_t('Ausschreibungen','Jobs')).'</a></div></section>';
        echo '<div class="pw-v498-kpis">'.pw_metric($s['open_jobs'],pw_t('offene Ausschreibungen','open jobs'),pw_t('im Marktplatz','in marketplace'),'brand').pw_metric($s['available'],pw_t('sofort verfügbare Mitarbeiter','available employees'),$s['workers'].' '.pw_t('Profile im Pool','profiles in pool')).pw_metric($s['requested'],pw_t('aktive Mitarbeiteranfragen','active employee requests'),pw_t('Reaktion erforderlich','action required'),$s['requested']?'warning':'').pw_metric($s['messages'],pw_t('ungelesene Nachrichten','unread messages'),pw_t('offene Kommunikation','open communication'),$s['messages']?'warning':'').'</div>';
        echo '<div class="pw-v498-dashboard-primary">'.pw_v498_action_center($uid,$role).pw_v498_copilot_card($uid).'</div>';
        echo pw_v498_compact_jobs($uid,5);
        echo pw_v498_plan_launcher($uid);
        if (pw_can('advanced_insights',$uid)) echo function_exists('pw_v501_scale_insights')?pw_v501_scale_insights($uid):pw_v498_scale_insights($uid);
    } else {
        $s=pw_v498_client_snapshot($uid);
        echo '<section class="pw-v498-welcome"><div><span class="pw-kicker">'.esc_html(pw_t('PERSONALSTEUERUNG','WORKFORCE CONTROL')).'</span><h1>'.esc_html($company?:$name).'</h1><p>'.esc_html(pw_t('Bedarf veröffentlichen, neue Profile prüfen und offene Abstimmungen direkt erledigen.','Publish demand, review new profiles and handle open conversations directly.')).'</p></div><div class="pw-v498-welcome-actions"><a class="pw-btn primary" href="'.esc_url(pw_page_url('vacancies',['new'=>1])).'">'.pw_icon('plus').' '.esc_html(pw_t('Auftrag anlegen','Create job')).'</a><a class="pw-btn ghost" href="'.esc_url(pw_page_url('vacancies')).'">'.pw_icon('users').' '.esc_html(pw_t('Profile prüfen','Review profiles')).'</a></div></section>';
        echo '<div class="pw-v498-kpis">'.pw_metric($s['open'],pw_t('offene Aufträge','open jobs'),$s['jobs'].' '.pw_t('insgesamt','total'),'brand').pw_metric($s['new'],pw_t('neue Profile','new profiles'),pw_t('noch nicht entschieden','not yet decided'),$s['new']?'warning':'').pw_metric($s['accepted'],pw_t('bestätigte Besetzungen','confirmed placements'),pw_t('laufend / geplant','active / planned'),'success').pw_metric($s['messages'],pw_t('ungelesene Nachrichten','unread messages'),pw_t('offene Abstimmungen','open conversations'),$s['messages']?'warning':'').'</div>';
        echo '<div class="pw-v498-dashboard-primary">'.pw_v498_action_center($uid,$role).pw_v498_client_help_card().'</div>';
        echo pw_v498_client_jobs($uid,5);
    }
    echo pw_portal_shell_end(); return ob_get_clean();
}

function pw_v498_copilot_card($uid) {
    $enabled = pw_can('assist_ai',$uid);
    ob_start(); ?>
    <section class="pw-card pw-v498-copilot-card <?php echo $enabled?'':'is-locked'; ?>">
      <div class="pw-card-head"><div><span class="pw-kicker">PURE ASSIST</span><h2><?php echo esc_html($enabled?pw_t('Frag nicht, wo du anfangen sollst.','Do not wonder where to start.'):pw_t('Dein Assistenz-Layer','Your assistance layer')); ?></h2></div><span class="pw-assist-orb"><?php echo pw_icon($enabled?'spark':'lock'); ?></span></div>
      <?php if($enabled): ?>
        <p><?php echo esc_html(pw_t('Im Dashboard nutzt Pure Assist deine Portal-Daten, Match-Werte, Wiedervorlagen und Pool-Qualität und schlägt den nächsten sinnvollen Schritt vor. Bei der Mitarbeiteranlage kann Pure Assist zusätzlich eingefügte Bewerbertexte strukturiert in Profilfelder übertragen.','On the dashboard, Pure Assist uses your portal data, match scores, follow-ups and pool quality to suggest the next sensible step. When creating an employee profile, Pure Assist can also structure pasted applicant text into profile fields.')); ?></p>
        <div class="pw-v498-assist-prompts"><button type="button" data-pw-copilot-open data-pw-copilot-prompt="today"><?php echo pw_icon('clock'); ?><span><b><?php echo esc_html(pw_t('Was ist heute wichtig?','What matters today?')); ?></b><small><?php echo esc_html(pw_t('Priorisierte Aufgaben','Prioritised tasks')); ?></small></span></button><button type="button" data-pw-copilot-open data-pw-copilot-prompt="match"><?php echo pw_icon('spark'); ?><span><b><?php echo esc_html(pw_t('Beste Chance finden','Find best opportunity')); ?></b><small><?php echo esc_html(pw_t('Pool gegen Bedarf','Pool against demand')); ?></small></span></button><button type="button" data-pw-copilot-open data-pw-copilot-prompt="sales"><?php echo pw_icon('target'); ?><span><b><?php echo esc_html(pw_t('Vertrieb vorbereiten','Prepare sales')); ?></b><small><?php echo esc_html(pw_t('Nächster Kundenkontakt','Next customer contact')); ?></small></span></button></div>
      <?php else: ?>
        <p><?php echo esc_html(pw_t('Kontextbezogene Hilfe ist für alle da. Datenbasierte Empfehlungen, Profil-Erkennung und Vertriebsassistenz werden ab Pro freigeschaltet.','Contextual help is available to everyone. Data-based recommendations, profile recognition and sales assistance unlock with Pro.')); ?></p>
        <a class="pw-btn primary full" href="<?php echo esc_url(pw_page_url('account',['tab'=>'billing'])); ?>"><?php echo esc_html(pw_t('Pro ansehen','View Pro')); ?> <?php echo pw_icon('arrow'); ?></a>
      <?php endif; ?>
    </section>
    <?php return ob_get_clean();
}

function pw_v498_client_help_card() {
    ob_start(); ?><section class="pw-card pw-v498-copilot-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('SO FUNKTIONIERT ES','HOW IT WORKS')); ?></span><h2><?php echo esc_html(pw_t('Drei Schritte bis zur Besetzung','Three steps to staffing')); ?></h2></div><?php echo pw_icon('help'); ?></div><div class="pw-v498-mini-flow"><span><i>1</i><?php echo esc_html(pw_t('Auftrag anlegen','Create job')); ?></span><b>→</b><span><i>2</i><?php echo esc_html(pw_t('Profile prüfen','Review profiles')); ?></span><b>→</b><span><i>3</i><?php echo esc_html(pw_t('Annehmen & chatten','Accept & chat')); ?></span></div><p class="pw-card-sub"><?php echo esc_html(pw_t('Mitarbeiter bleiben bis zur definierten Freigabestufe anonymisiert.','Employees remain anonymised until the defined release stage.')); ?></p></section><?php return ob_get_clean();
}

function pw_v498_compact_jobs($uid,$limit=5) {
    $jobs=get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','posts_per_page'=>$limit,'orderby'=>'date','order'=>'DESC','meta_query'=>[['key'=>'pw_status','value'=>'open']]]);
    ob_start(); ?><section class="pw-card pw-v498-list-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('NEUE AUSSCHREIBUNGEN','NEW JOBS')); ?></span><h2><?php echo esc_html(pw_t('Kurz prüfen. Direkt handeln.','Review quickly. Act directly.')); ?></h2></div><a href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><?php echo esc_html(pw_t('Alle anzeigen','View all')); ?></a></div><div class="pw-v498-job-list"><?php if(!$jobs): ?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch keine offenen Ausschreibungen im internen Marktplatz. Im Vertrieb findest du zusätzliche Marktchancen.','No open jobs in the internal marketplace yet. Sales contains additional market opportunities.')); ?></p><a class="pw-btn small ghost" href="<?php echo esc_url(pw_page_url('sales')); ?>"><?php echo esc_html(pw_t('Vertrieb öffnen','Open sales')); ?></a></div><?php else: foreach($jobs as $j):$v=pw_vacancy_fields($j->ID); ?><a href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$j->ID])); ?>"><span class="pw-job-id"><?php echo esc_html($v['public_id']); ?></span><div><b><?php echo esc_html($v['title']); ?></b><small><?php echo esc_html(trim($v['location'].' · '.$v['industry'],' ·')); ?></small></div><strong><?php echo (int)$v['qty']; ?>×</strong><?php echo pw_icon('arrow'); ?></a><?php endforeach; endif; ?></div></section><?php return ob_get_clean();
}

function pw_v498_client_jobs($uid,$limit=5) {
    $jobs=get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>$limit,'orderby'=>'date','order'=>'DESC']);
    ob_start(); ?><section class="pw-card pw-v498-list-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('DEINE AUFTRÄGE','YOUR JOBS')); ?></span><h2><?php echo esc_html(pw_t('Aktuelle Personalanfragen','Current staffing requests')); ?></h2></div><a href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><?php echo esc_html(pw_t('Alle anzeigen','View all')); ?></a></div><div class="pw-v498-job-list"><?php if(!$jobs): ?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch kein Auftrag angelegt.','No job created yet.')); ?></p><a class="pw-btn small primary" href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1])); ?>"><?php echo esc_html(pw_t('Ersten Auftrag anlegen','Create first job')); ?></a></div><?php else: foreach($jobs as $j):$v=pw_vacancy_fields($j->ID); ?><a href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$j->ID])); ?>"><span class="pw-job-id"><?php echo esc_html($v['public_id']); ?></span><div><b><?php echo esc_html($v['title']); ?></b><small><?php echo esc_html($v['location']); ?></small></div><?php echo pw_status_badge($v['status']); ?><?php echo pw_icon('arrow'); ?></a><?php endforeach; endif; ?></div></section><?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Sales hub – one clear entry instead of separate CRM and lead nav items
 * ---------------------------------------------------------------------- */
function pw_shortcode_sales_hub() {
    if(!is_user_logged_in()) return pw_require_login_html();
    $uid=get_current_user_id(); if(pw_user_role($uid)!=='agency') return pw_shortcode_crm();
    $stats=function_exists('pw_lead_pool_stats')?pw_lead_pool_stats():['total'=>0,'a'=>0,'b'=>0,'c'=>0,'evidence'=>0];
    $crm=function_exists('pw_crm_dashboard_metrics')?pw_crm_dashboard_metrics($uid):['total'=>0,'due'=>0,'hot'=>0,'won'=>0,'offer'=>0];
    ob_start(); echo pw_portal_shell_start(pw_t('Vertrieb','Sales'),pw_t('Marktchancen finden, Kontakte übernehmen und sauber nachfassen.','Find market opportunities, capture contacts and follow up cleanly.')); echo pw_flash_messages(); ?>
      <section class="pw-v498-welcome compact"><div><span class="pw-kicker"><?php echo esc_html(pw_t('VERTRIEB OHNE TAB-CHAOS','SALES WITHOUT TAB CHAOS')); ?></span><h1><?php echo esc_html(pw_t('Finden → übernehmen → nachfassen','Find → capture → follow up')); ?></h1><p><?php echo esc_html(pw_t('Leads und Kunden-Pipeline bleiben zwei getrennte Werkzeuge, aber du startest immer hier.','Leads and customer pipeline stay separate tools, but you always start here.')); ?></p></div><div class="pw-v498-welcome-actions"><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('market_live')); ?>"><?php echo pw_icon('target'); ?> <?php echo esc_html(pw_t('Leads öffnen','Open leads')); ?></a><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('crm')); ?>"><?php echo pw_icon('handshake'); ?> <?php echo esc_html(pw_t('Meine Kunden','My customers')); ?></a></div></section>
      <div class="pw-v498-kpis"><?php echo pw_metric($stats['a'],pw_t('Direktkontakte Stufe A','direct contacts tier A'),pw_t('höchste Kontaktqualität','highest contact quality'),'success'); echo pw_metric($stats['b'],pw_t('Kontakte Stufe B','contacts tier B'),pw_t('zuständiger Fachbereich','responsible department')); echo pw_metric($crm['due'],pw_t('fällige Wiedervorlagen','due follow-ups'),pw_t('heute oder überfällig','today or overdue'),$crm['due']?'warning':''); echo pw_metric($crm['won'],pw_t('gewonnene Kunden','won customers'),pw_t('deine Historie','your history'),'brand'); ?></div>
      <div class="pw-v498-sales-grid">
        <section class="pw-card"><span class="pw-v498-module-icon"><?php echo pw_icon('target'); ?></span><span class="pw-kicker"><?php echo esc_html(pw_t('MARKTCHANCEN','MARKET OPPORTUNITIES')); ?></span><h2><?php echo esc_html(pw_t('Leads & Zielkunden','Leads & target accounts')); ?></h2><p><?php echo esc_html(pw_t('Öffentliche AÜ-Bedarfe, hochwertige Kontaktstellen und – in Max – Zielkunden mit belegtem Bedarf.','Public staffing demand, high-quality contacts and, in Max, target accounts with evidenced demand.')); ?></p><div class="pw-v498-module-stats"><span><b><?php echo (int)$stats['total']; ?></b><?php echo esc_html(pw_t('Signale','signals')); ?></span><span><b><?php echo (int)$stats['evidence']; ?></b><?php echo esc_html(pw_t('mit Nachweis','with evidence')); ?></span></div><a class="pw-btn primary full" href="<?php echo esc_url(pw_page_url('market_live')); ?>"><?php echo esc_html(pw_t('Marktchancen öffnen','Open market opportunities')); ?> <?php echo pw_icon('arrow'); ?></a></section>
        <section class="pw-card <?php echo pw_can('crm',$uid)?'':'is-plan-locked'; ?>"><span class="pw-v498-module-icon"><?php echo pw_icon(pw_can('crm',$uid)?'handshake':'lock'); ?></span><span class="pw-kicker">CRM</span><h2><?php echo esc_html(pw_t('Meine Kunden','My customers')); ?></h2><p><?php echo esc_html(pw_t('Kontakt, Bedarf, Status, Notizen und Wiedervorlage in einer sauberen Kundenakte.','Contact, demand, status, notes and follow-up in a clean customer record.')); ?></p><div class="pw-v498-module-stats"><span><b><?php echo (int)$crm['total']; ?></b><?php echo esc_html(pw_t('Kontakte','contacts')); ?></span><span><b><?php echo (int)$crm['hot']; ?></b><?php echo esc_html(pw_t('heiß / qualifiziert','hot / qualified')); ?></span></div><a class="pw-btn <?php echo pw_can('crm',$uid)?'ghost':'primary'; ?> full" href="<?php echo esc_url(pw_can('crm',$uid)?pw_page_url('crm'):pw_page_url('account',['tab'=>'billing'])); ?>"><?php echo esc_html(pw_can('crm',$uid)?pw_t('Pipeline öffnen','Open pipeline'):pw_t('Pro freischalten','Unlock Pro')); ?> <?php echo pw_icon('arrow'); ?></a></section>
      </div>
      <?php if(pw_can('hot_lead_automation',$uid)): ?><div class="pw-v498-scale-strip"><span><?php echo pw_icon('spark'); ?></span><div><b><?php echo esc_html(pw_t('Max: Hot-Lead-Radar aktivierbar','Max: hot-lead radar available')); ?></b><small><?php echo esc_html(pw_t('Unter Automationen kannst du Zielkunden und fällige Vertriebsaktionen automatisch priorisieren lassen.','Under Automations you can automatically prioritise target accounts and due sales actions.')); ?></small></div><a href="<?php echo esc_url(pw_page_url('automations')); ?>"><?php echo esc_html(pw_t('Automationen','Automations')); ?> →</a></div><?php endif; ?>
    <?php echo pw_portal_shell_end(); return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Automations – real settings + daily notices
 * ---------------------------------------------------------------------- */
function pw_v498_automation_definitions() {
    return [
        'match_digest'=>['feature'=>'automations','icon'=>'spark','title'=>pw_t('Chancen-Digest','Opportunity digest'),'text'=>pw_t('Tägliche Zusammenfassung zu offenen Ausschreibungen und passenden Chancen.','Daily summary of open jobs and matching opportunities.')],
        'followups'=>['feature'=>'automations','icon'=>'clock','title'=>pw_t('Wiedervorlagen-Wächter','Follow-up watchdog'),'text'=>pw_t('Erinnert automatisch, wenn CRM-Wiedervorlagen fällig oder überfällig sind.','Automatically reminds you when CRM follow-ups are due or overdue.')],
        'pool_health'=>['feature'=>'pool_health','icon'=>'users','title'=>pw_t('Pool-Aktualitätscheck','Pool freshness check'),'text'=>pw_t('Warnt, wenn Profile unvollständig oder länger als 30 Tage nicht aktualisiert wurden.','Warns when profiles are incomplete or have not been updated for more than 30 days.')],
        'risk_watch'=>['feature'=>'risk_watch','icon'=>'alert','title'=>pw_t('Besetzungs-Risiko-Wächter','Placement risk watchdog'),'text'=>pw_t('Warnt, wenn ein Einsatzstart näher rückt, aber die Besetzung noch nicht final geplant ist.','Warns when an assignment start approaches but the placement is not finally planned yet.')],
        'compliance_watch'=>['feature'=>'compliance_watch','icon'=>'alert','title'=>pw_t('Einsatz-Prüfmarken-Wächter','Assignment checkpoint watchdog'),'text'=>pw_t('Erinnert vor deinen hinterlegten Equal-Pay- und Überlassungsdauer-Prüfmarken. Tarifliche oder betriebliche Abweichungen bleiben individuell prüfbar.','Reminds you before your configured equal-pay and assignment-duration checkpoints. Collective or company-specific deviations can still be reviewed individually.')],
        'timesheet_approval'=>['feature'=>'timesheets','icon'=>'check','title'=>pw_t('Freigaben-Wächter','Approval watchdog'),'text'=>pw_t('Erinnert an Stundenmeldungen, die länger als zwei Tage auf Freigabe warten.','Reminds you about timesheets that have been waiting for approval for more than two days.')],
        'billing_ready'=>['feature'=>'invoicing','icon'=>'receipt','title'=>pw_t('Abrechnungs-Autopilot','Billing autopilot'),'text'=>pw_t('Meldet freigegebene Stunden, die noch nicht in eine Rechnung übernommen wurden.','Flags approved hours that have not yet been transferred into an invoice.')],
        'invoice_due'=>['feature'=>'invoicing','icon'=>'receipt','title'=>pw_t('Rechnungs-Wächter','Invoice watchdog'),'text'=>pw_t('Erinnert an versendete Rechnungen, deren Zahlungsziel erreicht oder überschritten ist.','Reminds you about sent invoices that have reached or passed their due date.')],
        'hot_leads'=>['feature'=>'hot_lead_automation','icon'=>'target','title'=>pw_t('Hot-Lead-Radar','Hot-lead radar'),'text'=>pw_t('Max priorisiert Zielkunden mit belegtem Bedarf und erinnert an die nächste Vertriebsaktion.','Max prioritises target accounts with evidenced demand and reminds you of the next sales action.')],
    ];
}

function pw_shortcode_automations() {
    if(!is_user_logged_in()) return pw_require_login_html(); $uid=get_current_user_id();
    ob_start(); echo pw_portal_shell_start(pw_t('Automationen','Automations'),pw_t('Routinearbeit automatisch im Blick behalten – ohne Blackbox.','Keep routine work automatically in view without a black box.')); echo pw_flash_messages();
    if(pw_user_role($uid)!=='agency'){echo '<section class="pw-card pw-empty"><h2>'.esc_html(pw_t('Automationen sind für Zeitarbeitsfirmen vorgesehen.','Automations are designed for staffing agencies.')).'</h2></section>';echo pw_portal_shell_end();return ob_get_clean();}
    if(!pw_can('automations',$uid)){echo pw_plan_gate('automations');echo pw_portal_shell_end();return ob_get_clean();}
    $defs=pw_v498_automation_definitions(); ?>
      <section class="pw-v498-welcome compact"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE AUTOMATIONEN','PURE AUTOMATIONS')); ?></span><h1><?php echo esc_html(pw_t('Weniger nachsehen. Nichts verpassen.','Check less. Miss nothing.')); ?></h1><p><?php echo esc_html(pw_t('Alle Regeln sind bewusst einfach: Pure Work erinnert und priorisiert. Es verschickt keine Kundenansprache ohne dein Zutun.','All rules are deliberately simple: Pure Work reminds and prioritises. It never sends customer outreach without your action.')); ?></p></div></section>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-v498-automation-form"><input type="hidden" name="action" value="pw_v498_automation_save"><?php wp_nonce_field('pw_v498_automation_save'); ?>
        <div class="pw-v498-automation-grid">
          <?php foreach($defs as $key=>$d): $allowed=pw_can($d['feature'],$uid); $checked=pw_user_meta($uid,'pw_auto_'.$key,'0')==='1'; ?>
            <label class="pw-v498-auto-card <?php echo $allowed?'':'locked'; ?>"><input type="checkbox" name="auto_<?php echo esc_attr($key); ?>" value="1" <?php checked($checked && $allowed); ?> <?php disabled(!$allowed); ?>><span class="pw-v498-auto-icon"><?php echo pw_icon($allowed?$d['icon']:'lock'); ?></span><div><b><?php echo esc_html($d['title']); ?></b><p><?php echo esc_html($d['text']); ?></p><small><?php echo $allowed?esc_html(pw_t('Kann aktiviert werden','Can be enabled')):esc_html(pw_t('ab ','from ').pw_plan_public_label(pw_plan_required_for($d['feature']))); ?></small></div><i class="pw-switch"></i></label>
          <?php endforeach; ?>
        </div>
        <div class="pw-form-actions"><button class="pw-btn primary" type="submit"><?php echo esc_html(pw_t('Automationen speichern','Save automations')); ?></button><span class="pw-card-sub"><?php echo esc_html(pw_t('Die Prüfung läuft täglich über den bestehenden Pure-Work-Cron.','Checks run daily through the existing Pure Work cron.')); ?></span></div>
      </form>
    <?php echo pw_portal_shell_end(); return ob_get_clean();
}

function pw_handle_v498_automation_save() {
    if(!is_user_logged_in() || pw_user_role()!=='agency') wp_die('Keine Berechtigung.');
    check_admin_referer('pw_v498_automation_save'); $uid=get_current_user_id();
    foreach(pw_v498_automation_definitions() as $key=>$d) {
        $value=(pw_can($d['feature'],$uid) && !empty($_POST['auto_'.$key]))?'1':'0';
        update_user_meta($uid,'pw_auto_'.$key,$value);
    }
    wp_safe_redirect(pw_page_url('automations',['saved'=>1])); exit;
}
add_action('admin_post_pw_v498_automation_save','pw_handle_v498_automation_save');

function pw_v498_daily_automations() {
    foreach(get_users(['role'=>'pw_agency','fields'=>'ID']) as $uid) {
        $uid=(int)$uid; $u=get_userdata($uid); if(!$u) continue; $day=wp_date('Y-m-d');
        if(pw_can('automations',$uid) && pw_user_meta($uid,'pw_auto_followups','0')==='1') {
            $m=function_exists('pw_crm_dashboard_metrics')?pw_crm_dashboard_metrics($uid):['due'=>0];
            if((int)$m['due']>0 && pw_user_meta($uid,'pw_auto_followups_last','')!==$day) {
                pw_create_notice($uid,pw_t('Wiedervorlagen fällig','Follow-ups due'),sprintf(pw_t('%d Kundenkontakte sind heute fällig oder überfällig.','%d customer contacts are due or overdue today.'),(int)$m['due']),pw_page_url('crm'));
                update_user_meta($uid,'pw_auto_followups_last',$day);
            }
        }
        if(pw_can('pool_health',$uid) && pw_user_meta($uid,'pw_auto_pool_health','0')==='1') {
            $s=pw_v498_agency_snapshot($uid); $issues=$s['stale']+$s['incomplete'];
            if($issues>0 && pw_user_meta($uid,'pw_auto_pool_health_last','')!==$day) {
                pw_create_notice($uid,pw_t('Mitarbeiter-Pool prüfen','Review employee pool'),sprintf(pw_t('%d Profile sollten aktualisiert oder vervollständigt werden.','%d profiles should be updated or completed.'),$issues),pw_page_url('workers'));
                update_user_meta($uid,'pw_auto_pool_health_last',$day);
            }
        }
        if(pw_can('automations',$uid) && pw_user_meta($uid,'pw_auto_match_digest','0')==='1' && pw_user_meta($uid,'pw_auto_match_digest_last','')!==$day) {
            $s=pw_v498_agency_snapshot($uid); $best=$s['matches']? (int)$s['matches'][0]['best_score'] : 0;
            $msg=sprintf(pw_t('%d offene Ausschreibungen. Bester aktueller Pool-Treffer: %d%%.','%d open jobs. Best current pool match: %d%%.'),$s['open_jobs'],$best);
            pw_create_notice($uid,pw_t('Dein Chancen-Digest','Your opportunity digest'),$msg,pw_page_url('matches'));
            update_user_meta($uid,'pw_auto_match_digest_last',$day);
        }
        if(pw_can('timesheets',$uid) && pw_user_meta($uid,'pw_auto_timesheet_approval','0')==='1' && pw_user_meta($uid,'pw_auto_timesheet_approval_last','')!==$day) {
            $cut=time()-2*DAY_IN_SECONDS;$waiting=get_posts(['post_type'=>'pw_timesheet','post_status'=>'publish','posts_per_page'=>100,'meta_query'=>[['key'=>'pw_ts_agency_id','value'=>$uid],['key'=>'pw_ts_status','value'=>'submitted']]]);$late=0;
            foreach($waiting as $ts)if(strtotime($ts->post_date_gmt.' GMT')<$cut)$late++;
            if($late>0)pw_create_notice($uid,pw_t('Stundenfreigaben warten','Timesheet approvals waiting'),sprintf(pw_t('%d Stundenmeldungen warten seit mehr als zwei Tagen auf eine Entscheidung des Auftraggebers.','%d timesheets have been waiting for a client decision for more than two days.'),$late),pw_page_url('timesheets'));
            update_user_meta($uid,'pw_auto_timesheet_approval_last',$day);
        }
        if(pw_can('invoicing',$uid) && pw_user_meta($uid,'pw_auto_billing_ready','0')==='1' && pw_user_meta($uid,'pw_auto_billing_ready_last','')!==$day && function_exists('pw_v500_ready_timesheets_count')) {
            $ready=pw_v500_ready_timesheets_count($uid);
            if($ready>0)pw_create_notice($uid,pw_t('Abrechnung bereit','Billing ready'),sprintf(pw_t('%d freigegebene Stundenmeldungen können jetzt ohne erneute Erfassung in eine Rechnung übernommen werden.','%d approved timesheets can now be transferred to an invoice without re-entering data.'),$ready),pw_page_url('invoices'));
            update_user_meta($uid,'pw_auto_billing_ready_last',$day);
        }
        if(pw_can('hot_lead_automation',$uid) && pw_user_meta($uid,'pw_auto_hot_leads','0')==='1' && function_exists('pw_lead_pool_stats') && pw_user_meta($uid,'pw_auto_hot_leads_last','')!==$day) {
            $ls=pw_lead_pool_stats(); if((int)$ls['c']>0) pw_create_notice($uid,pw_t('Zielkunden-Radar','Target account radar'),sprintf(pw_t('%d Zielkunden mit nachweisbarem Bedarf warten auf Priorisierung.','%d target accounts with evidenced demand are waiting for prioritisation.'),(int)$ls['c']),pw_page_url('market_live',['tab'=>'targets']));
            update_user_meta($uid,'pw_auto_hot_leads_last',$day);
        }
    }
}
add_action('pw_daily_digest_event','pw_v498_daily_automations',30);

/* -------------------------------------------------------------------------
 * Contextual Pure Assist + command palette
 * ---------------------------------------------------------------------- */
function pw_v498_context_help($context) {
    $map=[
        'dashboard'=>[pw_t('Start','Home'),pw_t('Hier siehst du nur die Dinge, die heute eine Aktion brauchen. Kennzahlen sind bewusst reduziert.','This page only shows items that need action today. Metrics are intentionally reduced.')],
        'vacancies'=>[pw_t('Ausschreibungen','Jobs'),pw_t('Öffne einen Bedarf, prüfe Muss-Kriterien und ordne nur Mitarbeiter zu, die du wirklich anbieten möchtest.','Open a job, review must-have criteria and only assign employees you actually want to offer.')],
        'workers'=>[pw_t('Mitarbeiter','Employees'),pw_t('Dieser Pool ist privat. Je vollständiger Rolle, Ort, Qualifikation und Verfügbarkeit sind, desto besser werden Vorschläge.','This pool is private. The more complete role, city, qualification and availability are, the better suggestions become.')],
        'matches'=>[pw_t('Vorschläge','Suggestions'),pw_t('Pure Work vergleicht deine eigenen Mitarbeiter mit offenen Ausschreibungen. Der Score ist eine Entscheidungshilfe, keine automatische Zusage.','Pure Work compares your own employees with open jobs. The score is decision support, not an automatic commitment.')],
        'sales'=>[pw_t('Vertrieb','Sales'),pw_t('Marktchancen finden, dann in die Kunden-Pipeline übernehmen und mit Wiedervorlage weiterarbeiten.','Find market opportunities, capture them in the customer pipeline and continue with follow-ups.')],
        'messages'=>[pw_t('Nachrichten','Messages'),pw_t('Der Chat öffnet sich erst im passenden Prozessschritt. Dadurch bleiben Kontakte und Identitäten geschützt.','Chat opens only at the appropriate process stage so contacts and identities stay protected.')],
        'crm'=>[pw_t('Meine Kunden','My customers'),pw_t('Arbeite Kontakte konsequent über Status, Priorität und Wiedervorlage. So wird aus einer Marktchance ein nachvollziehbarer Vertriebsprozess.','Work contacts consistently through status, priority and follow-up. This turns a market opportunity into a traceable sales process.')],
        'assignments'=>[pw_t('Einsatzboard','Assignment board'),pw_t('Hier steuerst du bestätigte Besetzungen bis zum Start. Kritische Starts werden sichtbar, bevor sie zum Problem werden.','Control confirmed placements through start here. Critical starts become visible before they turn into a problem.')],
        'invoices'=>[pw_t('Abrechnung & E-Rechnung','Billing & e-invoicing'),pw_t('Pure Assist prüft Rechnungsstammdaten und Pflichtangaben. Freigegebene Stunden können direkt übernommen, kalkuliert und als strukturierte E-Rechnung vorbereitet werden.','Pure Assist checks invoice master data and required fields. Approved hours can be transferred, costed and prepared as a structured e-invoice.')],
        'timesheets'=>[pw_t('Stunden & Freigaben','Hours & approvals'),pw_t('Zeitarbeitsfirma meldet Stunden, Auftraggeber gibt sie frei. Erst danach wandern sie mit einem Klick in die Abrechnung.','The staffing agency submits hours, the client approves them, and only then can they flow into billing with one click.')],
        'market_live'=>[pw_t('Leads & Zielkunden','Leads & target accounts'),pw_t('Prüfe zuerst Kontaktqualität und Bedarfsnachweis. Relevante Kontakte kannst du anschließend in deine Pipeline übernehmen.','Check contact quality and demand evidence first. Relevant contacts can then be captured in your pipeline.')],
        'marketdata'=>[pw_t('Berufe & Daten','Occupations & data'),pw_t('Nutze den Datenbereich, um Tätigkeiten und Berufsbezeichnungen einheitlich zu pflegen. Einheitliche Begriffe verbessern Suche und Matching.','Use the data area to maintain consistent roles and occupation titles. Consistent terminology improves search and matching.')],
        'knowledge'=>[pw_t('Wissen & Tarif','Knowledge & plan'),pw_t('Hier findest du Hilfen zum Ablauf und siehst, welche Funktionen dein aktueller Tarif enthält.','Here you find workflow help and can see which features are included in your current plan.')],
        'account'=>[pw_t('Konto & Einstellungen','Account & settings'),pw_t('Hier steuerst du Unternehmensdaten, Verifizierung, Benachrichtigungen und deinen Tarif.','Manage company data, verification, notifications and your plan here.')],
        'automations'=>[pw_t('Automationen','Automations'),pw_t('Automationen erinnern und priorisieren. Kundenansprache wird niemals ungefragt automatisch versendet.','Automations remind and prioritise. Customer outreach is never sent automatically without your action.')],
    ];
    return $map[$context]??[pw_t('Pure Work Hilfe','Pure Work help'),pw_t('Nutze das Schnellmenü, um direkt zum nächsten Arbeitsbereich zu springen.','Use quick open to jump directly to the next workspace.')];
}

function pw_ajax_v498_copilot() {
    pw_ajax_guard(); $uid=get_current_user_id(); if(!$uid) wp_send_json_error(['message'=>'Login erforderlich.'],403);
    $prompt=sanitize_key(wp_unslash($_POST['prompt']??'help')); $context=sanitize_key(wp_unslash($_POST['context']??'dashboard'));
    $role=pw_user_role($uid);
    if($prompt==='help') {
        [$title,$body]=pw_v498_context_help($context);
        wp_send_json_success(['title'=>$title,'body'=>$body,'cta'=>pw_t('Verstanden','Got it'),'url'=>'']);
    }
    if($role==='client') {
        $s=pw_v498_client_snapshot($uid);$pending=function_exists('pw_v500_pending_timesheet_count')?pw_v500_pending_timesheet_count($uid):0;
        if($prompt==='approvals'){
            if($pending>0)wp_send_json_success(['title'=>pw_t('Freigaben warten','Approvals are waiting'),'body'=>sprintf(pw_t('%d Stundenmeldungen warten auf deine Entscheidung. Eine schnelle Freigabe hält Einsatz und Abrechnung im Fluss.','%d timesheets are awaiting your decision. A quick approval keeps assignment and billing flowing.'),$pending),'cta'=>pw_t('Freigaben prüfen','Review approvals'),'url'=>pw_page_url('timesheets')]);
            wp_send_json_success(['title'=>pw_t('Keine offene Freigabe','No approval pending'),'body'=>pw_t('Aktuell wartet keine Stundenmeldung. Du kannst dich auf neue Profile oder offene Aufträge konzentrieren.','No timesheet is waiting right now. You can focus on new profiles or open jobs.'),'cta'=>pw_t('Meine Aufträge','My jobs'),'url'=>pw_page_url('vacancies')]);
        }
        if($prompt==='demand'){
            wp_send_json_success(['title'=>pw_t('Bedarf in 3 Schritten','Demand in 3 steps'),'body'=>pw_t('Rolle und Anzahl festlegen, Einsatzrahmen ergänzen, veröffentlichen. Danach können passende Personaldienstleister anonymisierte Profile einreichen.','Choose role and quantity, add assignment conditions, then publish. Matching staffing providers can then submit anonymised profiles.'),'cta'=>pw_t('Auftrag anlegen','Create job'),'url'=>pw_page_url('vacancies',['new'=>1])]);
        }
        if($prompt==='today'){
            $items=pw_v498_today_actions($uid,$role,1);$a=$items?$items[0]:null;
            wp_send_json_success(['title'=>$a?$a['title']:pw_t('Alles im Fluss','Everything is flowing'),'body'=>$a?$a['text']:pw_t('Aktuell gibt es keine dringende Aktion. Prüfe laufende Einsätze oder starte einen neuen Bedarf.','There is no urgent action right now. Review active assignments or start a new demand.'),'cta'=>$a?$a['cta']:pw_t('Einsatzboard','Assignment board'),'url'=>$a?$a['url']:pw_page_url('assignments')]);
        }
    }
    if($role!=='agency' || !pw_can('assist_ai',$uid)) wp_send_json_error(['message'=>pw_t('Datenbasierte Pure-Assist-Empfehlungen sind ab Pro verfügbar.','Data-based Pure Assist recommendations are available from Pro.')],403);
    $s=pw_v498_agency_snapshot($uid);
    if($prompt==='match') {
        if($s['matches']) {$best=$s['matches'][0];$v=pw_vacancy_fields($best['vacancy']->ID);wp_send_json_success(['title'=>pw_t('Beste aktuelle Chance','Best current opportunity'),'body'=>sprintf(pw_t('%s in %s ist aktuell dein stärkster Pool-Treffer mit %d%%. Öffne den Bedarf und prüfe die vorgeschlagenen Mitarbeiter.','%s in %s is currently your strongest pool match at %d%%. Open the job and review the suggested employees.'),$v['title'],$v['location'],(int)$best['best_score']),'cta'=>pw_t('Chance öffnen','Open opportunity'),'url'=>pw_page_url('vacancies',['view'=>$v['id']])]);}
        wp_send_json_success(['title'=>pw_t('Noch kein belastbarer Treffer','No strong match yet'),'body'=>pw_t('Pflege Rolle, Ort, Qualifikationen und Verfügbarkeit im Mitarbeiter-Pool. Danach kann Pure Work deutlich genauer priorisieren.','Maintain role, city, qualifications and availability in the employee pool. Then Pure Work can prioritise much more accurately.'),'cta'=>pw_t('Mitarbeiter-Pool öffnen','Open employee pool'),'url'=>pw_page_url('workers')]);
    }
    if($prompt==='sales') {
        $crm=$s['crm'];
        if((int)$crm['due']>0) wp_send_json_success(['title'=>pw_t('Erst fällige Wiedervorlagen','Start with due follow-ups'),'body'=>sprintf(pw_t('%d Kontakte sind fällig. Bestehende Gespräche haben Vorrang vor neuer Recherche.','%d contacts are due. Existing conversations should come before new research.'),(int)$crm['due']),'cta'=>pw_t('Pipeline öffnen','Open pipeline'),'url'=>pw_page_url('crm')]);
        $stats=function_exists('pw_lead_pool_stats')?pw_lead_pool_stats():['a'=>0,'b'=>0,'c'=>0];
        wp_send_json_success(['title'=>pw_t('Nächste Vertriebsaktion','Next sales action'),'body'=>sprintf(pw_t('Aktuell stehen %d hochwertige Direktkontakte und %d Zielkunden-Signale bereit. Starte mit Stufe A und übernimm relevante Kontakte direkt in deine Pipeline.','There are currently %d high-quality direct contacts and %d target account signals. Start with tier A and capture relevant contacts directly in your pipeline.'),(int)$stats['a'],(int)$stats['c']),'cta'=>pw_t('Vertrieb öffnen','Open sales'),'url'=>pw_page_url('sales')]);
    }
    $actions=pw_v498_today_actions($uid,$role,1);$a=$actions?$actions[0]:null;
    wp_send_json_success(['title'=>$a?$a['title']:pw_t('Alles im grünen Bereich','Everything looks good'),'body'=>$a?$a['text']:pw_t('Aktuell gibt es keine dringende Aktion. Prüfe neue Ausschreibungen oder deinen Vertrieb.','There is no urgent action right now. Review new jobs or sales.'),'cta'=>$a?$a['cta']:pw_t('Start','Home'),'url'=>$a?$a['url']:pw_page_url('dashboard')]);
}
add_action('wp_ajax_pw_v498_copilot','pw_ajax_v498_copilot');

function pw_v498_current_page_key() {
    if(!function_exists('pw_page_definitions')) return 'dashboard';
    $ids=(array)get_option('pw_page_ids',[]); $current=get_queried_object_id();
    foreach($ids as $k=>$id) if((int)$id===(int)$current) return $k;
    return 'dashboard';
}

function pw_v498_portal_overlays() {
    if(!is_user_logged_in() || !function_exists('pw_is_portal_page') || !pw_is_portal_page()) return;
    $uid=get_current_user_id();$role=pw_user_role($uid);$ctx=pw_v498_current_page_key();$nav=pw_nav_items(); ?>
    <div class="pw-command-overlay" data-pw-command-overlay aria-hidden="true"><div class="pw-command-backdrop" data-pw-command-close></div><section class="pw-command-palette" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr(pw_t('Schnell öffnen','Quick open')); ?>"><header><?php echo pw_icon('search'); ?><input type="search" data-pw-command-input placeholder="<?php echo esc_attr(pw_t('Bereich oder Aktion suchen …','Search area or action …')); ?>"><button type="button" data-pw-command-close>ESC</button></header><div class="pw-command-list">
      <?php foreach($nav as $item): ?><a data-pw-command-item href="<?php echo esc_url(pw_page_url($item[0])); ?>"><span><?php echo pw_icon($item[1]); ?></span><div><b><?php echo esc_html($item[2]); ?></b><small><?php echo esc_html(pw_t('Öffnen','Open')); ?></small></div><kbd>↵</kbd></a><?php endforeach; ?>
      <?php if($role==='agency'): ?><a data-pw-command-item href="<?php echo esc_url(pw_page_url('workers',['new'=>1])); ?>"><span><?php echo pw_icon('plus'); ?></span><div><b><?php echo esc_html(pw_t('Neuen Mitarbeiter anlegen','Add new employee')); ?></b><small><?php echo esc_html(pw_t('Direkt zum Formular','Go straight to form')); ?></small></div><kbd>↵</kbd></a><?php else: ?><a data-pw-command-item href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1])); ?>"><span><?php echo pw_icon('plus'); ?></span><div><b><?php echo esc_html(pw_t('Neuen Auftrag anlegen','Create new job')); ?></b><small><?php echo esc_html(pw_t('Direkt zum Formular','Go straight to form')); ?></small></div><kbd>↵</kbd></a><?php endif; ?>
      <?php if($role==='agency'): ?><a data-pw-command-item href="<?php echo esc_url(pw_page_url('automations')); ?>"><span><?php echo pw_icon('spark'); ?></span><div><b><?php echo esc_html(pw_t('Automationen','Automations')); ?></b><small><?php echo esc_html(pw_t('Regeln ein- und ausschalten','Enable or disable rules')); ?></small></div><kbd>↵</kbd></a><?php endif; ?>
    </div><footer><span><?php echo esc_html(pw_t('Tipp: Strg/Cmd + K öffnet dieses Menü überall.','Tip: Ctrl/Cmd + K opens this menu anywhere.')); ?></span></footer></section></div>
    <?php if(in_array($role,['agency','client'],true)): ?>
    <button type="button" class="pw-assist-fab" data-pw-copilot-open aria-label="Pure Assist"><?php echo pw_icon('spark'); ?><span>Assist</span></button>
    <div class="pw-copilot-drawer" data-pw-copilot-drawer aria-hidden="true"><div class="pw-copilot-backdrop" data-pw-copilot-close></div><aside><header><div><span class="pw-kicker">PURE ASSIST</span><h2><?php echo esc_html(pw_t('Wobei brauchst du Hilfe?','What do you need help with?')); ?></h2></div><button type="button" data-pw-copilot-close>×</button></header><div class="pw-copilot-context"><span><?php echo esc_html(pw_t('Aktueller Bereich','Current area')); ?></span><b><?php echo esc_html((pw_v498_context_help($ctx))[0]); ?></b></div><div class="pw-copilot-prompts"><button type="button" data-pw-copilot-prompt="help"><?php echo pw_icon('help'); ?><span><b><?php echo esc_html(pw_t('Diese Seite erklären','Explain this page')); ?></b><small><?php echo esc_html(pw_t('Kurz und konkret','Short and concrete')); ?></small></span></button><button type="button" data-pw-copilot-prompt="today"><?php echo pw_icon('clock'); ?><span><b><?php echo esc_html(pw_t('Was ist heute wichtig?','What matters today?')); ?></b><small><?php echo esc_html(pw_t('Priorisierte nächste Aktion','Prioritised next action')); ?></small></span></button><?php if($role==='agency'): ?><button type="button" data-pw-copilot-prompt="match"><?php echo pw_icon('spark'); ?><span><b><?php echo esc_html(pw_t('Beste Chance finden','Find best opportunity')); ?></b><small><?php echo esc_html(pw_t('Mitarbeiter-Pool gegen Bedarf','Employee pool against demand')); ?></small></span></button><button type="button" data-pw-copilot-prompt="sales"><?php echo pw_icon('target'); ?><span><b><?php echo esc_html(pw_t('Vertrieb vorbereiten','Prepare sales')); ?></b><small><?php echo esc_html(pw_t('Nächster sinnvoller Kontakt','Next sensible contact')); ?></small></span></button><?php else: ?><button type="button" data-pw-copilot-prompt="demand"><?php echo pw_icon('plus'); ?><span><b><?php echo esc_html(pw_t('Personalbedarf vorbereiten','Prepare staffing demand')); ?></b><small><?php echo esc_html(pw_t('In drei klaren Schritten','In three clear steps')); ?></small></span></button><button type="button" data-pw-copilot-prompt="approvals"><?php echo pw_icon('check'); ?><span><b><?php echo esc_html(pw_t('Freigaben prüfen','Review approvals')); ?></b><small><?php echo esc_html(pw_t('Stunden und Entscheidungen','Hours and decisions')); ?></small></span></button><?php endif; ?></div><div class="pw-copilot-answer" data-pw-copilot-answer><span class="pw-assist-orb"><?php echo pw_icon('spark'); ?></span><div><b><?php echo esc_html(pw_t('Pure Assist ist bereit','Pure Assist is ready')); ?></b><p><?php echo esc_html(pw_t('Wähle oben eine Frage. Empfehlungen basieren auf deinen eigenen Portal-Daten.','Choose a question above. Recommendations are based on your own portal data.')); ?></p><a hidden data-pw-copilot-action class="pw-btn primary small" href="#"></a></div></div></aside></div>
    <script>window.PW_V498_CONTEXT=<?php echo wp_json_encode($ctx); ?>;</script>
    <?php endif;
}
add_action('wp_footer','pw_v498_portal_overlays',30);

/* -------------------------------------------------------------------------
 * Guard Pro-only CSV import – backend and UI remain predictable.
 * ---------------------------------------------------------------------- */
function pw_v498_worker_import_guard() {
    if(isset($_REQUEST['action']) && $_REQUEST['action']==='pw_worker_import' && is_user_logged_in() && pw_user_role()==='agency' && !pw_can('worker_import')) {
        wp_safe_redirect(pw_page_url('workers',['plan_gate'=>'worker_import'])); exit;
    }
}
add_action('admin_post_pw_worker_import','pw_v498_worker_import_guard',0);

/* -------------------------------------------------------------------------
 * Register / override shortcodes after all previous modules.
 * ---------------------------------------------------------------------- */
function pw_v498_register_shortcodes() {
    remove_shortcode('pw_dashboard'); add_shortcode('pw_dashboard','pw_shortcode_dashboard_v498');
    add_shortcode('pw_sales_hub','pw_shortcode_sales_hub');
    add_shortcode('pw_automations','pw_shortcode_automations');
}
add_action('init','pw_v498_register_shortcodes',500);
