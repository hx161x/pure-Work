<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9.5 – Lead-Qualität ehrlich klassifiziert.
 *
 * Ausgangslage 4.9.2–4.9.4: Die Radar-Seite hat 148 regionale Arbeitgeberkontakte
 * als "Direkt-Leads – ein Klick bis zum Telefon" ausgegeben. Tatsächlich waren das
 * überwiegend Zentralen-Rufnummern und Supplier-Postfächer von Unternehmen, für die
 * teilweise gar kein Zeitarbeits-Nachweis vorlag. Wer so eine Liste abtelefoniert,
 * verbrennt Zeit in der Vermittlung.
 *
 * Diese Version sortiert jeden Kontakt in eine von drei Stufen und zeigt nur noch
 * das als Lead, was diesen Namen verdient:
 *   A – namentlich benannte Person mit Durchwahl oder persönlicher Mailadresse
 *   B – benannter Fachbereich (Einkauf Dienstleistungen, Vergabestelle, Disposition)
 *   C – nur Zentrale/Sammelpostfach  ->  kein Lead, sondern Rechercheauftrag
 *
 * Zusätzlich zählt, ob das Unternehmen Zeitarbeit überhaupt nachweislich nutzt.
 * Ein A-Kontakt ohne AÜ-Nachweis rankt unter einem B-Kontakt mit laufendem Bedarf.
 */

/* ==========================================================================
 * Erkennung: Zentrale vs. echte Durchwahl
 * ======================================================================= */
function pw_lead_generic_mailboxes() {
    return ['info','kontakt','contact','office','zentrale','mail','email','hello','service','empfang',
            'anfrage','anfragen','post','presse','support','vertrieb','supplier','lieferant','einkauf-allgemein'];
}

function pw_lead_email_is_generic($email) {
    $email = pw_lower(trim((string)$email));
    if (!$email || strpos($email, '@') === false) return true;
    $local = substr($email, 0, strpos($email, '@'));
    $local = preg_replace('/[^a-z0-9]/', '', $local);
    if ($local === '') return true;
    foreach (pw_lead_generic_mailboxes() as $generic) {
        if ($local === $generic) return true;
    }
    // vorname.nachname@ oder v.nachname@ deutet auf eine Person hin
    return !(strpos($email, '.') !== false && strpos($email, '.') < strpos($email, '@'));
}

/**
 * Eine Durchwahl endet praktisch nie auf mehreren Nullen. Zentralen tun das fast
 * immer (…586800, …1000, …0). Zusätzlich gilt ein Bindestrich mit Ziffern danach
 * als klares Durchwahl-Signal.
 */
function pw_lead_phone_is_switchboard($phone) {
    $raw = trim((string)$phone);
    if ($raw === '') return true;
    if (preg_match('/-\s*\d{2,6}\s*$/', $raw)) return false;
    $digits = preg_replace('/\D/', '', $raw);
    if (strlen($digits) < 7) return true;
    $tail = substr($digits, -4);
    if (preg_match('/00$/', $tail)) return true;
    if (preg_match('/0$/', $digits) && preg_match('/(000|00)$/', substr($digits, -3))) return true;
    return false;
}

function pw_lead_role_is_function($role) {
    $r = pw_normalize_text((string)$role);
    if ($r === '') return false;
    $generic = ['zentrale','standort','empfang','allgemein','supplier','lieferantenportal','kontaktformular','hauptsitz','head office','location'];
    foreach ($generic as $g) if (pw_contains($r, $g)) return false;
    $functions = ['einkauf','beschaffung','vergabe','procurement','personal','disposition','fremdpersonal',
                  'werkleitung','schichtleitung','betriebsleitung','hr','human resources','recruiting',
                  'dienstleistung','contingent','workforce','logistikleitung','produktionsleitung'];
    foreach ($functions as $f) if (pw_contains($r, $f)) return true;
    return false;
}

/* ==========================================================================
 * Klassifikation und Score
 * ======================================================================= */
function pw_lead_contact_class($e) {
    $name  = trim((string)($e['contact_name'] ?? ''));
    $role  = (string)($e['contact_role'] ?? '');
    $email = (string)($e['email'] ?? '');
    $phone = (string)($e['phone'] ?? '');

    $personal_mail  = $email !== '' && !pw_lead_email_is_generic($email);
    $direct_dial    = $phone !== '' && !pw_lead_phone_is_switchboard($phone);

    if ($name !== '' && ($personal_mail || $direct_dial)) {
        return ['A', pw_t('Namentlicher Ansprechpartner mit Direktkontakt', 'Named contact with a direct line')];
    }
    if (pw_lead_role_is_function($role) && ($email !== '' || $phone !== '')) {
        return ['B', pw_t('Zuständiger Fachbereich benannt', 'Responsible department named')];
    }
    return ['C', pw_t('Nur Zentrale – Durchwahl muss ermittelt werden', 'Switchboard only – direct line must be researched')];
}

/** Branchen, in denen Arbeitnehmerüberlassung strukturell hoch ist. */
function pw_lead_intensive_sectors() {
    return ['logistik','lager','fulfillment','fulfilment','versand','spedition','kontraktlogistik',
            'produktion','fertigung','montage','automotive','metall','maschinenbau','elektro',
            'chemie','pharma','lebensmittel','getraenke','fleisch','verpackung','kunststoff',
            'e-commerce','handel','baugewerbe','bau','pflege','klinik','krankenhaus','reinigung',
            'hotel','gastronomie','catering','messe','entsorgung','recycling'];
}

function pw_lead_sector_intensity($e) {
    $hay = pw_normalize_text(($e['sector'] ?? '') . ' ' . ($e['keywords'] ?? '') . ' ' . implode(' ', (array)($e['signals'] ?? [])));
    if ($hay === '') return 0;
    foreach (pw_lead_intensive_sectors() as $s) if (pw_contains($hay, $s)) return 1;
    return 0;
}

/**
 * evidence: 'procurement' = laufende AÜ-Vergabe, 'confirmed' = AÜ-Nutzung belegt,
 * 'signal' = aktuelle öffentliche Personalsuche, 'none' = kein Nachweis.
 */
function pw_lead_score($e) {
    $class = pw_lead_contact_class($e)[0];
    $score = 0;
    $score += ['A' => 45, 'B' => 28, 'C' => 5][$class];
    $score += ['procurement' => 40, 'confirmed' => 32, 'signal' => 20, 'none' => 0][$e['evidence'] ?? 'none'] ?? 0;
    $score += pw_lead_sector_intensity($e) ? 10 : 0;
    $score += min(5, count((array)($e['signals'] ?? [])));
    return min(100, $score);
}

/* ==========================================================================
 * Alle Quellen auf ein gemeinsames Format bringen
 * ======================================================================= */
function pw_lead_pool($args = []) {
    $q      = pw_normalize_text((string)($args['q'] ?? ''));
    $where  = pw_normalize_text((string)($args['where'] ?? ''));
    $sector = pw_normalize_text((string)($args['sector'] ?? ''));
    $pool   = [];

    // 1. Offene AÜ-Vergaben (TED / Vergabeportale) – der Kontakt steht in der Bekanntmachung.
    if (function_exists('pw_direct_leads_all')) {
        foreach (pw_direct_leads_all() as $l) {
            $pool[] = [
                'id' => (string)($l['lead_id'] ?? ''), 'type' => 'tender',
                'company' => (string)($l['company'] ?? ''), 'city' => (string)($l['city'] ?? ''),
                'region' => (string)($l['region'] ?? ''), 'sector' => (string)($l['sector'] ?? ''),
                'contact_name' => (string)($l['contact_name'] ?? ''), 'contact_role' => (string)($l['contact_role'] ?? ''),
                'email' => (string)($l['email'] ?? ''), 'phone' => (string)($l['phone'] ?? ''),
                'source_url' => (string)($l['source_url'] ?? ''), 'verified_at' => (string)($l['verified_at'] ?? ''),
                'evidence' => 'procurement',
                'evidence_note' => (string)($l['summary'] ?? ''),
                'signals' => array_filter([(string)($l['title'] ?? '')]),
                'deadline' => (string)($l['deadline'] ?? ''),
                'keywords' => (string)($l['keywords'] ?? ''),
            ];
        }
    }

    // 2. Regionale Accounts mit belegten AÜ-Signalen.
    if (function_exists('pw_regional_staffing_accounts')) {
        foreach (pw_regional_staffing_accounts(['status' => 'current']) as $a) {
            $roles = array_values(array_filter(array_map(function ($s) { return $s['role'] ?? ''; }, (array)($a['signals'] ?? []))));
            $pool[] = [
                'id' => (string)($a['account_key'] ?? ''), 'type' => 'account',
                'company' => (string)($a['company'] ?? ''), 'city' => (string)($a['city'] ?? ''),
                'region' => (string)($a['region'] ?? ''), 'sector' => (string)($a['sector'] ?? ''),
                'contact_name' => (string)($a['contact_name'] ?? ''), 'contact_role' => (string)($a['contact_role'] ?? ''),
                'email' => (string)($a['email'] ?? ''), 'phone' => (string)($a['phone'] ?? ''),
                'source_url' => (string)($a['contact_url'] ?? ''), 'verified_at' => (string)($a['verified_at'] ?? ''),
                'evidence' => 'confirmed',
                'evidence_note' => (string)($a['summary'] ?? ''),
                'signals' => $roles, 'deadline' => '', 'keywords' => implode(' ', $roles),
            ];
        }
    }

    // 3. Regionale Arbeitgeberkontakte. Ohne AÜ-Nachweis sind das Zielkunden, keine Leads.
    if (function_exists('pw_local_direct_contacts_search_492')) {
        foreach (pw_local_direct_contacts_search_492([]) as $c) {
            $live = array_values(array_filter(array_map(function ($j) { return $j['title'] ?? ''; }, (array)($c['live_roles'] ?? []))));
            $evidence = ($c['staffing_status'] ?? '') === 'confirmed' ? 'confirmed' : ($live ? 'signal' : 'none');
            $pool[] = [
                'id' => (string)($c['lead_id'] ?? ''), 'type' => 'local',
                'company' => (string)($c['company'] ?? ''), 'city' => (string)($c['city'] ?? ''),
                'region' => (string)($c['region'] ?? ''), 'sector' => (string)($c['sector'] ?? ''),
                'contact_name' => (string)($c['contact_name'] ?? ''), 'contact_role' => (string)($c['contact_role'] ?? ''),
                'email' => (string)($c['email'] ?? ''), 'phone' => (string)($c['phone'] ?? ''),
                'source_url' => (string)($c['source_url'] ?? ''), 'verified_at' => (string)($c['verified_at'] ?? ''),
                'evidence' => $evidence,
                'evidence_note' => (string)($c['evidence_note'] ?? ''),
                'signals' => $live, 'deadline' => '', 'keywords' => (string)($c['keywords'] ?? ''),
            ];
        }
    }

    $out = [];
    foreach ($pool as $e) {
        if (!$e['company']) continue;
        if (function_exists('pw_lead_is_blocked') && pw_lead_is_blocked($e['company'], $e['email'])) continue;
        $hay = pw_normalize_text($e['company'] . ' ' . $e['sector'] . ' ' . $e['keywords'] . ' ' . implode(' ', $e['signals']) . ' ' . $e['contact_role']);
        if ($q && !pw_contains($hay, $q)) continue;
        if ($where && !pw_contains(pw_normalize_text($e['city'] . ' ' . $e['region']), $where)) continue;
        if ($sector && !pw_contains(pw_normalize_text($e['sector'] . ' ' . $e['keywords']), $sector)) continue;
        $e['class'] = pw_lead_contact_class($e);
        $e['score'] = pw_lead_score($e);
        $out[] = $e;
    }
    usort($out, function ($a, $b) { return $b['score'] <=> $a['score']; });
    return $out;
}

function pw_lead_pool_stats() {
    $pool = pw_lead_pool();
    $a = $b = $c = $withEvidence = 0;
    foreach ($pool as $e) {
        if ($e['class'][0] === 'A') $a++; elseif ($e['class'][0] === 'B') $b++; else $c++;
        if (($e['evidence'] ?? 'none') !== 'none') $withEvidence++;
    }
    return ['total' => count($pool), 'a' => $a, 'b' => $b, 'c' => $c, 'evidence' => $withEvidence];
}

/* ==========================================================================
 * Rechercheauftrag: Zentrale anrufen und die Durchwahl selbst holen
 * ======================================================================= */
function pw_lead_call_script($e) {
    $company = (string)($e['company'] ?? '');
    $roles = array_slice((array)($e['signals'] ?? []), 0, 3);
    $bedarf = $roles ? implode(', ', $roles) : pw_t('gewerbliches Personal', 'commercial staff');
    return sprintf(
        pw_t(
            "Ziel: Name und Durchwahl der Stelle, die bei %1\$s externes Personal beauftragt.\n\n"
          . "1. Zentrale anrufen und nach dem Einkauf für Dienstleistungen bzw. der Fremdpersonalsteuerung fragen – nicht nach der Personalabteilung.\n"
          . "2. Falls dort niemand zuständig ist: nach der Werk-, Schicht- oder Logistikleitung am Standort fragen.\n"
          . "3. Aufhänger: aktuell öffentlich sichtbarer Bedarf (%2\$s).\n"
          . "4. Am Ende immer erfragen: vollständiger Name, Durchwahl, geschäftliche E-Mail-Adresse.\n"
          . "5. Ergebnis hier im CRM eintragen – damit wird aus dem Zielkunden ein A-Kontakt.",
            "Goal: name and direct line of the function that commissions external staff at %1\$s.\n\n"
          . "1. Call the switchboard and ask for services procurement or contingent workforce management – not for HR.\n"
          . "2. If nobody there owns it, ask for plant, shift or logistics management at the site.\n"
          . "3. Hook: currently visible public demand (%2\$s).\n"
          . "4. Always close by asking for: full name, direct line, business e-mail.\n"
          . "5. Record the result in the CRM – that turns a target account into an A contact."
        ),
        $company, $bedarf
    );
}

function pw_lead_find_in_pool($type, $id) {
    foreach (pw_lead_pool() as $e) {
        if ($e['type'] === $type && $e['id'] === $id) return $e;
    }
    return null;
}

function pw_handle_lead_research_capture() {
    if (!is_user_logged_in() || (pw_user_role() !== 'agency' && !current_user_can('manage_options'))) wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_lead_research_capture');
    $type = sanitize_key(wp_unslash($_POST['lead_type'] ?? ''));
    $id   = sanitize_text_field(wp_unslash($_POST['lead_ref'] ?? ''));
    $e    = pw_lead_find_in_pool($type, $id);
    if (!$e) pw_form_redirect('market_live', ['error' => 'lead']);

    $uid = get_current_user_id();
    $existing = get_posts([
        'post_type' => 'pw_crm_lead', 'post_status' => 'publish', 'author' => $uid,
        'posts_per_page' => 1, 'fields' => 'ids',
        'meta_query' => [['key' => 'pw_crm_company', 'value' => $e['company']]],
    ]);
    $crm = $existing ? (int)$existing[0] : 0;

    $class = $e['class'][0];
    $notes = $class === 'C'
        ? "Zielkunde mit belegtem Personalbedarf, aber ohne veröffentlichte Durchwahl.\n\n" . pw_lead_call_script($e)
        : 'Kontakt aus Pure Work Lead-Pool (' . $class . '). Quelle geprüft am ' . ($e['verified_at'] ?: wp_date('Y-m-d')) . '.';

    $crm = pw_crm_create_or_update_lead($uid, [
        'company' => $e['company'], 'contact' => $e['contact_name'], 'contact_role' => $e['contact_role'],
        'email' => $e['email'], 'phone' => $e['phone'], 'city' => $e['city'], 'industry' => $e['sector'],
        'stage' => $class === 'C' ? 'new' : 'qualified',
        'priority' => $e['score'] >= 70 ? 'hot' : 'warm',
        'source' => 'Pure Work Lead-Pool · Stufe ' . $class,
        'source_url' => $e['source_url'], 'job_title' => implode(', ', array_slice($e['signals'], 0, 4)),
        'job_ref' => $e['id'], 'verified_at' => $e['verified_at'], 'lead_quality' => (string)$e['score'],
        'next_followup' => wp_date('Y-m-d', strtotime('+1 day')),
        'notes' => $notes, 'target_type' => 'client',
    ], $crm);
    if (is_wp_error($crm)) pw_form_redirect('market_live', ['error' => 'crm']);

    if ($class === 'C') {
        pw_crm_add_activity($crm, $uid, 'research', pw_lead_call_script($e), wp_date('Y-m-d', strtotime('+1 day')));
    } else {
        pw_crm_add_activity($crm, $uid, 'lead', 'Aus dem Pure Work Lead-Pool übernommen (Stufe ' . $class . ', Score ' . (int)$e['score'] . ').', wp_date('Y-m-d', strtotime('+1 day')));
    }
    pw_form_redirect('crm', ['lead' => $crm, 'saved' => 1]);
}
add_action('admin_post_pw_lead_research_capture', 'pw_handle_lead_research_capture');

/* ==========================================================================
 * Einheitliche Karte
 * ======================================================================= */
function pw_lead_evidence_label($evidence) {
    switch ($evidence) {
        case 'procurement': return [pw_t('Laufende AÜ-Vergabe', 'Active staffing procurement'), 'confirmed'];
        case 'confirmed':   return [pw_t('Zeitarbeits-Nutzung belegt', 'Staffing use evidenced'), 'confirmed'];
        case 'signal':      return [pw_t('Aktueller Personalbedarf sichtbar', 'Current hiring demand visible'), 'live'];
    }
    return [pw_t('Kein Zeitarbeits-Nachweis', 'No staffing evidence'), 'contact'];
}

function pw_lead_unified_card($e) {
    $class = $e['class'];
    $evidence = pw_lead_evidence_label($e['evidence'] ?? 'none');
    $phone = trim((string)$e['phone']);
    $email = sanitize_email((string)$e['email']);
    $isDirect = $phone !== '' && !pw_lead_phone_is_switchboard($phone);
    $subject = 'Pure Work – Arbeitnehmerüberlassung';
    $body = "Guten Tag,\n\nwir sind Personaldienstleister und unterstützen Unternehmen kurzfristig mit qualifiziertem Personal. Gerne würde ich mit der Stelle sprechen, die bei Ihnen externes Personal beauftragt.\n\nFreundliche Grüße";

    ob_start(); ?>
    <article class="pw-local-contact-card pw-lead-card-<?php echo esc_attr(pw_lower($class[0])); ?>">
      <div class="pw-local-contact-top">
        <span class="pw-company-logo small"><?php echo esc_html(pw_initials($e['company'])); ?></span>
        <div><h3><?php echo esc_html($e['company']); ?></h3><p><?php echo esc_html(trim($e['city'] . ($e['sector'] ? ' · ' . $e['sector'] : ''))); ?></p></div>
        <span class="pw-local-score"><?php echo (int)$e['score']; ?><small>%</small></span>
      </div>

      <div class="pw-local-status pw-local-<?php echo esc_attr($evidence[1]); ?>"><i></i><?php echo esc_html($evidence[0]); ?></div>

      <div class="pw-local-line">
        <?php echo pw_icon($class[0] === 'C' ? 'search' : 'check'); ?>
        <span><b><?php echo esc_html(pw_t('Stufe', 'Tier') . ' ' . $class[0]); ?></b> · <?php echo esc_html($class[1]); ?></span>
      </div>

      <?php if ($e['contact_name'] || $e['contact_role']): ?>
        <div class="pw-local-line"><?php echo pw_icon('briefcase'); ?><span><?php echo esc_html(trim($e['contact_name'] . ($e['contact_role'] ? ' · ' . $e['contact_role'] : ''))); ?></span></div>
      <?php endif; ?>

      <?php if ($e['signals']): ?>
        <div class="pw-chip-list"><?php foreach (array_slice($e['signals'], 0, 4) as $s) echo '<span>' . esc_html($s) . '</span>'; ?></div>
      <?php endif; ?>

      <?php if (!empty($e['evidence_note'])): ?><p class="pw-local-note"><?php echo esc_html(wp_trim_words($e['evidence_note'], 26, '…')); ?></p><?php endif; ?>

      <div class="pw-local-contact-actions">
        <?php if ($phone): ?>
          <a class="pw-local-phone" href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $phone)); ?>">
            <?php echo pw_icon('phone'); ?>
            <span><small><?php echo esc_html($isDirect ? pw_t('Durchwahl', 'Direct line') : pw_t('Zentrale – nach Fachbereich fragen', 'Switchboard – ask for the department')); ?></small><b><?php echo esc_html($phone); ?></b></span>
          </a>
        <?php endif; ?>
        <?php if ($email): ?>
          <a class="pw-local-mail" href="mailto:<?php echo esc_attr($email); ?>?subject=<?php echo rawurlencode($subject); ?>&body=<?php echo rawurlencode($body); ?>">
            <?php echo pw_icon('message'); ?>
            <span><small><?php echo esc_html(pw_lead_email_is_generic($email) ? pw_t('Sammelpostfach', 'Shared mailbox') : pw_t('Persönliche Adresse', 'Personal address')); ?></small><b><?php echo esc_html($email); ?></b></span>
          </a>
        <?php endif; ?>
      </div>

      <?php if ($class[0] === 'C'): ?>
        <details class="pw-account-evidence">
          <summary><?php echo esc_html(pw_t('Rechercheauftrag: Durchwahl in 5 Minuten holen', 'Research task: get the direct line in 5 minutes')); ?></summary>
          <div><p style="white-space:pre-line"><?php echo esc_html(pw_lead_call_script($e)); ?></p></div>
        </details>
      <?php endif; ?>

      <div class="pw-local-footer">
        <span>✓ <?php echo esc_html(pw_t('geprüft', 'checked')); ?> <?php echo esc_html(pw_format_date($e['verified_at'])); ?><?php if (!empty($e['deadline'])): ?> · <?php echo esc_html(pw_t('Frist', 'Deadline') . ' ' . pw_format_date($e['deadline'])); ?><?php endif; ?></span>
        <?php if (!empty($e['source_url'])): ?><a href="<?php echo esc_url($e['source_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(pw_t('Quelle', 'Source')); ?> <?php echo pw_icon('arrow'); ?></a><?php endif; ?>
      </div>

      <div class="pw-direct-actions">
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="pw_lead_research_capture">
          <input type="hidden" name="lead_type" value="<?php echo esc_attr($e['type']); ?>">
          <input type="hidden" name="lead_ref" value="<?php echo esc_attr($e['id']); ?>">
          <?php wp_nonce_field('pw_lead_research_capture'); ?>
          <button class="pw-btn primary small" type="submit"><?php echo pw_icon('briefcase'); ?> <?php echo esc_html($class[0] === 'C' ? pw_t('Rechercheauftrag ins CRM', 'Research task to CRM') : pw_t('Ins CRM + Wiedervorlage', 'CRM + follow-up')); ?></button>
        </form>
      </div>
    </article>
    <?php return ob_get_clean();
}

/* ==========================================================================
 * Der neue Lead-Bereich
 * ======================================================================= */
function pw_shortcode_leads_hub_495() {
    if (!is_user_logged_in()) return pw_require_login_html();
    $uid = get_current_user_id();
    $role = pw_user_role($uid);

    ob_start();
    echo pw_portal_shell_start(
        pw_t('Leads & Zielkunden', 'Leads & target accounts'),
        pw_t('Nach Kontaktqualität sortiert – Durchwahl vor Zentrale, Nachweis vor Vermutung', 'Sorted by contact quality – direct lines before switchboards, evidence before assumption')
    );
    echo pw_flash_messages();

    if ($role !== 'agency' && !current_user_can('manage_options')) {
        echo '<section class="pw-card pw-direct-client-info"><span class="pw-kicker">LEADS</span><h2>' . esc_html(pw_t('Vertriebsbereich für Personaldienstleister', 'Sales area for staffing agencies')) . '</h2><p>' . esc_html(pw_t('Als Auftraggeber verwaltest du deine eigenen Ausschreibungen unter „Aufträge“.', 'As a client you manage your own jobs under “Jobs”.')) . '</p><a class="pw-btn primary" href="' . esc_url(pw_page_url('vacancies')) . '">' . esc_html(pw_t('Zu meinen Aufträgen', 'Go to my jobs')) . '</a></section>';
        echo pw_portal_shell_end();
        return ob_get_clean();
    }
    $gate = current_user_can('manage_options') ? '' : pw_verified_gate(pw_t('Leads öffnen', 'open leads'));
    if ($gate) { echo $gate; echo pw_portal_shell_end(); return ob_get_clean(); }

    $tab = sanitize_key(wp_unslash($_GET['tab'] ?? 'contacts'));
    if (!in_array($tab, ['contacts', 'targets', 'own', 'rules'], true)) $tab = 'contacts';

    $q      = sanitize_text_field(wp_unslash($_GET['q'] ?? ''));
    $where  = sanitize_text_field(wp_unslash($_GET['where'] ?? ''));
    $sector = sanitize_text_field(wp_unslash($_GET['sector'] ?? ''));
    $stats  = pw_lead_pool_stats();

    // Ehrliche Kennzahlen statt einer geschönten Gesamtzahl.
    echo '<div class="pw-radar-overview">'
       . '<div><b>' . (int)($stats['a']) . '</b><span>' . esc_html(pw_t('Stufe A · Person + Direktkontakt', 'Tier A · person + direct contact')) . '</span></div>'
       . '<div><b>' . (int)($stats['b']) . '</b><span>' . esc_html(pw_t('Stufe B · Fachbereich benannt', 'Tier B · department named')) . '</span></div>'
       . '<div><b>' . (int)($stats['c']) . '</b><span>' . esc_html(pw_t('Stufe C · Durchwahl zu ermitteln', 'Tier C · direct line to research')) . '</span></div>'
       . '<div><b>' . (int)($stats['evidence']) . '</b><span>' . esc_html(pw_t('mit Zeitarbeits-Nachweis', 'with staffing evidence')) . '</span></div>'
       . '</div>';

    $tabs = [
        'contacts' => pw_t('Kontakte A & B', 'Contacts A & B'),
        'targets'  => pw_t('Zielkunden (Stufe C)', 'Target accounts (tier C)'),
        'own'      => pw_t('Eigene Recherche', 'Own research'),
        'rules'    => pw_t('Quellen & Sperrliste', 'Sources & block list'),
    ];
    echo '<nav class="pw-tabs">';
    foreach ($tabs as $key => $label) {
        $url = pw_page_url('market_live', $key === 'contacts' ? [] : ['tab' => $key]);
        echo '<a class="' . ($tab === $key ? 'active' : '') . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }
    echo '</nav>';

    if ($tab === 'own') {
        echo (function_exists('pw_can') && !pw_can('lead_import')) ? pw_plan_gate('lead_import') : pw_leads_own_panel();
        echo pw_portal_shell_end(); return ob_get_clean();
    }
    if ($tab === 'rules') {
        echo (function_exists('pw_can') && !pw_can('blocklist')) ? pw_plan_gate('blocklist') : pw_leads_rules_panel();
        echo pw_portal_shell_end(); return ob_get_clean();
    }
    if ($tab === 'targets' && function_exists('pw_can') && !pw_can('leads_targets')) {
        echo pw_plan_gate('leads_targets'); echo pw_portal_shell_end(); return ob_get_clean();
    }

    $pool = pw_lead_pool(['q' => $q, 'where' => $where, 'sector' => $sector]);
    $wanted = $tab === 'contacts' ? ['A', 'B'] : ['C'];
    $list = array_values(array_filter($pool, function ($e) use ($wanted) { return in_array($e['class'][0], $wanted, true); }));
    if ($tab === 'targets') {
        // Ohne Nachweis ist ein Zentralenkontakt kein Zielkunde, sondern Rauschen.
        $list = array_values(array_filter($list, function ($e) { return ($e['evidence'] ?? 'none') !== 'none'; }));
    }
    $limit = function_exists('pw_plan_lead_limit') ? pw_plan_lead_limit() : 0;
    $capped = $limit && count($list) > $limit;
    if ($capped) $list = array_slice($list, 0, $limit);
    ?>
    <?php if ($capped): ?>
      <div class="pw-alert info"><div><strong><?php echo esc_html(pw_t('Ansicht auf 10 Einträge begrenzt', 'View limited to 10 entries')); ?></strong><span><?php echo esc_html(pw_t('Im Tarif Pro werden alle Treffer angezeigt. Die besten stehen bereits oben.', 'The Pro plan shows every match. The strongest ones are already at the top.')); ?></span></div></div>
    <?php endif; ?>
    <div class="pw-radar-explainer">
      <b><?php echo esc_html($tab === 'contacts'
            ? pw_t('Hier steht ein Mensch am anderen Ende', 'A real person answers here')
            : pw_t('Bedarf belegt, Ansprechpartner fehlt noch', 'Demand evidenced, contact still missing')); ?></b>
      <p><?php echo esc_html($tab === 'contacts'
            ? pw_t('Stufe A heißt: Name plus Durchwahl oder persönliche E-Mail-Adresse, veröffentlicht in einer Vergabeunterlage oder im offiziellen Auftritt des Unternehmens. Stufe B heißt: Der zuständige Fachbereich ist benannt – Einkauf Dienstleistungen, Vergabestelle, Fremdpersonalsteuerung. Zentralen-Nummern erscheinen in dieser Liste bewusst nicht.', 'Tier A means: name plus direct line or personal e-mail, published in a tender document or the company’s official presence. Tier B means the responsible department is named. Switchboard numbers deliberately do not appear here.')
            : pw_t('Diese Unternehmen setzen nachweislich Zeitarbeit ein oder suchen aktuell öffentlich Personal – aber es ist keine Durchwahl veröffentlicht. Der Rechercheauftrag legt den Zielkunden mit Gesprächsleitfaden und Wiedervorlage im CRM an. Nach dem Anruf trägst du den Namen ein und der Kontakt wandert nach Stufe A.', 'These companies verifiably use temporary staffing or are currently hiring publicly, but no direct line is published. The research task creates the account with a call guide and follow-up in the CRM. After the call you add the name and the contact moves to tier A.')); ?></p>
    </div>

    <form class="pw-direct-filter" method="get">
      <?php if ($tab !== 'contacts'): ?><input type="hidden" name="tab" value="<?php echo esc_attr($tab); ?>"><?php endif; ?>
      <label><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($q); ?>" placeholder="<?php echo esc_attr(pw_t('Unternehmen, Tätigkeit, Branche…', 'Company, role, sector…')); ?>"></label>
      <label><?php echo pw_icon('map'); ?><input name="where" value="<?php echo esc_attr($where); ?>" placeholder="<?php echo esc_attr(pw_t('Ort oder Region', 'City or region')); ?>"></label>
      <label><input name="sector" value="<?php echo esc_attr($sector); ?>" placeholder="<?php echo esc_attr(pw_t('Branche', 'Sector')); ?>"></label>
      <button class="pw-btn primary" type="submit"><?php echo esc_html(pw_t('Filtern', 'Filter')); ?></button>
    </form>

    <div class="pw-direct-result-head">
      <div><b><?php echo count($list); ?></b><span><?php echo esc_html($tab === 'contacts' ? pw_t('nutzbare Kontakte', 'usable contacts') : pw_t('Zielkunden mit Nachweis', 'target accounts with evidence')); ?></span></div>
      <small><?php echo esc_html(pw_t('Sortiert nach Kontaktqualität, Nachweislage und Zeitarbeits-Intensität der Branche.', 'Sorted by contact quality, evidence and how staffing-intensive the sector is.')); ?></small>
    </div>

    <div class="pw-local-contact-grid">
      <?php if (!$list): ?>
        <div class="pw-card pw-empty span-all">
          <h3><?php echo esc_html(pw_t('Kein Treffer für diesen Filter', 'No match for this filter')); ?></h3>
          <p><?php echo esc_html($tab === 'contacts'
                ? pw_t('Erweitere den Filter oder wechsle zu den Zielkunden – dort stehen Unternehmen mit belegtem Bedarf, bei denen nur noch die Durchwahl fehlt.', 'Broaden the filter or switch to target accounts, where demand is evidenced and only the direct line is missing.')
                : pw_t('Erweitere den Filter oder importiere unter „Eigene Recherche“ deine eigenen Kontakte.', 'Broaden the filter or import your own contacts under “Own research”.')); ?></p>
        </div>
      <?php else: foreach ($list as $e) echo pw_lead_unified_card($e); endif; ?>
    </div>
    <?php
    echo pw_portal_shell_end();
    return ob_get_clean();
}

/** Läuft nach allen älteren Registrierungen (99 / 120) und ersetzt sie. */
function pw_leads_hub_register_495() {
    remove_shortcode('pw_market_live');
    add_shortcode('pw_market_live', 'pw_shortcode_leads_hub_495');
}
add_action('init', 'pw_leads_hub_register_495', 200);
