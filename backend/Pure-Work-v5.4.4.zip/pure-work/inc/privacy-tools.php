<?php
if (!defined('ABSPATH')) exit;

/** Privacy-by-design helpers. They support, but do not replace, the operator's legal GDPR setup. */
function pw_audit_event($action, $user_id = 0, $object_type = '', $object_id = 0, $detail = '') {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id || !post_type_exists('pw_audit')) return 0;
    $id = wp_insert_post([
        'post_type'=>'pw_audit',
        'post_status'=>'publish',
        'post_author'=>(int)$user_id,
        'post_title'=>sanitize_text_field($action),
        'post_content'=>sanitize_textarea_field($detail),
    ], true);
    if (is_wp_error($id)) return 0;
    update_post_meta($id, 'pw_action', sanitize_key($action));
    update_post_meta($id, 'pw_object_type', sanitize_key($object_type));
    update_post_meta($id, 'pw_object_id', (int)$object_id);
    update_post_meta($id, 'pw_occurred_at', time());
    return (int)$id;
}

function pw_audit_login($user_login, $user) {
    if ($user instanceof WP_User && in_array(pw_user_role($user->ID), ['agency','client'], true)) {
        pw_audit_event('login', $user->ID, 'account', $user->ID, 'Erfolgreiche Anmeldung');
    }
}
add_action('wp_login', 'pw_audit_login', 20, 2);

function pw_audit_logout() {
    $uid = get_current_user_id();
    if ($uid && in_array(pw_user_role($uid), ['agency','client'], true)) pw_audit_event('logout', $uid, 'account', $uid, 'Abmeldung');
}
add_action('wp_logout', 'pw_audit_logout', 5);

function pw_collect_portal_export($uid) {
    $user = get_userdata($uid);
    if (!$user) return [];
    $meta_keys = [
        'pw_company','pw_contact','pw_phone','pw_zip','pw_city','pw_industry','pw_email_verified','pw_email_verified_at',
        'pw_company_verified','pw_aug_type','pw_aug_expiry','pw_aug_verified','pw_terms_accepted_at','pw_terms_version','pw_privacy_version',
        'pw_notify_radius','pw_notify_frequency','pw_notify_clients','pw_notify_industries','pw_message_email','pw_plan','pw_plan_interest'
    ];
    $meta=[];
    foreach($meta_keys as $k) $meta[$k]=get_user_meta($uid,$k,true);

    $workers=[];
    foreach(get_posts(['post_type'=>'pw_worker','post_status'=>['publish','draft'],'author'=>$uid,'posts_per_page'=>-1]) as $p) {
        $w=pw_worker_fields($p->ID);
        // File system paths are deliberately excluded from exports.
        unset($w['cv_file'],$w['docs_file']);
        $workers[]=$w;
    }
    $vacancies=[];
    foreach(get_posts(['post_type'=>'pw_vacancy','post_status'=>['publish','draft'],'author'=>$uid,'posts_per_page'=>-1]) as $p) $vacancies[]=pw_vacancy_fields($p->ID);

    $submissions=[];
    $sub_ids=get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_agency_id','value'=>$uid]]]);
    if(pw_user_role($uid)==='client') {
        $v_ids=get_posts(['post_type'=>'pw_vacancy','post_status'=>['publish','draft'],'author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']);
        if($v_ids) $sub_ids=array_merge($sub_ids,get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_vacancy_id','value'=>$v_ids,'compare'=>'IN']]]));
    }
    foreach(array_unique(array_map('intval',$sub_ids)) as $sid) {
        $submissions[]=[
            'id'=>$sid,'vacancy_id'=>(int)pw_meta($sid,'pw_vacancy_id',0),'worker_id'=>(int)pw_meta($sid,'pw_worker_id',0),
            'status'=>pw_meta($sid,'pw_status','submitted'),'created'=>get_post_time(DATE_ATOM,true,$sid),
        ];
    }

    $messages=[];
    $msg_ids=get_posts(['post_type'=>'pw_message','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_query'=>['relation'=>'OR',['key'=>'pw_recipient','value'=>$uid]]]);
    foreach($msg_ids as $mid) {
        $p=get_post($mid);
        if(!$p)continue;
        if((int)$p->post_author!==$uid && (int)pw_meta($mid,'pw_recipient',0)!==$uid) continue;
        $messages[]=['id'=>$mid,'from'=>(int)$p->post_author,'to'=>(int)pw_meta($mid,'pw_recipient',0),'text'=>$p->post_content,'created'=>get_post_time(DATE_ATOM,true,$p)];
    }

    return [
        'generated_at'=>wp_date(DATE_ATOM),
        'account'=>['id'=>$uid,'email'=>$user->user_email,'display_name'=>$user->display_name,'registered'=>$user->user_registered,'role'=>pw_user_role($uid)],
        'company_meta'=>$meta,
        'talent_pool'=>$workers,
        'personalanfragen'=>$vacancies,
        'profileinreichungen'=>$submissions,
        'messages'=>$messages,
    ];
}

function pw_handle_data_export() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    check_admin_referer('pw_data_export');
    $uid=get_current_user_id();
    if(!in_array(pw_user_role($uid),['agency','client'],true)) wp_die('Keine Berechtigung.');
    $data=pw_collect_portal_export($uid);
    pw_audit_event('data_export',$uid,'account',$uid,'Nutzer hat einen Datenexport heruntergeladen');
    nocache_headers();
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="pure-work-datenexport-'.gmdate('Y-m-d').'.json"');
    echo wp_json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
add_action('admin_post_pw_data_export','pw_handle_data_export');

function pw_handle_delete_request() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    check_admin_referer('pw_delete_request');
    $uid=get_current_user_id();
    if(!in_array(pw_user_role($uid),['agency','client'],true)) wp_die('Keine Berechtigung.');
    update_user_meta($uid,'pw_delete_requested_at',time());
    pw_audit_event('delete_request',$uid,'account',$uid,'Löschanfrage gestellt');
    $u=get_userdata($uid);
    $company=pw_user_meta($uid,'pw_company',$u?$u->display_name:'Unternehmen');
    if($u) pw_send_mail($u->user_email,'Pure Work – Löschanfrage eingegangen','Löschanfrage eingegangen','Wir haben deine Anfrage zur Löschung des Pure Work Kontos erhalten. Der Portalbetreiber prüft vor der Löschung, ob gesetzliche oder vertragliche Aufbewahrungspflichten entgegenstehen.','Konto öffnen',pw_page_url('account',['tab'=>'security']));
    $admin=get_option('admin_email');
    if(is_email($admin)) pw_send_mail($admin,'Pure Work – Löschanfrage','Kontolöschung prüfen',$company.' hat eine Löschanfrage gestellt. Bitte datenschutzrechtliche und gesetzliche Aufbewahrungspflichten prüfen.','Im Backend öffnen',admin_url('admin.php?page=pure-work'));
    wp_safe_redirect(pw_page_url('account',['tab'=>'security','delete_requested'=>1]));
    exit;
}
add_action('admin_post_pw_delete_request','pw_handle_delete_request');

function pw_privacy_cleanup_event() {
    // Short-lived technical tokens are removed automatically. Business records are
    // not deleted on a guessed schedule; the operator can configure retention only
    // after the legal concept is finalised.
    $users=get_users(['role__in'=>['pw_agency','pw_client'],'fields'=>'ID']);
    foreach($users as $uid) {
        $exp=(int)get_user_meta($uid,'pw_email_verify_expires',true);
        if($exp && $exp < time()-DAY_IN_SECONDS){delete_user_meta($uid,'pw_email_verify_hash');delete_user_meta($uid,'pw_email_verify_expires');}
        $aexp=(int)get_user_meta($uid,'pw_aug_renew_expires',true);
        if($aexp && $aexp < time()-DAY_IN_SECONDS){delete_user_meta($uid,'pw_aug_renew_hash');delete_user_meta($uid,'pw_aug_renew_expires');}
    }
}
add_action('pw_privacy_cleanup_event','pw_privacy_cleanup_event');

function pw_schedule_privacy_cleanup() {
    if(!wp_next_scheduled('pw_privacy_cleanup_event')) wp_schedule_event(time()+1200,'daily','pw_privacy_cleanup_event');
}
add_action('init','pw_schedule_privacy_cleanup',41);
