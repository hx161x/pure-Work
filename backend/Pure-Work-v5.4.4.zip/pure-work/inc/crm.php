<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work CRM 4.7
 * Lightweight, company-scoped CRM for both staffing agencies and clients.
 * Market signals can be captured as leads without pretending they are registered Pure Work partners.
 */
function pw_crm_stages() {
    return [
        'new'       => ['Neu','New'],
        'qualified' => ['Qualifiziert','Qualified'],
        'contacted' => ['Kontaktiert','Contacted'],
        'meeting'   => ['Termin','Meeting'],
        'offer'     => ['Angebot','Offer'],
        'won'       => ['Gewonnen','Won'],
        'lost'      => ['Verloren','Lost'],
    ];
}

function pw_crm_stage_label($stage) {
    $stages = pw_crm_stages();
    if (!isset($stages[$stage])) $stage = 'new';
    return pw_t($stages[$stage][0], $stages[$stage][1]);
}

function pw_crm_lead_fields($lead_id) {
    $post = get_post((int)$lead_id);
    if (!$post || $post->post_type !== 'pw_crm_lead') return null;
    $keys = ['company','contact','contact_role','email','phone','city','industry','stage','source','source_url','job_title','job_ref','priority','next_followup','notes','target_type','market_published','lead_quality','verified_at','deadline','cpv','notice_id'];
    $out = ['id'=>(int)$post->ID,'author'=>(int)$post->post_author,'title'=>$post->post_title,'created'=>$post->post_date_gmt];
    foreach ($keys as $key) $out[$key] = pw_meta($post->ID, 'pw_crm_'.$key, '');
    if (!$out['stage']) $out['stage'] = 'new';
    if (!$out['priority']) $out['priority'] = 'warm';
    return $out;
}

function pw_crm_can_access($lead_id, $uid = 0) {
    if (!$uid) $uid = get_current_user_id();
    if (current_user_can('manage_options')) return true;
    $lead = pw_crm_lead_fields($lead_id);
    return $lead && (int)$lead['author'] === (int)$uid;
}

function pw_crm_get_leads($uid = 0, $args = []) {
    if (!$uid) $uid = get_current_user_id();
    $query = [
        'post_type'=>'pw_crm_lead','post_status'=>'publish','author'=>$uid,
        'posts_per_page'=>200,'orderby'=>'modified','order'=>'DESC'
    ];
    if (!empty($args['stage'])) $query['meta_query'] = [['key'=>'pw_crm_stage','value'=>sanitize_key($args['stage'])]];
    $posts = get_posts($query);
    $search = isset($args['search']) ? pw_normalize_text($args['search']) : '';
    if ($search) {
        $posts = array_values(array_filter($posts, function($p) use ($search) {
            $l = pw_crm_lead_fields($p->ID);
            $hay = pw_normalize_text(($l['company']??'').' '.($l['contact']??'').' '.($l['city']??'').' '.($l['job_title']??'').' '.($l['industry']??''));
            return pw_contains($hay, $search);
        }));
    }
    return $posts;
}

function pw_crm_create_or_update_lead($uid, $data, $lead_id = 0) {
    $company = sanitize_text_field((string)($data['company'] ?? ''));
    if (!$company) return new WP_Error('missing_company','Unternehmen fehlt.');
    $stage = sanitize_key((string)($data['stage'] ?? 'new'));
    if (!isset(pw_crm_stages()[$stage])) $stage = 'new';
    $priority = sanitize_key((string)($data['priority'] ?? 'warm'));
    if (!in_array($priority,['hot','warm','cold'],true)) $priority='warm';

    if ($lead_id) {
        if (!pw_crm_can_access($lead_id,$uid)) return new WP_Error('forbidden','Kein Zugriff.');
        wp_update_post(['ID'=>(int)$lead_id,'post_title'=>$company]);
    } else {
        $lead_id = wp_insert_post([
            'post_type'=>'pw_crm_lead','post_status'=>'publish','post_author'=>$uid,'post_title'=>$company,
        ]);
        if (is_wp_error($lead_id)) return $lead_id;
    }

    $map = [
        'company'=>$company,
        'contact'=>sanitize_text_field((string)($data['contact']??'')),
        'contact_role'=>sanitize_text_field((string)($data['contact_role']??'')),
        'email'=>sanitize_email((string)($data['email']??'')),
        'phone'=>sanitize_text_field((string)($data['phone']??'')),
        'city'=>sanitize_text_field((string)($data['city']??'')),
        'industry'=>sanitize_text_field((string)($data['industry']??'')),
        'stage'=>$stage,
        'source'=>sanitize_text_field((string)($data['source']??'manual')),
        'source_url'=>esc_url_raw((string)($data['source_url']??'')),
        'job_title'=>sanitize_text_field((string)($data['job_title']??'')),
        'job_ref'=>sanitize_text_field((string)($data['job_ref']??'')),
        'priority'=>$priority,
        'next_followup'=>sanitize_text_field((string)($data['next_followup']??'')),
        'notes'=>sanitize_textarea_field((string)($data['notes']??'')),
        'target_type'=>sanitize_key((string)($data['target_type']??'')),
        'market_published'=>sanitize_text_field((string)($data['market_published']??'')),
        'lead_quality'=>sanitize_text_field((string)($data['lead_quality']??'')),
        'verified_at'=>sanitize_text_field((string)($data['verified_at']??'')),
        'deadline'=>sanitize_text_field((string)($data['deadline']??'')),
        'cpv'=>sanitize_text_field((string)($data['cpv']??'')),
        'notice_id'=>sanitize_text_field((string)($data['notice_id']??'')),
    ];
    foreach ($map as $k=>$v) update_post_meta($lead_id,'pw_crm_'.$k,$v);
    update_post_meta($lead_id,'pw_crm_updated_at',current_time('mysql',true));
    return (int)$lead_id;
}

function pw_crm_add_activity($lead_id, $uid, $type, $text, $due = '', $done = '0') {
    if (!pw_crm_can_access($lead_id,$uid)) return 0;
    $activity_id = wp_insert_post([
        'post_type'=>'pw_crm_activity','post_status'=>'publish','post_author'=>$uid,
        'post_title'=>sanitize_text_field($type),'post_content'=>sanitize_textarea_field($text),
    ]);
    if (is_wp_error($activity_id)) return 0;
    update_post_meta($activity_id,'pw_crm_lead_id',(int)$lead_id);
    update_post_meta($activity_id,'pw_crm_type',sanitize_key($type));
    update_post_meta($activity_id,'pw_crm_due',sanitize_text_field($due));
    update_post_meta($activity_id,'pw_crm_done',$done==='1'?'1':'0');
    return (int)$activity_id;
}

function pw_crm_activities($lead_id, $uid = 0) {
    if (!$uid) $uid=get_current_user_id();
    if (!pw_crm_can_access($lead_id,$uid)) return [];
    return get_posts([
        'post_type'=>'pw_crm_activity','post_status'=>'publish','author'=>$uid,'posts_per_page'=>100,
        'orderby'=>'date','order'=>'DESC','meta_query'=>[['key'=>'pw_crm_lead_id','value'=>(int)$lead_id]],
    ]);
}

function pw_crm_handle_save() {
    if (!is_user_logged_in()) wp_die('Anmeldung erforderlich.');
    pw_require_post_nonce('pw_crm_save');
    $uid=get_current_user_id();
    $lead_id=(int)($_POST['lead_id']??0);
    $data=[];
    foreach(['company','contact','email','phone','city','industry','stage','source','source_url','job_title','job_ref','priority','next_followup','notes','target_type','market_published'] as $k){
        $data[$k]=isset($_POST[$k])?wp_unslash($_POST[$k]):'';
    }
    $saved=pw_crm_create_or_update_lead($uid,$data,$lead_id);
    if(is_wp_error($saved)) pw_form_redirect('crm',['error'=>'lead']);
    pw_form_redirect('crm',['lead'=>$saved,'saved'=>1]);
}
add_action('admin_post_pw_crm_save','pw_crm_handle_save');

function pw_crm_handle_capture_market() {
    if (!is_user_logged_in()) wp_die('Anmeldung erforderlich.');
    pw_require_post_nonce('pw_crm_capture_market');
    $uid=get_current_user_id();
    $company=sanitize_text_field(wp_unslash($_POST['company']??''));
    $job=sanitize_text_field(wp_unslash($_POST['job_title']??''));
    $city=sanitize_text_field(wp_unslash($_POST['city']??''));
    $ref=sanitize_text_field(wp_unslash($_POST['job_ref']??''));
    $source_url=esc_url_raw(wp_unslash($_POST['source_url']??''));
    $published=sanitize_text_field(wp_unslash($_POST['market_published']??''));
    if(!$company) pw_form_redirect('market_live',['error'=>'lead']);

    // De-duplicate by external reference when possible.
    $existing=[];
    if($ref){
        $existing=get_posts(['post_type'=>'pw_crm_lead','post_status'=>'publish','author'=>$uid,'fields'=>'ids','posts_per_page'=>1,'meta_query'=>[['key'=>'pw_crm_job_ref','value'=>$ref]]]);
    }
    if($existing){
        $lead_id=(int)$existing[0];
    } else {
        $lead_id=pw_crm_create_or_update_lead($uid,[
            'company'=>$company,'city'=>$city,'stage'=>'new','source'=>'Legacy-Marktsignal (nicht Direkt-Lead)',
            'source_url'=>$source_url,'job_title'=>$job,'job_ref'=>$ref,'priority'=>'hot',
            'market_published'=>$published,
            'target_type'=>pw_user_role($uid)==='agency'?'client':'agency',
            'notes'=>'Legacy-Marktsignal aus einer allgemeinen Stellenquelle; bewusst nicht als verifizierter Direkt-Lead eingestuft.',
        ]);
    }
    if(is_wp_error($lead_id)) pw_form_redirect('market_live',['error'=>'lead']);
    pw_crm_add_activity($lead_id,$uid,'signal','Legacy-Marktsignal in CRM übernommen; kein verifizierter Direkt-Lead.');
    pw_form_redirect('crm',['lead'=>$lead_id,'captured'=>1]);
}
add_action('admin_post_pw_crm_capture_market','pw_crm_handle_capture_market');

function pw_crm_handle_activity() {
    if(!is_user_logged_in())wp_die('Anmeldung erforderlich.');
    pw_require_post_nonce('pw_crm_activity');
    $uid=get_current_user_id();$lead_id=(int)($_POST['lead_id']??0);
    $text=sanitize_textarea_field(wp_unslash($_POST['activity_text']??''));
    $type=sanitize_key(wp_unslash($_POST['activity_type']??'note'));
    $due=sanitize_text_field(wp_unslash($_POST['due']??''));
    if(!$lead_id||!$text||!pw_crm_can_access($lead_id,$uid))pw_form_redirect('crm',['error'=>'activity']);
    pw_crm_add_activity($lead_id,$uid,$type,$text,$due);
    if($due) update_post_meta($lead_id,'pw_crm_next_followup',$due);
    pw_form_redirect('crm',['lead'=>$lead_id,'saved'=>1]);
}
add_action('admin_post_pw_crm_activity','pw_crm_handle_activity');

function pw_crm_handle_stage() {
    if(!is_user_logged_in())wp_die('Anmeldung erforderlich.');
    pw_require_post_nonce('pw_crm_stage');
    $uid=get_current_user_id();$lead_id=(int)($_POST['lead_id']??0);$stage=sanitize_key(wp_unslash($_POST['stage']??''));
    if(!$lead_id||!pw_crm_can_access($lead_id,$uid)||!isset(pw_crm_stages()[$stage]))pw_form_redirect('crm',['error'=>'stage']);
    update_post_meta($lead_id,'pw_crm_stage',$stage);update_post_meta($lead_id,'pw_crm_updated_at',current_time('mysql',true));
    pw_crm_add_activity($lead_id,$uid,'stage','Status geändert: '.pw_crm_stage_label($stage));
    pw_form_redirect('crm',['lead'=>$lead_id,'saved'=>1]);
}
add_action('admin_post_pw_crm_stage','pw_crm_handle_stage');

function pw_crm_handle_delete() {
    if(!is_user_logged_in())wp_die('Anmeldung erforderlich.');
    $uid=get_current_user_id();$lead_id=(int)($_GET['lead']??0);
    check_admin_referer('pw_crm_delete_'.$lead_id);
    if($lead_id&&pw_crm_can_access($lead_id,$uid)){
        foreach(pw_crm_activities($lead_id,$uid) as $a)wp_delete_post($a->ID,true);
        wp_delete_post($lead_id,true);
    }
    pw_form_redirect('crm',['deleted'=>1]);
}
add_action('admin_post_pw_crm_delete','pw_crm_handle_delete');

function pw_crm_ai_hint($lead) {
    if(!$lead)return '';
    $stage=$lead['stage'];$job=$lead['job_title'];$contact=$lead['contact'];$email=$lead['email'];
    if($stage==='new') return $job ? 'Marktsignal prüfen, passenden Talent Pool filtern und einen konkreten Personalvorschlag vorbereiten.' : 'Bedarf und Ansprechpartner qualifizieren. Danach nächsten Kontakttermin festlegen.';
    if($stage==='qualified' && !$contact) return 'Ansprechpartner ergänzen und Erstkontakt vorbereiten. Quelle und Unternehmensseite können dafür genutzt werden.';
    if($stage==='qualified') return 'Erstkontakt mit klarem Bezug auf den konkreten Bedarf vorbereiten.';
    if($stage==='contacted') return 'Wiedervorlage setzen. Falls keine Antwort kommt, mit einem konkreten Profil- oder Kapazitätsvorschlag nachfassen.';
    if($stage==='meeting') return 'Gespräch mit Bedarf, Starttermin, Schicht, Qualifikation, Menge und Verrechnungssatz strukturieren.';
    if($stage==='offer') return 'Angebot nachverfolgen und nächste Entscheidung mit Datum dokumentieren.';
    if($stage==='won') return 'Auftrag in Personalanfrage / Einsatzprozess überführen und weitere Bedarfe beim Kunden identifizieren.';
    return 'Lead dokumentieren und bei neuem Marktsignal erneut qualifizieren.';
}

function pw_crm_available_workers($uid, $limit=20) {
    if(pw_user_role($uid)!=='agency')return [];
    return get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>$limit,'orderby'=>'modified','order'=>'DESC','meta_query'=>[['key'=>'pw_status','value'=>['available','reserved'],'compare'=>'IN']]]);
}

function pw_crm_pitch_text($lead,$worker_ids=[]) {
    $company=$lead['company'];$job=$lead['job_title'];
    $lines=[];
    $lines[]='Guten Tag,';
    $lines[]='';
    $lines[]='wir haben Ihren aktuellen Personalbedarf'.($job?' im Bereich „'.$job.'“':'').' gesehen und können kurzfristig passende, verfügbare Profile anbieten.';
    if($worker_ids){
        $lines[]='';$lines[]='Auswahl verfügbarer Profile:';
        foreach($worker_ids as $wid){$w=pw_worker_fields((int)$wid);if(!$w||$w['author']!=get_current_user_id())continue;$lines[]='• '.$w['code'].' – '.$w['role'].' – '.$w['experience'].' Jahre Erfahrung – verfügbar ab '.pw_format_date($w['available_from']);}
    }
    $lines[]='';
    $lines[]='Gerne stimmen wir Einsatzbeginn, Schichtmodell und Konditionen kurzfristig mit Ihnen ab.';
    $lines[]='';
    $lines[]='Freundliche Grüße';
    $lines[]=pw_user_meta(get_current_user_id(),'pw_company','Pure Work Nutzer');
    return implode("\n",$lines);
}

function pw_crm_lead_detail($lead_id) {
    $uid=get_current_user_id();$lead=pw_crm_lead_fields($lead_id);
    if(!$lead||!pw_crm_can_access($lead_id,$uid))return '<div class="pw-card pw-empty"><h3>Lead nicht gefunden</h3></div>';
    $activities=pw_crm_activities($lead_id,$uid);$workers=pw_crm_available_workers($uid,12);
    $mail_subject='Personalvorschlag'.($lead['job_title']?' – '.$lead['job_title']:'');
    $pitch=pw_crm_pitch_text($lead,[]);
    ob_start(); ?>
    <div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('crm')); ?>">← CRM</a><div class="pw-title-line"><h2><?php echo esc_html($lead['company']); ?></h2><span class="pw-crm-priority <?php echo esc_attr($lead['priority']); ?>"><?php echo esc_html(strtoupper($lead['priority'])); ?></span></div><p><?php echo esc_html($lead['city']?:'Standort offen'); ?><?php if($lead['job_title']):?> · <?php echo esc_html($lead['job_title']); ?><?php endif;?></p></div><a class="pw-btn danger-ghost small pw-confirm" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_crm_delete&lead='.$lead_id),'pw_crm_delete_'.$lead_id)); ?>">Löschen</a></div>
    <div class="pw-crm-detail-grid">
      <section class="pw-card span2">
        <div class="pw-card-head"><div><span class="pw-kicker">PURE CRM</span><h2>360° Kunden-/Partnerakte</h2></div><span class="pw-badge info"><?php echo esc_html(pw_crm_stage_label($lead['stage'])); ?></span></div>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-form-grid two"><input type="hidden" name="action" value="pw_crm_save"><input type="hidden" name="lead_id" value="<?php echo (int)$lead_id; ?>"><?php wp_nonce_field('pw_crm_save'); ?>
          <label>Unternehmen<input name="company" required value="<?php echo esc_attr($lead['company']); ?>"></label><label>Ort<input name="city" value="<?php echo esc_attr($lead['city']); ?>"></label>
          <label>Ansprechpartner<input name="contact" value="<?php echo esc_attr($lead['contact']); ?>" placeholder="z. B. Vergabestelle / Dienstleistungseinkauf"></label><label>Funktion / Zuständigkeit<input name="contact_role" value="<?php echo esc_attr($lead['contact_role']); ?>" placeholder="z. B. Vergabestelle / Beschaffung AÜ"></label>
          <label>E-Mail<input type="email" name="email" value="<?php echo esc_attr($lead['email']); ?>"></label>
          <label>Telefon<input name="phone" value="<?php echo esc_attr($lead['phone']); ?>"></label><label>Branche<input name="industry" list="pw-industries" value="<?php echo esc_attr($lead['industry']); ?>"></label>
          <label>Status<select name="stage"><?php foreach(pw_crm_stages() as $key=>$labels):?><option value="<?php echo esc_attr($key); ?>" <?php selected($lead['stage'],$key); ?>><?php echo esc_html(pw_t($labels[0],$labels[1])); ?></option><?php endforeach;?></select></label>
          <label>Priorität<select name="priority"><option value="hot" <?php selected($lead['priority'],'hot'); ?>>Hot</option><option value="warm" <?php selected($lead['priority'],'warm'); ?>>Warm</option><option value="cold" <?php selected($lead['priority'],'cold'); ?>>Cold</option></select></label>
          <label>Nächste Wiedervorlage<input type="date" name="next_followup" value="<?php echo esc_attr($lead['next_followup']); ?>"></label><label>Aktuelles Marktsignal<input name="job_title" value="<?php echo esc_attr($lead['job_title']); ?>"></label>
          <label class="full">Notizen<textarea name="notes" rows="5"><?php echo esc_textarea($lead['notes']); ?></textarea></label>
          <input type="hidden" name="source" value="<?php echo esc_attr($lead['source']); ?>"><input type="hidden" name="source_url" value="<?php echo esc_attr($lead['source_url']); ?>"><input type="hidden" name="job_ref" value="<?php echo esc_attr($lead['job_ref']); ?>"><input type="hidden" name="target_type" value="<?php echo esc_attr($lead['target_type']); ?>"><input type="hidden" name="market_published" value="<?php echo esc_attr($lead['market_published']); ?>"><input type="hidden" name="lead_quality" value="<?php echo esc_attr($lead['lead_quality']); ?>"><input type="hidden" name="verified_at" value="<?php echo esc_attr($lead['verified_at']); ?>"><input type="hidden" name="deadline" value="<?php echo esc_attr($lead['deadline']); ?>"><input type="hidden" name="cpv" value="<?php echo esc_attr($lead['cpv']); ?>"><input type="hidden" name="notice_id" value="<?php echo esc_attr($lead['notice_id']); ?>">
          <div class="full pw-form-actions"><button class="pw-btn primary">CRM-Akte speichern</button><?php if($lead['source_url']):?><a class="pw-btn ghost" target="_blank" rel="noopener noreferrer" href="<?php echo esc_url($lead['source_url']); ?>">Öffentliche Quelle öffnen</a><?php endif;?></div>
        </form>
      </section>
      <?php if($lead['target_type']==='direct_staffing'): ?>
      <section class="pw-card pw-crm-source-proof">
        <span class="pw-kicker">DIREKT-LEAD NACHWEIS</span><h3>Zuständigkeit & Quelle</h3>
        <div class="pw-crm-proof-grid">
          <div><small>Kontakt</small><b><?php echo esc_html($lead['contact'] ?: 'Vergabe-/Beschaffungsstelle'); ?></b><span><?php echo esc_html($lead['contact_role'] ?: 'AÜ-Vergabekontakt'); ?></span></div>
          <div><small>Kontaktqualität</small><b><?php echo esc_html($lead['lead_quality'] ?: 'geprüft'); ?>/100</b><span>Quelle geprüft <?php echo esc_html(pw_format_date($lead['verified_at'])); ?></span></div>
          <div><small>Vergabe</small><b><?php echo esc_html($lead['notice_id'] ?: $lead['job_ref']); ?></b><span><?php echo $lead['deadline'] ? 'Frist '.esc_html(pw_format_date($lead['deadline'])) : 'laufender Bedarf'; ?></span></div>
        </div>
      </section>
      <?php endif; ?>
      <aside class="pw-card pw-crm-assist"><span class="pw-kicker">PURE ASSIST</span><h3>Nächster sinnvoller Schritt</h3><p><?php echo esc_html(pw_crm_ai_hint($lead)); ?></p><div class="pw-ai-orb"><i></i><i></i><span>AI</span></div></aside>
    </div>
    <?php if(pw_user_role($uid)==='agency'): ?>
    <section class="pw-card pw-crm-pitch"><div class="pw-card-head"><div><span class="pw-kicker">TALENT PITCH</span><h2>Personalangebot vorbereiten</h2><p>Wähle reale Profile aus deinem Talent Pool. Pure Work erstellt daraus einen anonymisierten Erstkontakt.</p></div><a href="<?php echo esc_url(pw_page_url('workers',['new'=>1])); ?>">+ Talent anlegen</a></div>
      <?php if(!$workers):?><div class="pw-empty compact"><h3>Noch keine verfügbaren Profile</h3><p>Lege zuerst Mitarbeiter im Talent Pool an.</p></div><?php else:?><div class="pw-crm-worker-select"><?php foreach($workers as $wp):$w=pw_worker_fields($wp->ID);?><label><input type="checkbox" data-pitch-worker data-code="<?php echo esc_attr($w['code']); ?>" data-role="<?php echo esc_attr($w['role']); ?>" data-exp="<?php echo esc_attr($w['experience']); ?>" data-date="<?php echo esc_attr(pw_format_date($w['available_from'])); ?>"><span class="pw-profile-code small"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><b><?php echo esc_html($w['code'].' · '.$w['role']); ?></b><small><?php echo (int)$w['experience']; ?> Jahre · ab <?php echo esc_html(pw_format_date($w['available_from'])); ?></small></div></label><?php endforeach;?></div>
      <div class="pw-crm-compose"><div><span class="pw-kicker">VORSCHAU</span><h3>Akquise-/Personalvorschlag</h3></div><textarea id="pw-crm-pitch-text" rows="11" data-base-company="<?php echo esc_attr($lead['company']); ?>" data-base-job="<?php echo esc_attr($lead['job_title']); ?>"><?php echo esc_textarea($pitch); ?></textarea><div class="pw-form-actions"><button type="button" class="pw-btn ghost" data-copy-target="#pw-crm-pitch-text">Text kopieren</button><?php if($lead['email']):?><a class="pw-btn primary" id="pw-crm-mailto" href="mailto:<?php echo esc_attr($lead['email']); ?>?subject=<?php echo rawurlencode($mail_subject); ?>&body=<?php echo rawurlencode($pitch); ?>">E-Mail vorbereiten</a><?php else:?><span class="pw-inline-info">Ansprechpartner/E-Mail ergänzen, um den Mail-Entwurf direkt zu öffnen.</span><?php endif;?></div></div><?php endif;?>
    </section>
    <?php endif; ?>
    <section class="pw-crm-activity-grid"><div class="pw-card"><span class="pw-kicker">AKTIVITÄT</span><h2>Kontaktverlauf</h2><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-crm-activity-form"><input type="hidden" name="action" value="pw_crm_activity"><input type="hidden" name="lead_id" value="<?php echo (int)$lead_id; ?>"><?php wp_nonce_field('pw_crm_activity'); ?><select name="activity_type"><option value="note">Notiz</option><option value="call">Telefonat</option><option value="email">E-Mail</option><option value="meeting">Termin</option><option value="task">Aufgabe</option></select><input type="date" name="due"><textarea name="activity_text" rows="3" required placeholder="Was wurde besprochen / was ist als Nächstes zu tun?"></textarea><button class="pw-btn primary small">Aktivität speichern</button></form></div><div class="pw-card"><span class="pw-kicker">HISTORIE</span><div class="pw-crm-timeline"><?php if(!$activities):?><p class="pw-muted">Noch keine Aktivitäten.</p><?php else:foreach($activities as $a):?><div><i></i><div><b><?php echo esc_html(ucfirst(pw_meta($a->ID,'pw_crm_type','Notiz'))); ?></b><p><?php echo nl2br(esc_html($a->post_content)); ?></p><small><?php echo esc_html(wp_date('d.m.Y · H:i',get_post_time('U',true,$a))); ?><?php $due=pw_meta($a->ID,'pw_crm_due','');if($due):?> · Wiedervorlage <?php echo esc_html(pw_format_date($due)); ?><?php endif;?></small></div></div><?php endforeach;endif;?></div></div></section>
    <?php return ob_get_clean();
}

function pw_crm_new_form($prefill=[]) {
    $company=sanitize_text_field($prefill['company']??'');$city=sanitize_text_field($prefill['city']??'');$job=sanitize_text_field($prefill['job_title']??'');
    ob_start();?><div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('crm')); ?>">← CRM</a><h2>CRM-Eintrag anlegen</h2><p>Unternehmen, Ansprechpartner, Chance und Wiedervorlage an einem Ort.</p></div></div><form class="pw-form-stack" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_crm_save"><?php wp_nonce_field('pw_crm_save'); ?><section class="pw-form-card"><div class="pw-form-section-title"><span>01</span><div><h3>Unternehmen & Chance</h3><p>Manuell anlegen oder direkt aus Direkt-Leads übernehmen.</p></div></div><div class="pw-form-grid two"><label>Unternehmen<input required name="company" value="<?php echo esc_attr($company); ?>"></label><label>Ort<input name="city" value="<?php echo esc_attr($city); ?>"></label><label>Ansprechpartner<input name="contact"></label><label>E-Mail<input type="email" name="email"></label><label>Telefon<input name="phone"></label><label>Branche<input name="industry" list="pw-industries"></label><label>Chance / Bedarf<input name="job_title" value="<?php echo esc_attr($job); ?>"></label><label>Status<select name="stage"><?php foreach(pw_crm_stages() as $key=>$labels):?><option value="<?php echo esc_attr($key); ?>"><?php echo esc_html(pw_t($labels[0],$labels[1])); ?></option><?php endforeach;?></select></label><label>Priorität<select name="priority"><option value="hot">Hot</option><option value="warm" selected>Warm</option><option value="cold">Cold</option></select></label><label>Wiedervorlage<input type="date" name="next_followup"></label><label class="full">Notiz<textarea name="notes" rows="4"></textarea></label></div></section><div class="pw-form-actions"><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('crm')); ?>">Abbrechen</a><button class="pw-btn primary">CRM-Akte anlegen</button></div></form><?php return ob_get_clean();
}

function pw_crm_dashboard_metrics($uid=0) {
    if(!$uid)$uid=get_current_user_id();$posts=pw_crm_get_leads($uid);$counts=array_fill_keys(array_keys(pw_crm_stages()),0);$due=0;$today=wp_date('Y-m-d');
    foreach($posts as $p){$l=pw_crm_lead_fields($p->ID);if(isset($counts[$l['stage']]))$counts[$l['stage']]++;if($l['next_followup']&&$l['next_followup']<=$today&&!in_array($l['stage'],['won','lost'],true))$due++;}
    return ['total'=>count($posts),'hot'=>$counts['new']+$counts['qualified'],'due'=>$due,'offer'=>$counts['offer'],'won'=>$counts['won']];
}

function pw_crm_dashboard_widget($uid=0) {
    if(!$uid)$uid=get_current_user_id();$m=pw_crm_dashboard_metrics($uid);$leads=array_slice(pw_crm_get_leads($uid),0,4);
    ob_start();?><section class="pw-card span2 pw-crm-widget"><div class="pw-card-head"><div><span class="pw-kicker">PURE CRM</span><h2>Pipeline & Wiedervorlagen</h2><p>Direkt-Leads, Partner und laufende Kontakte direkt aus deinem Puls steuern.</p></div><a href="<?php echo esc_url(pw_page_url('crm')); ?>">CRM öffnen</a></div><div class="pw-crm-widget-metrics"><div><b><?php echo (int)$m['total']; ?></b><span>Leads</span></div><div><b><?php echo (int)$m['hot']; ?></b><span>neu / qualifiziert</span></div><div class="<?php echo $m['due']?'danger':''; ?>"><b><?php echo (int)$m['due']; ?></b><span>Wiedervorlagen</span></div><div><b><?php echo (int)$m['won']; ?></b><span>gewonnen</span></div></div><?php if($leads):?><div class="pw-crm-mini-list"><?php foreach($leads as $p):$l=pw_crm_lead_fields($p->ID);?><a href="<?php echo esc_url(pw_page_url('crm',['lead'=>$p->ID])); ?>"><span class="pw-company-logo small"><?php echo esc_html(pw_initials($l['company'])); ?></span><div><b><?php echo esc_html($l['company']); ?></b><small><?php echo esc_html($l['job_title']?:$l['city']); ?></small></div><span class="pw-badge muted"><?php echo esc_html(pw_crm_stage_label($l['stage'])); ?></span></a><?php endforeach;?></div><?php else:?><div class="pw-empty compact"><p>Noch keine CRM-Leads. Übernimm einen verifizierten AÜ-Direkt-Lead inklusive Kontaktstelle mit einem Klick.</p><a class="pw-btn small primary" href="<?php echo esc_url(pw_page_url('market_live')); ?>">Direkt-Leads öffnen</a></div><?php endif;?></section><?php return ob_get_clean();
}

function pw_shortcode_crm() {
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();
    ob_start();echo pw_portal_shell_start(pw_t('Meine Kunden','My customers'),pw_t('Kunden, Partner und Wiedervorlagen in einer Übersicht','Customers, partners and follow-ups in one view'));echo pw_flash_messages();
    if(function_exists('pw_can')&&!pw_can('crm')){echo pw_plan_gate('crm');echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['lead'])){echo pw_crm_lead_detail((int)$_GET['lead']);echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['new'])){echo pw_crm_new_form();echo pw_portal_shell_end();return ob_get_clean();}
    $search=sanitize_text_field(wp_unslash($_GET['q']??''));$posts=pw_crm_get_leads($uid,['search'=>$search]);$metrics=pw_crm_dashboard_metrics($uid);$by=[];foreach(array_keys(pw_crm_stages()) as $s)$by[$s]=[];foreach($posts as $p){$l=pw_crm_lead_fields($p->ID);if(isset($by[$l['stage']]))$by[$l['stage']][]=$p;}
    ?><div class="pw-crm-hero"><div><span class="pw-kicker">PURE CRM</span><h2>Aus geprüften AÜ-Bedarfen werden direkte Beziehungen.</h2><p>AÜ-Bedarf entdecken, zuständige Kontaktstelle direkt übernehmen, Wiedervorlagen setzen und Personalangebote vorbereiten.</p></div><div class="pw-crm-orbit"><span>CRM</span><i></i><i></i><i></i></div></div>
    <div class="pw-mini-stats"><?php echo pw_metric($metrics['total'],'Leads insgesamt');echo pw_metric($metrics['hot'],'neu / qualifiziert','','info');echo pw_metric($metrics['due'],'heute fällig','','warning');echo pw_metric($metrics['won'],'gewonnen','','success'); ?></div>
    <div class="pw-list-toolbar"><form method="get" class="pw-search-bar"><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($search); ?>" placeholder="Unternehmen, Ort, Bedarf oder Ansprechpartner suchen"><button>Suche</button></form><div class="pw-toolbar-actions"><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('market_live')); ?>">Direkt-Leads</a><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('crm',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?> Lead anlegen</a></div></div>
    <div class="pw-crm-kanban"><?php foreach(pw_crm_stages() as $stage=>$labels): if($stage==='lost')continue; ?><section class="pw-crm-column" data-stage="<?php echo esc_attr($stage); ?>"><header><div><span><?php echo esc_html(pw_t($labels[0],$labels[1])); ?></span><b><?php echo count($by[$stage]); ?></b></div></header><div><?php if(!$by[$stage]):?><div class="pw-crm-empty-col">–</div><?php else:foreach($by[$stage] as $p):$l=pw_crm_lead_fields($p->ID);?><a class="pw-crm-card" href="<?php echo esc_url(pw_page_url('crm',['lead'=>$p->ID])); ?>"><div class="pw-crm-card-top"><span class="pw-company-logo small"><?php echo esc_html(pw_initials($l['company'])); ?></span><span class="pw-crm-priority <?php echo esc_attr($l['priority']); ?>"></span></div><h3><?php echo esc_html($l['company']); ?></h3><p><?php echo esc_html($l['job_title']?:($l['industry']?:'Allgemeine Chance')); ?></p><div class="pw-crm-card-meta"><span><?php echo pw_icon('map'); ?> <?php echo esc_html($l['city']?:'–'); ?></span><?php if($l['next_followup']):?><span><?php echo pw_icon('clock'); ?> <?php echo esc_html(pw_format_date($l['next_followup'])); ?></span><?php endif;?></div><?php if($l['source']):?><small><?php echo esc_html($l['source']); ?></small><?php endif;?></a><?php endforeach;endif;?></div></section><?php endforeach;?></div>
    <div class="pw-source-note"><b>CRM-Hinweis:</b> Pure Work Direkt-Leads übernehmen ausschließlich öffentliche Geschäftskontakte, die in der jeweiligen AÜ-/ANÜ-Vergabequelle als zuständige Kontaktstelle veröffentlicht sind. Allgemeine Stellenanzeigen werden nicht als Direkt-Leads behandelt.</div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}
add_shortcode('pw_crm','pw_shortcode_crm');
