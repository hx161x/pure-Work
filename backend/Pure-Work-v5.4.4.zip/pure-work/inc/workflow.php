<?php
if (!defined('ABSPATH')) exit;

function pw_vacancy_public_id($vacancy_id) {
    $id = (string)get_post_meta($vacancy_id, 'pw_public_id', true);
    if ($id) return $id;
    $year = get_post_time('y', true, $vacancy_id) ?: wp_date('y');
    $id = 'PW-' . $year . '-' . str_pad((string)(int)$vacancy_id, 6, '0', STR_PAD_LEFT);
    update_post_meta($vacancy_id, 'pw_public_id', $id);
    return $id;
}

function pw_vacancy_partner_code($vacancy_id) {
    $code = (string)get_post_meta($vacancy_id, 'pw_partner_code', true);
    if ($code) return $code;
    $raw = strtoupper(wp_generate_password(10, false, false));
    $raw = preg_replace('/[^A-Z0-9]/', '', $raw);
    $raw = str_pad(substr($raw,0,8), 8, 'X');
    $code = 'PWX-' . substr($raw,0,4) . '-' . substr($raw,4,4);
    update_post_meta($vacancy_id, 'pw_partner_code', $code);
    return $code;
}

function pw_migrate_vacancy_ids_480() {
    if (get_option('pw_vacancy_ids_480', '0') === '1') return;
    $ids = get_posts(['post_type'=>'pw_vacancy','post_status'=>'any','posts_per_page'=>-1,'fields'=>'ids']);
    foreach ($ids as $id) { pw_vacancy_public_id($id); pw_vacancy_partner_code($id); }
    update_option('pw_vacancy_ids_480', '1', false);
}

function pw_vacancy_unlocked_agencies($vacancy_id) {
    return array_values(array_unique(array_map('intval', (array)get_post_meta($vacancy_id, 'pw_identity_bypass_agencies', true))));
}

function pw_vacancy_partner_unlocked($vacancy_id, $agency_id = 0) {
    if (!$agency_id) $agency_id = get_current_user_id();
    return $agency_id && in_array((int)$agency_id, pw_vacancy_unlocked_agencies($vacancy_id), true);
}

function pw_vacancy_identity_released($vacancy_id, $agency_id = 0) {
    if (!$agency_id) $agency_id = get_current_user_id();
    if (!$vacancy_id || !$agency_id) return false;
    if (current_user_can('manage_options')) return true;
    if (pw_vacancy_partner_unlocked($vacancy_id, $agency_id)) return true;
    $subs = get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[
        'relation'=>'AND',
        ['key'=>'pw_vacancy_id','value'=>(int)$vacancy_id],
        ['key'=>'pw_agency_id','value'=>(int)$agency_id],
    ]]);
    foreach ($subs as $sid) if (get_post_meta($sid,'pw_identity_released',true)==='1') return true;
    return false;
}

function pw_vacancy_client_label($vacancy_id, $viewer_id = 0) {
    $client_id = (int)get_post_field('post_author', $vacancy_id);
    if (!$viewer_id) $viewer_id = get_current_user_id();
    if ($viewer_id === $client_id || current_user_can('manage_options')) return pw_user_meta($client_id,'pw_company',pw_company_alias($client_id));
    if (pw_user_role($viewer_id) === 'agency' && pw_vacancy_identity_released($vacancy_id,$viewer_id)) return pw_user_meta($client_id,'pw_company',pw_company_alias($client_id));
    return pw_t('Auftraggeber anonym','Client anonymous');
}

function pw_vacancy_client_contact($vacancy_id, $agency_id = 0) {
    if (!$agency_id) $agency_id = get_current_user_id();
    if (!pw_vacancy_identity_released($vacancy_id,$agency_id)) return [];
    $client = (int)get_post_field('post_author',$vacancy_id);
    $u = get_userdata($client);
    return [
        'company'=>pw_user_meta($client,'pw_company',''),
        'contact'=>pw_user_meta($client,'pw_contact',$u?$u->display_name:''),
        'email'=>$u?$u->user_email:'',
        'phone'=>pw_user_meta($client,'pw_phone',''),
        'city'=>pw_user_meta($client,'pw_city',''),
    ];
}

function pw_submission_status_labels_480() {
    return [
        'submitted'=>[pw_t('Neu eingereicht','New match'),'info'],
        'viewed'=>[pw_t('Angesehen','Viewed'),'muted'],
        'on_hold'=>[pw_t('Auf Eis','On hold'),'warning'],
        'accepted'=>[pw_t('Angenommen – Chat offen','Accepted – chat open'),'brand'],
        'identity_released'=>[pw_t('Zusammenarbeit bestätigt','Cooperation confirmed'),'success'],
        'rejected'=>[pw_t('Abgelehnt','Rejected'),'danger'],
        'planned'=>[pw_t('Einsatz geplant','Assignment planned'),'success'],
        'withdrawn'=>[pw_t('Zurückgezogen','Withdrawn'),'muted'],
        // legacy mappings
        'shortlisted'=>[pw_t('Auf Eis','On hold'),'warning'],
        'requested'=>[pw_t('Angenommen – Chat offen','Accepted – chat open'),'brand'],
        'confirmed'=>[pw_t('Zusammenarbeit bestätigt','Cooperation confirmed'),'success'],
    ];
}

function pw_submission_chat_open($submission_id) {
    $status = get_post_meta($submission_id,'pw_status',true) ?: 'submitted';
    return in_array($status,['accepted','identity_released','planned','requested','confirmed'],true);
}

function pw_submission_identity_released($submission_id) {
    return get_post_meta($submission_id,'pw_identity_released',true)==='1' || in_array(get_post_meta($submission_id,'pw_status',true),['identity_released','planned'],true);
}

function pw_handle_partner_unlock() {
    if (!is_user_logged_in() || pw_user_role()!=='agency') wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_partner_unlock');
    $code = strtoupper(sanitize_text_field(wp_unslash($_POST['partner_code'] ?? '')));
    if (!$code) pw_form_redirect('vacancies',['unlock_error'=>1]);
    $ids = get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','posts_per_page'=>1,'fields'=>'ids','meta_query'=>[['key'=>'pw_partner_code','value'=>$code]]]);
    if (!$ids) pw_form_redirect('vacancies',['unlock_error'=>1]);
    $vacancy = (int)$ids[0];
    $agencies = pw_vacancy_unlocked_agencies($vacancy);
    $agencies[] = get_current_user_id();
    update_post_meta($vacancy,'pw_identity_bypass_agencies',array_values(array_unique(array_map('intval',$agencies))));
    pw_audit_event('vacancy_partner_unlock',get_current_user_id(),'pw_vacancy',$vacancy,pw_vacancy_public_id($vacancy));
    if (function_exists('pw_crm_sync_unlocked_vacancy')) pw_crm_sync_unlocked_vacancy($vacancy,get_current_user_id());
    pw_form_redirect('vacancies',['view'=>$vacancy,'unlocked'=>1]);
}
add_action('admin_post_pw_partner_unlock','pw_handle_partner_unlock');

function pw_handle_finalize_match() {
    if (!is_user_logged_in() || pw_user_role()!=='client') wp_die('Keine Berechtigung.');
    $sid=(int)($_GET['submission']??0);
    if (!$sid || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'pw_finalize_'.$sid)) wp_die('Sicherheitsprüfung fehlgeschlagen.');
    if (!pw_can_access_submission($sid)) wp_die('Keine Berechtigung.');
    $status = pw_meta($sid,'pw_status','submitted');
    if (!in_array($status,['accepted','requested','confirmed'],true)) wp_die('Diese Zusammenarbeit kann noch nicht final bestätigt werden.');
    update_post_meta($sid,'pw_identity_released','1');
    update_post_meta($sid,'pw_identity_released_at',time());
    update_post_meta($sid,'pw_status','identity_released');
    [$agency,$client]=pw_submission_parties($sid);
    $vid=(int)pw_meta($sid,'pw_vacancy_id',0);
    $company=pw_user_meta($client,'pw_company','Auftraggeber');
    $agency_user=get_userdata($agency);
    pw_create_notice($agency,'Auftraggeber freigegeben',$company.' hat die Zusammenarbeit für '.pw_vacancy_public_id($vid).' bestätigt. Kontaktdaten sind jetzt nur für diese Ausschreibung sichtbar.',pw_page_url('messages',['thread'=>$sid]));
    if($agency_user) pw_send_mail($agency_user->user_email,'Pure Work – Zusammenarbeit bestätigt','Auftraggeber freigegeben',$company.' hat die Zusammenarbeit bestätigt. Die Unternehmens- und Kontaktdaten sind jetzt ausschließlich für diese Ausschreibung sichtbar.','Chat & Kontaktdaten öffnen',pw_page_url('messages',['thread'=>$sid]));
    if (function_exists('pw_crm_sync_submission_release')) pw_crm_sync_submission_release($sid);
    pw_audit_event('submission_identity_release',$client,'pw_submission',$sid,pw_vacancy_public_id($vid));
    pw_form_redirect('messages',['thread'=>$sid,'finalized'=>1]);
}
add_action('admin_post_pw_finalize_match','pw_handle_finalize_match');

function pw_worker_anonymous_profile_html($worker_id) {
    $w = pw_worker_fields($worker_id);
    $parts = [];
    $parts[] = '<div class="pw-anon-cv-head"><span class="pw-profile-code large">'.esc_html(pw_initials($w['role'])).'</span><div><span class="pw-kicker">ANONYMISIERTER PROFIL-LEBENSLAUF</span><h2>'.esc_html($w['role']).'</h2><p>'.esc_html($w['location']).' · '.(int)$w['experience'].' Jahre Erfahrung</p></div></div>';
    $parts[] = '<div class="pw-profile-facts"><div><span>Verfügbar ab</span><b>'.esc_html(pw_format_date($w['available_from'])).'</b></div><div><span>Schichten</span><b>'.esc_html(pw_list_string($w['shifts'])?:'–').'</b></div><div><span>Mobilität</span><b>'.($w['car']?'PKW vorhanden':($w['driver']?'Führerschein B':'–')).'</b></div><div><span>Letzter Einsatz</span><b>'.esc_html($w['last_assignment']?:'–').'</b></div></div>';
    foreach ([['Qualifikationen',$w['qualifications']],['Sprachen',$w['languages']],['Branchenerfahrung',$w['industries']]] as $g) {
        $parts[]='<div class="pw-anon-cv-block"><h3>'.esc_html($g[0]).'</h3><div class="pw-chip-list">'.implode('',array_map(function($x){return '<span>'.esc_html($x).'</span>';},$g[1])).'</div></div>';
    }
    $parts[]='<div class="pw-anon-note">'.pw_icon('lock').'<div><b>Persönliche Daten geschützt</b><p>Name, Geburtsdatum, E-Mail, Telefon und genaue Anschrift sind in diesem Profil nicht enthalten.</p></div></div>';
    return implode('', $parts);
}
