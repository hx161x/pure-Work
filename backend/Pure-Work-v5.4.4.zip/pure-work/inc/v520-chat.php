<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.2.0 – Live-Chat neu gebaut.
 *
 * Der Chat aus 5.1.2 konnte senden und pollen, aber:
 *   - Server und Browser haben doppelt escaped: aus "Müller's" wurde
 *     "Müller&#039;s", weil die AJAX-Antwort esc_html() lieferte und das
 *     Skript den Wert danach per textContent gesetzt hat.
 *   - Zeilenumbrüche gingen bei jeder neu eintreffenden Nachricht verloren.
 *   - Der Sendeweg prüfte nicht, ob der Chat überhaupt offen ist. Nach einer
 *     Ablehnung ließ sich per Direktaufruf weiter schreiben.
 *   - Keine Lesebestätigung, kein Tippen-Hinweis, keine Zustellanzeige.
 *   - Feste 3-Sekunden-Abfrage, auch nach Stunden ohne Aktivität.
 *
 * Neu ist zusätzlich das, was in der Zeitarbeit den Abschluss bringt:
 * verbindliche Angebote im Chat, Anhänge und Textbausteine.
 */

/* ==========================================================================
 * Grundlagen
 * ======================================================================= */
function pw_v520_chat_can($sid, $uid = 0) {
    if (!$uid) $uid = get_current_user_id();
    return $sid && pw_can_access_submission($sid, $uid) && pw_submission_chat_open($sid);
}

function pw_v520_offer($mid) {
    $raw = get_post_meta($mid, 'pw_offer', true);
    if (!$raw) return null;
    $data = is_array($raw) ? $raw : json_decode((string)$raw, true);
    return is_array($data) ? $data : null;
}

function pw_v520_attachment($mid) {
    $aid = (int)get_post_meta($mid, 'pw_attachment_id', true);
    if (!$aid) return null;
    $url = wp_get_attachment_url($aid);
    if (!$url) return null;
    $path = get_attached_file($aid);
    return [
        'id'   => $aid,
        'url'  => $url,
        'name' => get_the_title($aid) ?: basename((string)$url),
        'size' => $path && file_exists($path) ? size_format(filesize($path)) : '',
        'type' => (string)get_post_mime_type($aid),
    ];
}

/**
 * Rohtext, nicht escaped: der Browser setzt den Wert per textContent, das ist
 * die sichere Variante. Zusätzliches esc_html() würde nur sichtbaren Zeichenmüll
 * erzeugen.
 */
function pw_v520_message_payload($m, $uid) {
    $mine = (int)$m->post_author === $uid;
    return [
        'id'         => (int)$m->ID,
        'mine'       => $mine,
        'message'    => (string)$m->post_content,
        'time'       => wp_date('d.m. · H:i', get_post_time('U', true, $m)),
        'read'       => get_post_meta($m->ID, 'pw_read', true) === '1',
        'system'     => get_post_meta($m->ID, 'pw_system', true) === '1',
        'offer'      => pw_v520_offer($m->ID),
        'attachment' => pw_v520_attachment($m->ID),
        'business_card' => function_exists('pw_v543_card_from_message') ? pw_v543_card_from_message($m->ID, $uid) : null,
        'author'     => pw_v520_speaker_label((int)$m->post_author, $uid, (int)get_post_meta($m->ID, 'pw_submission_id', true)),
    ];
}

function pw_v520_speaker_label($author, $uid, $sid) {
    if ($author === $uid) return pw_t('Du', 'You');
    [$agency, $client] = pw_submission_parties($sid);
    $vid = (int)pw_meta($sid, 'pw_vacancy_id', 0);
    if ($author === $client) return pw_user_role($uid) === 'agency' ? pw_vacancy_client_label($vid, $uid) : pw_t('Auftraggeber', 'Client');
    return function_exists('pw_company_alias') ? pw_company_alias($agency) : pw_t('Zeitarbeitsfirma', 'Agency');
}

function pw_v520_counterpart($sid, $uid) {
    [$agency, $client] = pw_submission_parties($sid);
    return $uid === $agency ? $client : $agency;
}

/* ==========================================================================
 * Nachricht speichern
 * ======================================================================= */
function pw_v520_store_message($sid, $uid, $text, $meta = []) {
    $recipient = pw_v520_counterpart($sid, $uid);
    if (!$recipient) return new WP_Error('pw_no_recipient', pw_t('Empfänger fehlt.', 'Recipient missing.'));

    $id = wp_insert_post([
        'post_type'    => 'pw_message',
        'post_status'  => 'publish',
        'post_author'  => $uid,
        'post_title'   => 'Nachricht #' . $sid,
        'post_content' => $text,
    ]);
    if (is_wp_error($id)) return $id;

    update_post_meta($id, 'pw_submission_id', $sid);
    update_post_meta($id, 'pw_recipient', $recipient);
    update_post_meta($id, 'pw_read', '0');
    foreach ($meta as $k => $v) update_post_meta($id, $k, $v);

    // Der Thread soll in der Seitenleiste nach oben rutschen.
    wp_update_post(['ID' => $sid, 'post_modified' => current_time('mysql'), 'post_modified_gmt' => current_time('mysql', 1)]);

    $vid = (int)pw_meta($sid, 'pw_vacancy_id', 0);
    pw_create_notice($recipient, pw_t('Neue Nachricht', 'New message'), sprintf(pw_t('Neue Nachricht zu „%s“.', 'New message about “%s”.'), get_the_title($vid)), pw_page_url('messages', ['thread' => $sid]));

    // E-Mail nur, wenn der Empfänger gerade nicht im Chat sitzt – sonst
    // bekommt er bei einer lebhaften Unterhaltung zwanzig Mails.
    $recently_active = (int)get_transient('pw_v520_active_' . $sid . '_' . $recipient) === 1;
    $u = get_userdata($recipient);
    if ($u && !$recently_active && pw_user_meta($recipient, 'pw_message_email', '1') !== '0') {
        pw_send_mail($u->user_email, pw_t('Neue Nachricht bei Pure Work', 'New message on Pure Work'),
            pw_t('Du hast eine neue Nachricht', 'You have a new message'),
            wp_trim_words($text, 35, '…'), pw_t('Nachricht öffnen', 'Open message'),
            pw_page_url('messages', ['thread' => $sid]));
    }
    return (int)$id;
}

function pw_ajax_v520_send() {
    pw_ajax_guard();
    $uid  = get_current_user_id();
    $sid  = (int)($_POST['submission_id'] ?? 0);
    $text = trim((string)wp_unslash($_POST['message'] ?? ''));

    if (!pw_v520_chat_can($sid, $uid)) wp_send_json_error(['message' => pw_t('Dieser Chat ist nicht geöffnet.', 'This chat is not open.')], 403);

    // Flut-Schutz: 20 Nachrichten pro Minute je Nutzer reichen für jedes Gespräch.
    $bucket = 'pw_v520_rate_' . $uid;
    $count  = (int)get_transient($bucket);
    if ($count >= 20) wp_send_json_error(['message' => pw_t('Kurz durchatmen – zu viele Nachrichten in kurzer Zeit.', 'Slow down – too many messages in a short time.')], 429);
    set_transient($bucket, $count + 1, MINUTE_IN_SECONDS);

    $meta = [];
    $attachment_id = 0;
    if (!empty($_FILES['attachment']['tmp_name'])) {
        if (function_exists('pw_can') && pw_user_role($uid) === 'agency' && !pw_can('chat_attachments', $uid)) {
            wp_send_json_error(['message' => pw_t('Dateien im Chat gibt es ab dem Tarif Pro.', 'Files in chat are available from the Pro plan.')], 403);
        }
        $attachment_id = pw_v520_handle_upload($sid);
        if (is_wp_error($attachment_id)) wp_send_json_error(['message' => $attachment_id->get_error_message()], 400);
        $meta['pw_attachment_id'] = $attachment_id;
        if ($text === '') $text = pw_t('Datei gesendet', 'File sent');
    }

    if ($text === '') wp_send_json_error(['message' => pw_t('Bitte etwas schreiben.', 'Please write something.')], 400);
    if (mb_strlen($text) > 4000) $text = mb_substr($text, 0, 4000);
    $text = sanitize_textarea_field($text);

    $id = pw_v520_store_message($sid, $uid, $text, $meta);
    if (is_wp_error($id)) wp_send_json_error(['message' => $id->get_error_message()], 500);

    delete_transient('pw_v520_typing_' . $sid . '_' . $uid);
    $m = get_post($id);
    wp_send_json_success(['item' => pw_v520_message_payload($m, $uid)]);
}
add_action('wp_ajax_pw_v520_send', 'pw_ajax_v520_send');

/**
 * Anhänge: bewusst nur die Formate, die im Tagesgeschäft wirklich vorkommen –
 * Nachweis als PDF, Foto vom Schein, Stundenzettel.
 */
function pw_v520_handle_upload($sid) {
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $allowed = ['pdf' => 'application/pdf', 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png',
                'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    $file = $_FILES['attachment'];
    if ((int)$file['size'] > 5 * MB_IN_BYTES) return new WP_Error('pw_too_big', pw_t('Maximal 5 MB pro Datei.', 'Maximum 5 MB per file.'));

    $check = wp_check_filetype_and_ext($file['tmp_name'], $file['name'], $allowed);
    if (empty($check['ext'])) return new WP_Error('pw_bad_type', pw_t('Erlaubt sind PDF, JPG, PNG und Word-Dateien.', 'Allowed: PDF, JPG, PNG and Word files.'));

    $id = media_handle_upload('attachment', 0, [], ['test_form' => false, 'mimes' => $allowed]);
    if (is_wp_error($id)) return $id;
    update_post_meta($id, 'pw_chat_submission', (int)$sid);
    return (int)$id;
}

/* ==========================================================================
 * Aktualisierungen abholen
 * ======================================================================= */
function pw_ajax_v520_updates() {
    pw_ajax_guard();
    $uid  = get_current_user_id();
    $sid  = (int)($_POST['submission_id'] ?? 0);
    $last = (int)($_POST['last_id'] ?? 0);
    if (!pw_v520_chat_can($sid, $uid)) wp_send_json_error(['message' => pw_t('Chat nicht verfügbar.', 'Chat unavailable.')], 403);

    // Merken, dass dieser Nutzer gerade im Chat ist – unterdrückt Mail-Spam.
    set_transient('pw_v520_active_' . $sid . '_' . $uid, 1, 90);

    $posts = get_posts([
        'post_type' => 'pw_message', 'post_status' => 'publish', 'posts_per_page' => 100,
        'orderby' => 'ID', 'order' => 'ASC',
        'meta_query' => [['key' => 'pw_submission_id', 'value' => $sid]],
    ]);

    $items = []; $max = $last; $read_ids = [];
    foreach ($posts as $m) {
        $mid  = (int)$m->ID;
        $mine = (int)$m->post_author === $uid;

        if (!$mine && (int)pw_meta($mid, 'pw_recipient', 0) === $uid && get_post_meta($mid, 'pw_read', true) !== '1') {
            update_post_meta($mid, 'pw_read', '1');
            update_post_meta($mid, 'pw_read_at', time());
        }
        // Lesebestätigung: eigene Nachrichten, die die Gegenseite inzwischen gelesen hat.
        if ($mine && $mid <= $last && get_post_meta($mid, 'pw_read', true) === '1') $read_ids[] = $mid;

        if ($mid > $last) { $items[] = pw_v520_message_payload($m, $uid); $max = max($max, $mid); }
    }

    $other  = pw_v520_counterpart($sid, $uid);
    $typing = $other && (int)get_transient('pw_v520_typing_' . $sid . '_' . $other) === 1;

    wp_send_json_success([
        'items'    => $items,
        'read_ids' => $read_ids,
        'typing'   => $typing,
        'last_id'  => $max,
        'unread'   => pw_unread_message_count($uid),
        'status'   => pw_meta($sid, 'pw_status', 'accepted'),
    ]);
}
add_action('wp_ajax_pw_v520_updates', 'pw_ajax_v520_updates');

function pw_ajax_v520_typing() {
    pw_ajax_guard();
    $sid = (int)($_POST['submission_id'] ?? 0);
    $uid = get_current_user_id();
    if (!pw_v520_chat_can($sid, $uid)) wp_send_json_error(['message' => 'no'], 403);
    set_transient('pw_v520_typing_' . $sid . '_' . $uid, 1, 8);
    wp_send_json_success(['ok' => true]);
}
add_action('wp_ajax_pw_v520_typing', 'pw_ajax_v520_typing');

/* ==========================================================================
 * Verbindliche Angebote im Chat
 * ======================================================================= */
function pw_v520_offer_summary($offer) {
    $parts = [];
    if (!empty($offer['rate']))  $parts[] = pw_t('Verrechnungssatz', 'Charge rate') . ': ' . $offer['rate'] . ' €/h';
    if (!empty($offer['start'])) $parts[] = pw_t('Start', 'Start') . ': ' . pw_format_date($offer['start']);
    if (!empty($offer['shift'])) $parts[] = pw_t('Schicht', 'Shift') . ': ' . $offer['shift'];
    if (!empty($offer['hours'])) $parts[] = pw_t('Wochenstunden', 'Weekly hours') . ': ' . $offer['hours'];
    return implode(' · ', $parts);
}

function pw_ajax_v520_offer_send() {
    pw_ajax_guard();
    $uid = get_current_user_id();
    $sid = (int)($_POST['submission_id'] ?? 0);
    if (!pw_v520_chat_can($sid, $uid)) wp_send_json_error(['message' => pw_t('Chat nicht verfügbar.', 'Chat unavailable.')], 403);
    if (pw_user_role($uid) !== 'agency') wp_send_json_error(['message' => pw_t('Angebote stellt die Zeitarbeitsfirma.', 'Offers are made by the agency.')], 403);
    if (function_exists('pw_can') && !pw_can('chat_offers', $uid)) wp_send_json_error(['message' => pw_t('Verbindliche Angebote gibt es ab dem Tarif Pro.', 'Binding offers are available from the Pro plan.')], 403);

    $offer = [
        'rate'   => str_replace(',', '.', sanitize_text_field(wp_unslash($_POST['rate'] ?? ''))),
        'start'  => sanitize_text_field(wp_unslash($_POST['start'] ?? '')),
        'shift'  => sanitize_text_field(wp_unslash($_POST['shift'] ?? '')),
        'hours'  => sanitize_text_field(wp_unslash($_POST['hours'] ?? '')),
        'note'   => sanitize_textarea_field(wp_unslash($_POST['note'] ?? '')),
        'status' => 'open',
        'by'     => $uid,
    ];
    if ($offer['rate'] === '' || !is_numeric($offer['rate'])) wp_send_json_error(['message' => pw_t('Bitte einen Verrechnungssatz angeben.', 'Please enter a charge rate.')], 400);

    $text = pw_t('Angebot', 'Offer') . ': ' . pw_v520_offer_summary($offer) . ($offer['note'] ? "\n" . $offer['note'] : '');
    $id = pw_v520_store_message($sid, $uid, $text, ['pw_offer' => wp_json_encode($offer)]);
    if (is_wp_error($id)) wp_send_json_error(['message' => $id->get_error_message()], 500);

    wp_send_json_success(['item' => pw_v520_message_payload(get_post($id), $uid)]);
}
add_action('wp_ajax_pw_v520_offer_send', 'pw_ajax_v520_offer_send');

function pw_ajax_v520_offer_decide() {
    pw_ajax_guard();
    $uid = get_current_user_id();
    $sid = (int)($_POST['submission_id'] ?? 0);
    $mid = (int)($_POST['message_id'] ?? 0);
    $decision = sanitize_key(wp_unslash($_POST['decision'] ?? ''));
    if (!pw_v520_chat_can($sid, $uid)) wp_send_json_error(['message' => pw_t('Chat nicht verfügbar.', 'Chat unavailable.')], 403);
    if (pw_user_role($uid) !== 'client') wp_send_json_error(['message' => pw_t('Nur der Auftraggeber entscheidet über ein Angebot.', 'Only the client decides on an offer.')], 403);
    if (!in_array($decision, ['accepted', 'declined'], true)) wp_send_json_error(['message' => 'ungültig'], 400);

    $offer = pw_v520_offer($mid);
    if (!$offer) wp_send_json_error(['message' => pw_t('Angebot nicht gefunden.', 'Offer not found.')], 404);
    if (($offer['status'] ?? 'open') !== 'open') wp_send_json_error(['message' => pw_t('Dieses Angebot wurde bereits entschieden.', 'This offer has already been decided.')], 409);

    $offer['status'] = $decision;
    $offer['decided_at'] = time();
    update_post_meta($mid, 'pw_offer', wp_json_encode($offer));

    if ($decision === 'accepted') {
        update_post_meta($sid, 'pw_agreed_rate', $offer['rate']);
        if (!empty($offer['start'])) update_post_meta($sid, 'pw_agreed_start', $offer['start']);
        if (!empty($offer['shift'])) update_post_meta($sid, 'pw_agreed_shift', $offer['shift']);
        update_post_meta($sid, 'pw_agreed_at', time());
    }

    $text = $decision === 'accepted'
        ? pw_t('Angebot angenommen', 'Offer accepted') . ': ' . pw_v520_offer_summary($offer)
        : pw_t('Angebot abgelehnt', 'Offer declined') . ': ' . pw_v520_offer_summary($offer);
    $sys = pw_v520_store_message($sid, $uid, $text, ['pw_system' => '1']);

    wp_send_json_success([
        'status' => $decision,
        'item'   => is_wp_error($sys) ? null : pw_v520_message_payload(get_post($sys), $uid),
    ]);
}
add_action('wp_ajax_pw_v520_offer_decide', 'pw_ajax_v520_offer_decide');

/* ==========================================================================
 * Textbausteine
 * ======================================================================= */
function pw_v520_default_canned() {
    return [
        pw_t('Der Mitarbeiter kann ab Montag starten. Passt das für euch?', 'The employee can start on Monday. Does that work for you?'),
        pw_t('Wie sehen die Schichtzeiten und die Einsatzdauer konkret aus?', 'What exactly are the shift times and the assignment duration?'),
        pw_t('Ich schicke dir gleich ein verbindliches Angebot mit Verrechnungssatz.', 'I will send you a binding offer with the charge rate shortly.'),
        pw_t('Welche Schutzausrüstung wird gestellt, was muss der Mitarbeiter mitbringen?', 'Which protective equipment is provided, what does the employee need to bring?'),
        pw_t('Danke für die Rückmeldung – ich melde mich bis morgen früh.', 'Thanks for getting back to me – I will reply by tomorrow morning.'),
    ];
}

function pw_v520_canned($uid = 0) {
    if (!$uid) $uid = get_current_user_id();
    $own = get_user_meta($uid, 'pw_canned_replies', true);
    if (is_array($own) && $own) return $own;
    return pw_v520_default_canned();
}

function pw_handle_v520_canned_save() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    pw_require_post_nonce('pw_v520_canned_save');
    $uid = get_current_user_id();
    $raw = (string)wp_unslash($_POST['canned'] ?? '');
    $lines = array_values(array_filter(array_map(function ($l) { return sanitize_text_field(trim($l)); }, explode("\n", $raw))));
    update_user_meta($uid, 'pw_canned_replies', array_slice($lines, 0, 12));
    pw_form_redirect('messages', ['thread' => (int)($_POST['submission_id'] ?? 0), 'canned' => 1]);
}
add_action('admin_post_pw_v520_canned_save', 'pw_handle_v520_canned_save');
