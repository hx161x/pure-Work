<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9.9 – Work OS polish.
 * Clear plan tools in the sidebar, a guided workflow dashboard, assignment
 * control and Pro billing tools. No external service is required.
 */

/* -------------------------------------------------------------------------
 * Sidebar: current plan + useful shortcuts
 * ---------------------------------------------------------------------- */
function pw_v499_sidebar_plan_panel($uid=0) {
    if (!$uid) $uid=get_current_user_id();
    if (!$uid || pw_user_role($uid)!=='agency') return '';
    $plan=pw_current_plan($uid);
    $tools=[
        ['assist_ai','spark','Pure Assist','#assist'],
        ['automations','spark',pw_t('Automationen','Automations'),pw_page_url('automations')],
        ['invoicing','receipt',pw_t('Abrechnung','Billing'),pw_page_url('invoices')],
        ['leads_targets','target',pw_t('Zielkunden','Target accounts'),pw_page_url('market_live',['tab'=>'targets'])],
    ];
    ob_start(); ?>
    <section class="pw-v499-side-plan">
      <a class="pw-v499-side-plan-head" href="<?php echo esc_url(pw_page_url('account',['tab'=>'billing'])); ?>">
        <span><small><?php echo esc_html(pw_t('MEIN TARIF','MY PLAN')); ?></small><b><?php echo esc_html(pw_plan_public_label($plan)); ?></b></span>
        <?php echo pw_icon('arrow'); ?>
      </a>
      <div class="pw-v499-side-tools">
        <?php foreach($tools as $t): $open=pw_can($t[0],$uid); $needed=pw_plan_required_for($t[0]); ?>
          <?php if($t[0]==='assist_ai'): ?>
            <button type="button" class="<?php echo $open?'is-open':'is-help'; ?>" data-pw-copilot-open title="<?php echo esc_attr($open?'Pure Assist':pw_t('Seitenhilfe öffnen','Open page help')); ?>">
              <span><?php echo pw_icon('spark'); ?></span><b><?php echo esc_html($t[2]); ?></b><small><?php echo $open?esc_html(pw_t('Datenhilfe','Data help')):esc_html(pw_t('Hilfe','Help')); ?></small>
            </button>
          <?php else: ?>
            <a class="<?php echo $open?'is-open':'is-locked'; ?>" href="<?php echo esc_url($open?$t[3]:pw_page_url('account',['tab'=>'billing'])); ?>" title="<?php echo esc_attr($t[2]); ?>">
              <span><?php echo pw_icon($open?$t[1]:'lock'); ?></span><b><?php echo esc_html($t[2]); ?></b><small><?php echo $open?esc_html(pw_t('Öffnen','Open')):esc_html(pw_t('ab ','from ').pw_plan_public_label($needed)); ?></small>
            </a>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Dashboard helpers
 * ---------------------------------------------------------------------- */
function pw_v499_invoice_count($uid) {
    return (int)pw_v498_count_posts(['post_type'=>'pw_invoice','post_status'=>'publish','author'=>$uid]);
}

function pw_v499_active_assignments($uid) {
    $ids=get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[
        'relation'=>'AND',
        ['key'=>'pw_agency_id','value'=>$uid],
        ['key'=>'pw_status','value'=>['accepted','identity_released','confirmed','planned','requested'],'compare'=>'IN'],
    ]]);
    return array_map('intval',$ids);
}

function pw_v499_assignment_risks($uid,$days=7) {
    $out=[]; $cut=strtotime('+'.max(1,(int)$days).' days 23:59:59');
    foreach(pw_v499_active_assignments($uid) as $sid){
        $status=pw_meta($sid,'pw_status','submitted');
        if(in_array($status,['confirmed','planned'],true)) continue;
        $vid=(int)pw_meta($sid,'pw_vacancy_id',0); if(!$vid) continue;
        $v=pw_vacancy_fields($vid); $start=$v['start_date']??''; $ts=$start?strtotime($start.' 12:00:00'):0;
        if($ts && $ts<= $cut && $ts>=strtotime('-1 day')) $out[]=['submission'=>$sid,'vacancy'=>$v,'status'=>$status,'start'=>$start];
    }
    usort($out,function($a,$b){return strcmp($a['start'],$b['start']);});
    return $out;
}

function pw_v499_flow_strip($uid) {
    $s=pw_v498_agency_snapshot($uid);
    $assignments=count(pw_v499_active_assignments($uid));
    $invoices=pw_can('invoicing',$uid)?pw_v499_invoice_count($uid):0;
    $stages=[
        ['01','briefcase',pw_t('Bedarf','Demand'),$s['open_jobs'],pw_page_url('vacancies')],
        ['02','spark',pw_t('Match','Match'),count($s['matches']),pw_page_url('matches')],
        ['03','check',pw_t('Einreichung','Submission'),$s['submissions'],pw_page_url('vacancies')],
        ['04','calendar',pw_t('Einsatz','Assignment'),$assignments,pw_page_url('assignments')],
        ['05','receipt',pw_t('Abrechnung','Billing'),$invoices,pw_can('invoicing',$uid)?pw_page_url('invoices'):pw_page_url('account',['tab'=>'billing'])],
    ];
    ob_start(); ?>
    <section class="pw-card pw-v499-flow">
      <div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE ABLAUF','PURE FLOW')); ?></span><h2><?php echo esc_html(pw_t('Vom Bedarf bis zur Rechnung','From demand to invoice')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Der komplette Prozess in einer Linie. Du siehst sofort, wo Arbeit liegen bleibt.','The entire process in one line. See immediately where work is waiting.')); ?></p></div><span class="pw-v499-flow-live"><i></i><?php echo esc_html(pw_t('live','live')); ?></span></div>
      <div class="pw-v499-flow-track">
        <?php foreach($stages as $idx=>$stage): ?>
          <a href="<?php echo esc_url($stage[5]); ?>"><small><?php echo esc_html($stage[0]); ?></small><span><?php echo pw_icon($stage[1]); ?></span><div><b><?php echo esc_html($stage[2]); ?></b><strong><?php echo (int)$stage[3]; ?></strong></div><?php if($idx<count($stages)-1): ?><i class="pw-v499-flow-arrow">→</i><?php endif; ?></a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

function pw_v499_quick_tools($uid) {
    $tools=[
        ['handshake',pw_t('Meine Kunden','My customers'),pw_t('Kontakte, Bedarfe und Wiedervorlagen','Contacts, demand and follow-ups'),pw_page_url('crm'),'crm'],
        ['calendar',pw_t('Einsätze steuern','Control assignments'),pw_t('Bestätigte Besetzungen bis zum Start','Confirmed placements through start'),pw_page_url('assignments'),'assignments'],
        ['calculator',pw_t('Satz kalkulieren','Calculate rate'),pw_t('Kosten, Marge und Verrechnungssatz','Cost, margin and bill rate'),pw_page_url('invoices').'#calculator','rate_calculator'],
        ['spark',pw_t('Automatisieren','Automate'),pw_t('Wächter und Digests ein-/ausschalten','Enable or disable watchdogs and digests'),pw_page_url('automations'),'automations'],
    ];
    ob_start(); ?>
    <section class="pw-v499-tool-section"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('SCHNELL ERLEDIGEN','QUICK TOOLS')); ?></span><h2><?php echo esc_html(pw_t('Vier Wege statt zehn Klicks','Four paths instead of ten clicks')); ?></h2></div></div><div class="pw-v499-tool-grid">
      <?php foreach($tools as $t):$open=pw_can($t[4],$uid); ?><a class="<?php echo $open?'':'is-locked'; ?>" href="<?php echo esc_url($open?$t[3]:pw_page_url('account',['tab'=>'billing'])); ?>"><span><?php echo pw_icon($open?$t[0]:'lock'); ?></span><div><b><?php echo esc_html($t[1]); ?></b><small><?php echo esc_html($t[2]); ?></small></div><em><?php echo $open?pw_icon('arrow'):esc_html(pw_t('ab ','from ').pw_plan_public_label(pw_plan_required_for($t[4]))); ?></em></a><?php endforeach; ?>
    </div></section>
    <?php return ob_get_clean();
}

function pw_v499_risk_card($uid) {
    if(!pw_can('risk_watch',$uid)) return '';
    $risks=pw_v499_assignment_risks($uid,7);
    if(!$risks) return '<section class="pw-v499-risk-ok">'.pw_icon('check').'<div><b>'.esc_html(pw_t('Besetzungsampel: grün','Placement light: green')).'</b><small>'.esc_html(pw_t('Keine kritischen Starts in den nächsten 7 Tagen.','No critical starts in the next 7 days.')).'</small></div></section>';
    $r=$risks[0];
    return '<a class="pw-v499-risk-alert" href="'.esc_url(pw_page_url('assignments')).'">'.pw_icon('alert').'<div><b>'.esc_html(sprintf(pw_t('%d Start-Risiko(s) erkannt','%d start risk(s) detected'),count($risks))).'</b><small>'.esc_html(sprintf(pw_t('Nächster kritischer Start: %s · %s','Next critical start: %s · %s'),pw_format_date($r['start']),$r['vacancy']['title'])).'</small></div>'.pw_icon('arrow').'</a>';
}

function pw_shortcode_dashboard_v499() {
    if (!is_user_logged_in()) return pw_require_login_html();
    $uid=get_current_user_id(); $role=pw_user_role(); $user=wp_get_current_user();
    $name=pw_user_meta($uid,'pw_contact',$user->display_name); $company=pw_user_meta($uid,'pw_company','');
    $subtitle=$role==='agency'?pw_t('Dein Arbeitstag – priorisiert, verbunden und ohne Sucherei.','Your workday – prioritised, connected and without searching.'):pw_t('Personalbedarf und Profile in einem klaren Arbeitsfluss.','Staffing demand and profiles in one clear workflow.');
    ob_start(); echo pw_portal_shell_start(pw_t('Start','Home'),$subtitle); echo pw_flash_messages();
    if(isset($_GET['panel'])&&$_GET['panel']==='notifications'){echo pw_dashboard_notifications_panel();echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['panel'])&&$_GET['panel']==='insights'&&$role==='agency'){echo pw_can('advanced_insights',$uid)?(function_exists('pw_v501_scale_insights')?pw_v501_scale_insights($uid):pw_v498_scale_insights($uid)):pw_plan_gate('advanced_insights');echo pw_portal_shell_end();return ob_get_clean();}
    $verify=pw_verification_state($uid);
    if(!$verify['ready']) echo '<div class="pw-onboarding-banner compact"><div>'.pw_icon('lock').'<div><span class="pw-kicker">'.esc_html(pw_t('VERIFIZIERUNG','VERIFICATION')).'</span><h3>'.esc_html(pw_t('Noch nicht vollständig freigeschaltet','Not fully unlocked yet')).'</h3><p>'.esc_html(pw_t('Prüfe E-Mail, Unternehmen und AÜG-Status.','Check e-mail, company and AÜG status.')).'</p></div></div><a class="pw-btn white small" href="'.esc_url(pw_page_url('account',['tab'=>'verification'])).'">'.esc_html(pw_t('Status','Status')).'</a></div>';

    if($role==='agency'){
        $s=pw_v498_agency_snapshot($uid);$plan=pw_current_plan($uid);
        echo '<section class="pw-v499-hero"><div><div class="pw-v499-hero-line"><span class="pw-kicker">'.esc_html(pw_t('DEIN PURE WORK','YOUR PURE WORK')).'</span><span class="pw-v499-plan-pill">'.esc_html(pw_plan_public_label($plan)).'</span></div><h1>'.esc_html(pw_dashboard_greeting()).', '.esc_html($name).'.</h1><p>'.esc_html(pw_t('Heute zählt nur, was einen Kunden, einen Mitarbeiter oder einen Einsatz voranbringt.','Today only what moves a customer, employee or assignment forward matters.')).'</p></div><div class="pw-v499-hero-actions"><a class="pw-btn primary" href="'.esc_url(pw_page_url('workers',['new'=>1])).'">'.pw_icon('plus').' '.esc_html(pw_t('Mitarbeiter anlegen','Add employee')).'</a><button type="button" class="pw-btn ghost" data-pw-copilot-open>'.pw_icon('spark').' Pure Assist</button></div></section>';
        echo '<div class="pw-v499-kpi-row">'.pw_metric($s['requested'],pw_t('Anfragen brauchen Reaktion','requests need action'),pw_t('heute priorisieren','prioritise today'),$s['requested']?'warning':'').pw_metric($s['crm']['due'],pw_t('Kunden sind fällig','customers are due'),pw_t('Wiedervorlagen','follow-ups'),$s['crm']['due']?'warning':'').pw_metric($s['available'],pw_t('Mitarbeiter verfügbar','employees available'),$s['workers'].' '.pw_t('Profile gesamt','profiles total'),'brand').pw_metric($s['messages'],pw_t('Nachrichten offen','messages open'),pw_t('Kommunikation','communication'),$s['messages']?'warning':'').'</div>';
        echo pw_v499_risk_card($uid);
        echo '<div class="pw-v499-home-grid">'.pw_v498_action_center($uid,$role).pw_v498_copilot_card($uid).'</div>';
        echo pw_v499_flow_strip($uid);
        echo pw_v499_quick_tools($uid);
        echo pw_v498_compact_jobs($uid,4);
        if(pw_can('advanced_insights',$uid)) echo function_exists('pw_v501_scale_insights')?pw_v501_scale_insights($uid):pw_v498_scale_insights($uid);
    } else {
        $s=pw_v498_client_snapshot($uid);
        echo '<section class="pw-v499-hero"><div><span class="pw-kicker">'.esc_html(pw_t('PERSONALSTEUERUNG','WORKFORCE CONTROL')).'</span><h1>'.esc_html($company?:$name).'</h1><p>'.esc_html(pw_t('Bedarf, Profile und Abstimmungen in einer klaren Reihenfolge.','Demand, profiles and coordination in a clear sequence.')).'</p></div><div class="pw-v499-hero-actions"><a class="pw-btn primary" href="'.esc_url(pw_page_url('vacancies',['new'=>1])).'">'.pw_icon('plus').' '.esc_html(pw_t('Auftrag anlegen','Create job')).'</a></div></section>';
        echo '<div class="pw-v499-kpi-row">'.pw_metric($s['open'],pw_t('offene Aufträge','open jobs'),$s['jobs'].' '.pw_t('gesamt','total'),'brand').pw_metric($s['new'],pw_t('neue Profile','new profiles'),pw_t('Entscheidung offen','decision open'),$s['new']?'warning':'').pw_metric($s['accepted'],pw_t('bestätigte Besetzungen','confirmed placements'),pw_t('laufend / geplant','active / planned'),'success').pw_metric($s['messages'],pw_t('Nachrichten offen','messages open'),pw_t('Abstimmungen','coordination'),$s['messages']?'warning':'').'</div>';
        echo '<div class="pw-v499-home-grid">'.pw_v498_action_center($uid,$role).pw_v498_client_help_card().'</div>'.pw_v498_client_jobs($uid,5);
    }
    echo pw_portal_shell_end();return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Assignment board
 * ---------------------------------------------------------------------- */
function pw_v499_submission_bucket($status){
    if(in_array($status,['confirmed','planned'],true)) return 'planned';
    if(in_array($status,['accepted','identity_released'],true)) return 'confirmed';
    return 'clarify';
}

function pw_shortcode_assignments() {
    if(!is_user_logged_in()) return pw_require_login_html();
    $uid=get_current_user_id();$role=pw_user_role($uid);
    ob_start();echo pw_portal_shell_start(pw_t('Einsatzboard','Assignment board'),pw_t('Vom bestätigten Profil bis zum Einsatz – ohne Excel-Nebenliste.','From confirmed profile to assignment – without a parallel spreadsheet.'));echo pw_flash_messages();
    if($role==='agency'){
        $ids=pw_v499_active_assignments($uid);
    } else {
        $ids=[];$subs=pw_client_submissions($uid);foreach($subs as $s){$st=pw_meta($s->ID,'pw_status','submitted');if(in_array($st,['requested','accepted','identity_released','confirmed','planned'],true))$ids[]=$s->ID;}
    }
    $buckets=['clarify'=>[],'confirmed'=>[],'planned'=>[]];
    foreach($ids as $sid){$st=pw_meta($sid,'pw_status','submitted');$buckets[pw_v499_submission_bucket($st)][]=$sid;}
    ?>
    <section class="pw-v499-board-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE EINSÄTZE','PURE ASSIGNMENTS')); ?></span><h1><?php echo esc_html(pw_t('Besetzungen im Fluss halten','Keep placements moving')); ?></h1><p><?php echo esc_html(pw_t('Jede bestätigte Verbindung bekommt einen klaren nächsten Schritt.','Every confirmed connection gets a clear next step.')); ?></p></div><?php if($role==='agency'&&pw_can('invoicing',$uid)):?><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('invoices')); ?>"><?php echo pw_icon('receipt'); ?> <?php echo esc_html(pw_t('Abrechnung','Billing')); ?></a><?php endif;?></section>
    <div class="pw-v499-board-grid">
      <?php $labels=['clarify'=>[pw_t('In Klärung','Clarifying'),'warning'], 'confirmed'=>[pw_t('Bestätigt','Confirmed'),'success'], 'planned'=>[pw_t('Einsatz geplant','Assignment planned'),'brand']]; foreach($buckets as $key=>$list):?>
      <section class="pw-v499-board-col"><header><span><?php echo esc_html($labels[$key][0]); ?></span><b><?php echo count($list); ?></b></header><div>
        <?php if(!$list):?><div class="pw-v499-board-empty"><?php echo pw_icon('check'); ?><span><?php echo esc_html(pw_t('Nichts offen','Nothing open')); ?></span></div><?php else:foreach($list as $sid):$wid=(int)pw_meta($sid,'pw_worker_id',0);$vid=(int)pw_meta($sid,'pw_vacancy_id',0);$w=pw_worker_fields($wid);$v=pw_vacancy_fields($vid);$st=pw_meta($sid,'pw_status','submitted');$client=$role==='agency'?pw_vacancy_client_label($vid,$uid):pw_company_display_name((int)pw_meta($sid,'pw_agency_id',0),$uid,false);$risk=false;if($role==='agency'&&$v['start_date']&&!in_array($st,['confirmed','planned'],true)){$ts=strtotime($v['start_date']);$risk=$ts&&$ts<=strtotime('+7 days');}?>
          <article class="pw-v499-assignment-card <?php echo $risk?'is-risk':'';?>"><div class="pw-v499-assignment-top"><span class="pw-profile-code small"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><b><?php echo esc_html($w['role']); ?></b><small><?php echo esc_html($w['code'].' · '.$client); ?></small></div><?php if($risk):?><span class="pw-v499-risk-chip"><?php echo pw_icon('alert'); ?> <?php echo esc_html(pw_t('Start nah','Start soon')); ?></span><?php endif;?></div><p><?php echo esc_html($v['title']); ?></p><div class="pw-v499-assignment-facts"><span><?php echo pw_icon('calendar'); ?> <?php echo esc_html(pw_format_date($v['start_date'])); ?></span><span><?php echo esc_html(pw_meta($sid,'pw_rate','–')?:'–'); ?></span></div><div class="pw-v499-assignment-actions"><a href="<?php echo esc_url(pw_page_url('messages',['thread'=>$sid])); ?>"><?php echo pw_icon('message'); ?> <?php echo esc_html(pw_t('Chat','Chat')); ?></a><?php if(function_exists('pw_v503_handover_text') && pw_can('handover_briefing',$uid)): $brief=pw_v503_handover_text($sid,$uid); ?><button type="button" data-pw-copy-report data-report="<?php echo esc_attr($brief); ?>"><?php echo pw_icon('document'); ?> <?php echo esc_html(pw_t('Einsatzbriefing','Assignment brief')); ?></button><?php endif; ?><?php if($role==='agency'&&pw_can('invoicing',$uid)):?><a href="<?php echo esc_url(pw_page_url('invoices',['new'=>1,'submission'=>$sid])); ?>"><?php echo pw_icon('receipt'); ?> <?php echo esc_html(pw_t('Abrechnen','Bill')); ?></a><?php endif;?></div></article>
        <?php endforeach;endif;?></div></section>
      <?php endforeach;?>
    </div>
    <?php if($role==='agency'&&function_exists('pw_v503_compliance_center')) echo pw_v503_compliance_center($uid,false); ?>
    <?php if($role==='agency'&&pw_can('client_reports',$uid)): echo pw_v499_client_report_card($uid); endif; ?>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

function pw_v499_client_report_card($uid){
    $ids=pw_v499_active_assignments($uid);$planned=0;$clarify=0;$customers=[];
    foreach($ids as $sid){$st=pw_meta($sid,'pw_status','submitted');$vid=(int)pw_meta($sid,'pw_vacancy_id',0);$client=pw_vacancy_client_label($vid,$uid);if($client)$customers[$client]=1;if(in_array($st,['confirmed','planned'],true))$planned++;else$clarify++;}
    ob_start();?><section class="pw-card pw-v499-client-report"><div><span class="pw-kicker">MAX · <?php echo esc_html(pw_t('KUNDENSTATUS-REPORT','CLIENT STATUS REPORT')); ?></span><h2><?php echo esc_html(pw_t('Statusbericht mit einem Klick','Status report in one click')); ?></h2><p><?php echo esc_html(sprintf(pw_t('%d Kunden · %d geplante/bestätigte Einsätze · %d Punkte in Klärung.','%d customers · %d planned/confirmed assignments · %d items being clarified.'),count($customers),$planned,$clarify)); ?></p></div><button class="pw-btn ghost" type="button" data-pw-copy-report data-report="<?php echo esc_attr(sprintf(pw_t('Pure Work Status: %d Kunden, %d geplante/bestätigte Einsätze, %d Punkte in Klärung.','Pure Work status: %d customers, %d planned/confirmed assignments, %d items being clarified.'),count($customers),$planned,$clarify)); ?>"><?php echo pw_icon('document'); ?> <?php echo esc_html(pw_t('Status kopieren','Copy status')); ?></button></section><?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Billing / invoice drafts
 * ---------------------------------------------------------------------- */
function pw_v499_register_invoice_post_type(){
    register_post_type('pw_invoice',['labels'=>['name'=>'Pure Work Rechnungen','singular_name'=>'Pure Work Rechnung'],'public'=>false,'show_ui'=>current_user_can('manage_options'),'show_in_menu'=>false,'supports'=>['title','author']]);
}
add_action('init','pw_v499_register_invoice_post_type',18);

function pw_v499_decimal($value){
    $v=trim(str_replace(['€',' ',"\xc2\xa0"],'',(string)$value));
    if(strpos($v,',')!==false){$v=str_replace('.','',$v);$v=str_replace(',','.',$v);}
    return (float)$v;
}
function pw_v499_money($n){return number_format_i18n((float)$n,2).' €';}

function pw_v499_billing_profile($uid){
    return [
        'company'=>pw_user_meta($uid,'pw_invoice_company',pw_user_meta($uid,'pw_company','')),
        'street'=>pw_user_meta($uid,'pw_invoice_street',''),
        'zip'=>pw_user_meta($uid,'pw_invoice_zip',pw_user_meta($uid,'pw_zip','')),
        'city'=>pw_user_meta($uid,'pw_invoice_city',pw_user_meta($uid,'pw_city','')),
        'vat_id'=>pw_user_meta($uid,'pw_invoice_vat_id',''),
        'tax_id'=>pw_user_meta($uid,'pw_invoice_tax_id',''),
        'iban'=>pw_user_meta($uid,'pw_invoice_iban',''),
        'bic'=>pw_user_meta($uid,'pw_invoice_bic',''),
        'payment_days'=>max(1,(int)pw_user_meta($uid,'pw_invoice_payment_days',14)),
    ];
}
function pw_handle_v499_billing_profile_save(){
    if(!is_user_logged_in()||pw_user_role()!=='agency'||!pw_can('invoicing'))wp_die('Keine Berechtigung.');check_admin_referer('pw_v499_billing_profile');$uid=get_current_user_id();
    $map=['company'=>'pw_invoice_company','street'=>'pw_invoice_street','zip'=>'pw_invoice_zip','city'=>'pw_invoice_city','vat_id'=>'pw_invoice_vat_id','tax_id'=>'pw_invoice_tax_id','iban'=>'pw_invoice_iban','bic'=>'pw_invoice_bic'];
    foreach($map as $field=>$meta) update_user_meta($uid,$meta,sanitize_text_field(wp_unslash($_POST[$field]??'')));
    update_user_meta($uid,'pw_invoice_payment_days',max(1,min(120,(int)($_POST['payment_days']??14))));
    wp_safe_redirect(pw_page_url('invoices',['profile_saved'=>1]));exit;
}
add_action('admin_post_pw_v499_billing_profile_save','pw_handle_v499_billing_profile_save');
function pw_v499_billing_profile_card($uid){$b=pw_v499_billing_profile($uid);ob_start();?>
<section class="pw-card pw-v499-billing-profile"><details <?php echo empty($b['street'])?'open':'';?>><summary><span><?php echo pw_icon('building'); ?></span><div><b><?php echo esc_html(pw_t('Absender- & Zahlungsdaten','Sender & payment details')); ?></b><small><?php echo esc_html(pw_t('Einmal pflegen, in Rechnungsentwürfen verwenden.','Maintain once, use in invoice drafts.')); ?></small></div><?php echo pw_icon('arrow'); ?></summary><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-form-grid two"><input type="hidden" name="action" value="pw_v499_billing_profile_save"><?php wp_nonce_field('pw_v499_billing_profile');?><label class="full"><?php echo esc_html(pw_t('Firma','Company')); ?><input name="company" value="<?php echo esc_attr($b['company']); ?>"></label><label class="full"><?php echo esc_html(pw_t('Straße & Hausnummer','Street & number')); ?><input name="street" value="<?php echo esc_attr($b['street']); ?>"></label><label><?php echo esc_html(pw_t('PLZ','Postal code')); ?><input name="zip" value="<?php echo esc_attr($b['zip']); ?>"></label><label><?php echo esc_html(pw_t('Ort','City')); ?><input name="city" value="<?php echo esc_attr($b['city']); ?>"></label><label><?php echo esc_html(pw_t('USt-IdNr.','VAT ID')); ?><input name="vat_id" value="<?php echo esc_attr($b['vat_id']); ?>"></label><label><?php echo esc_html(pw_t('Steuernummer','Tax number')); ?><input name="tax_id" value="<?php echo esc_attr($b['tax_id']); ?>"></label><label><?php echo esc_html(pw_t('IBAN','IBAN')); ?><input name="iban" value="<?php echo esc_attr($b['iban']); ?>"></label><label><?php echo esc_html(pw_t('BIC','BIC')); ?><input name="bic" value="<?php echo esc_attr($b['bic']); ?>"></label><label><?php echo esc_html(pw_t('Zahlungsziel Tage','Payment term days')); ?><input type="number" min="1" max="120" name="payment_days" value="<?php echo (int)$b['payment_days']; ?>"></label><div class="full"><button class="pw-btn primary small" type="submit"><?php echo esc_html(pw_t('Daten speichern','Save details')); ?></button></div></form></details></section><?php return ob_get_clean();}
function pw_v499_overdue_invoices($uid){
    $ids=get_posts(['post_type'=>'pw_invoice','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_inv_status','value'=>'sent']]]);$today=wp_date('Y-m-d');$out=[];foreach($ids as $id){$due=pw_v499_invoice_meta($id,'due','');if($due&&$due<=$today)$out[]=(int)$id;}return $out;
}

function pw_v499_invoice_no($uid){
    $year=wp_date('Y');$count=pw_v498_count_posts(['post_type'=>'pw_invoice','post_status'=>'publish','author'=>$uid,'date_query'=>[['year'=>(int)$year]]]);return 'RE-'.$year.'-'.str_pad((string)($count+1),4,'0',STR_PAD_LEFT);
}
function pw_v499_invoice_meta($id,$key,$default=''){return pw_meta($id,'pw_inv_'.$key,$default);}
function pw_v499_invoice_access($id,$uid){return $id&&get_post_type($id)==='pw_invoice'&&((int)get_post_field('post_author',$id)===(int)$uid||user_can($uid,'manage_options'));}

function pw_v499_invoice_prefill($uid,$sid){
    $data=['submission_id'=>$sid,'customer'=>'','customer_address'=>'','description'=>pw_t('Arbeitnehmerüberlassung / Personaleinsatz','Temporary staffing / personnel assignment'),'period'=>'','hours'=>'160','rate'=>'','vat'=>'19'];
    if(!$sid||!pw_can_access_submission($sid)) return $data;
    $vid=(int)pw_meta($sid,'pw_vacancy_id',0);$v=pw_vacancy_fields($vid);$contact=function_exists('pw_vacancy_client_contact')?pw_vacancy_client_contact($vid,$uid):null;
    $data['customer']=$contact['company']??pw_vacancy_client_label($vid,$uid);$data['customer_address']=trim(($contact['address']??'').' '.($contact['zip']??'').' '.($contact['city']??''));$data['description']=$v['title'];$data['period']=$v['start_date']?pw_format_date($v['start_date']):'';$data['rate']=preg_replace('/[^0-9,\.]/','',(string)pw_meta($sid,'pw_rate',''));
    return $data;
}

function pw_handle_v499_invoice_save(){
    if(!is_user_logged_in()||pw_user_role()!=='agency'||!pw_can('invoicing'))wp_die('Keine Berechtigung.');check_admin_referer('pw_v499_invoice_save');$uid=get_current_user_id();
    $sid=(int)($_POST['submission_id']??0);$customer=sanitize_text_field(wp_unslash($_POST['customer']??''));$address=sanitize_textarea_field(wp_unslash($_POST['customer_address']??''));$desc=sanitize_text_field(wp_unslash($_POST['description']??''));$period=sanitize_text_field(wp_unslash($_POST['period']??''));$hours=max(0,pw_v499_decimal($_POST['hours']??0));$rate=max(0,pw_v499_decimal($_POST['rate']??0));$vat=max(0,min(100,pw_v499_decimal($_POST['vat']??19)));if(!$customer||!$desc||$hours<=0||$rate<=0){wp_safe_redirect(pw_page_url('invoices',['new'=>1,'error'=>'fields']));exit;}
    $net=round($hours*$rate,2);$tax=round($net*$vat/100,2);$gross=$net+$tax;$no=pw_v499_invoice_no($uid);$bp=pw_v499_billing_profile($uid);$payment_days=max(1,(int)$bp['payment_days']);
    $id=wp_insert_post(['post_type'=>'pw_invoice','post_status'=>'publish','post_author'=>$uid,'post_title'=>$no.' · '.$customer],true);if(is_wp_error($id))wp_die('Speichern fehlgeschlagen.');
    $vals=['no'=>$no,'date'=>wp_date('Y-m-d'),'due'=>wp_date('Y-m-d',strtotime('+'.$payment_days.' days')),'customer'=>$customer,'customer_address'=>$address,'description'=>$desc,'period'=>$period,'hours'=>$hours,'rate'=>$rate,'vat'=>$vat,'net'=>$net,'tax'=>$tax,'gross'=>$gross,'status'=>'draft','submission_id'=>$sid];foreach($vals as $k=>$v)update_post_meta($id,'pw_inv_'.$k,$v);
    wp_safe_redirect(pw_page_url('invoices',['view'=>$id,'saved'=>1]));exit;
}
add_action('admin_post_pw_v499_invoice_save','pw_handle_v499_invoice_save');

function pw_handle_v499_invoice_status(){
    if(!is_user_logged_in()||pw_user_role()!=='agency')wp_die('Keine Berechtigung.');$uid=get_current_user_id();$id=(int)($_GET['id']??0);check_admin_referer('pw_invoice_status_'.$id);if(!pw_v499_invoice_access($id,$uid))wp_die('Kein Zugriff.');$status=sanitize_key($_GET['status']??'draft');if(!in_array($status,['draft','sent','paid'],true))$status='draft';update_post_meta($id,'pw_inv_status',$status);wp_safe_redirect(pw_page_url('invoices',['view'=>$id]));exit;
}
add_action('admin_post_pw_v499_invoice_status','pw_handle_v499_invoice_status');

function pw_v499_rate_calculator(){
    ob_start();?><section class="pw-card pw-v499-rate-calc" id="calculator" data-pw-rate-calc><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE KALKULATION','PURE CALCULATOR')); ?></span><h2><?php echo esc_html(pw_t('Verrechnungssatz & Marge','Bill rate & margin')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Schnelle interne Kalkulation. Werte vor Vertrags- oder Rechnungsnutzung fachlich prüfen.','Fast internal calculation. Verify values before contractual or invoicing use.')); ?></p></div><?php echo pw_icon('calculator'); ?></div><div class="pw-v499-rate-grid"><label><?php echo esc_html(pw_t('Bruttolohn / Std.','Gross wage / hr')); ?><input type="number" min="0" step="0.01" value="16.50" data-rate-wage></label><label><?php echo esc_html(pw_t('AG-Faktor','Employer factor')); ?><input type="number" min="1" step="0.01" value="1.75" data-rate-factor></label><label><?php echo esc_html(pw_t('Overhead / Std.','Overhead / hr')); ?><input type="number" min="0" step="0.01" value="3.50" data-rate-overhead></label><label><?php echo esc_html(pw_t('Zielmarge','Target margin')); ?> %<input type="number" min="0" max="80" step="0.5" value="18" data-rate-margin></label></div><div class="pw-v499-rate-result"><div><span><?php echo esc_html(pw_t('Kostenbasis','Cost base')); ?></span><b data-rate-cost>–</b></div><div class="primary"><span><?php echo esc_html(pw_t('empf. Verrechnungssatz','recommended bill rate')); ?></span><b data-rate-result>–</b></div><div><span><?php echo esc_html(pw_t('Deckungsbeitrag / Std.','contribution / hr')); ?></span><b data-rate-profit>–</b></div></div></section><?php return ob_get_clean();
}

function pw_v499_invoice_view($id,$uid){
    if(!pw_v499_invoice_access($id,$uid))return '<div class="pw-alert danger">Kein Zugriff.</div>';$bp=pw_v499_billing_profile($uid);$company=$bp['company']?:pw_user_meta($uid,'pw_company','Pure Work Nutzer');$address=trim($bp['street'].'\n'.$bp['zip'].' '.$bp['city']);$status=pw_v499_invoice_meta($id,'status','draft');$labels=['draft'=>pw_t('Entwurf','Draft'),'sent'=>pw_t('Versendet','Sent'),'paid'=>pw_t('Bezahlt','Paid')];
    ob_start();?><div class="pw-page-head-inline pw-no-print"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('invoices')); ?>">← <?php echo esc_html(pw_t('Abrechnung','Billing')); ?></a><h2><?php echo esc_html(pw_v499_invoice_meta($id,'no')); ?></h2><p><?php echo esc_html(pw_v499_invoice_meta($id,'customer')); ?></p></div><div class="pw-head-actions"><button class="pw-btn ghost small" type="button" onclick="window.print()"><?php echo pw_icon('document'); ?> <?php echo esc_html(pw_t('Drucken / PDF','Print / PDF')); ?></button><?php if($status==='draft'):?><a class="pw-btn primary small" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v499_invoice_status&id='.$id.'&status=sent'),'pw_invoice_status_'.$id)); ?>"><?php echo esc_html(pw_t('Als versendet markieren','Mark sent')); ?></a><?php elseif($status==='sent'):?><a class="pw-btn primary small" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v499_invoice_status&id='.$id.'&status=paid'),'pw_invoice_status_'.$id)); ?>"><?php echo esc_html(pw_t('Als bezahlt markieren','Mark paid')); ?></a><?php endif;?></div></div><article class="pw-v499-invoice-sheet"><header><div><span class="pw-kicker">PURE WORK · <?php echo esc_html(pw_t('RECHNUNGSENTWURF','INVOICE DRAFT')); ?></span><h1><?php echo esc_html(pw_v499_invoice_meta($id,'no')); ?></h1></div><span class="pw-v499-invoice-status <?php echo esc_attr($status); ?>"><?php echo esc_html($labels[$status]??$status); ?></span></header><div class="pw-v499-invoice-parties"><div><small><?php echo esc_html(pw_t('VON','FROM')); ?></small><b><?php echo esc_html($company); ?></b><p><?php echo nl2br(esc_html($address)); ?><?php if($bp['vat_id']): ?><br><?php echo esc_html(pw_t('USt-ID: ','VAT ID: ').$bp['vat_id']); ?><?php endif; ?><?php if($bp['tax_id']): ?><br><?php echo esc_html(pw_t('Steuernr.: ','Tax no.: ').$bp['tax_id']); ?><?php endif; ?></p></div><div><small><?php echo esc_html(pw_t('AN','TO')); ?></small><b><?php echo esc_html(pw_v499_invoice_meta($id,'customer')); ?></b><p><?php echo nl2br(esc_html(pw_v499_invoice_meta($id,'customer_address'))); ?></p></div></div><div class="pw-v499-invoice-meta"><span><small><?php echo esc_html(pw_t('Rechnungsdatum','Invoice date')); ?></small><b><?php echo esc_html(pw_format_date(pw_v499_invoice_meta($id,'date'))); ?></b></span><span><small><?php echo esc_html(pw_t('Fällig','Due')); ?></small><b><?php echo esc_html(pw_format_date(pw_v499_invoice_meta($id,'due'))); ?></b></span><span><small><?php echo esc_html(pw_t('Leistungszeitraum','Service period')); ?></small><b><?php echo esc_html(pw_v499_invoice_meta($id,'period','–')); ?></b></span></div><table><thead><tr><th><?php echo esc_html(pw_t('Leistung','Service')); ?></th><th><?php echo esc_html(pw_t('Stunden','Hours')); ?></th><th><?php echo esc_html(pw_t('Satz','Rate')); ?></th><th><?php echo esc_html(pw_t('Betrag','Amount')); ?></th></tr></thead><tbody><tr><td><?php echo esc_html(pw_v499_invoice_meta($id,'description')); ?></td><td><?php echo esc_html(pw_v499_invoice_meta($id,'hours')); ?></td><td><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'rate'))); ?></td><td><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'net'))); ?></td></tr></tbody></table><div class="pw-v499-invoice-total"><span><small><?php echo esc_html(pw_t('Netto','Net')); ?></small><b><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'net'))); ?></b></span><span><small><?php echo esc_html(pw_t('USt.','VAT')); ?> <?php echo esc_html(pw_v499_invoice_meta($id,'vat')); ?>%</small><b><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'tax'))); ?></b></span><span class="gross"><small><?php echo esc_html(pw_t('Gesamt','Total')); ?></small><b><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($id,'gross'))); ?></b></span></div><?php if($bp['iban']): ?><div class="pw-v499-invoice-bank"><b><?php echo esc_html(pw_t('Zahlung','Payment')); ?></b><span>IBAN <?php echo esc_html($bp['iban']); ?><?php if($bp['bic']): ?> · BIC <?php echo esc_html($bp['bic']); ?><?php endif; ?></span></div><?php endif; ?><footer><?php echo esc_html(pw_t('Hinweis: Dieser Bereich erzeugt einen Rechnungsentwurf aus Portal-Daten. Pflichtangaben, Steuersachverhalt und E-Rechnungsanforderungen vor Versand prüfen.','Note: This area creates an invoice draft from portal data. Check mandatory information, tax treatment and e-invoicing requirements before sending.')); ?></footer></article><?php return ob_get_clean();
}

function pw_shortcode_invoices(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();ob_start();echo pw_portal_shell_start(pw_t('Abrechnung','Billing'),pw_t('Vom bestätigten Einsatz zur nachvollziehbaren Rechnungsgrundlage.','From confirmed assignment to a traceable billing basis.'));echo pw_flash_messages();if(pw_user_role($uid)!=='agency'){echo '<section class="pw-card pw-empty"><h2>'.esc_html(pw_t('Abrechnung ist für Zeitarbeitsfirmen vorgesehen.','Billing is designed for staffing agencies.')).'</h2></section>';echo pw_portal_shell_end();return ob_get_clean();}if(!pw_can('invoicing',$uid)){echo pw_plan_gate('invoicing');echo pw_portal_shell_end();return ob_get_clean();}
    $view=(int)($_GET['view']??0);if($view){echo pw_v499_invoice_view($view,$uid);echo pw_portal_shell_end();return ob_get_clean();}
    if(!empty($_GET['new'])){$sid=(int)($_GET['submission']??0);$d=pw_v499_invoice_prefill($uid,$sid);?><section class="pw-card pw-v499-invoice-form"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('NEUER ENTWURF','NEW DRAFT')); ?></span><h2><?php echo esc_html(pw_t('Rechnungsgrundlage erstellen','Create billing basis')); ?></h2></div></div><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-form-grid two"><input type="hidden" name="action" value="pw_v499_invoice_save"><input type="hidden" name="submission_id" value="<?php echo (int)$sid; ?>"><?php wp_nonce_field('pw_v499_invoice_save');?><label><?php echo esc_html(pw_t('Kunde','Customer')); ?><input name="customer" required value="<?php echo esc_attr($d['customer']); ?>"></label><label><?php echo esc_html(pw_t('Leistungszeitraum','Service period')); ?><input name="period" value="<?php echo esc_attr($d['period']); ?>"></label><label class="full"><?php echo esc_html(pw_t('Kundenanschrift','Customer address')); ?><textarea name="customer_address" rows="2"><?php echo esc_textarea($d['customer_address']); ?></textarea></label><label class="full"><?php echo esc_html(pw_t('Leistung','Service')); ?><input name="description" required value="<?php echo esc_attr($d['description']); ?>"></label><label><?php echo esc_html(pw_t('Stunden','Hours')); ?><input type="number" name="hours" min="0.01" step="0.01" required value="<?php echo esc_attr($d['hours']); ?>"></label><label><?php echo esc_html(pw_t('Verrechnungssatz netto','Net bill rate')); ?><input type="number" name="rate" min="0.01" step="0.01" required value="<?php echo esc_attr($d['rate']); ?>"></label><label><?php echo esc_html(pw_t('USt. %','VAT %')); ?><input type="number" name="vat" min="0" max="100" step="0.1" value="19"></label><div class="full pw-form-actions"><button class="pw-btn primary" type="submit"><?php echo pw_icon('receipt'); ?> <?php echo esc_html(pw_t('Entwurf erstellen','Create draft')); ?></button><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('invoices')); ?>"><?php echo esc_html(pw_t('Abbrechen','Cancel')); ?></a></div></form></section><?php echo pw_v499_rate_calculator();echo pw_portal_shell_end();return ob_get_clean();}
    $invoices=get_posts(['post_type'=>'pw_invoice','post_status'=>'publish','author'=>$uid,'posts_per_page'=>100,'orderby'=>'date','order'=>'DESC']);?>
    <section class="pw-v499-board-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE ABRECHNUNG','PURE BILLING')); ?></span><h1><?php echo esc_html(pw_t('Abrechnung ohne Medienbruch','Billing without switching tools')); ?></h1><p><?php echo esc_html(pw_t('Rechnungsentwürfe direkt aus bestätigten Einsätzen vorbereiten.','Prepare invoice drafts directly from confirmed assignments.')); ?></p></div><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('invoices',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?> <?php echo esc_html(pw_t('Rechnung anlegen','Create invoice')); ?></a></section>
    <?php echo pw_v499_billing_profile_card($uid); ?>
    <div class="pw-v499-billing-layout"><section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('RECHNUNGEN','INVOICES')); ?></span><h2><?php echo count($invoices); ?> <?php echo esc_html(pw_t('Entwürfe & Vorgänge','drafts & records')); ?></h2></div></div><div class="pw-v499-invoice-list"><?php if(!$invoices):?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch keine Rechnung angelegt. Öffne das Einsatzboard und starte bei einer bestätigten Besetzung.','No invoice yet. Open the assignment board and start from a confirmed placement.')); ?></p><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('assignments')); ?>"><?php echo esc_html(pw_t('Einsatzboard öffnen','Open assignment board')); ?></a></div><?php else:foreach($invoices as $inv):$st=pw_v499_invoice_meta($inv->ID,'status','draft');?><a href="<?php echo esc_url(pw_page_url('invoices',['view'=>$inv->ID])); ?>"><span class="pw-v499-invoice-icon"><?php echo pw_icon('receipt'); ?></span><div><b><?php echo esc_html(pw_v499_invoice_meta($inv->ID,'no')); ?> · <?php echo esc_html(pw_v499_invoice_meta($inv->ID,'customer')); ?></b><small><?php echo esc_html(pw_format_date(pw_v499_invoice_meta($inv->ID,'date'))); ?> · <?php echo esc_html(ucfirst($st)); ?></small></div><strong><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($inv->ID,'gross'))); ?></strong><?php echo pw_icon('arrow'); ?></a><?php endforeach;endif;?></div></section><?php echo pw_v499_rate_calculator();?></div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Automations extension
 * ---------------------------------------------------------------------- */
function pw_v499_daily_risk_watch(){
    foreach(get_users(['role'=>'pw_agency','fields'=>'ID']) as $uid){
        $uid=(int)$uid;$day=wp_date('Y-m-d');
        if(pw_can('risk_watch',$uid)&&pw_user_meta($uid,'pw_auto_risk_watch','0')==='1'&&pw_user_meta($uid,'pw_auto_risk_watch_last','')!==$day){$risks=pw_v499_assignment_risks($uid,7);if($risks)pw_create_notice($uid,pw_t('Besetzungs-Risiko erkannt','Placement risk detected'),sprintf(pw_t('%d Einsatzstart(s) liegen in den nächsten 7 Tagen und sind noch nicht final geplant.','%d assignment start(s) are within the next 7 days and are not finally planned yet.'),count($risks)),pw_page_url('assignments'));update_user_meta($uid,'pw_auto_risk_watch_last',$day);}
        if(pw_can('invoicing',$uid)&&pw_user_meta($uid,'pw_auto_invoice_due','0')==='1'&&pw_user_meta($uid,'pw_auto_invoice_due_last','')!==$day){$due=pw_v499_overdue_invoices($uid);if($due)pw_create_notice($uid,pw_t('Rechnungen fällig','Invoices due'),sprintf(pw_t('%d versendete Rechnung(en) haben ihr Zahlungsziel erreicht.','%d sent invoice(s) have reached their due date.'),count($due)),pw_page_url('invoices'));update_user_meta($uid,'pw_auto_invoice_due_last',$day);}
    }
}
add_action('pw_daily_digest_event','pw_v499_daily_risk_watch',40);

/* -------------------------------------------------------------------------
 * Pure Assist: add billing / assignment intelligence without pretending to be
 * an external LLM.
 * ---------------------------------------------------------------------- */
function pw_ajax_v499_ops_assist(){
    // Dedicated endpoint for new contextual tools if needed by future UI.
    pw_ajax_guard();$uid=get_current_user_id();if(!$uid||pw_user_role($uid)!=='agency')wp_send_json_error(['message'=>'Nicht verfügbar.'],403);$risks=pw_v499_assignment_risks($uid,7);wp_send_json_success(['risks'=>count($risks),'assignments'=>count(pw_v499_active_assignments($uid)),'invoices'=>pw_v499_invoice_count($uid)]);
}
add_action('wp_ajax_pw_v499_ops_assist','pw_ajax_v499_ops_assist');

/* -------------------------------------------------------------------------
 * Register current shortcodes last.
 * ---------------------------------------------------------------------- */
function pw_v499_register_shortcodes(){
    remove_shortcode('pw_dashboard');add_shortcode('pw_dashboard','pw_shortcode_dashboard_v499');
    add_shortcode('pw_assignments','pw_shortcode_assignments');
    add_shortcode('pw_invoices','pw_shortcode_invoices');
}
add_action('init','pw_v499_register_shortcodes',700);
