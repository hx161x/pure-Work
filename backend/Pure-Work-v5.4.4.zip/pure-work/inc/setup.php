<?php
if (!defined('ABSPATH')) exit;

/**
 * Compatibility helpers. Pure Work intentionally avoids hard dependencies on
 * mbstring and PHP 8-only string helpers so the portal fails gracefully on
 * typical managed WordPress hosts.
 */
function pw_lower($value) {
    $value = (string)$value;
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}

function pw_upper($value) {
    $value = (string)$value;
    return function_exists('mb_strtoupper') ? mb_strtoupper($value, 'UTF-8') : strtoupper($value);
}

function pw_substr($value, $start, $length = null) {
    $value = (string)$value;
    if (function_exists('mb_substr')) {
        return $length === null ? mb_substr($value, $start, null, 'UTF-8') : mb_substr($value, $start, $length, 'UTF-8');
    }
    return $length === null ? substr($value, $start) : substr($value, $start, $length);
}

function pw_contains($haystack, $needle) {
    $haystack = (string)$haystack;
    $needle = (string)$needle;
    if ($needle === '') return true;
    return strpos($haystack, $needle) !== false;
}

function pw_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('responsive-embeds');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);
}
add_action('after_setup_theme', 'pw_theme_setup');

function pw_register_roles() {
    add_role('pw_agency', 'Zeitarbeitsfirma', ['read' => true, 'upload_files' => true]);
    add_role('pw_client', 'Auftraggeber', ['read' => true, 'upload_files' => true]);
}

function pw_register_post_types() {
    $types = [
        'pw_vacancy' => ['Personalanfrage','Personalanfragen'],
        'pw_worker' => ['Mitarbeiterprofil','Mitarbeiterprofile'],
        'pw_submission' => ['Profileinreichung','Profileinreichungen'],
        'pw_message' => ['Nachricht','Nachrichten'],
        'pw_notice' => ['Benachrichtigung','Benachrichtigungen'],
        'pw_file' => ['Private Datei','Private Dateien'],
        'pw_audit' => ['Audit-Ereignis','Audit-Ereignisse'],
        'pw_crm_lead' => ['CRM-Lead','CRM-Leads'],
        'pw_crm_activity' => ['CRM-Aktivität','CRM-Aktivitäten'],
    ];
    foreach ($types as $slug => $labels) {
        register_post_type($slug, [
            'labels' => [
                'name' => $labels[1],
                'singular_name' => $labels[0],
            ],
            'public' => false,
            'show_ui' => current_user_can('manage_options'),
            'show_in_menu' => false,
            'supports' => ['title','editor','author'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);
    }
}
add_action('init', 'pw_register_post_types');

function pw_enqueue_assets() {
    wp_enqueue_style('pw-app', PW_URI . '/assets/css/app.css', [], PW_VERSION);
    // 5.3.0: verbindliche Oberflächenschicht, wird nach app.css geladen und
    // löst die widersprüchlichen Regeln der älteren Versionsschichten auf.
    wp_enqueue_style('pw-ui', PW_URI . '/assets/css/ui.css', ['pw-app'], PW_VERSION);
    if (file_exists(PW_DIR . '/assets/css/v541.css')) wp_enqueue_style('pw-v541', PW_URI . '/assets/css/v541.css', ['pw-ui'], PW_VERSION);
    if (file_exists(PW_DIR . '/assets/css/v542.css')) wp_enqueue_style('pw-v542', PW_URI . '/assets/css/v542.css', ['pw-v541'], PW_VERSION);
    if (file_exists(PW_DIR . '/assets/css/v543.css')) wp_enqueue_style('pw-v543', PW_URI . '/assets/css/v543.css', ['pw-v542'], PW_VERSION);
    wp_enqueue_script('pw-app', PW_URI . '/assets/js/app.js', [], PW_VERSION, true);
    if (file_exists(PW_DIR . '/assets/js/v541.js')) wp_enqueue_script('pw-v541', PW_URI . '/assets/js/v541.js', ['pw-app'], PW_VERSION, true);
    if (file_exists(PW_DIR . '/assets/js/v542.js')) wp_enqueue_script('pw-v542', PW_URI . '/assets/js/v542.js', ['pw-v541'], PW_VERSION, true);
    if (file_exists(PW_DIR . '/assets/js/v543.js')) wp_enqueue_script('pw-v543', PW_URI . '/assets/js/v543.js', ['pw-v542'], PW_VERSION, true);
    wp_localize_script('pw-app', 'PW_APP', [
        'ajax' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('pw_ajax'),
        'dashboard' => pw_page_url('dashboard'),
        'login' => pw_page_url('login'),
        'messages' => pw_page_url('messages'),
        'i18n' => [
            'saving' => pw_t('Wird gespeichert…','Saving…'),
            'saved' => pw_t('Gespeichert','Saved'),
            'error' => pw_t('Das hat nicht geklappt. Bitte erneut versuchen.','Something went wrong. Please try again.'),
            'confirmDelete' => pw_t('Wirklich löschen?','Really delete?'),
        ],
            'role' => is_user_logged_in() ? pw_user_role() : '',
    ]);
}
add_action('wp_enqueue_scripts', 'pw_enqueue_assets');

function pw_admin_assets($hook) {
    if (strpos((string)$hook, 'pure-work') !== false) {
        wp_enqueue_style('pw-app-admin', PW_URI . '/assets/css/app.css', [], PW_VERSION);
        wp_enqueue_style('pw-ui-admin', PW_URI . '/assets/css/ui.css', ['pw-app-admin'], PW_VERSION);
    }
}
add_action('admin_enqueue_scripts', 'pw_admin_assets');

function pw_page_definitions_legacy47() {
    return [
        'home' => ['Pure Work', '[pw_landing]'],
        'login' => ['Anmelden', '[pw_login]'],
        'register' => ['Registrieren', '[pw_register]'],
        'verify' => ['E-Mail bestätigen', '[pw_verify_email]'],
        'password' => ['Passwort zurücksetzen', '[pw_password]'],
        'dashboard' => ['Puls', '[pw_dashboard]'],
        'vacancies' => ['Personalanfragen', '[pw_vacancies]'],
        'workers' => ['Talent Pool', '[pw_workers]'],
        'matches' => ['Pure Match', '[pw_matches]'],
        'messages' => ['Nachrichten', '[pw_messages]'],
        'companies' => ['Unternehmen', '[pw_companies]'],
        'crm' => ['CRM', '[pw_crm]'],
        'market_live' => ['Direkt-Leads', '[pw_market_live]'],
        'marketdata' => ['Datenkatalog & Berufe', '[pw_marketdata]'],
        'account' => ['Konto & Einstellungen', '[pw_account]'],
        'pricing' => ['Tarife', '[pw_pricing]'],
        'legal' => ['Nutzungsbedingungen', '[pw_legal]'],
        'privacy' => ['Datenschutz', '[pw_privacy]'],
        'aug_renew' => ['AÜG aktualisieren', '[pw_aug_renew]'],
    ];
}


/**
 * Removes synthetic demo/test records created by older Pure Work versions.
 * Only records explicitly marked with pw_demo=1 are touched; real users and
 * production records are preserved.
 */
function pw_remove_legacy_demo_data() {
    if (get_option('pw_legacy_demo_cleanup_410', '0') === '1') return;

    foreach (['pw_message','pw_submission','pw_worker','pw_vacancy','pw_notice'] as $post_type) {
        $demo_ids = get_posts([
            'post_type' => $post_type,
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => [['key' => 'pw_demo', 'value' => '1']],
        ]);
        foreach ($demo_ids as $demo_id) wp_delete_post((int)$demo_id, true);
    }

    $demo_users = get_users(['meta_key' => 'pw_demo', 'meta_value' => '1', 'fields' => 'ID']);
    if ($demo_users) {
        if (!function_exists('wp_delete_user')) require_once ABSPATH . 'wp-admin/includes/user.php';
        foreach ($demo_users as $demo_user_id) wp_delete_user((int)$demo_user_id);
    }

    foreach ([
        'pw_demo_credentials','pw_demo_v4_client_id','pw_demo_v4_agency_id',
        'pw_demo_seed_version_v4','pw_demo_seed_version'
    ] as $option_name) delete_option($option_name);

    update_option('pw_legacy_demo_cleanup_410', '1', false);
}


/**
 * Pure Work 4.4 migration: older agency accounts had only an optional expiry
 * field. We never infer an unlimited permit from a blank legacy value; the
 * company can explicitly switch to "Unbefristet" in its account settings.
 */
function pw_migrate_aug_validity_440() {
    if (get_option('pw_aug_validity_migrated_440', '0') === '1') return;
    $agency_ids = get_users(['role' => 'pw_agency', 'fields' => 'ID']);
    foreach ($agency_ids as $agency_id) {
        if (get_user_meta((int)$agency_id, 'pw_aug_type', true) === '') {
            update_user_meta((int)$agency_id, 'pw_aug_type', 'limited');
        }
    }
    update_option('pw_aug_validity_migrated_440', '1', false);
}

function pw_install_theme() {
    $previous_version = (string)get_option('pw_installed_version', '');
    pw_register_roles();
    pw_register_post_types();

    $ids = get_option('pw_page_ids', []);
    foreach (pw_page_definitions() as $key => $def) {
        $existing = isset($ids[$key]) ? get_post((int)$ids[$key]) : null;
        if (!$existing || $existing->post_status === 'trash') {
            $id = wp_insert_post([
                'post_title' => $def[0],
                'post_content' => $def[1],
                'post_type' => 'page',
                'post_status' => 'publish',
            ]);
            if (!is_wp_error($id)) $ids[$key] = $id;
        } else {
            // Managed application pages must keep their shortcode. This repairs
            // blank pages left behind by a failed/partial previous installation.
            // 4.9.6: Der Titel wird mitgepflegt, sonst behalten bestehende
            // Installationen die alten Produktnamen ("Puls", "Pure Match").
            $needs_update = $existing->post_status !== 'publish'
                || trim((string)$existing->post_content) !== $def[1]
                || trim((string)$existing->post_title) !== $def[0];
            if ($needs_update) {
                wp_update_post([
                    'ID' => (int)$existing->ID,
                    'post_status' => 'publish',
                    'post_title' => $def[0],
                    'post_content' => $def[1],
                ]);
            }
        }
    }
    update_option('pw_page_ids', $ids);

    if (!empty($ids['home'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', (int)$ids['home']);
    }

    if (get_option('pw_trial_days', null) === null) update_option('pw_trial_days', 0);
    if (get_option('pw_basic_price', null) === null) update_option('pw_basic_price', '49');
    if (get_option('pw_pro_price', null) === null) update_option('pw_pro_price', '119');
    if (get_option('pw_company_name', null) === null) update_option('pw_company_name', 'Pure Work');
    if (get_option('pw_geocoding_enabled', null) === null) update_option('pw_geocoding_enabled', '1');
    if (get_option('pw_auto_verify_clients', null) === null) update_option('pw_auto_verify_clients', '0');
    // v4.6 separates identity confirmation from company verification. Existing
    // installations are migrated to the safer manual company-review default.
    if ($previous_version && version_compare($previous_version, '4.6.0', '<')) update_option('pw_auto_verify_clients', '0', false);
    if (get_option('pw_mail_from_name', null) === null) update_option('pw_mail_from_name', 'Pure Work');
    if (get_option('pw_mail_from', null) === null) update_option('pw_mail_from', get_option('admin_email'));
    if (get_option('pw_smtp_enabled', null) === null) update_option('pw_smtp_enabled', '0');
    if (get_option('pw_smtp_port', null) === null) update_option('pw_smtp_port', 587);
    if (get_option('pw_smtp_encryption', null) === null) update_option('pw_smtp_encryption', 'tls');
    if (get_option('pw_smtp_auth', null) === null) update_option('pw_smtp_auth', '1');

    if (!wp_next_scheduled('pw_daily_digest_event')) {
        wp_schedule_event(time() + 3600, 'daily', 'pw_daily_digest_event');
    }
    // Pure Work 4.6 is production-only: no launch/test bypass and no synthetic demo network.
    update_option('pw_require_email_verification', '1', false);
    delete_option('pw_launch_mode');
    delete_option('pw_auto_demo_network');
    if (function_exists('pw_remove_legacy_demo_data')) pw_remove_legacy_demo_data();
    if (function_exists('pw_migrate_aug_validity_440')) pw_migrate_aug_validity_440();
    update_option('pw_installed_version', PW_VERSION, false);
    flush_rewrite_rules();
}
function pw_after_switch_theme() {
    update_option('pw_needs_install', '1');
    pw_install_theme();
    delete_option('pw_needs_install');
}
add_action('after_switch_theme', 'pw_after_switch_theme');

function pw_maybe_install_theme() {
    // Run migrations not only on a theme switch, but also when an active Pure Work
    // theme is replaced by a newer ZIP. WordPress does not always fire
    // after_switch_theme in that update scenario.
    $installed = (string)get_option('pw_installed_version', '');
    $ids = (array)get_option('pw_page_ids', []);
    $definitions = pw_page_definitions();
    $missing_managed_page = false;
    foreach ($definitions as $key => $def) {
        if (empty($ids[$key]) || !get_post((int)$ids[$key])) {
            $missing_managed_page = true;
            break;
        }
    }
    if (get_option('pw_needs_install') === '1' || !$ids || $installed !== PW_VERSION || $missing_managed_page) {
        pw_install_theme();
        delete_option('pw_needs_install');
    }
}
add_action('init', 'pw_maybe_install_theme', 30);

function pw_template_redirects() {
    if (!is_page()) return;
    $ids = (array)get_option('pw_page_ids', []);
    $current = get_queried_object_id();
    $role = is_user_logged_in() ? pw_user_role() : '';

    // If a limited AÜG permit has expired, end an existing portal session too.
    // The renewal page stays public, so the company can upload current documents safely.
    if ($role === 'agency' && function_exists('pw_aug_state')) {
        $aug_state = pw_aug_state(get_current_user_id());
        $aug_locked = get_user_meta(get_current_user_id(), 'pw_aug_login_locked', true) === '1';
        if (!empty($aug_state['expired']) || $aug_locked) {
            wp_logout();
            wp_safe_redirect(pw_page_url('login', ['error'=>'aug_expired']));
            exit;
        }
    }

    // A signed-in portal user does not need the login/register screens.
    // Administrators are deliberately excluded so the public account flow can be tested while WordPress admin is open.
    if (in_array($role, ['agency','client'], true)) {
        if ((!empty($ids['login']) && $current === (int)$ids['login']) || (!empty($ids['register']) && $current === (int)$ids['register'])) {
            wp_safe_redirect(pw_page_url('dashboard'));
            exit;
        }
    }

    // All application pages are protected. Visitors are sent to the real login page,
    // and after login they return to the page they originally requested.
    $public_keys = ['home','login','register','verify','password','pricing','legal','privacy','aug_renew'];
    $private_ids = [];
    foreach ($ids as $key => $id) {
        if (!in_array($key, $public_keys, true)) $private_ids[] = (int)$id;
    }
    if (!is_user_logged_in() && in_array((int)$current, $private_ids, true)) {
        $target = get_permalink($current);
        wp_safe_redirect(pw_page_url('login', ['redirect_to' => $target]));
        exit;
    }
}
add_action('template_redirect', 'pw_template_redirects', 1);

function pw_no_cache_app_pages() {
    if (is_front_page() || pw_is_portal_page()) {
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        nocache_headers();
    }
}
add_action('template_redirect', 'pw_no_cache_app_pages', 0);


function pw_page_url($key, $args = []) {
    $ids = get_option('pw_page_ids', []);
    $url = !empty($ids[$key]) ? get_permalink((int)$ids[$key]) : home_url('/');
    if ($args) $url = add_query_arg($args, $url);
    return $url;
}

function pw_user_role($user_id = 0) {
    $user = $user_id ? get_userdata($user_id) : wp_get_current_user();
    if (!$user || !$user->exists()) return '';
    if (in_array('pw_agency', (array)$user->roles, true)) return 'agency';
    if (in_array('pw_client', (array)$user->roles, true)) return 'client';
    if (in_array('administrator', (array)$user->roles, true)) return 'admin';
    return '';
}

function pw_is_portal_page() {
    if (!is_page()) return false;
    $ids = array_map('intval', (array)get_option('pw_page_ids', []));
    return in_array(get_queried_object_id(), $ids, true);
}

function pw_body_classes($classes) {
    if (pw_is_portal_page()) $classes[] = 'pw-app-page';
    if (is_user_logged_in()) $classes[] = 'pw-logged-in';
    return $classes;
}
add_filter('body_class', 'pw_body_classes');

function pw_hide_admin_bar($show) {
    if (!current_user_can('manage_options')) return false;
    return $show;
}
add_filter('show_admin_bar', 'pw_hide_admin_bar');

function pw_login_redirect($redirect_to, $requested_redirect_to, $user) {
    if ($user instanceof WP_User && !user_can($user, 'manage_options')) return pw_page_url('dashboard');
    return $redirect_to;
}
add_filter('login_redirect', 'pw_login_redirect', 10, 3);

function pw_prevent_portal_admin() {
    // IMPORTANT: admin-post.php is the transport endpoint for every Pure Work form.
    // Never redirect it, otherwise login/registration/form submissions are swallowed
    // by admin_init before WordPress can dispatch admin_post(_nopriv)_* actions.
    global $pagenow;
    if ($pagenow === 'admin-post.php' || wp_doing_ajax()) return;
    if (is_admin() && !current_user_can('manage_options')) {
        wp_safe_redirect(pw_page_url('dashboard'));
        exit;
    }
}
add_action('admin_init', 'pw_prevent_portal_admin');

function pw_logout_url() {
    return wp_logout_url(pw_page_url('home', ['logged_out' => 1]));
}

function pw_brand() {
    return '<span class="pw-brand-mark" aria-hidden="true"><i></i><i></i></span><span class="pw-brand-name">pure <b>work</b></span>';
}

function pw_icon($name) {
    $icons = [
        'home' => '<path d="M3 10.8 12 3l9 7.8v9.2a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
        'briefcase' => '<path d="M8 6V4h8v2M3 8h18v11H3zM3 12h18M10 12v2h4v-2"/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
        'spark' => '<path d="m12 3 1.7 4.3L18 9l-4.3 1.7L12 15l-1.7-4.3L6 9l4.3-1.7zM19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8zM5 15l.6 1.4L7 17l-1.4.6L5 19l-.6-1.4L3 17l1.4-.6z"/>',
        'message' => '<path d="M21 15a4 4 0 0 1-4 4H8l-5 3v-7a4 4 0 0 1-1-2.7V7a4 4 0 0 1 4-4h11a4 4 0 0 1 4 4z"/>',
        'building' => '<path d="M4 21V4h10v17M14 9h6v12M8 8h2M8 12h2M8 16h2M17 13h1M17 17h1M2 21h20"/>',
        'settings' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.8 1.8 0 0 0 .36 1.98l.06.06-2.83 2.83-.06-.06A1.8 1.8 0 0 0 15 19.4a1.8 1.8 0 0 0-1 .6 1.8 1.8 0 0 0-.4 1.15V21h-4v-.08A1.8 1.8 0 0 0 8.6 19.4a1.8 1.8 0 0 0-1.98.36l-.06.06-2.83-2.83.06-.06A1.8 1.8 0 0 0 4.6 15a1.8 1.8 0 0 0-.6-1 1.8 1.8 0 0 0-1.15-.4H3v-4h.08A1.8 1.8 0 0 0 4.6 8.6a1.8 1.8 0 0 0-.36-1.98l-.06-.06 2.83-2.83.06.06A1.8 1.8 0 0 0 9 4.6a1.8 1.8 0 0 0 1-.6 1.8 1.8 0 0 0 .4-1.15V3h4v.08A1.8 1.8 0 0 0 15.4 4.6a1.8 1.8 0 0 0 1.98-.36l.06-.06 2.83 2.83-.06.06A1.8 1.8 0 0 0 19.4 9c.15.36.36.7.6 1 .3.33.7.5 1.15.5H21v4h-.08A1.8 1.8 0 0 0 19.4 15z"/>',
        'bell' => '<path d="M18 8a6 6 0 1 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
        'check' => '<path d="m5 12 4 4L19 6"/>',
        'arrow' => '<path d="M5 12h14M13 6l6 6-6 6"/>',
        'map' => '<path d="M12 21s7-5.2 7-12A7 7 0 1 0 5 9c0 6.8 7 12 7 12z"/><circle cx="12" cy="9" r="2"/>',
        'filter' => '<path d="M4 5h16M7 12h10M10 19h4"/>',
        'upload' => '<path d="M12 16V4M7 9l5-5 5 5M4 16v4h16v-4"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'lock' => '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
        'phone' => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.69 2.8a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.28-1.28a2 2 0 0 1 2.11-.45c.9.33 1.84.56 2.8.69A2 2 0 0 1 22 16.92z"/>',
        // 4.9.6: eigene Symbole je Bereich statt dreimal derselbe Aktenkoffer.
        'target' => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/>',
        'handshake' => '<path d="m8 12 2.5 2.5a2 2 0 0 0 2.8 0L18 10M2 10h4l3-3 4 1 3-1 3 3h3M6 10v7a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-7"/>',
        'book' => '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 0 4 22zM8 7h8M8 11h6"/>',
        'grid' => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
        'help' => '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.4 2.3c-.6.3-.9.8-.9 1.4v.6M12 17h.01"/>',
        'text' => '<path d="M4 7V5h16v2M9 19h6M12 5v14"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/>',
        'receipt' => '<path d="M6 3h12v18l-2-1.5L14 21l-2-1.5L10 21l-2-1.5L6 21zM9 8h6M9 12h6M9 16h4"/>',
        'card' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18M7 15h4"/>',
        'calculator' => '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8v4H8zM8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01M16 18h.01"/>',
        'alert' => '<path d="M12 3 2.5 20h19L12 3zM12 9v5M12 17h.01"/>',
        'chart' => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        'document' => '<path d="M6 2h8l4 4v16H6zM14 2v5h5M9 12h6M9 16h6"/>',
    ];
    $path = $icons[$name] ?? $icons['spark'];
    return '<svg class="pw-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
}

function pw_nav_items_legacy47() {
    $role = pw_user_role();
    $items = [
        ['dashboard','home','Puls'],
        ['vacancies','briefcase','Personalanfragen'],
    ];
    if ($role === 'agency' || $role === 'admin') $items[] = ['workers','users','Talent Pool'];
    if ($role === 'client') $items[] = ['workers','users','Talent Pool'];
    $items[] = ['matches','spark','Pure Match'];
    $items[] = ['messages','message','Nachrichten'];
    $items[] = ['companies','building','Partner & Umgebung'];
    $items[] = ['crm','briefcase','CRM'];
    $items[] = ['market_live','spark','Direkt-Leads'];
    $items[] = ['marketdata','search','Datenkatalog'];
    $items[] = ['account','settings','Konto'];
    return $items;
}

function pw_portal_shell_start_legacy47($title = '', $subtitle = '') {
    if (!is_user_logged_in()) return '';
    $user = wp_get_current_user();
    $company = get_user_meta($user->ID, 'pw_company', true);
    $notice_count = pw_unread_notice_count($user->ID);
    ob_start();
    ?>
    <div class="pw-shell">
      <aside class="pw-sidebar">
        <a class="pw-brand" href="<?php echo esc_url(pw_page_url('dashboard')); ?>"><?php echo pw_brand(); ?></a>
        <nav class="pw-nav">
          <?php foreach (pw_nav_items() as $item):
              $ids = get_option('pw_page_ids', []);
              $active = !empty($ids[$item[0]]) && is_page((int)$ids[$item[0]]);
          ?>
            <a class="pw-nav-item <?php echo $active ? 'is-active' : ''; ?>" href="<?php echo esc_url(pw_page_url($item[0])); ?>">
              <?php echo pw_icon($item[1]); ?><span><?php echo esc_html($item[2]); ?></span>
              <?php if ($item[0] === 'messages' && pw_unread_message_count($user->ID) > 0): ?><em><?php echo (int)pw_unread_message_count($user->ID); ?></em><?php endif; ?>
            </a>
          <?php endforeach; ?>
        </nav>
        <div class="pw-sidebar-foot">
          <?php if (pw_user_role() === 'agency'): ?>
            <div class="pw-plan-mini"><span>Zugang</span><strong>Kostenfrei</strong><a href="<?php echo esc_url(pw_page_url('account')); ?>">Konto</a></div>
          <?php endif; ?>
          <div class="pw-user-mini"><span class="pw-avatar"><?php echo esc_html(strtoupper(substr($company ?: $user->display_name, 0, 1))); ?></span><div><b><?php echo esc_html($company ?: $user->display_name); ?></b><small><?php echo esc_html(pw_user_role() === 'agency' ? 'Zeitarbeitsfirma' : 'Auftraggeber'); ?></small></div></div>
        </div>
      </aside>
      <section class="pw-main">
        <header class="pw-topbar">
          <div>
            <?php if ($title): ?><h1><?php echo esc_html($title); ?></h1><?php endif; ?>
            <?php if ($subtitle): ?><p><?php echo esc_html($subtitle); ?></p><?php endif; ?>
          </div>
          <div class="pw-top-actions">
            <?php echo pw_language_switcher(true); ?>
            <a class="pw-icon-button" href="<?php echo esc_url(pw_page_url('dashboard', ['panel'=>'notifications'])); ?>" aria-label="Benachrichtigungen"><?php echo pw_icon('bell'); ?><?php if ($notice_count): ?><span><?php echo (int)$notice_count; ?></span><?php endif; ?></a>
            <a class="pw-btn small ghost" href="<?php echo esc_url(pw_logout_url()); ?>">Abmelden</a>
            <a class="pw-profile-button" href="<?php echo esc_url(pw_page_url('account')); ?>"><span class="pw-avatar small"><?php echo esc_html(strtoupper(substr($company ?: $user->display_name, 0, 1))); ?></span></a>
          </div>
        </header>
        <main class="pw-workspace">
    <?php
    return ob_get_clean();
}

function pw_portal_shell_end() {
    if (!is_user_logged_in()) return '';
    ob_start(); ?>
        </main>
      </section>
      <nav class="pw-mobile-nav">
        <?php foreach (array_slice(pw_nav_items(),0,5) as $item): ?>
          <a href="<?php echo esc_url(pw_page_url($item[0])); ?>"><?php echo pw_icon($item[1]); ?><span><?php echo esc_html($item[2]); ?></span></a>
        <?php endforeach; ?>
      </nav>
    </div>
    <?php return ob_get_clean();
}

function pw_require_login_html() {
    return '<section class="pw-auth-gate"><a class="pw-brand" href="'.esc_url(home_url('/')).'">'.pw_brand().'</a><div class="pw-auth-card"><span class="pw-kicker">Geschützter Bereich</span><h1>Bitte anmelden</h1><p>Du musst angemeldet sein, um das Pure Work Portal zu nutzen.</p><a class="pw-btn primary full" href="'.esc_url(pw_page_url('login')).'">Anmelden</a><a class="pw-btn ghost full" href="'.esc_url(pw_page_url('register')).'">Kostenlos registrieren</a></div></section>';
}
