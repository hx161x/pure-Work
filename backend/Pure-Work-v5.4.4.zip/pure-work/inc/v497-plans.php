<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9.7 – Tarifstufen mit echtem Funktionsunterschied.
 *
 * Bisher unterschieden sich Basic, Pro und Max nur in der
 * Aufzählung auf der Preisseite – funktional bekam jeder alles. Das ist für ein
 * Abo-Modell tödlich: Niemand wechselt auf Pro, wenn Basic dasselbe kann.
 *
 * Die internen Schlüssel (basic / professional / enterprise) bleiben unverändert,
 * damit bestehende Konten und Stripe-Preise weiter passen. Nur die Bezeichnung
 * nach außen ändert sich: Basic · Pro · Max.
 *
 * Wichtig: Die Bedienung ist auf jeder Stufe identisch. Gesperrt sind ganze
 * Funktionsbereiche, niemals einzelne Klicks innerhalb eines Ablaufs.
 */

function pw_plan_public_label($plan) {
    $labels = ['basic' => 'Basic', 'professional' => 'Pro', 'enterprise' => 'Max', 'client' => pw_t('Auftraggeber', 'Client')];
    return $labels[$plan] ?? ucfirst((string)$plan);
}

/**
 * Was jede Stufe kann. Höhere Stufen erben alles Darunterliegende.
 */
function pw_plan_feature_matrix() {
    return [
        'basic' => [
            'vacancies','workers','submissions','messages','notifications','knowledge',
            'crm','assignments','timesheets','capacity_radar','handover_briefing','leads_contacts','chat_snippets',
        ],
        'professional' => [
            'assist_ai','cv_assistant','smart_matching','worker_import','automations',
            'daily_digest','pool_health','rate_calculator','risk_watch',
            'compliance_watch','leads_unlimited','marketdata','profile_studio','availability_planner',
            'chat_offers','chat_attachments',
        ],
        'enterprise' => [
            'leads_targets','advanced_insights','capacity_forecast','hot_lead_automation','client_reports',
            'client_sla','placement_radar',
        ],
    ];
}

function pw_plan_feature_labels() {
    return [
        'vacancies'       => [pw_t('Ausschreibungen & Bedarfe', 'Jobs & demand'), 'briefcase'],
        'workers'         => [pw_t('Eigener Mitarbeiter-Pool', 'Own employee pool'), 'users'],
        'submissions'     => [pw_t('Profile zuordnen & Status verfolgen', 'Match profiles & track status'), 'check'],
        'messages'        => [pw_t('Nachrichten mit Auftraggebern', 'Messages with clients'), 'message'],
        'notifications'   => [pw_t('Passende Chancen automatisch melden', 'Automatic matching opportunity alerts'), 'bell'],
        'knowledge'       => [pw_t('Wissen, Hilfen & Tarif', 'Knowledge, help & plan'), 'book'],
        'chat_snippets'   => [pw_t('Textbausteine im Chat', 'Chat snippets'), 'message'],
        'chat_offers'     => [pw_t('Verbindliche Angebote im Chat', 'Binding offers in chat'), 'handshake'],
        'chat_attachments'=> [pw_t('Dateien im Chat senden', 'Send files in chat'), 'upload'],
        'leads_contacts'  => [pw_t('Direktkontakte Stufe A/B', 'Direct contacts tier A/B'), 'target'],
        'crm'             => [pw_t('Meine Kunden & Kontaktakte', 'My customers & contact records'), 'handshake'],
        'assignments'     => [pw_t('Einsatzboard für laufende Besetzungen', 'Assignment board for active placements'), 'calendar'],
        'assist_ai'       => [pw_t('Pure Assist mit Datenhilfe', 'Pure Assist with data guidance'), 'spark'],

        'cv_assistant'      => [pw_t('CV-Assistent & Profilcheck', 'CV assistant & profile check'), 'document'],
        'smart_matching'    => [pw_t('Smart-Matching & Mehrfachzuordnung', 'Smart matching & bulk submission'), 'spark'],
        'availability_sync' => [pw_t('Verfügbarkeits- & Pool-Automatik', 'Availability & pool automation'), 'clock'],
        'lead_intelligence' => [pw_t('Qualitäts-Leads mit Priorisierung', 'Quality leads with prioritisation'), 'target'],
        'capacity_forecast' => [pw_t('30-Tage-Kapazitätsvorschau', '30-day capacity forecast'), 'chart'],
        'worker_import'   => [pw_t('CSV-Import für Mitarbeiter', 'CSV import for employees'), 'upload'],
        'marketdata'      => [pw_t('Berufe & Marktdaten', 'Occupations & market data'), 'grid'],
        'leads_unlimited' => [pw_t('Leads ohne Mengenbegrenzung', 'Leads without a volume cap'), 'search'],
        'automations'     => [pw_t('Automationen für Disposition & Vertrieb', 'Automations for dispatch & sales'), 'spark'],
        'daily_digest'    => [pw_t('Täglicher Chancen- & Aufgaben-Digest', 'Daily opportunity & task digest'), 'bell'],
        'pool_health'     => [pw_t('Pool-Aktualitätsprüfung', 'Pool freshness checks'), 'check'],
        'invoicing'       => [pw_t('Abrechnung & Rechnungsentwürfe', 'Billing & invoice drafts'), 'receipt'],
        'rate_calculator' => [pw_t('Verrechnungssatz- & Margenrechner', 'Bill-rate & margin calculator'), 'calculator'],
        'risk_watch'      => [pw_t('Besetzungs-Risiko-Wächter', 'Placement risk watchdog'), 'alert'],
        'timesheets'      => [pw_t('Stundenfreigabe mit Auftraggeber', 'Timesheet approval with client'), 'check'],
        'einvoice'        => [pw_t('E-Rechnung mit XRechnung-Export', 'E-invoicing with XRechnung export'), 'document'],
        'leads_targets'   => [pw_t('Zielkunden mit belegtem Bedarf', 'Target accounts with evidenced demand'), 'map'],
        'lead_import'     => [pw_t('Eigene Lead-Recherche importieren', 'Import your own lead research'), 'upload'],
        'research_tasks'  => [pw_t('Rechercheaufträge mit Gesprächsleitfaden', 'Research tasks with call guides'), 'phone'],
        'blocklist'       => [pw_t('Sperrliste für Widersprüche', 'Block list for objections'), 'lock'],
        'advanced_insights'=> [pw_t('Erweitertes Performance-Cockpit', 'Advanced performance cockpit'), 'chart'],
        'hot_lead_automation'=> [pw_t('Hot-Lead-Radar mit Priorisierung', 'Hot-lead radar with prioritisation'), 'target'],
        'client_reports'  => [pw_t('Kundenstatus-Reports aus Einsätzen', 'Client status reports from assignments'), 'document'],
        'capacity_radar' => [pw_t('Kapazitätsradar für verfügbare Mitarbeiter', 'Capacity radar for available employees'), 'users'],
        'handover_briefing'=> [pw_t('Einsatzbriefing mit einem Klick', 'One-click assignment briefing'), 'document'],
        'compliance_watch'=> [pw_t('Einsatz-Prüfmarken für Equal Pay & Überlassungsdauer', 'Assignment checkpoints for equal pay & assignment duration'), 'alert'],
        'client_sla'=> [pw_t('Auftraggeber-Reaktionszeiten & Entscheidungsstau', 'Client response times & decision backlog'), 'clock'],
        'profile_studio'=> [pw_t('Profilstudio für Kundenprofile', 'Profile studio for client-ready profiles'), 'document'],
        'availability_planner'=> [pw_t('Verfügbarkeitsplaner für den Mitarbeiter-Pool', 'Availability planner for the employee pool'), 'calendar'],
        'placement_radar'=> [pw_t('Platzierungsradar über den gesamten Pool', 'Placement radar across the full pool'), 'target'],
    ];
}

function pw_plan_features($plan) {
    $matrix = pw_plan_feature_matrix();
    $order  = ['basic', 'professional', 'enterprise'];
    $out    = [];
    foreach ($order as $level) {
        $out = array_merge($out, $matrix[$level]);
        if ($level === $plan) break;
    }
    return array_values(array_unique($out));
}

function pw_current_plan($uid = 0) {
    if (!$uid) $uid = get_current_user_id();
    if (!$uid) return '';
    if (user_can($uid, 'manage_options')) return 'enterprise';
    if (pw_user_role($uid) !== 'agency') return 'client';
    $state = function_exists('pw_subscription_state') ? pw_subscription_state($uid) : [];
    $plan  = (string)($state['plan'] ?? 'basic');
    return in_array($plan, ['basic', 'professional', 'enterprise'], true) ? $plan : 'basic';
}

/**
 * Auftraggeber bezahlen nichts und werden nicht eingeschränkt. Für sie sind nur
 * die Bereiche relevant, die es in ihrer Rolle überhaupt gibt.
 */
function pw_can($feature, $uid = 0) {
    $plan = pw_current_plan($uid);
    if ($plan === 'client') return in_array($feature, ['vacancies','submissions','messages','notifications','knowledge','crm','assist_ai','assignments','timesheets','handover_briefing'], true);
    if ($plan === '') return false;
    return in_array($feature, pw_plan_features($plan), true);
}

function pw_plan_required_for($feature) {
    foreach (['basic', 'professional', 'enterprise'] as $level) {
        if (in_array($feature, pw_plan_feature_matrix()[$level], true)) return $level;
    }
    return 'enterprise';
}

/** Ein Hinweis, der erklärt statt nur zu sperren. */
function pw_plan_gate($feature) {
    $needed = pw_plan_required_for($feature);
    $labels = pw_plan_feature_labels();
    $what   = $labels[$feature][0] ?? $feature;
    $extras = [];
    foreach (pw_plan_feature_matrix()[$needed] as $f) {
        if ($f !== $feature && isset($labels[$f])) $extras[] = $labels[$f][0];
    }
    ob_start(); ?>
    <section class="pw-card pw-plan-gate">
      <div class="pw-plan-gate-head">
        <span class="pw-assist-orb"><?php echo pw_icon('lock'); ?></span>
        <div>
          <span class="pw-kicker"><?php echo esc_html(pw_t('IM TARIF', 'IN PLAN') . ' ' . pw_upper(pw_plan_public_label($needed))); ?></span>
          <h2><?php echo esc_html($what); ?></h2>
          <p class="pw-card-sub"><?php echo esc_html(sprintf(
            pw_t('Diese Funktion gehört zum Tarif %s. Dein aktueller Tarif: %s.', 'This feature belongs to the %s plan. Your current plan: %s.'),
            pw_plan_public_label($needed), pw_plan_public_label(pw_current_plan())
          )); ?></p>
        </div>
      </div>
      <?php if ($extras): ?>
        <div class="pw-chip-list"><?php foreach (array_slice($extras, 0, 5) as $e) echo '<span>' . esc_html($e) . '</span>'; ?></div>
      <?php endif; ?>
      <div class="pw-form-actions">
        <a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('account', ['tab' => 'billing'])); ?>"><?php echo esc_html(pw_t('Tarife ansehen', 'View plans')); ?> <?php echo pw_icon('arrow'); ?></a>
      </div>
    </section>
    <?php return ob_get_clean();
}

/** Übersicht im Konto: was ist offen, was kommt mit der nächsten Stufe. */
function pw_plan_overview_card($uid = 0) {
    if (!$uid) $uid = get_current_user_id();
    $plan = pw_current_plan($uid);
    if ($plan === 'client' || $plan === '') return '';
    $labels = pw_plan_feature_labels();
    $active = pw_plan_features($plan);
    $next = $plan === 'basic' ? 'professional' : ($plan === 'professional' ? 'enterprise' : '');
    $locked = $next ? pw_plan_feature_matrix()[$next] : [];
    ob_start(); ?>
    <section class="pw-card pw-plan-overview pw-v499-plan-overview">
      <div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('DEIN FUNKTIONSUMFANG','YOUR FEATURE SET')); ?></span><h2><?php echo esc_html(pw_t('Tarif ','Plan ').pw_plan_public_label($plan)); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Jede Funktion hat einen festen Platz – klicken, öffnen, arbeiten.','Every feature has a fixed place – click, open and work.')); ?></p></div><span class="pw-v499-plan-badge"><?php echo esc_html(pw_plan_public_label($plan)); ?></span></div>
      <div class="pw-v499-feature-grid">
        <?php foreach ($active as $f): if (!isset($labels[$f])) continue; $icon=$labels[$f][1]??'check'; ?>
          <div class="pw-v499-feature-tile is-on"><span><?php echo pw_icon($icon); ?></span><div><b><?php echo esc_html($labels[$f][0]); ?></b><small><?php echo esc_html(pw_t('Freigeschaltet','Unlocked')); ?></small></div></div>
        <?php endforeach; ?>
        <?php foreach ($locked as $f): if (!isset($labels[$f])) continue; ?>
          <div class="pw-v499-feature-tile is-off"><span><?php echo pw_icon('lock'); ?></span><div><b><?php echo esc_html($labels[$f][0]); ?></b><small><?php echo esc_html(pw_t('ab ','from ').pw_plan_public_label($next)); ?></small></div></div>
        <?php endforeach; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

/** Menge der sichtbaren Leads je Stufe. */
function pw_plan_lead_limit($uid = 0) {
    return pw_can('leads_unlimited', $uid) ? 0 : 10;
}
