<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.0.3 – Operations maturity pass.
 * Adds a compact operational command layer without adding navigation clutter.
 */
function pw_v503_upgrade(){
    if(get_option('pw_version_503','')==='5.0.3') return;
    if(function_exists('pw_install_theme')) pw_install_theme();
    update_option('pw_version_503','5.0.3',false);
}
add_action('init','pw_v503_upgrade',1200);

function pw_v503_sidebar_plan_panel($uid=0){
    if(!$uid)$uid=get_current_user_id();
    if(!$uid||pw_user_role($uid)!=='agency')return '';
    $plan=pw_current_plan($uid);$state=pw_subscription_state($uid);
    $label=pw_plan_public_label($plan);$status=$state['status']==='promo'?pw_t('kostenfrei','free'):($state['active']?pw_t('aktiv','active'):pw_t('prüfen','check'));
    return '<div class="pw-nav-divider"><span>'.esc_html(pw_t('MEIN TARIF','MY PLAN')).'</span></div><nav class="pw-nav pw-nav-secondary"><a class="pw-nav-item" href="'.esc_url(pw_page_url('account',['tab'=>'billing'])).'">'.pw_icon('spark').'<span>'.esc_html($label).'</span><em>'.esc_html($status).'</em></a></nav>';
}

function pw_v503_guard_thresholds($uid){
    $equal=(int)pw_user_meta($uid,'pw_guard_equal_months',9);
    $max=(int)pw_user_meta($uid,'pw_guard_max_months',18);
    $equal=max(1,min(60,$equal)); $max=max($equal+1,min(84,$max));
    return [$equal,$max];
}

function pw_v503_assignment_checkpoints($uid){
    if(!function_exists('pw_v499_active_assignments')) return [];
    [$equal,$max]=pw_v503_guard_thresholds($uid); $now=current_time('timestamp'); $items=[];
    foreach(pw_v499_active_assignments($uid) as $sid){
        $st=pw_meta($sid,'pw_status','submitted');
        if(!in_array($st,['identity_released','confirmed','planned'],true)) continue;
        $vid=(int)pw_meta($sid,'pw_vacancy_id',0); $wid=(int)pw_meta($sid,'pw_worker_id',0);
        if(!$vid||!$wid) continue; $v=pw_vacancy_fields($vid); $w=pw_worker_fields($wid);
        $start=!empty($v['start_date'])?strtotime($v['start_date'].' 12:00:00'):0; if(!$start) continue;
        foreach([
            ['key'=>'equal','months'=>$equal,'label'=>pw_t('Equal-Pay-Prüfmarke','Equal-pay checkpoint')],
            ['key'=>'max','months'=>$max,'label'=>pw_t('Überlassungsdauer-Prüfmarke','Assignment-duration checkpoint')],
        ] as $cp){
            $due=strtotime('+'.$cp['months'].' months',$start); $days=(int)floor(($due-$now)/DAY_IN_SECONDS);
            $tone=$days<=30?'danger':($days<=90?'warning':'muted');
            $items[]=['sid'=>$sid,'vid'=>$vid,'wid'=>$wid,'type'=>$cp['key'],'label'=>$cp['label'],'months'=>$cp['months'],'due'=>$due,'days'=>$days,'tone'=>$tone,'worker'=>$w,'vacancy'=>$v];
        }
    }
    usort($items,function($a,$b){return $a['due']<=>$b['due'];}); return $items;
}

function pw_v503_days_label($days){
    if($days<0) return sprintf(pw_t('seit %d Tagen prüfen','review overdue by %d days'),abs($days));
    if($days===0) return pw_t('heute prüfen','review today');
    return sprintf(pw_t('in %d Tagen','in %d days'),$days);
}

function pw_v503_compliance_center($uid,$compact=false){
    if(!pw_can('compliance_watch',$uid)){
        if($compact) return '<section class="pw-card pw-v503-guard is-locked"><div class="pw-v503-lockline">'.pw_icon('lock').'<div><span class="pw-kicker">'.esc_html(pw_t('PURE EINSATZWÄCHTER','PURE GUARD')).'</span><b>'.esc_html(pw_t('Einsatz-Prüfmarken ab Pro','Assignment checkpoints from Pro')).'</b><small>'.esc_html(pw_t('Frühzeitig an Equal Pay und Überlassungsdauer denken.','Stay ahead of equal pay and assignment duration.')).'</small></div><a href="'.esc_url(pw_page_url('account',['tab'=>'billing'])).'">Pro →</a></div></section>';
        return '';
    }
    [$equal,$max]=pw_v503_guard_thresholds($uid); $items=pw_v503_assignment_checkpoints($uid); $near=array_values(array_filter($items,fn($x)=>$x['days']<=120));
    ob_start(); ?>
    <section class="pw-card pw-v503-guard <?php echo $compact?'is-compact':''; ?>">
      <div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE EINSATZWÄCHTER','PURE GUARD')); ?></span><h2><?php echo esc_html(pw_t('Einsätze mit Vorlauf prüfen','Review assignments before deadlines')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Prüfmarken statt Überraschungen. Pure Work erinnert – die konkrete tarifliche oder betriebliche Rechtslage bleibt individuell zu prüfen.','Checkpoints instead of surprises. Pure Work reminds you – the applicable collective or company-specific legal situation must still be checked individually.')); ?></p></div><span class="pw-v503-guard-count <?php echo $near?'warning':'success'; ?>"><?php echo count($near); ?></span></div>
      <div class="pw-v503-guard-list">
      <?php if(!$near): ?><div class="pw-empty compact"><?php echo pw_icon('check'); ?><p><?php echo esc_html(pw_t('Aktuell liegt keine Prüfmarke in den nächsten 120 Tagen.','No checkpoint falls within the next 120 days.')); ?></p></div>
      <?php else: foreach(array_slice($near,0,$compact?3:8) as $x): ?>
        <a href="<?php echo esc_url(pw_page_url('assignments')); ?>" class="<?php echo esc_attr($x['tone']); ?>"><span><?php echo pw_icon($x['type']==='max'?'alert':'clock'); ?></span><div><b><?php echo esc_html($x['worker']['code'].' · '.$x['worker']['role']); ?></b><small><?php echo esc_html($x['label'].' · '.$x['vacancy']['title']); ?></small></div><em><?php echo esc_html(pw_v503_days_label($x['days'])); ?></em></a>
      <?php endforeach; endif; ?>
      </div>
      <?php if(!$compact): ?><details class="pw-v503-guard-settings"><summary><?php echo pw_icon('settings'); ?> <?php echo esc_html(pw_t('Prüfmarken einstellen','Configure checkpoints')); ?></summary><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-form-grid two"><input type="hidden" name="action" value="pw_v503_guard_settings"><?php wp_nonce_field('pw_v503_guard_settings'); ?><label><?php echo esc_html(pw_t('Equal-Pay-Prüfmarke (Monate)','Equal-pay checkpoint (months)')); ?><input type="number" min="1" max="60" name="equal_months" value="<?php echo (int)$equal; ?>"></label><label><?php echo esc_html(pw_t('Überlassungsdauer-Prüfmarke (Monate)','Assignment-duration checkpoint (months)')); ?><input type="number" min="2" max="84" name="max_months" value="<?php echo (int)$max; ?>"></label><div class="full pw-form-actions"><button class="pw-btn primary small"><?php echo esc_html(pw_t('Prüfmarken speichern','Save checkpoints')); ?></button></div></form></details><?php endif; ?>
    </section><?php return ob_get_clean();
}

function pw_handle_v503_guard_settings(){
    if(!is_user_logged_in()||pw_user_role()!=='agency'||!pw_can('compliance_watch')) wp_die('Keine Berechtigung.');
    check_admin_referer('pw_v503_guard_settings'); $uid=get_current_user_id();
    $equal=max(1,min(60,(int)($_POST['equal_months']??9))); $max=max($equal+1,min(84,(int)($_POST['max_months']??18)));
    update_user_meta($uid,'pw_guard_equal_months',$equal); update_user_meta($uid,'pw_guard_max_months',$max);
    wp_safe_redirect(pw_page_url('assignments',['guard_saved'=>1])); exit;
}
add_action('admin_post_pw_v503_guard_settings','pw_handle_v503_guard_settings');

function pw_v503_agency_waiting_decisions($uid){
    $subs=get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>200,'meta_query'=>[['key'=>'pw_agency_id','value'=>$uid],['key'=>'pw_status','value'=>['submitted','viewed','shortlisted','on_hold'],'compare'=>'IN']]]);
    $late=0;$oldest=0;$now=time(); foreach($subs as $s){$age=max(0,(int)(($now-get_post_time('U',true,$s))/HOUR_IN_SECONDS));if($age>=48)$late++;$oldest=max($oldest,$age);} return ['total'=>count($subs),'late'=>$late,'oldest'=>$oldest];
}

function pw_v503_capacity_snapshot($uid){
    $workers=get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']);$today=wp_date('Y-m-d');$soonDate=wp_date('Y-m-d',time()+14*DAY_IN_SECONDS);
    $now=0;$soon=0;$reserved=0;$idle=0;
    foreach($workers as $id){$w=pw_worker_fields($id);if($w['status']==='inactive')continue;if($w['status']==='reserved')$reserved++;$from=$w['available_from']?:$today;if($w['status']==='available'&&$from<=$today)$now++;elseif($w['status']==='available'&&$from>$today&&$from<=$soonDate)$soon++;
        if($w['status']==='available'){$active=get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>1,'fields'=>'ids','meta_query'=>[['key'=>'pw_worker_id','value'=>$id],['key'=>'pw_status','value'=>['submitted','viewed','on_hold','accepted','identity_released','confirmed','planned','requested'],'compare'=>'IN']]]);if(!$active)$idle++;}
    }
    $best=function_exists('pw_best_vacancies_for_agency')?pw_best_vacancies_for_agency($uid,1):[];
    return ['now'=>$now,'soon'=>$soon,'reserved'=>$reserved,'idle'=>$idle,'best'=>$best?$best[0]:null];
}

function pw_v503_operations_center($uid){
    $c=pw_v503_capacity_snapshot($uid);$d=pw_v503_agency_waiting_decisions($uid);$guard=pw_can('compliance_watch',$uid)?pw_v503_assignment_checkpoints($uid):[];$near=count(array_filter($guard,fn($x)=>$x['days']<=90));$best=$c['best'];
    ob_start(); ?>
    <section class="pw-card pw-v503-ops">
      <div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE BETRIEB','PURE OPERATIONS')); ?></span><h2><?php echo esc_html(pw_t('Dein Betrieb in vier Signalen','Your operation in four signals')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Kapazität, Kundenentscheidungen, Einsätze und Abrechnung – ohne vier Seiten zu öffnen.','Capacity, client decisions, assignments and billing without opening four pages.')); ?></p></div><span class="pw-v503-live"><i></i> <?php echo esc_html(pw_t('LIVE','LIVE')); ?></span></div>
      <div class="pw-v503-signal-grid">
        <a href="<?php echo esc_url(pw_page_url('workers')); ?>"><span><?php echo pw_icon('users'); ?></span><b><?php echo (int)$c['now']; ?></b><small><?php echo esc_html(pw_t('jetzt verfügbar','available now')); ?></small><em><?php echo (int)$c['soon']; ?> <?php echo esc_html(pw_t('in 14 Tagen','within 14 days')); ?></em></a>
        <a href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><span><?php echo pw_icon('clock'); ?></span><b><?php echo pw_can('client_sla',$uid)?(int)$d['late']:'Max'; ?></b><small><?php echo esc_html(pw_can('client_sla',$uid)?pw_t('Entscheidungen >48 h','decisions >48 h'):pw_t('Reaktionszeiten','response times')); ?></small><em><?php echo pw_can('client_sla',$uid)?esc_html(sprintf(pw_t('%d Vorgänge warten','%d items waiting'),$d['total'])):esc_html(pw_t('ab Max','from Max')); ?></em></a>
        <a href="<?php echo esc_url(pw_page_url('assignments')); ?>"><span><?php echo pw_icon('alert'); ?></span><b><?php echo pw_can('compliance_watch',$uid)?(int)$near:'Pro'; ?></b><small><?php echo esc_html(pw_can('compliance_watch',$uid)?pw_t('Prüfmarken <90 Tage','checkpoints <90 days'):pw_t('Einsatz-Prüfmarken','assignment checkpoints')); ?></small><em><?php echo esc_html(pw_can('compliance_watch',$uid)?pw_t('Einsatzwächter','Pure Guard'):pw_t('ab Pro','from Pro')); ?></em></a>
        <a href="<?php echo esc_url(pw_page_url('invoices')); ?>"><span><?php echo pw_icon('receipt'); ?></span><b><?php echo function_exists('pw_v500_ready_timesheets_count')?(int)pw_v500_ready_timesheets_count($uid):0; ?></b><small><?php echo esc_html(pw_t('freigegeben & abrechenbar','approved & billable')); ?></small><em><?php echo esc_html(pw_t('direkt übernehmen','transfer directly')); ?></em></a>
      </div>
      <?php if($best): $v=pw_vacancy_fields($best['vacancy']->ID);$m=$best['workers'][0]??null;$w=$m?pw_worker_fields($m['worker']->ID):null; ?>
      <div class="pw-v503-bestmove"><span><?php echo pw_icon('spark'); ?></span><div><small><?php echo esc_html(pw_t('BESTER NÄCHSTER TREFFER','BEST NEXT MATCH')); ?></small><b><?php echo esc_html(($w?$w['code'].' · '.$w['role'].' → ':'').$v['title']); ?></b><em><?php echo (int)$best['best_score']; ?>%</em></div><a href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$v['id']])); ?>"><?php echo esc_html(pw_t('Öffnen','Open')); ?> <?php echo pw_icon('arrow'); ?></a></div>
      <?php elseif($c['idle']>0): ?><div class="pw-v503-bestmove muted"><span><?php echo pw_icon('users'); ?></span><div><small><?php echo esc_html(pw_t('FREIE KAPAZITÄT','UNASSIGNED CAPACITY')); ?></small><b><?php echo esc_html(sprintf(pw_t('%d verfügbare Mitarbeiter haben aktuell keinen laufenden Vorgang.','%d available employees currently have no active process.'),$c['idle'])); ?></b></div><a href="<?php echo esc_url(pw_page_url('matches')); ?>"><?php echo esc_html(pw_t('Vorschläge prüfen','Review suggestions')); ?> <?php echo pw_icon('arrow'); ?></a></div><?php endif; ?>
    </section><?php return ob_get_clean();
}

function pw_v503_client_decision_center($uid){
    $subs=pw_client_submissions($uid);$items=[];$now=time();
    foreach($subs as $s){$st=pw_meta($s->ID,'pw_status','submitted');if(!in_array($st,['submitted','viewed','shortlisted','on_hold'],true))continue;$hours=max(0,(int)(($now-get_post_time('U',true,$s))/HOUR_IN_SECONDS));$items[]=['post'=>$s,'hours'=>$hours];}
    usort($items,fn($a,$b)=>$b['hours']<=>$a['hours']);
    ob_start(); ?><section class="pw-card pw-v503-decisions"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('ENTSCHEIDUNGSCENTER','DECISION CENTER')); ?></span><h2><?php echo esc_html(pw_t('Profile entscheiden, bevor Tempo verloren geht','Decide on profiles before momentum is lost')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Die ältesten offenen Entscheidungen stehen oben. Ein Klick führt direkt zum Profil.','The oldest open decisions appear first. One click opens the profile directly.')); ?></p></div><span class="pw-focus-count"><?php echo count($items); ?></span></div><div class="pw-v503-decision-list">
    <?php if(!$items): ?><div class="pw-empty compact"><?php echo pw_icon('check'); ?><p><?php echo esc_html(pw_t('Keine Profilentscheidung offen.','No profile decision is open.')); ?></p></div><?php else: foreach(array_slice($items,0,5) as $it):$s=$it['post'];$wid=(int)pw_meta($s->ID,'pw_worker_id',0);$vid=(int)pw_meta($s->ID,'pw_vacancy_id',0);$w=pw_worker_fields($wid);$age=$it['hours']>=48?'danger':($it['hours']>=24?'warning':'brand');$when=$it['hours']<24?sprintf(pw_t('seit %d Std.','for %d h'),max(1,$it['hours'])):sprintf(pw_t('seit %d Tagen','for %d days'),max(1,(int)floor($it['hours']/24)));?><a class="<?php echo esc_attr($age); ?>" href="<?php echo esc_url(pw_page_url('vacancies',['submission'=>$s->ID])); ?>"><span class="pw-profile-code small"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><b><?php echo esc_html($w['code'].' · '.$w['role']); ?></b><small><?php echo esc_html(get_the_title($vid)); ?></small></div><em><?php echo esc_html($when); ?></em><?php echo pw_icon('arrow'); ?></a><?php endforeach;endif; ?></div></section><?php return ob_get_clean();
}

function pw_v503_handover_text($sid,$viewer=0){
    if(!$viewer)$viewer=get_current_user_id();if(!pw_can_access_submission($sid,$viewer))return '';$wid=(int)pw_meta($sid,'pw_worker_id',0);$vid=(int)pw_meta($sid,'pw_vacancy_id',0);$w=pw_worker_fields($wid);$v=pw_vacancy_fields($vid);$released=function_exists('pw_submission_identity_released')?pw_submission_identity_released($sid):false;$person=$released&&$w['full_name']?$w['full_name']:$w['code'];$client=pw_vacancy_client_label($vid,$viewer);$lines=[pw_t('PURE WORK · EINSATZBRIEFING','PURE WORK · ASSIGNMENT BRIEF'),'',pw_t('Mitarbeiter: ','Employee: ').$person,pw_t('Rolle: ','Role: ').$w['role'],pw_t('Auftrag: ','Job: ').$v['title'],pw_t('Auftraggeber: ','Client: ').$client,pw_t('Einsatzort: ','Location: ').($v['location']?:'–'),pw_t('Start: ','Start: ').pw_format_date($v['start_date']),pw_t('Arbeitszeit: ','Hours: ').($v['hours']?:'–'),pw_t('Schicht: ','Shift: ').($v['shift']?:'–')];$rate=pw_meta($sid,'pw_rate','');if($rate)$lines[]=pw_t('Verrechnungssatz: ','Bill rate: ').$rate;$lines[]='';$lines[]=pw_t('Nächster Schritt: Startdetails und Ansprechpartner im Chat final bestätigen.','Next step: confirm start details and contacts in chat.');return implode("\n",$lines);
}

function pw_shortcode_dashboard_v503(){
    if(!is_user_logged_in()) return pw_require_login_html();$uid=get_current_user_id();$role=pw_user_role($uid);$user=wp_get_current_user();$name=pw_user_meta($uid,'pw_contact',$user->display_name);$company=pw_user_meta($uid,'pw_company','');
    if($role==='agency'){
        ob_start();echo pw_portal_shell_start(pw_t('Start','Home'),pw_t('Heute erledigen, was Besetzung, Kunden und Abrechnung voranbringt.','Do today what moves staffing, clients and billing forward.'));echo pw_flash_messages();
        if(isset($_GET['panel'])&&$_GET['panel']==='notifications'){echo pw_dashboard_notifications_panel();echo pw_portal_shell_end();return ob_get_clean();}
        if(isset($_GET['panel'])&&$_GET['panel']==='insights'){echo pw_can('advanced_insights',$uid)?(function_exists('pw_v501_scale_insights')?pw_v501_scale_insights($uid):pw_v498_scale_insights($uid)):pw_plan_gate('advanced_insights');echo pw_portal_shell_end();return ob_get_clean();}
        $verify=pw_verification_state($uid);if(!$verify['ready'])echo '<div class="pw-onboarding-banner compact"><div>'.pw_icon('lock').'<div><span class="pw-kicker">'.esc_html(pw_t('VERIFIZIERUNG','VERIFICATION')).'</span><h3>'.esc_html(pw_t('Noch nicht vollständig freigeschaltet','Not fully unlocked yet')).'</h3><p>'.esc_html(pw_t('Prüfe E-Mail, Unternehmen und AÜG-Status.','Check e-mail, company and AÜG status.')).'</p></div></div><a class="pw-btn white small" href="'.esc_url(pw_page_url('account',['tab'=>'verification'])).'">'.esc_html(pw_t('Status','Status')).'</a></div>';
        $s=pw_v498_agency_snapshot($uid);$plan=pw_current_plan($uid);
        echo '<section class="pw-v499-hero"><div><div class="pw-v499-hero-line"><span class="pw-kicker">'.esc_html(pw_t('DEIN PURE WORK','YOUR PURE WORK')).'</span><span class="pw-v499-plan-pill">'.esc_html(pw_plan_public_label($plan)).'</span></div><h1>'.esc_html(pw_dashboard_greeting()).', '.esc_html($name).'.</h1><p>'.esc_html(pw_t('Pure Work zeigt dir nicht alles – sondern zuerst das, was heute Umsatz, Besetzung oder Kundentempo bewegt.','Pure Work does not show everything first – it shows what moves revenue, staffing or client momentum today.')).'</p></div><div class="pw-v499-hero-actions"><a class="pw-btn primary" href="'.esc_url(pw_page_url('workers',['new'=>1])).'">'.pw_icon('plus').' '.esc_html(pw_t('Mitarbeiter anlegen','Add employee')).'</a><button type="button" class="pw-btn ghost" data-pw-copilot-open>'.pw_icon('spark').' Pure Assist</button></div></section>';
        echo '<div class="pw-v499-kpi-row">'.pw_metric($s['requested'],pw_t('Anfragen brauchen Reaktion','requests need action'),pw_t('heute priorisieren','prioritise today'),$s['requested']?'warning':'').pw_metric($s['crm']['due'],pw_t('Kunden sind fällig','customers are due'),pw_t('Wiedervorlagen','follow-ups'),$s['crm']['due']?'warning':'').pw_metric($s['available'],pw_t('Mitarbeiter verfügbar','employees available'),$s['workers'].' '.pw_t('Profile gesamt','profiles total'),'brand').pw_metric($s['messages'],pw_t('Nachrichten offen','messages open'),pw_t('Kommunikation','communication'),$s['messages']?'warning':'').'</div>';
        echo pw_v499_risk_card($uid);echo '<div class="pw-v499-home-grid">'.pw_v498_action_center($uid,$role).pw_v498_copilot_card($uid).'</div>';echo pw_v503_operations_center($uid);echo pw_v499_flow_strip($uid);echo pw_v499_quick_tools($uid);echo pw_v498_compact_jobs($uid,4);if(pw_can('advanced_insights',$uid))echo function_exists('pw_v501_scale_insights')?pw_v501_scale_insights($uid):pw_v498_scale_insights($uid);echo pw_portal_shell_end();return ob_get_clean();
    }
    ob_start();echo pw_portal_shell_start(pw_t('Start','Home'),pw_t('Personalbedarf, Profile, Freigaben und Einsätze in einem Arbeitsfluss.','Demand, profiles, approvals and assignments in one workflow.'));echo pw_flash_messages();if(isset($_GET['panel'])&&$_GET['panel']==='notifications'){echo pw_dashboard_notifications_panel();echo pw_portal_shell_end();return ob_get_clean();}$verify=pw_verification_state($uid);if(!$verify['ready'])echo '<div class="pw-onboarding-banner compact"><div>'.pw_icon('lock').'<div><span class="pw-kicker">'.esc_html(pw_t('VERIFIZIERUNG','VERIFICATION')).'</span><h3>'.esc_html(pw_t('Unternehmensfreigabe noch offen','Company approval still pending')).'</h3><p>'.esc_html(pw_t('Nach der Prüfung sind alle sensiblen Marktplatzfunktionen verfügbar.','After approval all sensitive marketplace functions are available.')).'</p></div></div><a class="pw-btn white small" href="'.esc_url(pw_page_url('account',['tab'=>'verification'])).'">'.esc_html(pw_t('Status öffnen','Open status')).'</a></div>';$s=pw_v498_client_snapshot($uid);$pending=pw_v500_pending_timesheet_count($uid);
    echo '<section class="pw-v499-hero pw-v500-client-hero"><div><span class="pw-kicker">'.esc_html(pw_t('DEIN PURE WORK','YOUR PURE WORK')).'</span><h1>'.esc_html($company?:$name).'</h1><p>'.esc_html(pw_t('Bedarf einstellen, Profile entscheiden, Stunden freigeben und Einsätze verfolgen – mit einem klaren nächsten Schritt pro Vorgang.','Publish demand, decide on profiles, approve hours and track assignments with one clear next step per item.')).'</p></div><div class="pw-v499-hero-actions"><a class="pw-btn primary" href="'.esc_url(pw_page_url('vacancies',['new'=>1])).'">'.pw_icon('plus').' '.esc_html(pw_t('Personalbedarf anlegen','Create staffing request')).'</a><button type="button" class="pw-btn ghost" data-pw-copilot-open>'.pw_icon('spark').' Pure Assist</button></div></section>';
    echo '<div class="pw-v499-kpi-row">'.pw_metric($s['open'],pw_t('offene Aufträge','open jobs'),$s['jobs'].' '.pw_t('gesamt','total'),'brand').pw_metric($s['new'],pw_t('Profile brauchen Entscheidung','profiles need a decision'),pw_t('jetzt prüfen','review now'),$s['new']?'warning':'').pw_metric($pending,pw_t('Stundenfreigaben offen','timesheets awaiting approval'),pw_t('von Partnern','from partners'),$pending?'warning':'').pw_metric($s['messages'],pw_t('Nachrichten offen','messages open'),pw_t('Abstimmungen','coordination'),$s['messages']?'warning':'').'</div>';
    echo '<div class="pw-v500-client-grid">'.pw_v498_action_center($uid,$role).pw_v500_client_demand_starter().'</div>';echo pw_v503_client_decision_center($uid);echo pw_v500_client_staffing_monitor($uid);echo '<div class="pw-v500-client-grid">'.pw_v500_client_approval_center($uid).pw_v498_client_help_card().'</div>';echo pw_portal_shell_end();return ob_get_clean();
}
function pw_v503_register_dashboard(){remove_shortcode('pw_dashboard');add_shortcode('pw_dashboard','pw_shortcode_dashboard_v503');}
add_action('init','pw_v503_register_dashboard',1400);

function pw_v503_daily_guard(){
    foreach(get_users(['role'=>'pw_agency','fields'=>'ID']) as $uid){$uid=(int)$uid;if(!pw_can('compliance_watch',$uid)||pw_user_meta($uid,'pw_auto_compliance_watch','0')!=='1')continue;$day=wp_date('Y-m-d');if(pw_user_meta($uid,'pw_auto_compliance_watch_last','')===$day)continue;$near=array_values(array_filter(pw_v503_assignment_checkpoints($uid),fn($x)=>$x['days']<=30));if($near){$first=$near[0];pw_create_notice($uid,pw_t('Einsatz-Prüfmarke nähert sich','Assignment checkpoint approaching'),sprintf(pw_t('%d Prüfmarken liegen innerhalb der nächsten 30 Tage. Nächster Punkt: %s · %s.','%d checkpoints fall within the next 30 days. Next: %s · %s.'),count($near),$first['worker']['code'],pw_v503_days_label($first['days'])),pw_page_url('assignments'));}update_user_meta($uid,'pw_auto_compliance_watch_last',$day);}
}
add_action('pw_daily_digest_event','pw_v503_daily_guard',45);
