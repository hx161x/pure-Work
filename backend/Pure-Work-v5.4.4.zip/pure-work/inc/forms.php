<?php
if (!defined('ABSPATH')) exit;

function pw_form_redirect($key, $args = []) {
    wp_safe_redirect(pw_page_url($key, $args));
    exit;
}

function pw_require_post_nonce($action) {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), $action)) {
        wp_die('Sicherheitsprüfung fehlgeschlagen.');
    }
}

function pw_handle_login() {
    // The admin-post action itself is the source of truth. Do not depend on the
    // submit button being present: browsers may omit it when the form is sent
    // with Enter, which previously made the login appear to simply reload.
    pw_require_post_nonce('pw_login');
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $pass = (string)($_POST['password'] ?? '');
    $remember = !empty($_POST['remember']);
    $redirect_to = esc_url_raw(wp_unslash($_POST['redirect_to'] ?? ''));
    if (!$email || !$pass) pw_form_redirect('login', ['error' => 'missing', 'email' => $email]);

    // Resolve the real WordPress username from the business e-mail first. This
    // removes any dependency on host/core e-mail-login filters and makes login
    // deterministic on every supported WordPress installation.
    $account = get_user_by('email', $email);
    $login_name = $account instanceof WP_User ? $account->user_login : $email;
    $user = wp_signon(['user_login'=>$login_name,'user_password'=>$pass,'remember'=>$remember], is_ssl());
    if (is_wp_error($user)) {
        $codes = $user->get_error_codes();
        if (in_array('pw_unverified', $codes, true)) $error = 'unverified';
        elseif (in_array('pw_aug_expired', $codes, true)) $error = 'aug_expired';
        else $error = 'credentials';
        pw_form_redirect('login',['error'=>$error,'email'=>$email]);
    }
    if (!in_array(pw_user_role($user->ID), ['agency','client'], true) && !user_can($user,'manage_options')) {
        wp_logout();
        pw_form_redirect('login',['error'=>'account','email'=>$email]);
    }
    update_user_meta($user->ID, 'pw_last_portal_login', time());
    if (function_exists('pw_audit_log')) pw_audit_log($user->ID, 'login', 'Portal login');
    if ($redirect_to && wp_validate_redirect($redirect_to, false)) {
        wp_safe_redirect($redirect_to);
        exit;
    }
    pw_form_redirect('dashboard',['welcome'=>1]);
}
add_action('admin_post_nopriv_pw_login','pw_handle_login');
add_action('admin_post_pw_login','pw_handle_login');

function pw_handle_register_legacy47() {
    pw_require_post_nonce('pw_register');
    $role = sanitize_key(wp_unslash($_POST['role'] ?? ''));
    if (!in_array($role,['agency','client'],true)) pw_form_redirect('register',['error'=>'role']);
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $company = sanitize_text_field(wp_unslash($_POST['company'] ?? ''));
    $contact = sanitize_text_field(wp_unslash($_POST['contact'] ?? ''));
    $zip = sanitize_text_field(wp_unslash($_POST['zip'] ?? ''));
    $city = sanitize_text_field(wp_unslash($_POST['city'] ?? ''));
    $industry = sanitize_text_field(wp_unslash($_POST['industry'] ?? ''));
    $phone = sanitize_text_field(wp_unslash($_POST['phone'] ?? ''));
    $terms = !empty($_POST['accept_terms']);
    $selected_plan = sanitize_key(wp_unslash($_POST['selected_plan'] ?? ''));
    if (!in_array($selected_plan,['client','basic','professional','enterprise'],true)) $selected_plan = '';
    if (!$email || !is_email($email) || email_exists($email) || strlen($password) < 8 || !$company || !$contact || !$terms) {
        pw_form_redirect('register',['type'=>$role,'error'=>'invalid']);
    }

    $aug_type = 'limited';
    $aug_expiry = '';
    if ($role === 'agency') {
        $aug_type = sanitize_key(wp_unslash($_POST['aug_type'] ?? 'limited'));
        if (!in_array($aug_type, ['limited','unlimited'], true)) $aug_type = 'limited';
        $aug_expiry = $aug_type === 'unlimited' ? '' : sanitize_text_field(wp_unslash($_POST['aug_expiry'] ?? ''));
        if ($aug_type === 'limited') {
            $expiry_ts = $aug_expiry ? strtotime($aug_expiry.' 23:59:59') : false;
            if (!$expiry_ts || $expiry_ts < time()) {
                pw_form_redirect('register',['type'=>'agency','error'=>'aug']);
            }
        }
        if (empty($_FILES['aug_file']['tmp_name'])) {
            pw_form_redirect('register',['type'=>'agency','error'=>'aug_file']);
        }
    }

    $base = sanitize_user(strtok($email,'@'), true) ?: 'purework';
    $login = $base; $i = 1;
    while (username_exists($login)) { $login = $base . $i; $i++; }
    $user_id = wp_insert_user([
        'user_login'=>$login,
        'user_email'=>$email,
        'user_pass'=>$password,
        'display_name'=>$contact,
        'role'=>$role === 'agency' ? 'pw_agency' : 'pw_client',
    ]);
    if (is_wp_error($user_id)) pw_form_redirect('register',['type'=>$role,'error'=>'create']);

    update_user_meta($user_id,'pw_company',$company);
    update_user_meta($user_id,'pw_contact',$contact);
    update_user_meta($user_id,'pw_phone',$phone);
    update_user_meta($user_id,'pw_zip',$zip);
    update_user_meta($user_id,'pw_city',$city);
    update_user_meta($user_id,'pw_industry',$industry);
    update_user_meta($user_id,'pw_email_verified','0');
    update_user_meta($user_id,'pw_lang',function_exists('pw_current_lang') ? pw_current_lang() : 'de');
    update_user_meta($user_id,'pw_company_verified','0'); // company review remains pending until the configured verification step
    update_user_meta($user_id,'pw_terms_accepted_at',time());
    update_user_meta($user_id,'pw_terms_version','4.6');
    update_user_meta($user_id,'pw_privacy_version','4.6');
    update_user_meta($user_id,'pw_notify_radius',50);
    update_user_meta($user_id,'pw_notify_frequency','immediate');
    update_user_meta($user_id,'pw_notify_clients','all');
    update_user_meta($user_id,'pw_message_email','1');
    update_user_meta($user_id,'pw_favorites',[]);
    update_user_meta($user_id,'pw_blocked_companies',[]);
    $geo = pw_geocode_location(trim($zip.' '.$city));
    if ($geo) { update_user_meta($user_id,'pw_lat',$geo['lat']); update_user_meta($user_id,'pw_lng',$geo['lng']); }

    if ($role === 'agency') {
        update_user_meta($user_id,'pw_plan','free');
        update_user_meta($user_id,'pw_plan_interest',$selected_plan && $selected_plan !== 'client' ? $selected_plan : 'professional');
        update_user_meta($user_id,'pw_subscription_status','active');
        update_user_meta($user_id,'pw_trial_until',0);
        update_user_meta($user_id,'pw_aug_type',$aug_type);
        update_user_meta($user_id,'pw_aug_expiry',$aug_expiry);
        update_user_meta($user_id,'pw_aug_verified','0');
        if (!empty($_FILES['aug_file']['tmp_name'])) {
            $file_id = pw_store_private_upload('aug_file',$user_id,'aug',0);
            if (!is_wp_error($file_id) && $file_id) update_user_meta($user_id,'pw_aug_file',(int)$file_id);
        }
    }

    // Production flow: create account -> confirm business e-mail -> log in.
    // We deliberately do not set an auth cookie before the confirmation step.
    $verification_sent = pw_send_verification_email($user_id);
    if ($role === 'agency') {
        pw_send_mail(
            $email,
            'Pure Work – Registrierung als Zeitarbeitsfirma',
            'Dein Pure Work Firmenkonto ist angelegt',
            'Deine Registrierung war erfolgreich. Bitte bestätige jetzt deine geschäftliche E-Mail-Adresse über den separaten Aktivierungslink. Danach kannst du dich jederzeit mit deiner E-Mail-Adresse und deinem Passwort anmelden. Deine AÜG-Unterlagen werden anschließend im geschützten Portalbereich geprüft.',
            'Zum Pure Work Zugang',
            home_url('/')
        );
    }
    $admin_email = get_option('admin_email');
    if (is_email($admin_email)) {
        pw_send_mail($admin_email,'Neue Pure Work Registrierung','Neues Unternehmen registriert',$company.' hat sich als '.($role === 'agency'?'Zeitarbeitsfirma':'Auftraggeber').' registriert. Die E-Mail-Adresse muss noch bestätigt werden.','Im WordPress-Backend prüfen',admin_url('admin.php?page=pure-work'));
    }
    // Keep the visitor signed out until the e-mail address was confirmed.
    wp_clear_auth_cookie();
    pw_form_redirect('login', ['registered'=>1,'email'=>$email,'mail_error'=>$verification_sent ? 0 : 1]);
}
add_action('admin_post_nopriv_pw_register','pw_handle_register');
add_action('admin_post_pw_register','pw_handle_register');


function pw_handle_password_request() {
    pw_require_post_nonce('pw_password_request');
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $sent_ok = true;

    // Simple abuse protection: at most three reset mails per address per hour.
    $throttle_key = 'pw_pwreset_' . md5(pw_lower($email));
    $attempts = (int)get_transient($throttle_key);

    if ($email && is_email($email) && $attempts < 3) {
        set_transient($throttle_key, $attempts + 1, HOUR_IN_SECONDS);
        $user = get_user_by('email', $email);
        if ($user && in_array(pw_user_role($user->ID), ['agency','client'], true)) {
            $key = get_password_reset_key($user);
            if (!is_wp_error($key)) {
                // The login is passed unencoded: add_query_arg()/WordPress handle the
                // URL encoding. Encoding it here as well produced a double-encoded
                // value that check_password_reset_key() could not resolve.
                $url = pw_page_url('password', [
                    'mode' => 'reset',
                    'key' => $key,
                    'login' => $user->user_login,
                ]);
                $lang = pw_user_meta($user->ID, 'pw_lang', 'de');
                if ($lang === 'en') {
                    $sent_ok = pw_send_mail($user->user_email,'Pure Work – Reset your password','Choose a new password','A password change was requested for your Pure Work account. The link is valid for 24 hours. If this was not you, simply ignore this message – your current password stays valid.','Reset password',$url);
                } else {
                    $sent_ok = pw_send_mail($user->user_email,'Pure Work – Passwort zurücksetzen','Neues Passwort festlegen','Für dein Pure Work Konto wurde eine Passwortänderung angefordert. Der Link ist 24 Stunden gültig. Wenn du das nicht warst, ignoriere diese Nachricht einfach – dein aktuelles Passwort bleibt gültig.','Passwort zurücksetzen',$url);
                }
            }
        }
    }

    // Keine Auskunft darüber, ob ein Konto existiert.
    pw_form_redirect('password', ['sent' => 1, 'mail_error' => $sent_ok ? 0 : 1]);
}
add_action('admin_post_nopriv_pw_password_request','pw_handle_password_request');
add_action('admin_post_pw_password_request','pw_handle_password_request');

function pw_handle_password_reset() {
    pw_require_post_nonce('pw_password_reset');
    $login = sanitize_user(rawurldecode((string)wp_unslash($_POST['login'] ?? '')), true);
    $key = sanitize_text_field(wp_unslash($_POST['key'] ?? ''));
    $pass1 = (string)($_POST['password'] ?? '');
    $pass2 = (string)($_POST['password_confirm'] ?? '');

    if (!$login || !$key) pw_form_redirect('password', ['error' => 'invalid']);
    if (strlen($pass1) < 8 || $pass1 !== $pass2) {
        pw_form_redirect('password', ['mode'=>'reset','key'=>$key,'login'=>rawurlencode($login),'error'=>'password']);
    }

    $user = check_password_reset_key($key, $login);
    if (is_wp_error($user)) pw_form_redirect('password', ['error' => 'invalid']);

    reset_password($user, $pass1);

    // Receiving the reset link proves control over the mailbox, so a still
    // pending e-mail confirmation is settled here. Otherwise a user could set a
    // new password and would still be refused at the login screen.
    if (!pw_email_is_verified($user->ID)) {
        update_user_meta($user->ID, 'pw_email_verified', '1');
        update_user_meta($user->ID, 'pw_email_verified_at', time());
        delete_user_meta($user->ID, 'pw_email_verify_hash');
        delete_user_meta($user->ID, 'pw_email_verify_expires');
        if (pw_user_role($user->ID) === 'client' && get_option('pw_auto_verify_clients', '0') === '1') {
            update_user_meta($user->ID, 'pw_company_verified', '1');
        }
    }
    delete_transient('pw_pwreset_' . md5(pw_lower($user->user_email)));

    pw_send_mail(
        $user->user_email,
        'Pure Work – Passwort geändert',
        'Passwort erfolgreich geändert',
        'Das Passwort deines Pure Work Kontos wurde geändert. Du kannst dich ab sofort mit dem neuen Passwort anmelden. Falls du das nicht warst, melde dich bitte umgehend beim Portalbetreiber.',
        'Jetzt anmelden',
        pw_page_url('login')
    );
    // Land the user directly on the sign-in screen with the address prefilled
    // instead of dropping them on the marketing home page.
    pw_form_redirect('login', ['password_reset' => 1, 'email' => $user->user_email]);
}
add_action('admin_post_nopriv_pw_password_reset','pw_handle_password_reset');
add_action('admin_post_pw_password_reset','pw_handle_password_reset');

function pw_handle_account_save() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    pw_require_post_nonce('pw_account_save');
    $uid = get_current_user_id();
    foreach (['company','contact','phone','zip','city','industry'] as $field) {
        if (isset($_POST[$field])) update_user_meta($uid,'pw_'.$field,sanitize_text_field(wp_unslash($_POST[$field])));
    }

    if (pw_user_role($uid) === 'agency') {
        if (isset($_POST['notify_radius'])) update_user_meta($uid,'pw_notify_radius',max(0,min(500,(int)$_POST['notify_radius'])));
        if (isset($_POST['notify_frequency'])) update_user_meta($uid,'pw_notify_frequency',in_array($_POST['notify_frequency'],['immediate','daily','portal'],true) ? sanitize_key($_POST['notify_frequency']) : 'immediate');
        if (isset($_POST['notify_clients'])) update_user_meta($uid,'pw_notify_clients',($_POST['notify_clients'] === 'favorites') ? 'favorites':'all');
        if (isset($_POST['notify_industries'])) update_user_meta($uid,'pw_notify_industries',pw_sanitize_csv_list(wp_unslash($_POST['notify_industries'])));

        $old_type = pw_user_meta($uid,'pw_aug_type','limited');
        $old_expiry = pw_user_meta($uid,'pw_aug_expiry','');
        $old_file = (int)pw_user_meta($uid,'pw_aug_file',0);
        $aug_changed = false;

        if (isset($_POST['aug_type'])) {
            $aug_type = sanitize_key(wp_unslash($_POST['aug_type']));
            if (!in_array($aug_type, ['limited','unlimited'], true)) $aug_type = 'limited';
            $aug_expiry = $aug_type === 'unlimited' ? '' : sanitize_text_field(wp_unslash($_POST['aug_expiry'] ?? ''));
            if ($aug_type === 'limited') {
                $ts = $aug_expiry ? strtotime($aug_expiry.' 23:59:59') : false;
                if (!$ts || $ts < time()) pw_form_redirect('account',['tab'=>'profile','error'=>'aug']);
            }
            update_user_meta($uid,'pw_aug_type',$aug_type);
            update_user_meta($uid,'pw_aug_expiry',$aug_expiry);
            if ($old_type !== $aug_type || $old_expiry !== $aug_expiry) $aug_changed = true;
        }

        if (!empty($_FILES['aug_file']['tmp_name'])) {
            $fid = pw_store_private_upload('aug_file',$uid,'aug',0);
            if (is_wp_error($fid) || !$fid) pw_form_redirect('account',['tab'=>'profile','error'=>'upload']);
            update_user_meta($uid,'pw_aug_file',(int)$fid);
            if ((int)$fid !== $old_file) $aug_changed = true;
        }

        if ($aug_changed) {
            update_user_meta($uid,'pw_aug_verified','0');
            update_user_meta($uid,'pw_aug_updated_at',time());
            if (function_exists('pw_aug_clear_reminder_flags')) pw_aug_clear_reminder_flags($uid);
            if (function_exists('pw_aug_refresh_lock_state')) pw_aug_refresh_lock_state($uid);
            $u=get_userdata($uid);
            if ($u) pw_send_mail($u->user_email,'Pure Work – AÜG-Daten aktualisiert','AÜG-Daten gespeichert','Deine AÜG-Angaben wurden aktualisiert und warten auf eine erneute Portalprüfung.','Verifizierungsstatus öffnen',pw_page_url('account',['tab'=>'verification']));
            $admin=get_option('admin_email');
            if (is_email($admin)) pw_send_mail($admin,'Pure Work – AÜG-Daten geändert','AÜG-Prüfung erforderlich',pw_user_meta($uid,'pw_company','Ein Personaldienstleister').' hat AÜG-Daten oder das AÜG-Dokument geändert.','Im Backend prüfen',admin_url('admin.php?page=pure-work'));
        }
    }

    $loc = trim(pw_user_meta($uid,'pw_zip','').' '.pw_user_meta($uid,'pw_city',''));
    $geo = pw_geocode_location($loc);
    if ($geo) { update_user_meta($uid,'pw_lat',$geo['lat']); update_user_meta($uid,'pw_lng',$geo['lng']); }
    pw_form_redirect('account',['saved'=>1]);
}
add_action('admin_post_pw_account_save','pw_handle_account_save');

function pw_handle_vacancy_save_legacy47() {
    if (!is_user_logged_in() || !in_array(pw_user_role(),['client','admin'],true)) wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_vacancy_save');
    if (!pw_account_active() && !current_user_can('manage_options')) pw_form_redirect('login',['error'=>'login']);
    $uid = get_current_user_id();
    $id = (int)($_POST['vacancy_id'] ?? 0);
    if ($id && ((int)get_post_field('post_author',$id) !== $uid) && !current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
    $description = sanitize_textarea_field(wp_unslash($_POST['description'] ?? ''));
    if (!$title) pw_form_redirect('vacancies',['error'=>'title']);
    $is_new = !$id;
    $postarr = ['post_type'=>'pw_vacancy','post_status'=>$is_new?'draft':'publish','post_title'=>$title,'post_content'=>$description,'post_author'=>$uid];
    if ($id) $postarr['ID']=$id;
    $id = wp_insert_post($postarr,true);
    if (is_wp_error($id)) pw_form_redirect('vacancies',['error'=>'save']);

    $fields = [
        'qty' => max(1,(int)($_POST['qty'] ?? 1)),
        'location' => sanitize_text_field(wp_unslash($_POST['location'] ?? '')),
        'start_date' => sanitize_text_field(wp_unslash($_POST['start_date'] ?? '')),
        'duration' => sanitize_text_field(wp_unslash($_POST['duration'] ?? '')),
        'hours' => sanitize_text_field(wp_unslash($_POST['hours'] ?? '')),
        'shift' => sanitize_text_field(wp_unslash($_POST['shift'] ?? '')),
        'industry' => sanitize_text_field(wp_unslash($_POST['industry'] ?? '')),
        'must_quals' => pw_sanitize_csv_list(wp_unslash($_POST['must_quals'] ?? '')),
        'nice_quals' => pw_sanitize_csv_list(wp_unslash($_POST['nice_quals'] ?? '')),
        'language' => sanitize_text_field(wp_unslash($_POST['language'] ?? '')),
        'driver' => !empty($_POST['driver']) ? '1':'0',
        'rate_max' => sanitize_text_field(wp_unslash($_POST['rate_max'] ?? '')),
        'deadline' => sanitize_text_field(wp_unslash($_POST['deadline'] ?? '')),
        'target_mode' => in_array($_POST['target_mode'] ?? 'all',['all','favorites','selected'],true) ? sanitize_key($_POST['target_mode']) : 'all',
        'target_agencies' => array_map('intval',(array)($_POST['target_agencies'] ?? [])),
        'status' => in_array($_POST['status'] ?? 'open',['open','paused','filled'],true) ? sanitize_key($_POST['status']) : 'open',
    ];
    foreach ($fields as $k=>$v) update_post_meta($id,'pw_'.$k,$v);
    $geo = pw_geocode_location($fields['location']);
    if ($geo) { update_post_meta($id,'pw_lat',$geo['lat']); update_post_meta($id,'pw_lng',$geo['lng']); }
    if ($is_new) wp_update_post(['ID'=>$id,'post_status'=>'publish']);
    pw_form_redirect('vacancies',['saved'=>1,'view'=>$id]);
}
add_action('admin_post_pw_vacancy_save','pw_handle_vacancy_save');

function pw_handle_vacancy_delete() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    $id = (int)($_GET['id'] ?? 0);
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')),'pw_delete_vacancy_'.$id)) wp_die('Sicherheitsprüfung fehlgeschlagen.');
    if ((int)get_post_field('post_author',$id) !== get_current_user_id() && !current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    wp_trash_post($id);
    pw_form_redirect('vacancies',['deleted'=>1]);
}
add_action('admin_post_pw_vacancy_delete','pw_handle_vacancy_delete');

function pw_handle_worker_save_legacy47() {
    if (!is_user_logged_in() || !in_array(pw_user_role(),['agency','admin'],true)) wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_worker_save');
    if (!pw_account_active() && !current_user_can('manage_options')) pw_form_redirect('login',['error'=>'login']);
    $uid = get_current_user_id();
    $id = (int)($_POST['worker_id'] ?? 0);
    if ($id && ((int)get_post_field('post_author',$id)!==$uid) && !current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    $role = sanitize_text_field(wp_unslash($_POST['role'] ?? ''));
    if (!$role) pw_form_redirect('workers',['error'=>'role']);
    $code = $id ? pw_meta($id,'pw_code','') : 'PW-'.strtoupper(wp_generate_password(6,false,false));
    $postarr = ['post_type'=>'pw_worker','post_status'=>'publish','post_title'=>$role.' · '.$code,'post_author'=>$uid]; if ($id) $postarr['ID']=$id;
    $id = wp_insert_post($postarr,true); if (is_wp_error($id)) pw_form_redirect('workers',['error'=>'save']);
    $fields = [
        'code'=>$code,
        'role'=>$role,
        'experience'=>max(0,(int)($_POST['experience'] ?? 0)),
        'location'=>sanitize_text_field(wp_unslash($_POST['location'] ?? '')),
        'available_from'=>sanitize_text_field(wp_unslash($_POST['available_from'] ?? '')),
        'shifts'=>pw_sanitize_csv_list(wp_unslash($_POST['shifts'] ?? '')),
        'qualifications'=>pw_sanitize_csv_list(wp_unslash($_POST['qualifications'] ?? '')),
        'languages'=>pw_sanitize_csv_list(wp_unslash($_POST['languages'] ?? '')),
        'driver'=>!empty($_POST['driver'])?'1':'0',
        'car'=>!empty($_POST['car'])?'1':'0',
        'industries'=>pw_sanitize_csv_list(wp_unslash($_POST['industries'] ?? '')),
        'last_assignment'=>sanitize_text_field(wp_unslash($_POST['last_assignment'] ?? '')),
        'status'=>in_array($_POST['status'] ?? 'available',['available','reserved','assigned','inactive'],true)?sanitize_key($_POST['status']):'available',
        'full_name'=>sanitize_text_field(wp_unslash($_POST['full_name'] ?? '')),
        'email'=>sanitize_email(wp_unslash($_POST['worker_email'] ?? '')),
        'phone'=>sanitize_text_field(wp_unslash($_POST['worker_phone'] ?? '')),
        'address'=>sanitize_text_field(wp_unslash($_POST['worker_address'] ?? '')),
    ];
    foreach ($fields as $k=>$v) update_post_meta($id,'pw_'.$k,$v);
    $geo=pw_geocode_location($fields['location']); if ($geo) {update_post_meta($id,'pw_lat',$geo['lat']);update_post_meta($id,'pw_lng',$geo['lng']);}
    if (!empty($_FILES['cv_file']['tmp_name'])) {
        $fid=pw_store_private_upload('cv_file',$uid,'cv',$id); if (!is_wp_error($fid) && $fid) update_post_meta($id,'pw_cv_file',(int)$fid);
    }
    if (!empty($_FILES['docs_file']['tmp_name'])) {
        $fid=pw_store_private_upload('docs_file',$uid,'qualification',$id); if (!is_wp_error($fid) && $fid) update_post_meta($id,'pw_docs_file',(int)$fid);
    }
    pw_form_redirect('workers',['saved'=>1,'view'=>$id]);
}
add_action('admin_post_pw_worker_save','pw_handle_worker_save');

function pw_handle_worker_delete() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    $id=(int)($_GET['id']??0); if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'pw_delete_worker_'.$id)) wp_die('Sicherheitsprüfung fehlgeschlagen.');
    if ((int)get_post_field('post_author',$id)!==get_current_user_id() && !current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    wp_trash_post($id); pw_form_redirect('workers',['deleted'=>1]);
}
add_action('admin_post_pw_worker_delete','pw_handle_worker_delete');

function pw_handle_worker_import_legacy47() {
    if (!is_user_logged_in() || pw_user_role()!=='agency') wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_worker_import');
    if (!pw_account_active()) pw_form_redirect('login',['error'=>'login']);
    if (empty($_FILES['csv_file']['tmp_name'])) pw_form_redirect('workers',['error'=>'csv']);
    $handle=fopen($_FILES['csv_file']['tmp_name'],'r'); if (!$handle) pw_form_redirect('workers',['error'=>'csv']);
    $first=fgets($handle); if ($first===false){fclose($handle);pw_form_redirect('workers',['error'=>'csv']);}
    $delimiter=substr_count($first,';')>substr_count($first,',')?';':',';
    $header=str_getcsv($first,$delimiter); if (!$header){fclose($handle);pw_form_redirect('workers',['error'=>'csv']);}
    $header=array_map(function($v){return sanitize_key(trim($v));},$header);
    $count=0; $uid=get_current_user_id();
    $max_import = 500;
    while (($row=fgetcsv($handle,0,$delimiter))!==false && $count<$max_import) {
        $data=[]; foreach ($header as $i=>$key) $data[$key]=$row[$i]??'';
        $role=sanitize_text_field($data['role']??''); if (!$role) continue;
        $code='PW-'.strtoupper(wp_generate_password(6,false,false));
        $id=wp_insert_post(['post_type'=>'pw_worker','post_status'=>'publish','post_author'=>$uid,'post_title'=>$role.' · '.$code]); if (is_wp_error($id)) continue;
        $map=[
            'code'=>$code,'role'=>$role,'experience'=>(int)($data['experience']??0),'location'=>sanitize_text_field($data['location']??''),
            'available_from'=>sanitize_text_field($data['available_from']??''),'shifts'=>pw_sanitize_csv_list($data['shifts']??''),'qualifications'=>pw_sanitize_csv_list($data['qualifications']??''),
            'languages'=>pw_sanitize_csv_list($data['languages']??''),'driver'=>!empty($data['driver'])?'1':'0','car'=>!empty($data['car'])?'1':'0',
            'industries'=>pw_sanitize_csv_list($data['industries']??''),'last_assignment'=>sanitize_text_field($data['last_assignment']??''),'status'=>'available',
            'full_name'=>sanitize_text_field($data['full_name']??''),'email'=>sanitize_email($data['email']??''),'phone'=>sanitize_text_field($data['phone']??''),'address'=>sanitize_text_field($data['address']??''),
        ];
        foreach ($map as $k=>$v) update_post_meta($id,'pw_'.$k,$v);
        if ($map['location']) { $geo=pw_geocode_location($map['location']); if($geo){update_post_meta($id,'pw_lat',$geo['lat']);update_post_meta($id,'pw_lng',$geo['lng']);} }
        $count++;
    }
    fclose($handle); pw_form_redirect('workers',['imported'=>$count]);
}
add_action('admin_post_pw_worker_import','pw_handle_worker_import');

function pw_create_submission_legacy47($vacancy_id,$worker_id,$rate='',$earliest='',$note='',$notify_client=true) {
    $agency=(int)get_post_field('post_author',$worker_id); $client=(int)get_post_field('post_author',$vacancy_id);
    if (!$agency || !$client) return new WP_Error('party','Parteien fehlen.');
    $existing=pw_submission_exists($vacancy_id,$worker_id); if ($existing) return $existing;
    $code=pw_meta($worker_id,'pw_code','Profil');
    $id=wp_insert_post(['post_type'=>'pw_submission','post_status'=>'publish','post_author'=>$agency,'post_title'=>$code.' → '.get_the_title($vacancy_id)]);
    if (is_wp_error($id)) return $id;
    update_post_meta($id,'pw_vacancy_id',$vacancy_id);update_post_meta($id,'pw_worker_id',$worker_id);update_post_meta($id,'pw_agency_id',$agency);update_post_meta($id,'pw_client_id',$client);
    update_post_meta($id,'pw_rate',sanitize_text_field($rate));update_post_meta($id,'pw_earliest',sanitize_text_field($earliest));update_post_meta($id,'pw_note',sanitize_textarea_field($note));
    update_post_meta($id,'pw_status','submitted');update_post_meta($id,'pw_released','0');
    $client_user=get_userdata($client); $w=pw_worker_fields($worker_id);
    if ($notify_client) {
        pw_create_notice($client,'Neues Mitarbeiterprofil eingereicht',$w['code'].' wurde auf „'.get_the_title($vacancy_id).'“ eingereicht.',pw_page_url('vacancies',['submission'=>$id]));
        if ($client_user) pw_send_mail($client_user->user_email,'Neues Profil bei Pure Work','Neues Profil eingereicht',$w['role'].' · '.$w['experience'].' Jahre Erfahrung · '.$w['location'].' wurde auf deine Personalanfrage angeboten.','Profil ansehen',pw_page_url('vacancies',['submission'=>$id]));
    }
    return $id;
}

function pw_handle_submit_profile_legacy47() {
    if (!is_user_logged_in() || pw_user_role()!=='agency') wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_submit_profile');
    if (!pw_account_active()) pw_form_redirect('login',['error'=>'login']);
    $vacancy=(int)($_POST['vacancy_id']??0);$worker=(int)($_POST['worker_id']??0);
    if ((int)get_post_field('post_author',$worker)!==get_current_user_id() || !pw_agency_can_see_vacancy(get_current_user_id(),$vacancy)) wp_die('Keine Berechtigung.');
    $id=pw_create_submission($vacancy,$worker,wp_unslash($_POST['rate']??''),wp_unslash($_POST['earliest']??''),wp_unslash($_POST['note']??''));
    if (is_wp_error($id)) pw_form_redirect('vacancies',['error'=>'submit']);
    pw_form_redirect('vacancies',['submitted'=>1,'view'=>$vacancy]);
}
add_action('admin_post_pw_submit_profile','pw_handle_submit_profile');

function pw_handle_client_pool_request_legacy47() {
    if (!is_user_logged_in() || pw_user_role()!=='client') wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_client_pool_request');
    if (!pw_account_active()) pw_form_redirect('login',['error'=>'login']);
    $vacancy=(int)($_POST['vacancy_id']??0);$worker=(int)($_POST['worker_id']??0);
    if ((int)get_post_field('post_author',$vacancy)!==get_current_user_id() || get_post_type($worker)!=='pw_worker') wp_die('Keine Berechtigung.');
    if (pw_meta($vacancy,'pw_status','open') !== 'open') wp_die('Diese Personalanfrage ist nicht mehr offen.');
    $agency=(int)get_post_field('post_author',$worker);
    if (!$agency || !pw_account_active($agency) || !pw_agency_has_access($agency) || pw_is_demo_user($agency)!==pw_is_demo_user(get_current_user_id())) wp_die('Dieses Profil steht nicht zur Verfügung.');
    if (!in_array(pw_meta($worker,'pw_status','inactive'),['available','reserved'],true)) wp_die('Dieses Profil steht nicht zur Verfügung.');
    $id=pw_create_submission($vacancy,$worker,'','','Direktanfrage aus dem Talent Pool',false);
    if (is_wp_error($id)) pw_form_redirect('workers',['error'=>'request']);
    update_post_meta($id,'pw_status','requested');
    $u=get_userdata($agency);
    pw_create_notice($agency,'Konkrete Personalanfrage','Ein Auftraggeber hat '.pw_meta($worker,'pw_code','ein Profil').' für eine Personalanfrage angefragt.',pw_page_url('messages',['thread'=>$id]));
    if ($u) pw_send_mail($u->user_email,'Personalanfrage bei Pure Work','Ein Auftraggeber interessiert sich für dein Profil','Für '.get_the_title($vacancy).' wurde ein Profil aus deinem Pool konkret angefragt.','Anfrage öffnen',pw_page_url('messages',['thread'=>$id]));
    pw_form_redirect('workers',['requested'=>1]);
}
add_action('admin_post_pw_client_pool_request','pw_handle_client_pool_request');

function pw_handle_release_profile_legacy47() {
    if (!is_user_logged_in() || pw_user_role()!=='agency') wp_die('Keine Berechtigung.');
    $sid=(int)($_GET['submission']??0); if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'pw_release_'.$sid)) wp_die('Sicherheitsprüfung fehlgeschlagen.');
    [$agency,$client]=pw_submission_parties($sid); if ($agency!==get_current_user_id()) wp_die('Keine Berechtigung.');
    update_post_meta($sid,'pw_released','1');
    $u=get_userdata($client); pw_create_notice($client,'Profildaten freigegeben','Die Zeitarbeitsfirma hat die erweiterten Profildaten freigegeben.',pw_page_url('vacancies',['submission'=>$sid]));
    if ($u) pw_send_mail($u->user_email,'Profildaten freigegeben','Freigabe bestätigt','Die erweiterten Daten des angefragten Profils stehen dir jetzt im Portal zur Verfügung.','Profil öffnen',pw_page_url('vacancies',['submission'=>$sid]));
    pw_form_redirect('messages',['thread'=>$sid,'released'=>1]);
}
add_action('admin_post_pw_release_profile','pw_handle_release_profile');

function pw_handle_download_file() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    $id=(int)($_GET['file']??0); if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'pw_download_'.$id)) wp_die('Sicherheitsprüfung fehlgeschlagen.');
    if (!pw_can_download_file($id)) wp_die('Keine Berechtigung für diese Datei.');
    $path=pw_meta($id,'pw_path',''); if (!$path || !is_file($path)) wp_die('Datei nicht gefunden.');
    $mime=pw_meta($id,'pw_mime','application/octet-stream'); $name=get_the_title($id) ?: basename($path);
    nocache_headers(); header('Content-Type: '.$mime); header('Content-Length: '.filesize($path)); header('Content-Disposition: attachment; filename="'.rawurlencode($name).'"');
    readfile($path); exit;
}
add_action('admin_post_pw_download_file','pw_handle_download_file');

function pw_handle_mark_notices() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'pw_mark_notices')) wp_die('Sicherheitsprüfung fehlgeschlagen.');
    $q=get_posts(['post_type'=>'pw_notice','post_status'=>'publish','author'=>get_current_user_id(),'posts_per_page'=>-1,'fields'=>'ids']);
    foreach ($q as $id) update_post_meta($id,'pw_read','1');
    pw_form_redirect('dashboard',['panel'=>'notifications']);
}
add_action('admin_post_pw_mark_notices','pw_handle_mark_notices');
