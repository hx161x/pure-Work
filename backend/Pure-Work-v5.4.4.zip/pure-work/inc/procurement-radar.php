<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9.1 – official procurement radar.
 * Uses the open TED Search API and only promotes results to a Direct Lead when
 * a business contact can be resolved from the published TED notice XML.
 */

function pw_ted_staffing_query() {
    // 4.9.5: 79600000/79610000/79611000/79622000/79630000 ergänzt. Ohne sie fielen
    // allgemeine Personalbereitstellungs- und Vermittlungsvergaben durch das Raster.
    return 'classification-cpv IN (79600000 79610000 79611000 79620000 79621000 79622000 79623000 79624000 79625000 79630000) AND buyer-country = DEU';
}

function pw_ted_staffing_endpoints() {
    return [
        'https://api.ted.europa.eu/v3/notices/search',
        'https://tedweb.api.ted.europa.eu/v3/notices/search',
    ];
}

function pw_ted_scalar($value) {
    if (is_scalar($value)) return trim((string)$value);
    if (!is_array($value)) return '';
    foreach (['deu','de','ger','eng','en'] as $k) {
        if (isset($value[$k])) {
            $v = pw_ted_scalar($value[$k]);
            if ($v !== '') return $v;
        }
    }
    foreach ($value as $v) {
        $s = pw_ted_scalar($v);
        if ($s !== '') return $s;
    }
    return '';
}

function pw_ted_array_value($row, $keys) {
    foreach ((array)$keys as $key) {
        if (isset($row[$key])) return $row[$key];
        $alt = str_replace('-', '_', $key);
        if (isset($row[$alt])) return $row[$alt];
        $alt2 = str_replace('_', '-', $key);
        if (isset($row[$alt2])) return $row[$alt2];
    }
    return '';
}

function pw_ted_iso_date($value) {
    $s = pw_ted_scalar($value);
    if (!$s) return '';
    if (preg_match('/(20\d{2})[-\/]([01]\d)[-\/]([0-3]\d)/', $s, $m)) return $m[1].'-'.$m[2].'-'.$m[3];
    if (preg_match('/([0-3]\d)[\.\/]([01]\d)[\.\/](20\d{2})/', $s, $m)) return $m[3].'-'.$m[2].'-'.$m[1];
    $t = strtotime($s);
    return $t ? gmdate('Y-m-d', $t) : '';
}

function pw_ted_search_page($page = 1, $limit = 50) {
    $payload = [
        'query' => pw_ted_staffing_query(),
        'fields' => [
            'publication-number','publication-date','notice-title','buyer-name','notice-type',
            'classification-cpv','place-of-performance','deadline-receipt-tender-date-lot'
        ],
        'page' => max(1,(int)$page),
        'limit' => min(100,max(1,(int)$limit)),
        'scope' => 'ACTIVE',
        'checkQuerySyntax' => false,
        'paginationMode' => 'PAGE_NUMBER',
    ];
    $last_error = '';
    foreach (pw_ted_staffing_endpoints() as $endpoint) {
        $res = wp_remote_post($endpoint, [
            'timeout'=>18,
            'redirection'=>2,
            'headers'=>['Content-Type'=>'application/json','Accept'=>'application/json','User-Agent'=>'PureWork/'.PW_VERSION],
            'body'=>wp_json_encode($payload),
        ]);
        if (is_wp_error($res)) { $last_error = $res->get_error_message(); continue; }
        $code = (int)wp_remote_retrieve_response_code($res);
        $json = json_decode(wp_remote_retrieve_body($res), true);
        if ($code >= 200 && $code < 300 && is_array($json)) return $json;
        $last_error = 'HTTP '.$code;
    }
    return new WP_Error('ted_search_failed', $last_error ?: 'TED Search API nicht erreichbar.');
}

function pw_ted_rows_from_response($json) {
    if (!is_array($json)) return [];
    foreach (['notices','results','items','content'] as $key) {
        if (!empty($json[$key]) && is_array($json[$key])) return array_values($json[$key]);
    }
    $keys=array_keys($json); if ($keys === range(0, count($json)-1)) return $json;
    return [];
}

function pw_ted_notice_xml($publication_number) {
    $publication_number = preg_replace('/[^0-9\-]/','',(string)$publication_number);
    if (!$publication_number) return new WP_Error('bad_notice','Ungültige TED-ID.');
    $url = 'https://ted.europa.eu/en/notice/'.$publication_number.'/xml';
    $res = wp_remote_get($url,['timeout'=>16,'redirection'=>3,'headers'=>['Accept'=>'application/xml,text/xml,*/*','User-Agent'=>'PureWork/'.PW_VERSION]]);
    if (is_wp_error($res)) return $res;
    $code=(int)wp_remote_retrieve_response_code($res);
    $body=wp_remote_retrieve_body($res);
    if ($code < 200 || $code >= 300 || !$body) return new WP_Error('ted_xml','TED XML HTTP '.$code);
    return $body;
}

function pw_ted_notice_contact_from_xml($xml, $buyer_name = '') {
    if (!$xml || !class_exists('DOMDocument')) return [];
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    if (!@$dom->loadXML($xml, LIBXML_NONET|LIBXML_NOCDATA)) { libxml_clear_errors(); return []; }
    libxml_clear_errors();
    $xp = new DOMXPath($dom);
    $buyer_norm = function_exists('pw_normalize_text') ? pw_normalize_text($buyer_name) : strtolower($buyer_name);
    $best = [];
    $parties = $xp->query('//*[local-name()="Party" or local-name()="Organization"]');
    if ($parties) foreach ($parties as $party) {
        $nameNode = $xp->query('.//*[local-name()="PartyName"]/*[local-name()="Name"] | ./*[local-name()="Name"]', $party)->item(0);
        $name = $nameNode ? trim($nameNode->textContent) : '';
        $name_norm = function_exists('pw_normalize_text') ? pw_normalize_text($name) : strtolower($name);
        $emailNode = $xp->query('.//*[local-name()="ElectronicMail"]', $party)->item(0);
        $phoneNode = $xp->query('.//*[local-name()="Telephone"]', $party)->item(0);
        $deptNode  = $xp->query('.//*[local-name()="Department" or local-name()="ContactPoint" or local-name()="JobTitle"]', $party)->item(0);
        $email = $emailNode ? sanitize_email(trim($emailNode->textContent)) : '';
        $phone = $phoneNode ? sanitize_text_field(trim($phoneNode->textContent)) : '';
        $dept  = $deptNode ? sanitize_text_field(trim($deptNode->textContent)) : '';
        if (!$email && !$phone) continue;
        $candidate=['name'=>$name,'role'=>$dept ?: 'Vergabe-/Beschaffungsstelle','email'=>$email,'phone'=>$phone];
        if ($buyer_norm && $name_norm && (strpos($name_norm,$buyer_norm)!==false || strpos($buyer_norm,$name_norm)!==false)) return $candidate;
        if (!$best) $best=$candidate;
    }
    if ($best) return $best;
    $emailNode=$xp->query('//*[local-name()="ElectronicMail"]')->item(0);
    $phoneNode=$xp->query('//*[local-name()="Telephone"]')->item(0);
    return [
        'name'=>$buyer_name,
        'role'=>'Vergabe-/Beschaffungsstelle',
        'email'=>$emailNode ? sanitize_email(trim($emailNode->textContent)) : '',
        'phone'=>$phoneNode ? sanitize_text_field(trim($phoneNode->textContent)) : '',
    ];
}

function pw_ted_make_direct_lead($row) {
    if (!is_array($row)) return null;
    $pub = pw_ted_scalar(pw_ted_array_value($row,['publication-number','publicationNumber','notice-publication-number']));
    $pub = preg_replace('/[^0-9\-]/','',$pub);
    if (!$pub) return null;
    $title = pw_ted_scalar(pw_ted_array_value($row,['notice-title','title']));
    $buyer = pw_ted_scalar(pw_ted_array_value($row,['buyer-name','buyerName','buyer']));
    if (!$title) $title='Arbeitnehmerüberlassung / Personaldienstleistung';
    $xml = pw_ted_notice_xml($pub);
    if (is_wp_error($xml)) return null;
    $contact = pw_ted_notice_contact_from_xml($xml,$buyer);
    $email = sanitize_email($contact['email'] ?? '');
    $phone = sanitize_text_field($contact['phone'] ?? '');
    if (!$email && !$phone) return null;
    $place = pw_ted_scalar(pw_ted_array_value($row,['place-of-performance','placeOfPerformance']));
    $deadline = pw_ted_iso_date(pw_ted_array_value($row,['deadline-receipt-tender-date-lot','deadline']));
    $published = pw_ted_iso_date(pw_ted_array_value($row,['publication-date','publicationDate']));
    $cpv = pw_ted_scalar(pw_ted_array_value($row,['classification-cpv','cpv']));
    if (preg_match('/\b(796\d{5})\b/',$cpv,$m)) $cpv=$m[1];
    $q = ($email && $phone) ? 99 : 97;
    return [
        'lead_id'=>'PWDL-TED-'.str_replace('-','',$pub),
        'company'=>$buyer ?: 'Öffentlicher Auftraggeber',
        'title'=>$title,
        'city'=>$place,
        'region'=>'Deutschland',
        'deadline'=>$deadline,
        'published'=>$published,
        'contact_name'=>'',
        'contact_role'=>sanitize_text_field($contact['role'] ?? 'Vergabe-/Beschaffungsstelle'),
        'email'=>$email,
        'phone'=>$phone,
        'cpv'=>$cpv ?: '79620000',
        'notice_id'=>$pub,
        'source_name'=>'TED – Tenders Electronic Daily · Live-Sync',
        'source_url'=>'https://ted.europa.eu/de/notice/-/detail/'.$pub,
        'verified_at'=>wp_date('Y-m-d'),
        'quality'=>(string)$q,
        'sector'=>'Öffentliche Beschaffung',
        'summary'=>'Automatisch aus dem offiziellen TED-Beschaffungsradar importiert. Arbeitnehmerüberlassung/Personaldienstleistung über einschlägige CPV-Klassifikation; Kontakt aus dem veröffentlichten TED-Dokument.',
        'keywords'=>'TED,Arbeitnehmerüberlassung,Personaldienstleistung,Live',
    ];
}

function pw_procurement_radar_cached_leads() {
    $cached=get_option('pw_ted_staffing_leads_cache',[]);
    return is_array($cached)?$cached:[];
}

function pw_ted_staffing_sync($force = false) {
    $lock=(int)get_transient('pw_ted_staffing_sync_lock');
    if ($lock && !$force) return new WP_Error('busy','Sync läuft bereits.');
    set_transient('pw_ted_staffing_sync_lock',1,5*MINUTE_IN_SECONDS);
    $leads=[];$errors=[];$seen=[];
    for($page=1;$page<=2;$page++) {
        $json=pw_ted_search_page($page,30);
        if(is_wp_error($json)){ $errors[]=$json->get_error_message(); break; }
        $rows=pw_ted_rows_from_response($json);
        if(!$rows) break;
        foreach($rows as $row){
            $pub=pw_ted_scalar(pw_ted_array_value($row,['publication-number','publicationNumber','notice-publication-number']));
            if(!$pub || isset($seen[$pub])) continue;
            $seen[$pub]=1;
            $lead=pw_ted_make_direct_lead($row);
            if($lead) $leads[$lead['lead_id']]=$lead;
            if(count($seen)>=45) break 2; // polite fair-use cap per sync
        }
        if(count($rows)<30) break;
    }
    delete_transient('pw_ted_staffing_sync_lock');
    if($leads) update_option('pw_ted_staffing_leads_cache',$leads,false);
    $status=[
        'last_sync'=>current_time('mysql',true),
        'count'=>count($leads ?: pw_procurement_radar_cached_leads()),
        'fresh_count'=>count($leads),
        'error'=>implode(' · ',$errors),
    ];
    update_option('pw_ted_staffing_sync_status',$status,false);
    return $status;
}

function pw_ted_staffing_sync_status() {
    $s=get_option('pw_ted_staffing_sync_status',[]);
    return is_array($s)?$s:[];
}

function pw_ted_staffing_schedule() {
    if(!wp_next_scheduled('pw_ted_staffing_daily_sync')) wp_schedule_event(time()+300,'daily','pw_ted_staffing_daily_sync');
}
add_action('after_switch_theme','pw_ted_staffing_schedule');
add_action('init','pw_ted_staffing_schedule',30);
add_action('pw_ted_staffing_daily_sync',function(){ pw_ted_staffing_sync(false); });

function pw_ted_staffing_sync_admin() {
    if(!current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    check_admin_referer('pw_ted_staffing_sync_now');
    $r=pw_ted_staffing_sync(true);
    $url=admin_url('admin.php?page=pure-work-direct-leads&ted_sync=1');
    if(is_wp_error($r)) $url=add_query_arg('ted_error',rawurlencode($r->get_error_message()),$url);
    wp_safe_redirect($url);exit;
}
add_action('admin_post_pw_ted_staffing_sync_now','pw_ted_staffing_sync_admin');
