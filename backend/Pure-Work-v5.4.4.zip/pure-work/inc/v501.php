<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.0.1 – UX integration pass.
 * - plan tools use the exact sidebar grammar
 * - usable subscription/payment setup
 * - compact pricing
 * - calmer billing/e-invoice workspace
 * - richer target radar and Max cockpit
 * - strict DE/EN UI guard for the new OS labels
 */

function pw_v501_upgrade(){
    if(get_option('pw_version_501','')==='5.0.1') return;
    if(function_exists('pw_install_theme')) pw_install_theme();
    update_option('pw_version_501','5.0.1',false);
    flush_rewrite_rules(false);
}
add_action('init','pw_v501_upgrade',980);

/* -------------------------------------------------------------------------
 * Sidebar – no special card; exactly the same structure as all other groups.
 * ---------------------------------------------------------------------- */
function pw_v501_sidebar_plan_panel($uid=0){
    if(!$uid)$uid=get_current_user_id();
    if(!$uid||pw_user_role($uid)!=='agency')return '';
    $plan=pw_current_plan($uid);
    $state=pw_subscription_state($uid);
    $auto=0;
    foreach(['match_digest','followups','pool_health','risk_watch','timesheet_approval','billing_ready','invoice_due','hot_leads','compliance_watch'] as $key){
        if(pw_user_meta($uid,'pw_auto_'.$key,'0')==='1')$auto++;
    }
    $items=[
        ['__plan','spark',pw_plan_public_label($plan),pw_page_url('account',['tab'=>'billing'])],
        ['assist_ai','spark','Pure Assist','assist'],
        ['automations','bell',pw_t('Automationen','Automations'),pw_page_url('automations')],
        ['invoicing','receipt',pw_t('E-Rechnung','E-invoicing'),pw_page_url('invoices')],
        ['rate_calculator','calculator',pw_t('Kalkulation','Calculator'),pw_page_url('calculator')],
        ['leads_targets','target',pw_t('Zielkunden','Target accounts'),pw_page_url('market_live',['tab'=>'targets'])],
        ['advanced_insights','chart',pw_t('Performance','Performance'),pw_page_url('dashboard',['panel'=>'insights'])],
    ];
    ob_start(); ?>
      <div class="pw-nav-divider pw-v501-plan-divider"><span><?php echo esc_html(pw_t('MEIN TARIF','MY PLAN')); ?></span></div>
      <nav class="pw-nav pw-nav-secondary pw-v501-plan-nav" aria-label="<?php echo esc_attr(pw_t('Mein Tarif und Funktionen','My plan and features')); ?>">
      <?php foreach($items as $item):
          [$feature,$icon,$label,$url]=$item;
          if($feature==='__plan'){
              $status=$state['status']==='promo'?pw_t('frei','free'):($state['active']?pw_t('aktiv','active'):pw_t('prüfen','check'));
              ?>
              <a class="pw-nav-item pw-v501-plan-item" href="<?php echo esc_url($url); ?>"><?php echo pw_icon($icon); ?><span><?php echo esc_html($label); ?></span><em><?php echo esc_html($status); ?></em></a>
              <?php continue;
          }
          $open=pw_can($feature,$uid);$needed=pw_plan_required_for($feature);$assist=$url==='assist';if($assist)$open=true;
          $badge='';
          if($feature==='automations'&&pw_can('automations',$uid))$badge=(string)$auto;
          elseif(!$open)$badge=pw_plan_public_label($needed);
          if($assist): ?>
             <button type="button" class="pw-nav-item pw-v501-plan-item <?php echo pw_can('assist_ai',$uid)?'':'is-soft'; ?>" data-pw-copilot-open><?php echo pw_icon('spark'); ?><span><?php echo esc_html($label); ?></span><?php if(!pw_can('assist_ai',$uid)):?><em>Pro</em><?php endif;?></button>
          <?php else: ?>
             <a class="pw-nav-item pw-v501-plan-item <?php echo $open?'':'is-locked'; ?>" href="<?php echo esc_url($open?$url:pw_page_url('account',['tab'=>'billing'])); ?>"><?php echo pw_icon($open?$icon:'lock'); ?><span><?php echo esc_html($label); ?></span><?php if($badge!==''):?><em><?php echo esc_html($badge); ?></em><?php endif;?></a>
          <?php endif;
      endforeach; ?>
      </nav>
    <?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Stripe: collect payment details during the free phase, without charging.
 * ---------------------------------------------------------------------- */
function pw_v501_stripe_secret_ready(){return trim((string)get_option('pw_stripe_secret_key',''))!=='';}
function pw_v501_stripe_ensure_customer($uid){
    $existing=trim((string)pw_user_meta($uid,'pw_stripe_customer_id',''));
    if($existing)return $existing;
    if(!pw_v501_stripe_secret_ready())return new WP_Error('stripe','Stripe ist nicht konfiguriert.');
    $u=get_userdata($uid);if(!$u)return new WP_Error('user','Benutzer fehlt.');
    $customer=pw_stripe_api_post('customers',[
        'email'=>$u->user_email,
        'name'=>pw_user_meta($uid,'pw_company',$u->display_name),
        'metadata[user_id]'=>(string)$uid,
        'metadata[source]'=>'pure-work',
    ]);
    if(is_wp_error($customer))return $customer;
    if(empty($customer['id']))return new WP_Error('stripe','Stripe-Kunde konnte nicht angelegt werden.');
    update_user_meta($uid,'pw_stripe_customer_id',sanitize_text_field($customer['id']));
    return sanitize_text_field($customer['id']);
}
function pw_v501_payment_setup_session($uid){
    $customer=pw_v501_stripe_ensure_customer($uid);if(is_wp_error($customer))return $customer;
    return pw_stripe_api_post('checkout/sessions',[
        'mode'=>'setup',
        'customer'=>$customer,
        'billing_address_collection'=>'required',
        'success_url'=>pw_page_url('account',['tab'=>'billing','payment_setup'=>'success']).'&session_id={CHECKOUT_SESSION_ID}',
        'cancel_url'=>pw_page_url('account',['tab'=>'billing','payment_setup'=>'cancel']),
        'metadata[user_id]'=>(string)$uid,
        'setup_intent_data[metadata][user_id]'=>(string)$uid,
        'setup_intent_data[metadata][source]'=>'pure-work-subscription',
    ]);
}
function pw_handle_v501_payment_setup(){
    if(!is_user_logged_in()||pw_user_role()!=='agency')wp_die('Keine Berechtigung.');
    check_admin_referer('pw_v501_payment_setup');
    $s=pw_v501_payment_setup_session(get_current_user_id());
    if(!is_wp_error($s)&&!empty($s['url'])){wp_redirect(esc_url_raw($s['url']));exit;}
    $msg=is_wp_error($s)?$s->get_error_message():'Stripe';
    wp_safe_redirect(pw_page_url('account',['tab'=>'billing','payment_setup'=>'error','detail'=>rawurlencode($msg)]));exit;
}
add_action('admin_post_pw_v501_payment_setup','pw_handle_v501_payment_setup');

function pw_v501_subscription_workspace($uid){
    $s=pw_subscription_state($uid);$plans=pw_plan_definitions();$plan=$plans[$s['plan']]??$plans['professional'];
    $customer=trim((string)pw_user_meta($uid,'pw_stripe_customer_id',''));
    $stripe=pw_v501_stripe_secret_ready();
    $price=number_format_i18n((float)$plan['price'],0).' €';
    $until=$s['until']?wp_date('d.m.Y',$s['until']):'';
    $setup=sanitize_key($_GET['payment_setup']??'');
    ob_start(); ?>
    <?php if($setup==='success'):?><div class="pw-alert success"><div><strong><?php echo esc_html(pw_t('Zahlungsdaten gespeichert','Payment details saved')); ?></strong><span><?php echo esc_html(pw_t('Die Zahlungsmethode ist bei Stripe sicher hinterlegt und kann dort verwaltet werden.','The payment method is securely stored with Stripe and can be managed there.')); ?></span></div></div><?php elseif($setup==='error'):?><div class="pw-alert danger"><div><strong><?php echo esc_html(pw_t('Zahlungsdaten konnten nicht geöffnet werden','Payment setup could not be opened')); ?></strong><span><?php echo esc_html(sanitize_text_field(wp_unslash($_GET['detail']??''))); ?></span></div></div><?php endif; ?>
    <section class="pw-v501-subscription-hero">
      <div><span class="pw-kicker"><?php echo esc_html(pw_t('MEIN TARIF','MY PLAN')); ?></span><div class="pw-v501-subscription-title"><h2><?php echo esc_html($plan['label']); ?></h2><span class="pw-badge <?php echo esc_attr(pw_subscription_label($uid)[1]); ?>"><?php echo esc_html(pw_v500_subscription_status_label($s['status'])); ?></span></div><p><?php echo $s['status']==='promo'&&$until?esc_html(sprintf(pw_t('Kostenfrei bis %s. Danach %s pro Monat, sofern der Tarif aktiviert bleibt.','Free until %s. Then %s per month if the plan remains active.'),$until,$price)):esc_html(sprintf(pw_t('%s pro Monat. Tarif und Zahlungsdaten kannst du hier zentral verwalten.','%s per month. Manage plan and payment details here.'),$price)); ?></p></div>
      <a class="pw-btn ghost small" href="#tarife"><?php echo pw_icon('grid'); ?> <?php echo esc_html(pw_t('Tarife vergleichen','Compare plans')); ?></a>
    </section>
    <div class="pw-v501-subscription-grid">
      <section class="pw-card pw-v501-sub-card"><span class="pw-v501-sub-icon"><?php echo pw_icon('spark'); ?></span><div><small><?php echo esc_html(pw_t('AKTUELLER TARIF','CURRENT PLAN')); ?></small><h3><?php echo esc_html($plan['label']); ?></h3><p><?php echo esc_html($s['status']==='promo'?pw_t('Einführungsphase aktiv','Launch phase active'):pw_t('Regulärer Zugang','Regular access')); ?></p></div><a href="#tarife"><?php echo esc_html(pw_t('Ändern','Change')); ?> <?php echo pw_icon('arrow'); ?></a></section>
      <section class="pw-card pw-v501-sub-card"><span class="pw-v501-sub-icon"><?php echo pw_icon('receipt'); ?></span><div><small><?php echo esc_html(pw_t('ZAHLUNGSART','PAYMENT METHOD')); ?></small><h3><?php echo esc_html($customer?pw_t('Bei Stripe hinterlegt','Stored with Stripe'):pw_t('Noch nicht hinterlegt','Not added yet')); ?></h3><p><?php echo esc_html($customer?pw_t('Kartendaten oder andere Zahlungsarten bleiben bei Stripe.','Card or other payment details stay with Stripe.'):pw_t('Kann schon während der kostenfreien Phase hinterlegt werden.','Can be added during the free phase.')); ?></p></div><?php if($stripe):?><?php if($customer):?><a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_v500_customer_portal'),'pw_v500_customer_portal')); ?>"><?php echo esc_html(pw_t('Verwalten','Manage')); ?> <?php echo pw_icon('arrow'); ?></a><?php else:?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_v501_payment_setup"><?php wp_nonce_field('pw_v501_payment_setup');?><button class="pw-link-button"><?php echo esc_html(pw_t('Hinterlegen','Add')); ?> <?php echo pw_icon('arrow'); ?></button></form><?php endif;?><?php else:?><span class="pw-v501-muted-action"><?php echo esc_html(pw_t('Stripe noch nicht eingerichtet','Stripe not configured')); ?></span><?php endif;?></section>
      <section class="pw-card pw-v501-sub-card"><span class="pw-v501-sub-icon"><?php echo pw_icon('calendar'); ?></span><div><small><?php echo esc_html(pw_t('NÄCHSTER SCHRITT','NEXT STEP')); ?></small><h3><?php echo esc_html($s['status']==='promo'&&$until?sprintf(pw_t('Bis %s kostenfrei','Free until %s'),$until):pw_t('Zugang aktiv halten','Keep access active')); ?></h3><p><?php echo esc_html($customer?pw_t('Zahlungsdaten sind vorbereitet.','Payment details are ready.'):pw_t('Zahlungsdaten rechtzeitig ergänzen.','Add payment details in time.')); ?></p></div><a href="#tarife"><?php echo esc_html(pw_t('Tarif prüfen','Review plan')); ?> <?php echo pw_icon('arrow'); ?></a></section>
    </div>
    <?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Compact, useful pricing cards. Long feature lists are tucked into details.
 * ---------------------------------------------------------------------- */
function pw_v501_pricing_cards($inside=true){
    $plans=pw_plan_definitions();$promo=pw_launch_promo_available();$uid=is_user_logged_in()?get_current_user_id():0;$current=$uid&&pw_user_role($uid)==='agency'?pw_current_plan($uid):'';
    ob_start();if($promo):?><div class="pw-launch-banner"><span><?php echo pw_icon('spark'); ?></span><div><b><?php echo sprintf(esc_html(pw_t('Einführungsaktion: %d Monate kostenfrei','Launch offer: %d months free')),max(1,(int)get_option('pw_launch_promo_months',6))); ?></b><small><?php echo esc_html(pw_t('Für berechtigte neue Zeitarbeitsfirmen automatisch beim Start.','Automatically applied to eligible new staffing agencies.')); ?></small></div></div><?php endif; ?>
    <div class="pw-pricing-grid pw-pricing-grid-four pw-v501-pricing" id="tarife">
      <article class="client-plan"><span><?php echo esc_html(pw_t('AUFTRAGGEBER','CLIENTS')); ?></span><h3><b>0 €</b><small>/ <?php echo esc_html(pw_t('Monat','month')); ?></small></h3><p><?php echo esc_html(pw_t('Für Unternehmen mit Personalbedarf.','For companies needing staff.')); ?></p><ul><li><?php echo esc_html(pw_t('Aufträge veröffentlichen','Publish jobs')); ?></li><li><?php echo esc_html(pw_t('Profile & Besetzungen steuern','Manage profiles & placements')); ?></li><li><?php echo esc_html(pw_t('Stunden freigeben','Approve hours')); ?></li><li><?php echo esc_html(pw_t('Nachrichten & Partner','Messages & partners')); ?></li></ul><?php if(!$inside):?><a class="pw-btn ghost full" href="<?php echo esc_url(pw_page_url('register',['type'=>'client'])); ?>"><?php echo esc_html(pw_t('Kostenlos registrieren','Register free')); ?></a><?php endif;?></article>
      <?php foreach($plans as $key=>$p):$featured=$key==='professional';$isCurrent=$current===$key;$features=array_values($p['features']);$preview=array_slice($features,0,4);$rest=array_slice($features,4);?>
      <article class="<?php echo $featured?'featured ':'';echo $isCurrent?'is-current':'';?>"><?php if($featured):?><div class="pw-popular"><?php echo esc_html(pw_t('EMPFOHLEN','RECOMMENDED')); ?></div><?php endif;?><?php if($isCurrent):?><div class="pw-v501-current-plan"><?php echo esc_html(pw_t('DEIN TARIF','YOUR PLAN')); ?></div><?php endif;?><span><?php echo esc_html(strtoupper($p['label'])); ?></span><h3><b><?php echo esc_html(number_format_i18n($p['price'],0)); ?> €</b><small>/ <?php echo esc_html(pw_t('Monat','month')); ?></small></h3><?php if($promo):?><div class="pw-free-now"><?php echo sprintf(esc_html(pw_t('%d MONATE 0 €','%d MONTHS €0')),max(1,(int)get_option('pw_launch_promo_months',6))); ?></div><?php endif;?><ul><?php foreach($preview as $f)echo '<li>'.esc_html($f).'</li>';?></ul><?php if($rest):?><details class="pw-v501-plan-details"><summary><?php echo esc_html(sprintf(pw_t('%d weitere Funktionen','%d more features'),count($rest))); ?> <?php echo pw_icon('arrow'); ?></summary><ul><?php foreach($rest as $f)echo '<li>'.esc_html($f).'</li>';?></ul></details><?php endif;?><?php if($inside):?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_billing_checkout"><input type="hidden" name="plan" value="<?php echo esc_attr($key); ?>"><?php wp_nonce_field('pw_billing_checkout');?><button class="pw-btn <?php echo $featured?'primary':'ghost';?> full" <?php echo $isCurrent?'disabled':''; ?>><?php echo esc_html($isCurrent?pw_t('Aktueller Tarif','Current plan'):pw_t('Tarif wählen','Choose plan')); ?></button></form><?php else:?><a class="pw-btn <?php echo $featured?'primary':'ghost';?> full" href="<?php echo esc_url(pw_page_url('register',['type'=>'agency','plan'=>$key])); ?>"><?php echo esc_html(pw_t('Registrieren','Register')); ?></a><?php endif;?></article>
      <?php endforeach;?>
    </div><?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Account billing tab – real payment controls + compact plan comparison.
 * Other account tabs remain untouched.
 * ---------------------------------------------------------------------- */
function pw_shortcode_account_v501(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();$role=pw_user_role();$tab=sanitize_key($_GET['tab']??'profile');
    if($tab!=='billing'||$role!=='agency')return pw_shortcode_account();
    ob_start();echo pw_portal_shell_start(pw_t('Konto & Einstellungen','Account & settings'),pw_t('Tarif, Zahlung und Unternehmenszugang an einem Ort.','Plan, payment and company access in one place.'));echo pw_flash_messages();
    $tabs=['profile'=>pw_t('Unternehmen','Company'),'verification'=>pw_t('Verifizierung','Verification'),'notifications'=>pw_t('Benachrichtigungen','Notifications'),'billing'=>pw_t('Abo','Subscription'),'security'=>pw_t('Sicherheit','Security')];echo '<nav class="pw-tabs">';foreach($tabs as $k=>$l)echo '<a class="'.($tab===$k?'active':'').'" href="'.esc_url(pw_page_url('account',['tab'=>$k])).'">'.esc_html($l).'</a>';echo '</nav>';
    echo pw_v501_subscription_workspace($uid);echo pw_v501_pricing_cards(true);
    if(!pw_v501_stripe_secret_ready())echo '<div class="pw-source-note"><b>'.esc_html(pw_t('Zahlungsanbindung','Payment connection')).':</b> '.esc_html(pw_t('Der Administrator muss einmal den Stripe API-Zugang hinterlegen. Erst dann können Zahlungsdaten gespeichert und Abos automatisch abgerechnet werden.','The administrator must configure Stripe API access once. Payment details and automatic subscriptions become available after that.')).'</div>';
    echo pw_portal_shell_end();return ob_get_clean();
}
function pw_v501_register_account(){remove_shortcode('pw_account');add_shortcode('pw_account','pw_shortcode_account_v501');}
add_action('init','pw_v501_register_account',1100);

function pw_shortcode_pricing_v501(){ob_start();echo pw_public_header();?><section class="pw-simple-public pw-pricing-page"><div class="pw-public-wrap"><div class="pw-section-head narrow"><span class="pw-kicker"><?php echo esc_html(pw_t('ZUGÄNGE & TARIFE','ACCESS & PLANS')); ?></span><h1><?php echo esc_html(pw_t('Einfach starten. Mit dem Unternehmen wachsen.','Start simple. Grow with your company.')); ?></h1><p><?php echo esc_html(pw_t('Auftraggeber bleiben kostenlos. Zeitarbeitsfirmen wählen Basic, Pro oder Max. Details öffnest du nur bei Bedarf.','Clients remain free. Staffing agencies choose Basic, Pro or Max. Open details only when needed.')); ?></p></div><?php echo pw_v501_pricing_cards(false);?></div></section><?php return ob_get_clean();}
function pw_v501_register_pricing(){remove_shortcode('pw_pricing');add_shortcode('pw_pricing','pw_shortcode_pricing_v501');}
add_action('init','pw_v501_register_pricing',1100);

/* -------------------------------------------------------------------------
 * Billing UI – calmer workspace, standards visible, AI helper stays central.
 * ---------------------------------------------------------------------- */
function pw_v501_invoice_profile($uid){
    $b=pw_v500_billing_profile($uid);$b['standard']=pw_user_meta($uid,'pw_invoice_standard','xrechnung_b2b');$b['buyer_reference']=pw_user_meta($uid,'pw_invoice_buyer_reference','');return $b;
}
function pw_handle_v501_invoice_profile_save(){
    if(!is_user_logged_in()||pw_user_role()!=='agency'||!pw_can('invoicing'))wp_die('Keine Berechtigung.');check_admin_referer('pw_v501_invoice_profile');$uid=get_current_user_id();
    $map=['company'=>'pw_invoice_company','street'=>'pw_invoice_street','zip'=>'pw_invoice_zip','city'=>'pw_invoice_city','vat_id'=>'pw_invoice_vat_id','tax_id'=>'pw_invoice_tax_id','iban'=>'pw_invoice_iban','bic'=>'pw_invoice_bic','email'=>'pw_invoice_email'];
    foreach($map as $field=>$meta){$raw=wp_unslash($_POST[$field]??'');$val=$field==='email'?sanitize_email($raw):sanitize_text_field($raw);update_user_meta($uid,$meta,$val);}update_user_meta($uid,'pw_invoice_payment_days',max(1,min(120,(int)($_POST['payment_days']??14))));
    $standard=sanitize_key($_POST['standard']??'xrechnung_b2b');if(!in_array($standard,['xrechnung_b2b','xrechnung_b2g'],true))$standard='xrechnung_b2b';update_user_meta($uid,'pw_invoice_standard',$standard);update_user_meta($uid,'pw_invoice_buyer_reference',sanitize_text_field(wp_unslash($_POST['buyer_reference']??'')));
    wp_safe_redirect(pw_page_url('invoices',['profile_saved'=>1]));exit;
}
add_action('admin_post_pw_v501_invoice_profile_save','pw_handle_v501_invoice_profile_save');

function pw_v501_billing_profile_card($uid){$b=pw_v501_invoice_profile($uid);$complete=$b['company']&&$b['street']&&$b['zip']&&$b['city']&&$b['email']&&$b['vat_id']&&$b['iban'];ob_start();?>
<section class="pw-card pw-v501-billing-profile"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('RECHNUNGSSTANDARD & STAMMDATEN','INVOICE STANDARD & MASTER DATA')); ?></span><h2><?php echo esc_html(pw_t('Einmal einrichten. Danach nur noch abrechnen.','Set up once. Then just bill.')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Absender, Bankdaten und Standard gelten als Voreinstellung für neue E-Rechnungen.','Sender, bank details and standard are defaults for new e-invoices.')); ?></p></div><span class="pw-badge <?php echo $complete?'success':'warning'; ?>"><?php echo esc_html($complete?pw_t('bereit','ready'):pw_t('ergänzen','complete')); ?></span></div>
<div class="pw-v501-standard-strip"><span><?php echo pw_icon('document'); ?><div><small><?php echo esc_html(pw_t('STANDARD','STANDARD')); ?></small><b><?php echo esc_html($b['standard']==='xrechnung_b2g'?pw_t('XRechnung · öffentlicher Auftraggeber','XRechnung · public sector'):pw_t('XRechnung · B2B','XRechnung · B2B')); ?></b></div></span><span><?php echo pw_icon('receipt'); ?><div><small><?php echo esc_html(pw_t('FORMAT','FORMAT')); ?></small><b>UBL / EN 16931</b></div></span><span><?php echo pw_icon('clock'); ?><div><small><?php echo esc_html(pw_t('ZAHLUNGSZIEL','PAYMENT TERM')); ?></small><b><?php echo (int)$b['payment_days']; ?> <?php echo esc_html(pw_t('Tage','days')); ?></b></div></span></div>
<details <?php echo $complete?'':'open';?>><summary><?php echo pw_icon('settings'); ?><span><?php echo esc_html(pw_t('Standard & Rechnungsdaten bearbeiten','Edit standard & invoice details')); ?></span><?php echo pw_icon('arrow'); ?></summary><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pw-form-grid two"><input type="hidden" name="action" value="pw_v501_invoice_profile_save"><?php wp_nonce_field('pw_v501_invoice_profile');?><label class="full"><?php echo esc_html(pw_t('Rechnungsstandard','Invoice standard')); ?><select name="standard"><option value="xrechnung_b2b" <?php selected($b['standard'],'xrechnung_b2b');?>><?php echo esc_html(pw_t('XRechnung 3.0 · B2B','XRechnung 3.0 · B2B')); ?></option><option value="xrechnung_b2g" <?php selected($b['standard'],'xrechnung_b2g');?>><?php echo esc_html(pw_t('XRechnung 3.0 · öffentlicher Auftraggeber','XRechnung 3.0 · public sector')); ?></option></select></label><label class="full"><?php echo esc_html(pw_t('Standard-Bestellreferenz / Leitweg-ID','Default buyer reference / routing ID')); ?><input name="buyer_reference" value="<?php echo esc_attr($b['buyer_reference']); ?>" placeholder="<?php echo esc_attr(pw_t('optional bei B2B','optional for B2B')); ?>"></label><label class="full"><?php echo esc_html(pw_t('Firma','Company')); ?><input name="company" required value="<?php echo esc_attr($b['company']); ?>"></label><label class="full"><?php echo esc_html(pw_t('Straße & Hausnummer','Street & number')); ?><input name="street" required value="<?php echo esc_attr($b['street']); ?>"></label><label><?php echo esc_html(pw_t('PLZ','Postal code')); ?><input name="zip" required value="<?php echo esc_attr($b['zip']); ?>"></label><label><?php echo esc_html(pw_t('Ort','City')); ?><input name="city" required value="<?php echo esc_attr($b['city']); ?>"></label><label><?php echo esc_html(pw_t('Rechnungs-E-Mail','Invoice email')); ?><input type="email" name="email" required value="<?php echo esc_attr($b['email']); ?>"></label><label><?php echo esc_html(pw_t('USt-IdNr.','VAT ID')); ?><input name="vat_id" required value="<?php echo esc_attr($b['vat_id']); ?>"></label><label><?php echo esc_html(pw_t('Steuernummer','Tax number')); ?><input name="tax_id" value="<?php echo esc_attr($b['tax_id']); ?>"></label><label><?php echo esc_html(pw_t('IBAN','IBAN')); ?><input name="iban" required value="<?php echo esc_attr($b['iban']); ?>"></label><label><?php echo esc_html(pw_t('BIC','BIC')); ?><input name="bic" value="<?php echo esc_attr($b['bic']); ?>"></label><label><?php echo esc_html(pw_t('Zahlungsziel in Tagen','Payment term in days')); ?><input type="number" min="1" max="120" name="payment_days" value="<?php echo (int)$b['payment_days']; ?>"></label><div class="full pw-form-actions"><button class="pw-btn primary small"><?php echo esc_html(pw_t('Einstellungen speichern','Save settings')); ?></button></div></form></details></section><?php return ob_get_clean();}

function pw_v501_billing_steps($uid,$invoiceCount,$approved){$profile=pw_v501_invoice_profile($uid);$profileReady=$profile['company']&&$profile['street']&&$profile['vat_id']&&$profile['iban'];ob_start();?>
<div class="pw-v501-billing-steps"><a href="#rechnungsdaten" class="<?php echo $profileReady?'done':'';?>"><i><?php echo $profileReady?'✓':'1';?></i><span><small><?php echo esc_html(pw_t('SCHRITT 1','STEP 1')); ?></small><b><?php echo esc_html(pw_t('Rechnungsdaten','Invoice setup')); ?></b><em><?php echo esc_html($profileReady?pw_t('bereit','ready'):pw_t('einrichten','set up')); ?></em></span></a><a href="<?php echo esc_url(pw_page_url('timesheets')); ?>" class="<?php echo $approved?'done':'';?>"><i><?php echo $approved?'✓':'2';?></i><span><small><?php echo esc_html(pw_t('SCHRITT 2','STEP 2')); ?></small><b><?php echo esc_html(pw_t('Stunden freigeben','Approve hours')); ?></b><em><?php echo esc_html($approved?sprintf(pw_t('%d bereit','%d ready'),$approved):pw_t('optional','optional')); ?></em></span></a><a href="<?php echo esc_url(pw_page_url('invoices',['new'=>1])); ?>" class="<?php echo $invoiceCount?'done':'';?>"><i><?php echo $invoiceCount?'✓':'3';?></i><span><small><?php echo esc_html(pw_t('SCHRITT 3','STEP 3')); ?></small><b><?php echo esc_html(pw_t('E-Rechnung erstellen','Create e-invoice')); ?></b><em><?php echo esc_html($invoiceCount?sprintf(pw_t('%d vorhanden','%d existing'),$invoiceCount):pw_t('starten','start')); ?></em></span></a></div><?php return ob_get_clean();}

function pw_shortcode_invoices_v501(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();ob_start();echo pw_portal_shell_start(pw_t('E-Rechnung & Abrechnung','E-invoicing & billing'),pw_t('Rechnungsdaten, Kalkulation und E-Rechnung in einem ruhigen Arbeitsbereich.','Invoice setup, costing and e-invoicing in one calm workspace.'));echo pw_flash_messages();
    if(pw_user_role($uid)!=='agency'){echo '<section class="pw-card pw-empty"><h2>'.esc_html(pw_t('Abrechnung ist für Zeitarbeitsfirmen vorgesehen.','Billing is designed for staffing agencies.')).'</h2></section>';echo pw_portal_shell_end();return ob_get_clean();}
    if(!pw_can('invoicing',$uid)){echo pw_plan_gate('invoicing');echo pw_portal_shell_end();return ob_get_clean();}
    $view=(int)($_GET['view']??0);if($view){echo pw_v500_invoice_view($view,$uid);echo pw_portal_shell_end();return ob_get_clean();}
    $edit=(int)($_GET['edit']??0);if(!empty($_GET['new'])){echo '<div id="rechnungsdaten">'.pw_v501_billing_profile_card($uid).'</div>';echo '<section class="pw-v501-compose-intro"><div><span class="pw-kicker">PURE ASSIST</span><h2>'.esc_html(pw_t('Rechnung Schritt für Schritt erstellen','Create the invoice step by step')).'</h2><p>'.esc_html(pw_t('Der KI-Helfer prüft Pflichtangaben live. Wenn du den Verrechnungssatz zuerst kalkulieren möchtest, öffne die Kalkulation als eigenes Werkzeug.','The AI helper checks required information live. If you want to calculate the bill rate first, open the calculator as a separate tool.')).'</p><a class="pw-text-link" href="'.esc_url(pw_page_url('calculator')).'">'.pw_icon('calculator').' '.esc_html(pw_t('Kalkulation öffnen','Open calculator')).'</a></div><span>'.pw_icon('spark').'</span></section>';echo pw_v500_invoice_form($uid,(int)($_GET['submission']??0),$edit);echo pw_portal_shell_end();return ob_get_clean();}
    $invoices=get_posts(['post_type'=>'pw_invoice','post_status'=>'publish','author'=>$uid,'posts_per_page'=>100,'orderby'=>'date','order'=>'DESC']);$overdue=pw_v499_overdue_invoices($uid);$approved=pw_v500_ready_timesheets_count($uid);?>
    <section class="pw-v501-billing-hero"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE ABRECHNUNG','PURE BILLING')); ?></span><h1><?php echo esc_html(pw_t('E-Rechnung ohne Umwege','E-invoicing without detours')); ?></h1><p><?php echo esc_html(pw_t('Einmal Rechnungsstandard hinterlegen, Stunden übernehmen, Rechnung prüfen und strukturiert bereitstellen.','Set your invoice standard once, import hours, review the invoice and provide it in structured form.')); ?></p></div><div class="pw-v501-billing-actions"><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('invoices',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?> <?php echo esc_html(pw_t('E-Rechnung erstellen','Create e-invoice')); ?></a><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('calculator')); ?>"><?php echo pw_icon('calculator'); ?> <?php echo esc_html(pw_t('Kalkulation','Calculator')); ?></a></div></section>
    <?php echo pw_v501_billing_steps($uid,count($invoices),$approved); ?>
    <div id="rechnungsdaten"><?php echo pw_v501_billing_profile_card($uid); ?></div>
    <div class="pw-v501-billing-main"><section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('RECHNUNGEN','INVOICES')); ?></span><h2><?php echo esc_html(pw_t('Deine Rechnungen','Your invoices')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Entwurf, versendet und bezahlt – klar in einer Liste.','Draft, sent and paid – clearly in one list.')); ?></p></div><span class="pw-badge <?php echo $overdue?'warning':'success'; ?>"><?php echo $overdue?count($overdue).' '.esc_html(pw_t('überfällig','overdue')):esc_html(pw_t('alles im Blick','under control')); ?></span></div><div class="pw-v499-invoice-list"><?php if(!$invoices):?><div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch keine Rechnung. Du kannst direkt eine E-Rechnung starten oder zuerst freigegebene Stunden übernehmen.','No invoice yet. Start an e-invoice directly or import approved hours first.')); ?></p><div class="pw-form-actions"><a class="pw-btn primary small" href="<?php echo esc_url(pw_page_url('invoices',['new'=>1])); ?>"><?php echo esc_html(pw_t('E-Rechnung starten','Start e-invoice')); ?></a><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('timesheets')); ?>"><?php echo esc_html(pw_t('Stunden öffnen','Open hours')); ?></a></div></div><?php else:foreach($invoices as $inv):$st=pw_v499_invoice_meta($inv->ID,'status','draft');$labels=['draft'=>pw_t('Entwurf','Draft'),'sent'=>pw_t('Versendet','Sent'),'paid'=>pw_t('Bezahlt','Paid')];?><a href="<?php echo esc_url(pw_page_url('invoices',['view'=>$inv->ID])); ?>"><span class="pw-v499-invoice-icon"><?php echo pw_icon('receipt'); ?></span><div><b><?php echo esc_html(pw_v499_invoice_meta($inv->ID,'no')); ?> · <?php echo esc_html(pw_v499_invoice_meta($inv->ID,'customer')); ?></b><small><?php echo esc_html(pw_format_date(pw_v499_invoice_meta($inv->ID,'date'))); ?> · <?php echo esc_html($labels[$st]??$st); ?></small></div><strong><?php echo esc_html(pw_v499_money(pw_v499_invoice_meta($inv->ID,'gross'))); ?></strong><?php echo pw_icon('arrow'); ?></a><?php endforeach;endif;?></div></section><aside class="pw-card pw-v501-billing-help"><span class="pw-assist-orb"><?php echo pw_icon('spark'); ?></span><span class="pw-kicker">PURE ASSIST</span><h3><?php echo esc_html(pw_t('Was ist der nächste sinnvolle Schritt?','What is the next sensible step?')); ?></h3><?php if($approved):?><p><?php echo esc_html(sprintf(pw_t('%d freigegebene Stundenmeldung(en) warten auf Abrechnung.','%d approved timesheet(s) are ready for billing.'),$approved)); ?></p><a class="pw-btn primary small" href="<?php echo esc_url(pw_page_url('timesheets')); ?>"><?php echo esc_html(pw_t('Freigaben öffnen','Open approvals')); ?></a><?php elseif(!$invoices):?><p><?php echo esc_html(pw_t('Lege zuerst deine Rechnungsdaten fest oder starte direkt eine neue Rechnung.','Set your invoice details first or start a new invoice directly.')); ?></p><button class="pw-btn ghost small" type="button" data-pw-copilot-open><?php echo esc_html(pw_t('Pure Assist fragen','Ask Pure Assist')); ?></button><?php else:?><p><?php echo esc_html(pw_t('Prüfe offene Rechnungen oder nutze die Kalkulation für den nächsten Verrechnungssatz.','Review open invoices or use the calculator for the next bill rate.')); ?></p><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('calculator')); ?>"><?php echo esc_html(pw_t('Zur Kalkulation','Open calculator')); ?></a><?php endif;?></aside></div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}
function pw_v501_register_invoices(){remove_shortcode('pw_invoices');add_shortcode('pw_invoices','pw_shortcode_invoices_v501');}
add_action('init','pw_v501_register_invoices',1200);

/* -------------------------------------------------------------------------
 * Dedicated calculator – intentionally separate from e-invoicing.
 * ---------------------------------------------------------------------- */
function pw_shortcode_calculator_v501(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();ob_start();
    echo pw_portal_shell_start(pw_t('Kalkulation & Marge','Costing & margin'),pw_t('Verrechnungssatz kalkulieren, Marge verstehen und den fertigen Satz direkt in eine E-Rechnung übergeben.','Calculate the bill rate, understand margin and transfer the result directly into an e-invoice.'));echo pw_flash_messages();
    if(pw_user_role($uid)!=='agency'){echo '<section class="pw-card pw-empty"><h2>'.esc_html(pw_t('Die Kalkulation ist für Zeitarbeitsfirmen vorgesehen.','The calculator is designed for staffing agencies.')).'</h2></section>';echo pw_portal_shell_end();return ob_get_clean();}
    if(!pw_can('rate_calculator',$uid)){echo pw_plan_gate('rate_calculator');echo pw_portal_shell_end();return ob_get_clean();}
    ?>
    <section class="pw-v501-calculator-hero"><div><span class="pw-kicker"><?php echo esc_html(pw_t('PURE KALKULATION','PURE CALCULATOR')); ?></span><h1><?php echo esc_html(pw_t('Welcher Verrechnungssatz lohnt sich wirklich?','Which bill rate actually pays?')); ?></h1><p><?php echo esc_html(pw_t('Lohnkosten, Arbeitgeberfaktor, Gemeinkosten und Zielmarge werden transparent getrennt. Danach kannst du den empfohlenen Satz direkt in eine neue E-Rechnung übernehmen.','Wage costs, employer factor, overhead and target margin stay transparent. Then transfer the recommended rate directly into a new e-invoice.')); ?></p></div><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('invoices')); ?>"><?php echo pw_icon('receipt'); ?> <?php echo esc_html(pw_t('Zu E-Rechnungen','Open e-invoices')); ?></a></section>
    <div class="pw-v501-calculator-layout"><div><?php echo pw_v500_rate_calculator(); ?></div><aside class="pw-card pw-v501-calc-guide"><span class="pw-assist-orb"><?php echo pw_icon('spark'); ?></span><span class="pw-kicker">PURE ASSIST</span><h3><?php echo esc_html(pw_t('Kalkulation verstehen, bevor du anbietest.','Understand the calculation before you quote.')); ?></h3><div class="pw-v501-calc-guide-list"><span><i>1</i><div><b><?php echo esc_html(pw_t('Kostenbasis prüfen','Check cost base')); ?></b><small><?php echo esc_html(pw_t('Lohn + Arbeitgeberkosten + Gemeinkosten.','Wage + employer costs + overhead.')); ?></small></div></span><span><i>2</i><div><b><?php echo esc_html(pw_t('Zielmarge festlegen','Set target margin')); ?></b><small><?php echo esc_html(pw_t('Nicht nur Umsatz, sondern Deckungsbeitrag betrachten.','Focus on contribution, not just revenue.')); ?></small></div></span><span><i>3</i><div><b><?php echo esc_html(pw_t('Satz übernehmen','Transfer rate')); ?></b><small><?php echo esc_html(pw_t('Pure Work startet eine neue E-Rechnung mit dem berechneten Satz.','Pure Work starts a new e-invoice with the calculated rate.')); ?></small></div></span></div><button type="button" class="pw-btn ghost small" data-pw-copilot-open><?php echo pw_icon('spark'); ?> <?php echo esc_html(pw_t('Pure Assist fragen','Ask Pure Assist')); ?></button></aside></div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}
function pw_v501_register_calculator(){add_shortcode('pw_calculator','pw_shortcode_calculator_v501');}
add_action('init','pw_v501_register_calculator',1200);

/* -------------------------------------------------------------------------
 * Max cockpit: turn four dry numbers into interpreted operating signals.
 * ---------------------------------------------------------------------- */
function pw_v501_scale_insights($uid){
    if(!pw_can('advanced_insights',$uid))return '';$s=pw_v498_agency_snapshot($uid);$conversion=$s['submissions']?(int)round(($s['accepted']/$s['submissions'])*100):0;$pool=$s['workers']?(int)round((($s['workers']-$s['stale']-$s['incomplete'])/$s['workers'])*100):0;$pool=max(0,min(100,$pool));
    $health=(int)round(($conversion+$pool+min(100,$s['crm']['hot']*12)+min(100,$s['crm']['won']*10))/4);
    $tip=$pool<70?pw_t('Pool zuerst pflegen: veraltete und unvollständige Profile bremsen das Matching.','Clean the pool first: stale and incomplete profiles slow matching.'):($conversion<25?pw_t('Einreichungen prüfen: viele Vorschläge führen noch nicht zum Einsatz.','Review submissions: many suggestions are not yet turning into assignments.'):pw_t('Basis ist gesund. Fokus auf fällige Kunden und heiße Chancen.','The base is healthy. Focus on due customers and hot opportunities.'));
    ob_start();?>
    <section class="pw-card pw-v501-insights"><div class="pw-card-head"><div><span class="pw-kicker"><?php echo esc_html(pw_t('MAX PERFORMANCE','MAX PERFORMANCE')); ?></span><h2><?php echo esc_html(pw_t('Nicht nur Zahlen. Ein klarer Handlungsimpuls.','Not just numbers. A clear action signal.')); ?></h2><p class="pw-card-sub"><?php echo esc_html(pw_t('Pure Work verbindet Besetzung, Pool und Vertrieb zu einem Betriebsbild.','Pure Work connects placements, pool and sales into one operating picture.')); ?></p></div><span class="pw-v501-health-ring" style="--p:<?php echo (int)$health;?>"><b><?php echo (int)$health;?></b><small>/100</small></span></div><div class="pw-v501-insight-grid"><article><span><?php echo pw_icon('check'); ?></span><div><b><?php echo (int)$conversion;?>%</b><small><?php echo esc_html(pw_t('Einreichung → Einsatz','submission → assignment')); ?></small></div><i style="--p:<?php echo (int)$conversion;?>%"></i></article><article><span><?php echo pw_icon('users'); ?></span><div><b><?php echo (int)$pool;?>%</b><small><?php echo esc_html(pw_t('Pool-Qualität','pool quality')); ?></small></div><i style="--p:<?php echo (int)$pool;?>%"></i></article><article><span><?php echo pw_icon('target'); ?></span><div><b><?php echo (int)$s['crm']['hot'];?></b><small><?php echo esc_html(pw_t('heiße Kundenchancen','hot customer opportunities')); ?></small></div></article><article><span><?php echo pw_icon('handshake'); ?></span><div><b><?php echo (int)$s['crm']['won'];?></b><small><?php echo esc_html(pw_t('gewonnene Kunden','won customers')); ?></small></div></article></div><div class="pw-v501-insight-tip"><span><?php echo pw_icon('spark'); ?></span><div><small>PURE ASSIST</small><b><?php echo esc_html($tip); ?></b></div><button type="button" class="pw-btn ghost small" data-pw-copilot-open><?php echo esc_html(pw_t('Warum?','Why?')); ?></button></div></section>
    <?php return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Target radar wrapper: gives context and a three-step visual workflow.
 * ---------------------------------------------------------------------- */
function pw_shortcode_leads_hub_v501(){
    $html=pw_shortcode_leads_hub_495();
    if(sanitize_key($_GET['tab']??'contacts')!=='targets'||pw_user_role()!=='agency')return $html;
    ob_start();?><section class="pw-v501-radar-hero"><div><span class="pw-kicker"><?php echo esc_html(pw_t('ZIELKUNDEN-RADAR','TARGET ACCOUNT RADAR')); ?></span><h2><?php echo esc_html(pw_t('Aus einem Signal wird ein nächster Vertriebs-Schritt.','Turn a signal into the next sales step.')); ?></h2><p><?php echo esc_html(pw_t('Pure Work zeigt nur belegte Bedarfssignale. Du siehst sofort, ob recherchieren, anrufen oder ins CRM übernehmen der nächste Schritt ist.','Pure Work shows evidenced demand signals. You immediately see whether research, a call or CRM handoff is next.')); ?></p></div><div class="pw-v501-radar-flow"><span><i>1</i><b><?php echo esc_html(pw_t('Signal','Signal')); ?></b><small><?php echo esc_html(pw_t('Bedarf erkannt','Demand detected')); ?></small></span><em>→</em><span><i>2</i><b><?php echo esc_html(pw_t('Kontakt','Contact')); ?></b><small><?php echo esc_html(pw_t('Ansprechpartner finden','Find decision maker')); ?></small></span><em>→</em><span><i>3</i><b>CRM</b><small><?php echo esc_html(pw_t('Wiedervorlage setzen','Set follow-up')); ?></small></span></div></section><?php $hero=ob_get_clean();
    $needle='<div class="pw-radar-overview">';$pos=strpos($html,$needle);if($pos!==false)$html=substr_replace($html,$hero.$needle,$pos,strlen($needle));return $html;
}
function pw_v501_register_market(){remove_shortcode('pw_market_live');add_shortcode('pw_market_live','pw_shortcode_leads_hub_v501');}
add_action('init','pw_v501_register_market',1200);

/* -------------------------------------------------------------------------
 * Strict language guard for product UI labels that historically leaked EN.
 * ---------------------------------------------------------------------- */
function pw_v501_ui_language_guard($html){
    if(!is_string($html)||$html==='')return $html;
    $de=[
        'PURE BILLING'=>'PURE ABRECHNUNG','Pure Billing'=>'Pure Abrechnung','PURE CALCULATOR'=>'PURE KALKULATION','Pure Calculator'=>'Pure Kalkulation','PURE FLOW'=>'PURE ABLAUF','PURE ASSIGNMENTS'=>'PURE EINSÄTZE','PURE AUTOMATIONS'=>'PURE AUTOMATIONEN','MY PLAN'=>'MEIN TARIF','Target account radar'=>'Zielkunden-Radar','Performance cockpit'=>'Performance-Cockpit','Billing & e-invoicing'=>'Abrechnung & E-Rechnung','Billing'=>'Abrechnung','Calculator'=>'Kalkulation','My plan'=>'Mein Tarif','Target Account Radar'=>'Zielkunden-Radar','Performance Cockpit'=>'Performance-Cockpit','Assignment board'=>'Einsatzboard','Automations'=>'Automationen'
    ];
    $en=array_flip($de);
    return strtr($html,pw_current_lang()==='de'?$de:$en);
}
add_filter('the_content','pw_v501_ui_language_guard',1000);


/* Calculator handoff: standalone calculation -> prefilled e-invoice. */
function pw_v501_frontend_data(){
    if(!wp_script_is('pw-app','enqueued'))return;
    wp_add_inline_script('pw-app','window.PW_V501='.wp_json_encode(['invoiceNew'=>pw_page_url('invoices',['new'=>1]),'lang'=>pw_current_lang()]).';','before');
}
add_action('wp_enqueue_scripts','pw_v501_frontend_data',40);
