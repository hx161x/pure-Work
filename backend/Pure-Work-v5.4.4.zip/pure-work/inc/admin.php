<?php
if (!defined('ABSPATH')) exit;

function pw_admin_menu() {
    add_menu_page('Pure Work','Pure Work','manage_options','pure-work','pw_admin_page','dashicons-networking',3);
}
add_action('admin_menu','pw_admin_menu');

function pw_admin_page() {
    if (!current_user_can('manage_options')) return;
    $tab=sanitize_key($_GET['tab']??'overview');
    ?>
    <div class="wrap pw-admin-wrap">
      <h1>Pure Work</h1>
      <p>Portalverwaltung, Verifizierung, E-Mail-Versand und zukünftige Monetarisierung.</p>
      <nav class="nav-tab-wrapper">
        <a class="nav-tab <?php echo $tab==='overview'?'nav-tab-active':''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=pure-work&tab=overview')); ?>">Unternehmen</a>
        <a class="nav-tab <?php echo $tab==='settings'?'nav-tab-active':''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=pure-work&tab=settings')); ?>">Einstellungen & E-Mail</a>
        <a class="nav-tab <?php echo $tab==='system'?'nav-tab-active':''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=pure-work&tab=system')); ?>">System</a>
      </nav>
      <?php if(isset($_GET['updated'])) echo '<div class="notice notice-success"><p>Gespeichert.</p></div>'; ?>
      <?php if(isset($_GET['mailtest'])) { $ok=$_GET['mailtest']==='1'; echo '<div class="notice '.($ok?'notice-success':'notice-error').'"><p>'.($ok?'Prüfmail wurde an die Administrator-Adresse übergeben.':'Prüfmail konnte nicht versendet werden. Prüfe SMTP und den Systemstatus.').'</p></div>'; } ?>
      <?php if(isset($_GET['aug_error'])) echo '<div class="notice notice-error"><p>AÜG kann nicht bestätigt werden: Bei befristeter Erlaubnis muss ein gültiges, nicht abgelaufenes Datum und ein Dokument vorliegen.</p></div>'; ?>
      <?php if($tab==='overview') pw_admin_companies(); elseif($tab==='settings') pw_admin_settings(); else pw_admin_system(); ?>
    </div>
    <?php
}

function pw_admin_companies() {
    $users=get_users(['role__in'=>['pw_agency','pw_client'],'orderby'=>'registered','order'=>'DESC']);
    ?>
    <h2>Registrierte Unternehmen</h2>
    <p>Neue Konten bestätigen zuerst ihre E-Mail-Adresse. Auftraggeber können danach automatisch freigeschaltet werden; Personaldienstleister benötigen zusätzlich Unternehmens- und AÜG-Prüfung.</p>
    <table class="widefat striped"><thead><tr><th>Unternehmen</th><th>Rolle</th><th>E-Mail</th><th>Standort</th><th>Unternehmen</th><th>AÜG</th><th>Zugang</th><th>Aktionen</th></tr></thead><tbody>
    <?php if(!$users): ?><tr><td colspan="8">Noch keine Portalnutzer.</td></tr><?php else: foreach($users as $u):$role=pw_user_role($u->ID);$company=(get_user_meta($u->ID,'pw_company_verified',true)==='1');$email=pw_email_is_verified($u->ID);$aug=(get_user_meta($u->ID,'pw_aug_verified',true)==='1');$aug_type=pw_user_meta($u->ID,'pw_aug_type','limited');$aug_expiry=pw_user_meta($u->ID,'pw_aug_expiry','');$aug_state=function_exists('pw_aug_state')?pw_aug_state($u->ID):null;$aug_label=function_exists('pw_aug_status_label')?pw_aug_status_label($u->ID):['Status offen','warning']; ?>
      <tr>
        <td><strong><?php echo esc_html(pw_user_meta($u->ID,'pw_company',$u->display_name)); ?></strong><br><small><?php echo esc_html($u->user_email); ?> · <?php echo esc_html(pw_user_meta($u->ID,'pw_contact','')); ?></small></td>
        <td><?php echo esc_html($role==='agency'?'Zeitarbeitsfirma':'Auftraggeber'); ?></td>
        <td><?php echo $email?'<span style="color:#087a55;font-weight:700">✓ bestätigt</span>':'<span style="color:#b54708;font-weight:700">ausstehend</span>'; ?></td>
        <td><?php echo esc_html(trim(pw_user_meta($u->ID,'pw_zip','').' '.pw_user_meta($u->ID,'pw_city',''))); ?></td>
        <td><?php echo $company?'<span style="color:#087a55;font-weight:700">✓ freigegeben</span>':'<span style="color:#b54708;font-weight:700">ausstehend</span>'; ?></td>
        <td><?php if($role==='agency'): echo $aug?'<span style="color:#087a55;font-weight:700">✓ geprüft</span>':'<span style="color:#b54708;font-weight:700">Prüfung offen</span>'; echo '<br><small>'.esc_html($aug_label[0]).'</small>'; if(($aug_state && !empty($aug_state['expired'])) || get_user_meta($u->ID,'pw_aug_login_locked',true)==='1') echo '<br><strong style="color:#b42318">LOGIN GESPERRT</strong>'; $fid=(int)pw_user_meta($u->ID,'pw_aug_file',0); if($fid){ echo '<br><a href="'.esc_url(pw_file_download_url($fid)).'">Dokument</a>'; } else { echo '<br><small>Kein Dokument</small>'; } else: echo '–'; endif; ?></td>
        <td><?php if($role==='agency'): echo 'kostenfrei'; else: echo 'kostenlos'; endif; ?></td>
        <td>
          <?php if(!$email): ?><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_admin_resend_email&user='.$u->ID),'pw_admin_resend_email_'.$u->ID)); ?>">Bestätigung erneut senden</a>
          <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_admin_confirm_email&user='.$u->ID),'pw_admin_confirm_email_'.$u->ID)); ?>" title="Nur nutzen, wenn die Adresse auf anderem Weg geprüft wurde.">E-Mail manuell bestätigen</a><?php endif; ?>
          <?php if(!$company): ?><a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_admin_verify&user='.$u->ID.'&set=1'),'pw_admin_verify_'.$u->ID)); ?>">Unternehmen freigeben</a><?php else:?><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_admin_verify&user='.$u->ID.'&set=0'),'pw_admin_verify_'.$u->ID)); ?>">Unternehmen sperren</a><?php endif; ?>
          <?php if($role==='agency'): ?>
            <?php if(!$aug): ?><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_admin_aug&user='.$u->ID.'&set=1'),'pw_admin_aug_'.$u->ID)); ?>">AÜG bestätigen</a><?php endif; ?>
            <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_admin_subscription&user='.$u->ID.'&status=active'),'pw_admin_subscription_'.$u->ID)); ?>">Zugang aktiv markieren</a>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody></table>
    <?php
}

function pw_admin_settings_legacy47() {
    ?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action" value="pw_admin_settings">
      <?php wp_nonce_field('pw_admin_settings'); ?>
      <h2>Portal</h2>
      <table class="form-table">
        <tr><th><label>Portalname</label></th><td><input class="regular-text" name="company_name" value="<?php echo esc_attr(get_option('pw_company_name','Pure Work')); ?>"></td></tr>
        <tr><th>Auftraggeber-Freigabe</th><td><label><input type="checkbox" name="auto_verify_clients" value="1" <?php checked(get_option('pw_auto_verify_clients','0'),'1'); ?>> Auftraggeber nach erfolgreicher E-Mail-Bestätigung automatisch als Unternehmen freigeben</label><p class="description">Standardmäßig bleibt diese Option aus: E-Mail-Bestätigung aktiviert den Login, die Unternehmensprüfung schaltet sensible Marktplatzfunktionen frei. Personaldienstleister bleiben zusätzlich in der AÜG-Prüfung.</p></td></tr>
        <tr><th>E-Mail-Bestätigung</th><td><strong>Automatische Bestätigungs-E-Mail aktiv.</strong><p class="description">Neue Konten können direkt starten; die E-Mail-Bestätigung dient zusätzlich als Vertrauens- und Sicherheitsmerkmal.</p></td></tr>
        <tr><th><label>Späterer Basic-Preis / Monat</label></th><td><input class="small-text" name="basic_price" value="<?php echo esc_attr(get_option('pw_basic_price','49')); ?>"> €</td></tr>
        <tr><th><label>Späterer Pro-Preis / Monat</label></th><td><input class="small-text" name="pro_price" value="<?php echo esc_attr(get_option('pw_pro_price','119')); ?>"> €</td></tr>
        <tr><th><label>Startphasen-Tage (für spätere Monetarisierung)</label></th><td><input class="small-text" type="number" min="0" max="90" name="trial_days" value="<?php echo esc_attr(get_option('pw_trial_days',14)); ?>"> Tage</td></tr>
        <tr><th><label>Basic Payment-/Checkout-Link</label></th><td><input class="large-text" type="url" name="basic_payment_url" value="<?php echo esc_attr(get_option('pw_basic_payment_url','')); ?>"><p class="description">Optional: sicherer externer Checkout-Link. Ohne Link erfolgt die Freischaltung manuell.</p></td></tr>
        <tr><th><label>Pro Payment-/Checkout-Link</label></th><td><input class="large-text" type="url" name="pro_payment_url" value="<?php echo esc_attr(get_option('pw_pro_payment_url','')); ?>"></td></tr>
        <tr><th>Geokodierung / Radius</th><td><label><input type="checkbox" name="geocoding_enabled" value="1" <?php checked(get_option('pw_geocoding_enabled','1'),'1'); ?>> Standort-Geokodierung aktivieren</label><p class="description">Ermittelt Koordinaten für Radiusfilter. Bei Deaktivierung arbeitet das Portal mit Text-/Regionsvergleichen.</p></td></tr>
      </table>

      <h2>E-Mail & SMTP</h2>
      <p>Pure Work nutzt für Bestätigungs-Mails, neue Personalanfragen, Profile, Statusänderungen und Chat-Hinweise den WordPress-Mailversand. Mit SMTP ist die Zustellung auf Produktivsystemen zuverlässiger.</p>
      <table class="form-table">
        <tr><th><label>Absendername</label></th><td><input class="regular-text" name="mail_from_name" value="<?php echo esc_attr(get_option('pw_mail_from_name','Pure Work')); ?>"></td></tr>
        <tr><th><label>Absender-E-Mail</label></th><td><input class="regular-text" type="email" name="mail_from" value="<?php echo esc_attr(get_option('pw_mail_from',get_option('admin_email'))); ?>"></td></tr>
        <tr><th>SMTP</th><td><label><input type="checkbox" name="smtp_enabled" value="1" <?php checked(get_option('pw_smtp_enabled','0'),'1'); ?>> SMTP direkt über Pure Work verwenden</label></td></tr>
        <tr><th><label>SMTP Host</label></th><td><input class="regular-text" name="smtp_host" value="<?php echo esc_attr(get_option('pw_smtp_host','')); ?>" placeholder="smtp.example.de"></td></tr>
        <tr><th><label>Port</label></th><td><input class="small-text" type="number" name="smtp_port" value="<?php echo esc_attr(get_option('pw_smtp_port',587)); ?>"> <select name="smtp_encryption"><option value="tls" <?php selected(get_option('pw_smtp_encryption','tls'),'tls'); ?>>TLS</option><option value="ssl" <?php selected(get_option('pw_smtp_encryption','tls'),'ssl'); ?>>SSL</option><option value="none" <?php selected(get_option('pw_smtp_encryption','tls'),'none'); ?>>Keine</option></select></td></tr>
        <tr><th>Authentifizierung</th><td><label><input type="checkbox" name="smtp_auth" value="1" <?php checked(get_option('pw_smtp_auth','1'),'1'); ?>> Benutzername/Passwort verwenden</label></td></tr>
        <tr><th><label>SMTP Benutzername</label></th><td><input class="regular-text" name="smtp_username" value="<?php echo esc_attr(get_option('pw_smtp_username','')); ?>"></td></tr>
        <tr><th><label>SMTP Passwort</label></th><td><input class="regular-text" type="password" name="smtp_password" value="" autocomplete="new-password" placeholder="Leer lassen = vorhandenes Passwort behalten"><p class="description">Das Passwort wird nur geändert, wenn hier ein neuer Wert eingetragen wird.</p></td></tr>
      </table>
      <?php submit_button('Einstellungen speichern'); ?>
    </form>
    <?php
}

function pw_admin_system() {
    $ids=get_option('pw_page_ids',[]);
    $mail_status=get_option('pw_last_mail_status','');$mail_time=(int)get_option('pw_last_mail_time',0);$mail_error=get_option('pw_last_mail_error','');
    ?>
    <h2>Systemstatus</h2>
    <table class="widefat striped" style="max-width:1000px"><tbody>
      <tr><td>Theme-Version</td><td><strong><?php echo esc_html(PW_VERSION); ?></strong></td></tr>
      <tr><td>Login & E-Mail-Verifizierung</td><td><span style="color:#087a55">✓ aktiv</span> · Registrierung → Bestätigungs-E-Mail → Login · klare Fehlermeldungen · Resend-Funktion</td></tr>
      <tr><td>SMTP</td><td><?php echo get_option('pw_smtp_enabled','0')==='1' ? '<span style="color:#087a55">✓ aktiviert</span> · '.esc_html(get_option('pw_smtp_host','')) : 'WordPress/Hosting-Mailversand'; ?></td></tr>
      <tr><td>Letzter Mailversand</td><td><?php if(!$mail_status) echo 'Noch kein Versand protokolliert'; else echo ($mail_status==='success'?'<span style="color:#087a55">✓ erfolgreich</span>':'<span style="color:#b42318">✕ Fehler</span>').($mail_time?' · '.esc_html(wp_date('d.m.Y H:i',$mail_time)):'').($mail_error?'<br><code>'.esc_html($mail_error).'</code>':''); ?></td></tr>
      <tr><td>PHP</td><td><?php echo esc_html(PHP_VERSION); ?></td></tr>
      <tr><td>Private Uploads</td><td><?php $dir=pw_private_dir();echo is_writable($dir)?'<span style="color:#087a55">✓ beschreibbar</span>':'<span style="color:#b42318">✕ nicht beschreibbar</span>'; ?><br><code><?php echo esc_html($dir); ?></code></td></tr>
      <tr><td>Portal-Seiten</td><td><?php echo count($ids); ?> angelegt</td></tr>
      <tr><td>Datenkataloge</td><td><strong><?php echo number_format_i18n(pw_catalog_official_occupation_count()); ?></strong> KldB-Berufsbezeichnungen · <?php echo count(pw_catalog_roles()); ?> Zeitarbeits-Tätigkeiten · <?php echo count(pw_catalog_industries()); ?> Branchen · <?php echo count(pw_catalog_qualifications()); ?> Qualifikationen · <?php echo count(pw_catalog_locations()); ?> Regionen · 100 Unternehmens-Marktreferenzen</td></tr>
      <tr><td>WP-Cron Tagesdigest</td><td><?php echo wp_next_scheduled('pw_daily_digest_event')?'✓ geplant':'nicht geplant'; ?></td></tr>
      <tr><td>AÜG-Ablaufkontrolle</td><td><?php $augcron=wp_next_scheduled('pw_compliance_daily_event'); echo $augcron?'<span style="color:#087a55">✓ täglich geplant</span> · nächste Prüfung '.esc_html(wp_date('d.m.Y H:i',$augcron)):'<span style="color:#b42318">nicht geplant</span>'; ?></td></tr>
      <tr><td>Datenschutz-Tokenbereinigung</td><td><?php $pcron=wp_next_scheduled('pw_privacy_cleanup_event'); echo $pcron?'<span style="color:#087a55">✓ täglich geplant</span>':'<span style="color:#b42318">nicht geplant</span>'; ?></td></tr>
      <tr><td>Direkt-Leads</td><td>Qualitätsgeprüfte AÜ/ANÜ-Bedarfe mit öffentlicher zuständiger Vergabe-/Beschaffungskontaktstelle · keine generischen Stellenanzeigen</td></tr>
    </tbody></table>
    <p><a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_admin_repair'),'pw_admin_repair')); ?>">Seiten & Rollen reparieren</a> <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_admin_mail_test'),'pw_admin_mail_test')); ?>">E-Mail-Verbindung prüfen</a></p>
    <div class="notice notice-warning inline"><p><strong>Vor Live-Betrieb:</strong> Datenschutz, AÜG-Prozess, Plattformrolle, Nutzungsbedingungen, Löschfristen und Zahlungs-/Abo-Prozess fachlich und juristisch final prüfen.</p></div>
    <?php
}

function pw_admin_verify() {
    if(!current_user_can('manage_options'))wp_die('Keine Berechtigung.');$uid=(int)($_GET['user']??0);check_admin_referer('pw_admin_verify_'.$uid);$set=($_GET['set']??'0')==='1'?'1':'0';update_user_meta($uid,'pw_company_verified',$set);
    if($set==='1'){$u=get_userdata($uid);if($u)pw_send_mail($u->user_email,'Pure Work: Unternehmen freigegeben','Unternehmen freigeschaltet','Dein Unternehmen wurde geprüft. '.(pw_user_role($uid)==='agency'?'Sobald auch die AÜG-Prüfung abgeschlossen ist, steht dir der geschlossene Marktplatz vollständig zur Verfügung.':'Du kannst Pure Work jetzt vollständig nutzen.'),'Zum Dashboard',pw_page_url('dashboard'));}
    wp_safe_redirect(admin_url('admin.php?page=pure-work&updated=1'));exit;
}
add_action('admin_post_pw_admin_verify','pw_admin_verify');

function pw_admin_aug() {
    if(!current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    $uid=(int)($_GET['user']??0);
    check_admin_referer('pw_admin_aug_'.$uid);
    $set=($_GET['set']??'0')==='1'?'1':'0';

    if($set==='1' && function_exists('pw_aug_state')){
        $state=pw_aug_state($uid);
        $fid=(int)pw_user_meta($uid,'pw_aug_file',0);
        if(($state['type']==='limited' && ($state['missing'] || $state['expired'])) || !$fid){
            wp_safe_redirect(admin_url('admin.php?page=pure-work&aug_error=1'));
            exit;
        }
    }

    update_user_meta($uid,'pw_aug_verified',$set);
    if($set==='1'){
        delete_user_meta($uid,'pw_aug_expired');
        delete_user_meta($uid,'pw_aug_login_locked');
        if(function_exists('pw_aug_refresh_lock_state')) pw_aug_refresh_lock_state($uid);
        $u=get_userdata($uid);
        if($u) pw_send_mail($u->user_email,'Pure Work: AÜG-Erlaubnis geprüft','AÜG-Prüfung abgeschlossen','Deine hinterlegte AÜG-Erlaubnis wurde geprüft. Wenn auch dein Unternehmen und deine E-Mail-Adresse bestätigt sind, kannst du den geschlossenen Marktplatz vollständig nutzen.','Zum Dashboard',pw_page_url('dashboard'));
    } else {
        $u=get_userdata($uid);
        if($u) pw_send_mail($u->user_email,'Pure Work: AÜG-Prüfung zurückgesetzt','AÜG-Prüfung erforderlich','Deine AÜG-Prüfung wurde zurückgesetzt. Bitte prüfe deine AÜG-Daten und lade bei Bedarf aktuelle Unterlagen hoch.','Konto öffnen',pw_page_url('account',['tab'=>'profile']));
    }
    wp_safe_redirect(admin_url('admin.php?page=pure-work&updated=1'));exit;
}
add_action('admin_post_pw_admin_aug','pw_admin_aug');

function pw_admin_resend_email() {
    if(!current_user_can('manage_options'))wp_die('Keine Berechtigung.');$uid=(int)($_GET['user']??0);check_admin_referer('pw_admin_resend_email_'.$uid);pw_send_verification_email($uid);wp_safe_redirect(admin_url('admin.php?page=pure-work&updated=1'));exit;
}
add_action('admin_post_pw_admin_resend_email','pw_admin_resend_email');

function pw_admin_subscription() {
    if(!current_user_can('manage_options'))wp_die('Keine Berechtigung.');$uid=(int)($_GET['user']??0);check_admin_referer('pw_admin_subscription_'.$uid);$status=sanitize_key($_GET['status']??'active');if(!in_array($status,['active','inactive','past_due','trial'],true))$status='active';update_user_meta($uid,'pw_subscription_status',$status);wp_safe_redirect(admin_url('admin.php?page=pure-work&updated=1'));exit;
}
add_action('admin_post_pw_admin_subscription','pw_admin_subscription');

function pw_admin_settings_save_legacy47() {
    if(!current_user_can('manage_options'))wp_die('Keine Berechtigung.');check_admin_referer('pw_admin_settings');
    update_option('pw_company_name',sanitize_text_field(wp_unslash($_POST['company_name']??'Pure Work')));
    update_option('pw_auto_verify_clients',!empty($_POST['auto_verify_clients'])?'1':'0');
    update_option('pw_basic_price',sanitize_text_field(wp_unslash($_POST['basic_price']??'49')));
    update_option('pw_pro_price',sanitize_text_field(wp_unslash($_POST['pro_price']??'119')));
    update_option('pw_trial_days',max(0,min(90,(int)($_POST['trial_days']??14))));
    update_option('pw_basic_payment_url',esc_url_raw(wp_unslash($_POST['basic_payment_url']??'')));
    update_option('pw_pro_payment_url',esc_url_raw(wp_unslash($_POST['pro_payment_url']??'')));
    update_option('pw_geocoding_enabled',!empty($_POST['geocoding_enabled'])?'1':'0');
    update_option('pw_mail_from_name',sanitize_text_field(wp_unslash($_POST['mail_from_name']??'Pure Work')));
    $from=sanitize_email(wp_unslash($_POST['mail_from']??''));if($from)update_option('pw_mail_from',$from);
    update_option('pw_smtp_enabled',!empty($_POST['smtp_enabled'])?'1':'0');
    update_option('pw_smtp_host',sanitize_text_field(wp_unslash($_POST['smtp_host']??'')));
    update_option('pw_smtp_port',max(1,min(65535,(int)($_POST['smtp_port']??587))));
    $enc=sanitize_key($_POST['smtp_encryption']??'tls');update_option('pw_smtp_encryption',in_array($enc,['tls','ssl','none'],true)?$enc:'tls');
    update_option('pw_smtp_auth',!empty($_POST['smtp_auth'])?'1':'0');
    update_option('pw_smtp_username',sanitize_text_field(wp_unslash($_POST['smtp_username']??'')));
    if(isset($_POST['smtp_password']) && $_POST['smtp_password']!=='') update_option('pw_smtp_password',(string)wp_unslash($_POST['smtp_password']));
    wp_safe_redirect(admin_url('admin.php?page=pure-work&tab=settings&updated=1'));exit;
}
add_action('admin_post_pw_admin_settings','pw_admin_settings_save');
// Pure Work 4.9.3: the settings form actually submits action=pw_admin_settings_save.
// Without this second hook WordPress dispatched nothing and every saved SMTP /
// price setting was silently discarded ("0" response), which broke all outgoing mail.
add_action('admin_post_pw_admin_settings_save','pw_admin_settings_save');

function pw_admin_mail_test() {
    if(!current_user_can('manage_options'))wp_die('Keine Berechtigung.');check_admin_referer('pw_admin_mail_test');
    $to=sanitize_email(wp_unslash($_POST['test_email']??$_GET['test_email']??''));
    if(!$to||!is_email($to))$to=get_option('admin_email');$ok=pw_send_mail($to,'Pure Work – Prüfmail','E-Mail-Versand funktioniert','Diese Nachricht bestätigt, dass Pure Work E-Mails an WordPress/SMTP übergeben kann.','Pure Work öffnen',home_url('/'));wp_safe_redirect(admin_url('admin.php?page=pure-work&tab=system&mailtest='.($ok?'1':'0')));exit;
}
add_action('admin_post_pw_admin_mail_test','pw_admin_mail_test');

function pw_admin_repair() {
    if(!current_user_can('manage_options'))wp_die('Keine Berechtigung.');check_admin_referer('pw_admin_repair');pw_install_theme();wp_safe_redirect(admin_url('admin.php?page=pure-work&tab=system&updated=1'));exit;
}
add_action('admin_post_pw_admin_repair','pw_admin_repair');

/**
 * Pure Work 4.9.3: manual e-mail confirmation.
 * If a portal is launched before SMTP is finished, new companies could never
 * sign in because the activation link was never delivered. An administrator can
 * now unlock a verified-by-other-means account without touching the database.
 */
function pw_admin_confirm_email() {
    if(!current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    $uid=(int)($_GET['user']??0);
    check_admin_referer('pw_admin_confirm_email_'.$uid);
    if(!get_userdata($uid)) wp_die('Benutzer nicht gefunden.');
    update_user_meta($uid,'pw_email_verified','1');
    update_user_meta($uid,'pw_email_verified_at',time());
    update_user_meta($uid,'pw_email_verified_manually','1');
    delete_user_meta($uid,'pw_email_verify_hash');
    delete_user_meta($uid,'pw_email_verify_expires');
    if(pw_user_role($uid)==='client' && get_option('pw_auto_verify_clients','0')==='1') update_user_meta($uid,'pw_company_verified','1');
    wp_safe_redirect(admin_url('admin.php?page=pure-work&updated=1'));exit;
}
add_action('admin_post_pw_admin_confirm_email','pw_admin_confirm_email');
