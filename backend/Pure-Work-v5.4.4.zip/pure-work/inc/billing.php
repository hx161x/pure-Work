<?php
if (!defined('ABSPATH')) exit;

/**
 * 4.9.7: Die Aufzählungen kommen jetzt aus derselben Quelle wie die tatsächliche
 * Freischaltung (pw_plan_feature_matrix). Damit kann die Preisseite nichts mehr
 * versprechen, was die Software nicht wirklich freigibt.
 */
function pw_plan_definitions() {
    $labels = function_exists('pw_plan_feature_labels') ? pw_plan_feature_labels() : [];
    $bullets = function($level) use ($labels) {
        if (!function_exists('pw_plan_feature_matrix')) return [];
        $out = [];
        foreach (pw_plan_feature_matrix()[$level] as $f) if (isset($labels[$f])) $out[] = $labels[$f][0];
        return $out;
    };
    return [
        'basic'=>['label'=>'Basic','price'=>(float)get_option('pw_basic_price','49'),'features'=>$bullets('basic') ?: ['Marktplatz & Ausschreibungen','Mitarbeiter-Pool']],
        'professional'=>['label'=>'Pro','price'=>(float)get_option('pw_pro_price','119'),'features'=>array_merge(['Alles aus Basic'],$bullets('professional'))],
        'enterprise'=>['label'=>'Max','price'=>(float)get_option('pw_enterprise_price','249'),'features'=>array_merge(['Alles aus Pro'],$bullets('enterprise'))],
    ];
}


function pw_billing_t_for_user($uid,$de,$en){
    $lang=sanitize_key((string)get_user_meta((int)$uid,'pw_lang',true));
    return $lang==='en'?$en:$de;
}

function pw_launch_promo_claimed_ids() { return array_values(array_unique(array_map('intval',(array)get_option('pw_launch_promo_claimed_users',[])))); }
function pw_launch_promo_available() { return count(pw_launch_promo_claimed_ids()) < max(0,(int)get_option('pw_launch_promo_limit',20)); }

function pw_billing_initialize_agency($user_id, $plan='professional') {
    if (pw_user_role($user_id)!=='agency') return;
    $plans=pw_plan_definitions(); if(!isset($plans[$plan]))$plan='professional';
    if (get_user_meta($user_id,'pw_billing_initialized',true)==='1') return;
    update_user_meta($user_id,'pw_plan',$plan);
    update_user_meta($user_id,'pw_billing_initialized','1');
    $claimed=pw_launch_promo_claimed_ids();
    $promo_limit=max(0,(int)get_option('pw_launch_promo_limit',20));
    $promo_months=max(1,(int)get_option('pw_launch_promo_months',6));
    if (count($claimed)<$promo_limit) {
        $claimed[]=(int)$user_id; update_option('pw_launch_promo_claimed_users',array_values(array_unique($claimed)),false);
        update_user_meta($user_id,'pw_launch_promo','1');
        update_user_meta($user_id,'pw_promo_started_at',time());
        update_user_meta($user_id,'pw_promo_until',strtotime('+'.$promo_months.' months',time()));
        update_user_meta($user_id,'pw_subscription_status','promo');
    } else {
        update_user_meta($user_id,'pw_launch_promo','0');
        update_user_meta($user_id,'pw_subscription_status','payment_required');
    }
}

function pw_billing_migrate_480() {
    if (get_option('pw_billing_migrated_480','0')==='1') return;
    $users=get_users(['role'=>'pw_agency','orderby'=>'registered','order'=>'ASC','fields'=>'ID']);
    foreach($users as $uid){
        $interest=pw_user_meta((int)$uid,'pw_plan_interest','professional');
        if(!in_array($interest,['basic','professional','enterprise'],true))$interest='professional';
        pw_billing_initialize_agency((int)$uid,$interest);
    }
    update_option('pw_billing_migrated_480','1',false);
}

function pw_subscription_state($user_id=0) {
    if(!$user_id)$user_id=get_current_user_id();
    if(!$user_id)return ['active'=>false,'status'=>'none','plan'=>'','promo'=>false,'until'=>0];
    if(user_can($user_id,'manage_options'))return ['active'=>true,'status'=>'admin','plan'=>'enterprise','promo'=>false,'until'=>0];
    if(pw_user_role($user_id)!=='agency')return ['active'=>true,'status'=>'free','plan'=>'client','promo'=>false,'until'=>0];
    $status=pw_user_meta($user_id,'pw_subscription_status','');
    $plan=pw_user_meta($user_id,'pw_plan','professional');
    $promo=pw_user_meta($user_id,'pw_launch_promo','0')==='1';
    $until=(int)pw_user_meta($user_id,'pw_promo_until',0);
    if($status==='promo' && $until && $until<time())$status='payment_required';
    $active=in_array($status,['promo','active','trialing'],true);
    return ['active'=>$active,'status'=>$status?:'payment_required','plan'=>$plan,'promo'=>$promo,'until'=>$until,'stripe_connected'=>pw_user_meta($user_id,'pw_stripe_subscription_id','')!==''];
}

function pw_subscription_human_label($user_id=0) {
    $s=pw_subscription_state($user_id);$plans=pw_plan_definitions();$label=$plans[$s['plan']]['label']??ucfirst($s['plan']);
    if($s['status']==='promo')return [$label.' · '.max(1,(int)get_option('pw_launch_promo_months',6)).' '.pw_t('Monate kostenfrei','months free'),'success'];
    if($s['status']==='active'||$s['status']==='trialing')return [$label.' · '.pw_t('aktiv','active'),'success'];
    if($s['status']==='payment_required')return [$label.' · '.pw_t('Zahlung erforderlich','payment required'),'warning'];
    return [$label.' · '.$s['status'],'muted'];
}

function pw_stripe_ready() {
    return trim((string)get_option('pw_stripe_secret_key',''))!=='' && trim((string)get_option('pw_stripe_price_basic',''))!=='' && trim((string)get_option('pw_stripe_price_professional',''))!=='' && trim((string)get_option('pw_stripe_price_enterprise',''))!=='';
}

function pw_stripe_api_post($path,$params) {
    $secret=trim((string)get_option('pw_stripe_secret_key',''));
    if(!$secret)return new WP_Error('stripe_config','Stripe ist nicht konfiguriert.');
    $res=wp_remote_post('https://api.stripe.com/v1/'.ltrim($path,'/'),[
        'timeout'=>20,
        'headers'=>['Authorization'=>'Bearer '.$secret,'Content-Type'=>'application/x-www-form-urlencoded'],
        'body'=>$params,
    ]);
    if(is_wp_error($res))return $res;
    $code=(int)wp_remote_retrieve_response_code($res);$json=json_decode(wp_remote_retrieve_body($res),true);
    if($code<200||$code>=300||!is_array($json))return new WP_Error('stripe_api',is_array($json)&&!empty($json['error']['message'])?$json['error']['message']:'Stripe API Fehler');
    return $json;
}

function pw_stripe_api_get($path,$params=[]) {
    $secret=trim((string)get_option('pw_stripe_secret_key',''));
    if(!$secret)return new WP_Error('stripe_config','Stripe ist nicht konfiguriert.');
    $url='https://api.stripe.com/v1/'.ltrim($path,'/');
    if($params)$url=add_query_arg($params,$url);
    $res=wp_remote_get($url,[
        'timeout'=>20,
        'headers'=>['Authorization'=>'Bearer '.$secret],
    ]);
    if(is_wp_error($res))return $res;
    $code=(int)wp_remote_retrieve_response_code($res);$json=json_decode(wp_remote_retrieve_body($res),true);
    if($code<200||$code>=300||!is_array($json))return new WP_Error('stripe_api',is_array($json)&&!empty($json['error']['message'])?$json['error']['message']:'Stripe API Fehler');
    return $json;
}

function pw_billing_checkout_session($uid,$plan) {
    $prices=['basic'=>get_option('pw_stripe_price_basic',''),'professional'=>get_option('pw_stripe_price_professional',''),'enterprise'=>get_option('pw_stripe_price_enterprise','')];
    if(empty($prices[$plan]))return new WP_Error('price','Stripe Price-ID fehlt.');
    $u=get_userdata($uid); if(!$u)return new WP_Error('user','Benutzer fehlt.');
    $customer=trim((string)pw_user_meta($uid,'pw_stripe_customer_id',''));
    if(!$customer && function_exists('pw_v501_stripe_ensure_customer')){
        $created=pw_v501_stripe_ensure_customer($uid);
        if(is_wp_error($created))return $created;
        $customer=$created;
    }
    $params=[
        'mode'=>'subscription','client_reference_id'=>(string)$uid,
        'billing_address_collection'=>'required','allow_promotion_codes'=>'true',
        'payment_method_collection'=>'always',
        'tax_id_collection[enabled]'=>'true',
        'line_items[0][price]'=>$prices[$plan],'line_items[0][quantity]'=>1,
        'success_url'=>pw_page_url('account',['tab'=>'billing','billing'=>'success']).'&session_id={CHECKOUT_SESSION_ID}',
        'cancel_url'=>pw_page_url('account',['tab'=>'billing','billing'=>'cancel']),
        'metadata[user_id]'=>(string)$uid,'metadata[plan]'=>$plan,'metadata[source]'=>'pure-work',
        'subscription_data[metadata][user_id]'=>(string)$uid,'subscription_data[metadata][plan]'=>$plan,'subscription_data[metadata][source]'=>'pure-work',
    ];
    if($customer){$params['customer']=$customer;$params['customer_update[address]']='auto';$params['customer_update[name]']='auto';}
    else $params['customer_email']=$u->user_email;
    $state=pw_subscription_state($uid);
    if($state['status']==='promo' && $state['until']>time()+172800) $params['subscription_data[trial_end]']=(string)$state['until'];
    return pw_stripe_api_post('checkout/sessions',$params);
}

function pw_handle_billing_checkout() {
    if(!is_user_logged_in()||pw_user_role()!=='agency')wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_billing_checkout');
    $uid=get_current_user_id();
    $plan=sanitize_key(wp_unslash($_POST['plan']??'')); if(!isset(pw_plan_definitions()[$plan]))$plan='professional';
    if(pw_stripe_ready()){
        $sub=trim((string)pw_user_meta($uid,'pw_stripe_subscription_id',''));
        $state=pw_subscription_state($uid);
        // Existing paid/trial subscription: change its price instead of creating a duplicate subscription.
        if($sub && in_array($state['status'],['active','trialing'],true)){
            $prices=['basic'=>get_option('pw_stripe_price_basic',''),'professional'=>get_option('pw_stripe_price_professional',''),'enterprise'=>get_option('pw_stripe_price_enterprise','')];
            $stripeSub=pw_stripe_api_get('subscriptions/'.$sub,['expand[]'=>'items.data.price']);
            if(!is_wp_error($stripeSub) && !empty($stripeSub['items']['data'][0]['id']) && !empty($prices[$plan])){
                $item=$stripeSub['items']['data'][0]['id'];
                $changed=pw_stripe_api_post('subscriptions/'.$sub,[
                    'items[0][id]'=>$item,
                    'items[0][price]'=>$prices[$plan],
                    'proration_behavior'=>'create_prorations',
                    'metadata[user_id]'=>(string)$uid,
                    'metadata[plan]'=>$plan,
                    'metadata[source]'=>'pure-work',
                ]);
                if(!is_wp_error($changed)){
                    update_user_meta($uid,'pw_plan',$plan);
                    delete_transient('pw_v502_stripe_snapshot_'.$uid);
                    pw_form_redirect('account',['tab'=>'billing','billing'=>'plan_changed']);
                }
                pw_form_redirect('account',['tab'=>'billing','billing_error'=>rawurlencode(is_wp_error($changed)?$changed->get_error_message():'stripe')]);
            }
        }
        update_user_meta($uid,'pw_plan',$plan);
        $session=pw_billing_checkout_session($uid,$plan);
        if(!is_wp_error($session)&&!empty($session['url'])){wp_redirect(esc_url_raw($session['url']));exit;}
        pw_form_redirect('account',['tab'=>'billing','billing_error'=>is_wp_error($session)?rawurlencode($session->get_error_message()):'stripe']);
    }
    $fallback=['basic'=>get_option('pw_basic_payment_url',''),'professional'=>get_option('pw_pro_payment_url',''),'enterprise'=>get_option('pw_enterprise_payment_url','')];
    if(!empty($fallback[$plan])){update_user_meta($uid,'pw_plan',$plan);wp_redirect(esc_url_raw($fallback[$plan]));exit;}
    pw_form_redirect('account',['tab'=>'billing','billing_error'=>'not_configured']);
}
add_action('admin_post_pw_billing_checkout','pw_handle_billing_checkout');

function pw_stripe_verify_signature($payload,$header) {
    $secret=trim((string)get_option('pw_stripe_webhook_secret','')); if(!$secret||!$header)return false;
    $parts=[];foreach(explode(',',$header) as $piece){$kv=explode('=',trim($piece),2);if(count($kv)===2)$parts[$kv[0]][]=$kv[1];}
    $t=isset($parts['t'][0])?(int)$parts['t'][0]:0;if(!$t||abs(time()-$t)>300)return false;
    $expected=hash_hmac('sha256',$t.'.'.$payload,$secret);
    foreach((array)($parts['v1']??[]) as $sig)if(hash_equals($expected,$sig))return true;
    return false;
}


function pw_billing_user_by_stripe($customer='',$subscription=''){
    foreach([['pw_stripe_subscription_id',$subscription],['pw_stripe_customer_id',$customer]] as $pair){
        if(!$pair[1])continue;
        $ids=get_users(['meta_key'=>$pair[0],'meta_value'=>sanitize_text_field($pair[1]),'fields'=>'ID','number'=>1]);
        if($ids)return (int)$ids[0];
    }
    return 0;
}

function pw_stripe_webhook($request) {
    $payload=$request->get_body();$sig=$request->get_header('stripe-signature');
    if(!pw_stripe_verify_signature($payload,$sig))return new WP_REST_Response(['ok'=>false],400);
    $event=json_decode($payload,true);if(!is_array($event))return new WP_REST_Response(['ok'=>false],400);
    $type=$event['type']??'';$obj=$event['data']['object']??[];$meta=$obj['metadata']??[];
    $subscriptionId=is_string($obj['subscription']??null)?$obj['subscription']:((($obj['object']??'')==='subscription')?($obj['id']??''):'');
    $uid=(int)($meta['user_id']??$obj['client_reference_id']??0);if(!$uid)$uid=pw_billing_user_by_stripe($obj['customer']??'',$subscriptionId);
    if($uid&&get_userdata($uid)){
        if(!empty($obj['customer']))update_user_meta($uid,'pw_stripe_customer_id',sanitize_text_field($obj['customer']));
        if($type==='checkout.session.completed'){
            if(!empty($obj['subscription']))update_user_meta($uid,'pw_stripe_subscription_id',sanitize_text_field($obj['subscription']));
            if(!empty($meta['plan']))update_user_meta($uid,'pw_plan',sanitize_key($meta['plan']));
            if(($obj['mode']??'')==='setup' && !empty($obj['setup_intent'])){
                $setup=pw_stripe_api_get('setup_intents/'.rawurlencode($obj['setup_intent']));
                if(!is_wp_error($setup)&&!empty($setup['payment_method'])){
                    $pm=sanitize_text_field($setup['payment_method']);update_user_meta($uid,'pw_stripe_payment_method_id',$pm);update_user_meta($uid,'pw_payment_method_ready','1');
                    $customer=trim((string)pw_user_meta($uid,'pw_stripe_customer_id',''));if($customer)pw_stripe_api_post('customers/'.$customer,['invoice_settings[default_payment_method]'=>$pm]);
                    $pmo=pw_stripe_api_get('payment_methods/'.$pm);if(!is_wp_error($pmo)){
                        $label=strtoupper((string)($pmo['type']??''));if(($pmo['type']??'')==='card')$label=ucfirst((string)($pmo['card']['brand']??'Karte')).' •••• '.(string)($pmo['card']['last4']??'');elseif(($pmo['type']??'')==='sepa_debit')$label='SEPA •••• '.(string)($pmo['sepa_debit']['last4']??'');
                        update_user_meta($uid,'pw_payment_method_label',sanitize_text_field($label));
                    }
                }
            }
            if(($obj['mode']??'')==='subscription' && !empty($obj['subscription'])){
                $sub=pw_stripe_api_get('subscriptions/'.rawurlencode($obj['subscription']),['expand[]'=>'default_payment_method']);
                if(!is_wp_error($sub)){
                    $st=sanitize_key($sub['status']??'active');$map=['active'=>'active','trialing'=>'trialing','past_due'=>'payment_required','unpaid'=>'payment_required','canceled'=>'canceled','incomplete'=>'payment_required','incomplete_expired'=>'canceled'];update_user_meta($uid,'pw_subscription_status',$map[$st]??'active');
                    if(!empty($sub['trial_end']))update_user_meta($uid,'pw_stripe_trial_end',(int)$sub['trial_end']);if(!empty($sub['current_period_end']))update_user_meta($uid,'pw_stripe_period_end',(int)$sub['current_period_end']);
                    $pm=$sub['default_payment_method']??null;if(is_array($pm)&&!empty($pm['id'])){update_user_meta($uid,'pw_stripe_payment_method_id',sanitize_text_field($pm['id']));update_user_meta($uid,'pw_payment_method_ready','1');}
                }
            }
        } elseif($type==='setup_intent.succeeded'){
            if(!empty($obj['payment_method'])){update_user_meta($uid,'pw_stripe_payment_method_id',sanitize_text_field($obj['payment_method']));update_user_meta($uid,'pw_payment_method_ready','1');$customer=trim((string)($obj['customer']??pw_user_meta($uid,'pw_stripe_customer_id','')));if($customer)pw_stripe_api_post('customers/'.$customer,['invoice_settings[default_payment_method]'=>sanitize_text_field($obj['payment_method'])]);}
        } elseif(strpos($type,'customer.subscription.')===0){
            if(!empty($obj['id']))update_user_meta($uid,'pw_stripe_subscription_id',sanitize_text_field($obj['id']));
            if(!empty($meta['plan']))update_user_meta($uid,'pw_plan',sanitize_key($meta['plan']));
            $status=sanitize_key($obj['status']??'');$map=['active'=>'active','trialing'=>'trialing','past_due'=>'payment_required','unpaid'=>'payment_required','canceled'=>'canceled','incomplete'=>'payment_required','incomplete_expired'=>'canceled','paused'=>'payment_required'];
            if(isset($map[$status]))update_user_meta($uid,'pw_subscription_status',$map[$status]);
            update_user_meta($uid,'pw_stripe_cancel_at_period_end',!empty($obj['cancel_at_period_end'])?'1':'0');if(!empty($obj['trial_end']))update_user_meta($uid,'pw_stripe_trial_end',(int)$obj['trial_end']);if(!empty($obj['current_period_end']))update_user_meta($uid,'pw_stripe_period_end',(int)$obj['current_period_end']);
        } elseif($type==='invoice.payment_failed'){
            update_user_meta($uid,'pw_subscription_status','payment_required');update_user_meta($uid,'pw_last_payment_status','failed');
            pw_create_notice($uid,pw_billing_t_for_user($uid,'Zahlung erforderlich','Payment required'),pw_billing_t_for_user($uid,'Die Abo-Zahlung konnte nicht verarbeitet werden. Bitte aktualisiere deine Zahlungsdaten.','The subscription payment could not be processed. Please update your payment details.'),pw_page_url('account',['tab'=>'billing']));
        } elseif($type==='invoice.paid'){
            update_user_meta($uid,'pw_subscription_status','active');update_user_meta($uid,'pw_last_payment_status','paid');update_user_meta($uid,'pw_last_invoice_id',sanitize_text_field($obj['id']??''));update_user_meta($uid,'pw_last_invoice_amount',(int)($obj['amount_paid']??0));update_user_meta($uid,'pw_last_invoice_url',esc_url_raw($obj['hosted_invoice_url']??''));update_user_meta($uid,'pw_last_payment_at',time());
        }
        delete_transient('pw_v502_stripe_snapshot_'.$uid);
    }
    return new WP_REST_Response(['received'=>true],200);
}

function pw_register_billing_routes(){register_rest_route('pure-work/v1','/stripe-webhook',['methods'=>'POST','callback'=>'pw_stripe_webhook','permission_callback'=>'__return_true']);}
add_action('rest_api_init','pw_register_billing_routes');

function pw_billing_daily_check(){
    foreach(get_users(['role'=>'pw_agency','fields'=>'ID']) as $uid){
        $uid=(int)$uid;$s=pw_subscription_state($uid);
        if($s['status']==='promo'&&$s['until']){
            $days=(int)ceil(($s['until']-time())/DAY_IN_SECONDS);
            foreach([30,7,1] as $d){$key='pw_billing_reminder_'.$d;if($days<=$d&&$days>=0&&get_user_meta($uid,$key,true)!=='1'){
                $u=get_userdata($uid);$noticeTitle=pw_billing_t_for_user($uid,'Einführungsphase endet bald','Launch period ends soon');$noticeBody=pw_billing_t_for_user($uid,'Deine kostenfreie Einführungsphase endet in '.$days.' Tagen. Hinterlege rechtzeitig dein Abo, damit der Zugang ohne Unterbrechung weiterläuft.','Your free launch period ends in '.$days.' days. Set up your subscription in time to keep access uninterrupted.');pw_create_notice($uid,$noticeTitle,$noticeBody,pw_page_url('account',['tab'=>'billing']));
                if($u)pw_send_mail($u->user_email,'Pure Work – '.$noticeTitle,pw_billing_t_for_user($uid,'Abo vorbereiten','Prepare subscription'),pw_billing_t_for_user($uid,'Deine kostenfreie Einführungsphase endet in '.$days.' Tagen. Aktiviere deinen gewählten Tarif rechtzeitig.','Your free launch period ends in '.$days.' days. Activate your selected plan in time.'),pw_billing_t_for_user($uid,'Abo verwalten','Manage subscription'),pw_page_url('account',['tab'=>'billing']));
                update_user_meta($uid,$key,'1');
            }}
            if($s['until']<time()&&empty(pw_user_meta($uid,'pw_stripe_subscription_id',''))){update_user_meta($uid,'pw_subscription_status','payment_required');}
        }
    }
}
add_action('pw_daily_billing_event','pw_billing_daily_check');
