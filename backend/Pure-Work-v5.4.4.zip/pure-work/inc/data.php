<?php
if (!defined('ABSPATH')) exit;

function pw_meta($post_id, $key, $default = '') {
    $value = get_post_meta($post_id, $key, true);
    return ($value === '' || $value === null) ? $default : $value;
}

function pw_user_meta($user_id, $key, $default = '') {
    $value = get_user_meta($user_id, $key, true);
    return ($value === '' || $value === null) ? $default : $value;
}

function pw_is_demo_user($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    return $user_id && get_user_meta($user_id, 'pw_demo', true) === '1';
}

function pw_is_demo_post($post_id) {
    return $post_id && get_post_meta($post_id, 'pw_demo', true) === '1';
}

function pw_demo_scope_matches($user_id, $post_id) {
    return pw_is_demo_user($user_id) === pw_is_demo_post($post_id);
}

function pw_company_alias($user_id) {
    $role = pw_user_role($user_id);
    $prefix = $role === 'agency' ? 'Personaldienstleister' : 'Auftraggeber';
    $hash = strtoupper(substr(hash('sha256', 'purework|' . (int)$user_id . '|' . wp_salt('auth')), 0, 4));
    return $prefix . ' #' . $hash;
}

function pw_company_display_name_legacy47($user_id, $viewer_id = 0, $force_private = false) {
    $company = pw_user_meta($user_id, 'pw_company', '');
    if (!$viewer_id) $viewer_id = get_current_user_id();
    if (current_user_can('manage_options') || $viewer_id === (int)$user_id || (!$force_private && pw_counterparty_identity_released($viewer_id, $user_id))) {
        return $company ?: pw_company_alias($user_id);
    }
    return pw_company_alias($user_id);
}


function pw_account_active($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    if (user_can($user_id, 'manage_options')) return true;
    if (!in_array(pw_user_role($user_id), ['agency','client'], true)) return false;
    if (pw_user_role($user_id) === 'agency' && function_exists('pw_aug_state')) {
        $state = pw_aug_state($user_id);
        if (!empty($state['expired'])) return false;
    }
    return true;
}

function pw_is_verified($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    if (user_can($user_id, 'manage_options')) return true;
    if (function_exists('pw_email_is_verified') && !pw_email_is_verified($user_id)) return false;
    if (get_user_meta($user_id, 'pw_company_verified', true) !== '1') return false;
    if (pw_user_role($user_id) === 'agency' && get_user_meta($user_id, 'pw_aug_verified', true) !== '1') return false;
    return true;
}

function pw_verification_state($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return ['email' => false, 'company' => false, 'aug' => false, 'ready' => false];
    $role = pw_user_role($user_id);
    $email = function_exists('pw_email_is_verified') ? pw_email_is_verified($user_id) : true;
    $company = user_can($user_id, 'manage_options') || get_user_meta($user_id, 'pw_company_verified', true) === '1';
    $aug = $role !== 'agency' || get_user_meta($user_id, 'pw_aug_verified', true) === '1';
    return ['email' => $email, 'company' => $company, 'aug' => $aug, 'ready' => ($email && $company && $aug)];
}

function pw_agency_has_access_legacy47($user_id = 0) {
    // Pure Work 4.6 keeps the launch phase free, while verification and compliance locks remain active.
    if (!$user_id) $user_id = get_current_user_id();
    return pw_account_active($user_id);
}

function pw_subscription_label_legacy47($user_id = 0) {
    return ['Kostenfrei', 'success'];
}

function pw_verified_gate($action_text = '') {
    if ($action_text==='') $action_text=pw_t('diese Funktion nutzen','use this feature');
    if (!pw_is_verified()) {
        $state = pw_verification_state();
        $aug_state = function_exists('pw_aug_state') ? pw_aug_state() : ['expired'=>false];
        if (!empty($aug_state['expired'])) {
            $title = pw_t('AÜG-Erlaubnis abgelaufen','AÜG permit expired');
            $text = pw_t('Der Marktplatzzugang ist gesperrt, bis aktuelle AÜG-Unterlagen geprüft wurden.','Marketplace access is locked until current AÜG documents have been reviewed.');
        } elseif (!$state['email']) {
            $title = pw_t('E-Mail-Adresse noch nicht bestätigt','Email address not confirmed yet');
            $text = sprintf(pw_t('Bestätige deine geschäftliche E-Mail-Adresse, bevor du %s.','Confirm your business email address before you %s.'),$action_text);
        } elseif (!$state['company']) {
            $title = pw_t('Unternehmensprüfung läuft','Company review in progress');
            $text = sprintf(pw_t('Nach der Prüfung deines Unternehmens kannst du %s.','After your company has been reviewed, you can %s.'),$action_text);
        } else {
            $title = pw_t('AÜG-Prüfung erforderlich','AÜG review required');
            $text = sprintf(pw_t('Deine AÜG-Erlaubnis muss bestätigt sein, bevor du %s.','Your AÜG permit must be confirmed before you %s.'),$action_text);
        }
        return '<div class="pw-gate-card">'.pw_icon('lock').'<div><strong>'.esc_html($title).'</strong><p>'.esc_html($text).'</p></div><a class="pw-btn small" href="'.esc_url(pw_page_url('account',['tab'=>'verification'])).'">'.esc_html(pw_t('Status ansehen','View status')).'</a></div>';
    }
    if (pw_user_role()==='agency' && function_exists('pw_agency_has_access') && !pw_agency_has_access()) {
        return '<div class="pw-gate-card pw-payment-gate">'.pw_icon('lock').'<div><strong>'.esc_html(pw_t('Tarif aktivieren','Activate your plan')).'</strong><p>'.esc_html(pw_t('Die kostenfreie Startphase ist für dieses Konto nicht aktiv. Wähle Basic, Pro oder Max, um Pure Work vollständig zu nutzen.','The free launch phase is not active for this account. Choose Basic, Pro or Max to use Pure Work fully.')).'</p></div><a class="pw-btn primary small" href="'.esc_url(pw_page_url('account',['tab'=>'billing'])).'">'.esc_html(pw_t('Tarif & Zahlung öffnen','Open plan & payment')).'</a></div>';
    }
    return '';
}

function pw_sanitize_csv_list($value) {
    if (is_array($value)) $value = implode(',', $value);
    $parts = preg_split('/[,;\n]+/', (string)$value);
    $parts = array_filter(array_map(function($v){ return sanitize_text_field(trim($v)); }, $parts));
    return array_values(array_unique($parts));
}

function pw_list_string($value) {
    if (is_array($value)) return implode(', ', $value);
    return (string)$value;
}

function pw_normalize_text($text) {
    $text = remove_accents(pw_lower((string)$text));
    $text = preg_replace('/[^a-z0-9äöüß\s\-]/u', ' ', $text);
    $text = preg_replace('/\s+/', ' ', $text);
    return trim($text);
}

function pw_geocode_location($query) {
    $query = trim((string)$query);
    if (!$query || get_option('pw_geocoding_enabled','1') !== '1') return null;
    $key = 'pw_geo_' . md5(pw_lower($query));
    $cached = get_transient($key);
    if (is_array($cached)) return $cached;

    $url = add_query_arg([
        'format' => 'jsonv2',
        'limit' => 1,
        'countrycodes' => 'de',
        'q' => $query,
    ], 'https://nominatim.openstreetmap.org/search');
    $response = wp_remote_get($url, [
        'timeout' => 4,
        'headers' => ['User-Agent' => 'PureWork-WordPress/' . PW_VERSION . ' (' . home_url('/') . ')'],
    ]);
    if (is_wp_error($response)) return null;
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (!empty($body[0]['lat']) && !empty($body[0]['lon'])) {
        $geo = ['lat' => (float)$body[0]['lat'], 'lng' => (float)$body[0]['lon']];
        set_transient($key, $geo, MONTH_IN_SECONDS);
        return $geo;
    }
    return null;
}

function pw_distance_km($lat1, $lng1, $lat2, $lng2) {
    if (!$lat1 || !$lng1 || !$lat2 || !$lng2) return null;
    $earth = 6371;
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lng2 - $lng1);
    $a = sin($dLat/2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon/2) ** 2;
    return $earth * (2 * atan2(sqrt($a), sqrt(1-$a)));
}

function pw_user_distance_to_location($user_id, $lat, $lng) {
    $ulat = (float)pw_user_meta($user_id, 'pw_lat', 0);
    $ulng = (float)pw_user_meta($user_id, 'pw_lng', 0);
    return pw_distance_km($ulat, $ulng, (float)$lat, (float)$lng);
}

function pw_vacancy_fields_legacy47($post_id) {
    $keys = ['qty','location','lat','lng','start_date','duration','hours','shift','industry','must_quals','nice_quals','language','driver','rate_max','deadline','target_mode','target_agencies','status'];
    $out = ['id' => (int)$post_id, 'title' => get_the_title($post_id), 'description' => get_post_field('post_content',$post_id), 'author' => (int)get_post_field('post_author',$post_id)];
    foreach ($keys as $k) $out[$k] = pw_meta($post_id, 'pw_'.$k, '');
    $out['must_quals'] = is_array($out['must_quals']) ? $out['must_quals'] : pw_sanitize_csv_list($out['must_quals']);
    $out['nice_quals'] = is_array($out['nice_quals']) ? $out['nice_quals'] : pw_sanitize_csv_list($out['nice_quals']);
    $out['target_agencies'] = is_array($out['target_agencies']) ? array_map('intval',$out['target_agencies']) : array_filter(array_map('intval', explode(',', (string)$out['target_agencies'])));
    return $out;
}

function pw_worker_fields_legacy47($post_id) {
    $keys = ['code','role','experience','location','lat','lng','available_from','availability','shifts','qualifications','languages','driver','car','industries','last_assignment','status','cv_file','docs_file','full_name','email','phone','address'];
    $out = ['id' => (int)$post_id, 'author' => (int)get_post_field('post_author',$post_id), 'title' => get_the_title($post_id)];
    foreach ($keys as $k) $out[$k] = pw_meta($post_id, 'pw_'.$k, '');
    foreach (['shifts','qualifications','languages','industries'] as $k) {
        if (!is_array($out[$k])) $out[$k] = pw_sanitize_csv_list($out[$k]);
    }
    return $out;
}

function pw_match_worker_to_vacancy($worker_id, $vacancy_id) {
    $w = pw_worker_fields($worker_id);
    $v = pw_vacancy_fields($vacancy_id);
    $score = 0;
    $reasons = [];
    $misses = [];

    // Role / title (20)
    $role = pw_normalize_text($w['role']);
    $title = pw_normalize_text($v['title']);
    $roleHit = $role && $title && (pw_contains($title,$role) || pw_contains($role,$title));
    if (!$roleHit && $role && $title) {
        $roleWords = array_filter(explode(' ', $role));
        foreach ($roleWords as $word) if (strlen($word) > 3 && pw_contains($title, $word)) { $roleHit = true; break; }
    }
    if ($roleHit) { $score += 20; $reasons[] = 'Tätigkeit passt'; }
    else $misses[] = 'Tätigkeit abweichend';

    // Distance (25)
    $distance = pw_distance_km((float)$w['lat'], (float)$w['lng'], (float)$v['lat'], (float)$v['lng']);
    $radius = (int)pw_user_meta($w['author'], 'pw_notify_radius', 50);
    if ($distance !== null) {
        if ($distance <= min(15,$radius)) { $score += 25; $reasons[] = round($distance).' km entfernt'; }
        elseif ($distance <= $radius) { $score += 18; $reasons[] = round($distance).' km im Radius'; }
        else { $misses[] = round($distance).' km entfernt'; }
    } else {
        $wloc = pw_normalize_text($w['location']); $vloc = pw_normalize_text($v['location']);
        if ($wloc && $vloc && ($wloc === $vloc || pw_contains($wloc,$vloc) || pw_contains($vloc,$wloc))) { $score += 20; $reasons[] = 'Region passt'; }
        else $score += 8;
    }

    // Availability (15)
    $status = (string)$w['status'];
    $available = (string)$w['available_from'];
    if (in_array($status,['available','reserved'],true)) {
        if (!$available || !$v['start_date'] || strtotime($available) <= strtotime((string)$v['start_date'])) { $score += 15; $reasons[] = 'Zum Start verfügbar'; }
        else { $score += 5; $misses[] = 'Erst ab '.wp_date('d.m.Y', strtotime($available)); }
    } else $misses[] = 'Derzeit nicht verfügbar';

    // Shift (10)
    $shift = pw_normalize_text($v['shift']);
    $workerShifts = pw_normalize_text(implode(' ', (array)$w['shifts']));
    if (!$shift || $shift === 'keine angabe') { $score += 8; }
    elseif ($workerShifts && (pw_contains($workerShifts,$shift) || pw_contains($shift,$workerShifts))) { $score += 10; $reasons[] = 'Schichtmodell passt'; }
    else $misses[] = 'Schichtmodell prüfen';

    // Must qualifications (20)
    $must = array_map('pw_normalize_text', (array)$v['must_quals']);
    $have = pw_normalize_text(implode(' ', (array)$w['qualifications']));
    if (!$must) { $score += 16; }
    else {
        $hit = 0;
        foreach ($must as $q) if ($q && pw_contains($have,$q)) $hit++;
        $ratio = $hit / max(1,count($must));
        $score += (int)round(20*$ratio);
        if ($ratio >= 1) $reasons[] = 'Alle Muss-Qualifikationen';
        elseif ($ratio > 0) $misses[] = 'Muss-Kriterien teilweise erfüllt';
        else $misses[] = 'Muss-Qualifikationen fehlen';
    }

    // Language (5)
    $lang = pw_normalize_text($v['language']);
    $langs = pw_normalize_text(implode(' ', (array)$w['languages']));
    if (!$lang) $score += 4;
    elseif ($langs && pw_contains($langs, $lang)) { $score += 5; $reasons[] = 'Sprache passt'; }
    else $misses[] = 'Sprache prüfen';

    // Mobility / industry (5)
    $ind = pw_normalize_text($v['industry']);
    $inds = pw_normalize_text(implode(' ', (array)$w['industries']));
    if ($ind && $inds && (pw_contains($inds,$ind) || pw_contains($ind,$inds))) { $score += 3; $reasons[] = 'Branchenerfahrung'; }
    if ($v['driver'] && $w['driver']) { $score += 2; $reasons[] = 'Führerschein vorhanden'; }
    elseif (!$v['driver']) $score += 2;

    return [
        'score' => min(100,max(0,$score)),
        'reasons' => array_slice($reasons,0,4),
        'misses' => array_slice($misses,0,3),
        'distance' => $distance,
    ];
}

function pw_best_workers_for_vacancy($vacancy_id, $agency_id = 0, $limit = 20) {
    $args = ['post_type'=>'pw_worker','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC'];
    if ($agency_id) $args['author'] = (int)$agency_id;
    $q = new WP_Query($args);
    $items = [];
    foreach ($q->posts as $post) {
        $vacancy_demo = pw_is_demo_post($vacancy_id);
        $worker_agency = (int)$post->post_author;
        if (pw_is_demo_user($worker_agency) !== $vacancy_demo) continue;
        if (!pw_account_active($worker_agency) || !pw_agency_has_access($worker_agency)) continue;
        if (pw_meta($post->ID,'pw_status','available') === 'inactive') continue;
        $match = pw_match_worker_to_vacancy($post->ID,$vacancy_id);
        if ($match['score'] >= 35) $items[] = ['worker'=>$post,'match'=>$match];
    }
    usort($items,function($a,$b){ return $b['match']['score'] <=> $a['match']['score']; });
    return array_slice($items,0,$limit);
}

function pw_best_vacancies_for_agency($agency_id, $limit = 20) {
    $q = new WP_Query(['post_type'=>'pw_vacancy','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC']);
    $items = [];
    foreach ($q->posts as $vacancy) {
        if (!pw_agency_can_see_vacancy($agency_id,$vacancy->ID)) continue;
        if (pw_meta($vacancy->ID,'pw_status','open') !== 'open') continue;
        $workers = pw_best_workers_for_vacancy($vacancy->ID,$agency_id,5);
        $best = $workers ? $workers[0]['match']['score'] : 0;
        if ($workers) $items[] = ['vacancy'=>$vacancy,'workers'=>$workers,'best_score'=>$best];
    }
    usort($items,function($a,$b){ return $b['best_score'] <=> $a['best_score']; });
    return array_slice($items,0,$limit);
}

function pw_agency_can_see_vacancy_legacy47($agency_id, $vacancy_id) {
    $v = pw_vacancy_fields($vacancy_id);
    if (!$v || get_post_type($vacancy_id) !== 'pw_vacancy') return false;
    if (!pw_account_active($agency_id)) return false;
    if (!pw_agency_has_access($agency_id)) return false;
    if (!pw_demo_scope_matches($agency_id, $vacancy_id)) return false;

    $mode = $v['target_mode'] ?: 'all';
    if ($mode === 'selected' && !in_array((int)$agency_id,(array)$v['target_agencies'],true)) return false;
    if ($mode === 'favorites') {
        $fav = array_map('intval',(array)pw_user_meta($v['author'],'pw_favorites',[]));
        if (!in_array((int)$agency_id,$fav,true)) return false;
    }

    $blocked = array_map('intval',(array)pw_user_meta($agency_id,'pw_blocked_companies',[]));
    if (in_array((int)$v['author'],$blocked,true)) return false;
    $client_blocked = array_map('intval',(array)pw_user_meta($v['author'],'pw_blocked_companies',[]));
    if (in_array((int)$agency_id,$client_blocked,true)) return false;

    $onlyFav = pw_user_meta($agency_id,'pw_notify_clients','all') === 'favorites';
    if ($onlyFav) {
        $favs = array_map('intval',(array)pw_user_meta($agency_id,'pw_favorites',[]));
        if (!in_array((int)$v['author'],$favs,true)) return false;
    }

    $radius = (int)pw_user_meta($agency_id,'pw_notify_radius',50);
    $distance = pw_user_distance_to_location($agency_id,(float)$v['lat'],(float)$v['lng']);
    if ($distance !== null && $radius > 0 && $distance > $radius) return false;

    $industries = (array)pw_user_meta($agency_id,'pw_notify_industries',[]);
    if ($industries && $v['industry']) {
        $hay = pw_normalize_text(implode(' ',$industries));
        $needle = pw_normalize_text($v['industry']);
        if ($needle && !pw_contains($hay,$needle) && !pw_contains($needle,$hay)) return false;
    }
    return true;
}

function pw_matching_agencies_for_vacancy_legacy47($vacancy_id) {
    $users = get_users(['role'=>'pw_agency','fields'=>'ID']);
    return array_values(array_filter(array_map('intval',$users), function($uid) use ($vacancy_id){ return pw_agency_can_see_vacancy($uid,$vacancy_id); }));
}

function pw_counterparty_identity_released_legacy47($viewer_id, $other_user_id) {
    if (!$viewer_id || !$other_user_id) return false;
    if ($viewer_id === $other_user_id) return true;
    $subs = get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>20,'meta_query'=>[
        'relation'=>'AND',
        ['key'=>'pw_agency_id','value'=>[min($viewer_id,$other_user_id),max($viewer_id,$other_user_id)],'compare'=>'IN'],
    ]]);
    // Above query is intentionally broad; validate pair below.
    foreach ($subs as $sub) {
        $agency = (int)pw_meta($sub->ID,'pw_agency_id',0);
        $vacancy = (int)pw_meta($sub->ID,'pw_vacancy_id',0);
        $client = $vacancy ? (int)get_post_field('post_author',$vacancy) : (int)pw_meta($sub->ID,'pw_client_id',0);
        if (in_array($viewer_id,[$agency,$client],true) && in_array($other_user_id,[$agency,$client],true)) {
            $status = pw_meta($sub->ID,'pw_status','submitted');
            if (in_array($status,['confirmed','planned'],true)) return true;
        }
    }
    return false;
}

function pw_status_labels_legacy47() {
    return [
        'submitted' => ['Eingereicht','info'],
        'viewed' => ['Angesehen','muted'],
        'shortlisted' => ['Vorgemerkt','warning'],
        'requested' => ['Angefragt','brand'],
        'confirmed' => ['Bestätigt','success'],
        'planned' => ['Einsatz geplant','success'],
        'rejected' => ['Abgelehnt','danger'],
        'withdrawn' => ['Zurückgezogen','muted'],
    ];
}

function pw_status_badge($status) {
    $all = pw_status_labels(); $item = $all[$status] ?? [$status,'muted'];
    return '<span class="pw-badge '.$item[1].'">'.esc_html($item[0]).'</span>';
}

function pw_worker_status_badge($status) {
    $map = [
        'available'=>['Sofort verfügbar','success'],
        'reserved'=>['Reserviert','warning'],
        'assigned'=>['Im Einsatz','info'],
        'inactive'=>['Inaktiv','muted'],
    ];
    $it = $map[$status] ?? $map['available'];
    return '<span class="pw-badge '.$it[1].'">'.esc_html($it[0]).'</span>';
}

function pw_create_notice($user_id, $title, $message, $url = '') {
    if (!$user_id) return 0;
    $id = wp_insert_post(['post_type'=>'pw_notice','post_status'=>'publish','post_author'=>(int)$user_id,'post_title'=>wp_strip_all_tags($title),'post_content'=>wp_kses_post($message)]);
    if (!is_wp_error($id)) {
        update_post_meta($id,'pw_url',esc_url_raw($url));
        update_post_meta($id,'pw_read','0');
        return $id;
    }
    return 0;
}

function pw_unread_notice_count($user_id) {
    if (!$user_id) return 0;
    $q = new WP_Query(['post_type'=>'pw_notice','post_status'=>'publish','author'=>$user_id,'posts_per_page'=>1,'fields'=>'ids','meta_query'=>[['key'=>'pw_read','value'=>'0']]]);
    return (int)$q->found_posts;
}

function pw_unread_message_count($user_id) {
    if (!$user_id) return 0;
    $q = new WP_Query(['post_type'=>'pw_message','post_status'=>'publish','posts_per_page'=>1,'fields'=>'ids','meta_query'=>[
        'relation'=>'AND',
        ['key'=>'pw_recipient','value'=>(int)$user_id],
        ['key'=>'pw_read','value'=>'0'],
    ]]);
    return (int)$q->found_posts;
}

function pw_send_mail($to, $subject, $headline, $body, $button_label = '', $button_url = '') {
    if (!$to || !is_email($to)) return false;
    $brand = esc_html(get_option('pw_company_name','Pure Work'));
    $logo = esc_url(PW_URI . '/assets/pure-work-logo.png');
    $html = '<!doctype html><html><body style="margin:0;background:#f3f5f9;font-family:Arial,Helvetica,sans-serif;color:#172033;padding:24px 12px"><div style="max-width:620px;margin:0 auto;background:#fff;border-radius:20px;overflow:hidden;border:1px solid #e3e7ef;box-shadow:0 16px 45px rgba(18,30,60,.08)"><div style="padding:22px 30px;background:#101828;border-bottom:3px solid #3157f6"><img src="'.$logo.'" alt="Pure Work" style="display:block;max-width:155px;max-height:38px;width:auto;height:auto"></div><div style="padding:34px 30px 30px"><div style="font-size:12px;font-weight:800;letter-spacing:.12em;color:#3157f6;text-transform:uppercase;margin-bottom:10px">PURE WORK</div><h1 style="font-size:25px;line-height:1.2;margin:0 0 16px;color:#101828">'.esc_html($headline).'</h1><div style="font-size:15px;line-height:1.7;color:#475467">'.wp_kses_post(wpautop($body)).'</div>';
    if ($button_label && $button_url) $html .= '<p style="margin:26px 0 0"><a href="'.esc_url($button_url).'" style="display:inline-block;background:#3157f6;color:#fff;text-decoration:none;font-weight:700;padding:12px 18px;border-radius:10px">'.esc_html($button_label).'</a></p>';
    $html .= '</div><div style="padding:18px 30px;background:#f8fafc;border-top:1px solid #eef1f5;color:#98a2b3;font-size:12px;line-height:1.55">Diese Nachricht wurde automatisch von Pure Work versendet.<br>Bitte antworte nicht auf Systemnachrichten, sofern keine Antwortadresse angegeben ist.</div></div></body></html>';
    return wp_mail($to, $subject, $html, ['Content-Type: text/html; charset=UTF-8']);
}

function pw_queue_vacancy_notification($agency_id, $vacancy_id) {
    $frequency = pw_user_meta($agency_id,'pw_notify_frequency','immediate');
    if ($frequency === 'portal') {
        pw_create_notice($agency_id,'Neue passende Personalanfrage','Eine neue Personalanfrage passt zu deinen Filtern.',pw_page_url('vacancies',['view'=>$vacancy_id]));
        return;
    }
    if ($frequency === 'daily') {
        $queue = array_map('intval',(array)pw_user_meta($agency_id,'pw_digest_queue',[]));
        $queue[] = (int)$vacancy_id;
        update_user_meta($agency_id,'pw_digest_queue',array_values(array_unique($queue)));
        pw_create_notice($agency_id,'Neue passende Personalanfrage','Eine neue Personalanfrage wurde für deine tägliche Zusammenfassung vorgemerkt.',pw_page_url('vacancies',['view'=>$vacancy_id]));
        return;
    }
    $v = pw_vacancy_fields($vacancy_id);
    $user = get_userdata($agency_id);
    if (!$user) return;
    pw_create_notice($agency_id,'Neue passende Personalanfrage',esc_html($v['title']).' in '.esc_html($v['location']).' passt zu deinen Filtern.',pw_page_url('vacancies',['view'=>$vacancy_id]));
    pw_send_mail($user->user_email,'Neue Personalanfrage bei Pure Work: '.$v['title'],'Neue passende Personalanfrage',$v['qty'].' Mitarbeiter gesucht: '.$v['title'].' in '.$v['location'].'. Start: '.($v['start_date'] ? wp_date('d.m.Y',strtotime($v['start_date'])) : 'offen').'.','Personalanfrage öffnen',pw_page_url('vacancies',['view'=>$vacancy_id]));
}

function pw_on_vacancy_publish($new_status, $old_status, $post) {
    if ($post->post_type !== 'pw_vacancy' || $new_status !== 'publish' || $old_status === 'publish') return;
    foreach (pw_matching_agencies_for_vacancy($post->ID) as $agency_id) pw_queue_vacancy_notification($agency_id,$post->ID);
}
add_action('transition_post_status','pw_on_vacancy_publish',10,3);

function pw_send_daily_digests() {
    $users = get_users(['role'=>'pw_agency']);
    foreach ($users as $user) {
        $queue = array_map('intval',(array)pw_user_meta($user->ID,'pw_digest_queue',[]));
        if (!$queue) continue;
        // v5.1: Der tägliche Digest ist ein echter Pro-Vorteil. Basic bekommt weiterhin
        // In-App-Hinweise, aber keine kostenpflichtig vermarktete Mail-Automation.
        if (function_exists('pw_can') && !pw_can('daily_digest', $user->ID)) {
            delete_user_meta($user->ID,'pw_digest_queue');
            continue;
        }
        $lines = [];
        foreach (array_slice($queue,0,20) as $vacancy_id) {
            if (get_post_status($vacancy_id) === 'publish') {
                $v = pw_vacancy_fields($vacancy_id);
                $lines[] = '• '.$v['title'].' — '.$v['location'].' — '.(int)$v['qty'].' Mitarbeiter';
            }
        }
        if ($lines) pw_send_mail($user->user_email,'Deine Pure Work Tagesübersicht','Passende Personalanfragen',implode("\n",$lines),'Pure Work öffnen',pw_page_url('vacancies'));
        delete_user_meta($user->ID,'pw_digest_queue');
    }
}
add_action('pw_daily_digest_event','pw_send_daily_digests');

function pw_submission_parties($submission_id) {
    $agency = (int)pw_meta($submission_id,'pw_agency_id',0);
    $vacancy = (int)pw_meta($submission_id,'pw_vacancy_id',0);
    $client = $vacancy ? (int)get_post_field('post_author',$vacancy) : (int)pw_meta($submission_id,'pw_client_id',0);
    return [$agency,$client];
}

function pw_can_access_submission($submission_id, $user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (user_can($user_id,'manage_options')) return true;
    return in_array((int)$user_id,pw_submission_parties($submission_id),true);
}

function pw_submission_exists($vacancy_id,$worker_id) {
    $q = get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>1,'fields'=>'ids','meta_query'=>[
        'relation'=>'AND',
        ['key'=>'pw_vacancy_id','value'=>(int)$vacancy_id],
        ['key'=>'pw_worker_id','value'=>(int)$worker_id],
    ]]);
    return $q ? (int)$q[0] : 0;
}

function pw_mark_submission_viewed($submission_id) {
    if (pw_user_role() !== 'client') return;
    if (!pw_can_access_submission($submission_id)) return;
    if (pw_meta($submission_id,'pw_status','submitted') === 'submitted') {
        update_post_meta($submission_id,'pw_status','viewed');
        update_post_meta($submission_id,'pw_viewed_at',time());
    }
}

function pw_private_dir() {
    $dir = WP_CONTENT_DIR . '/purework-private';
    if (!is_dir($dir)) wp_mkdir_p($dir);
    if (is_dir($dir)) {
        $ht = $dir.'/.htaccess';
        if (!file_exists($ht)) @file_put_contents($ht,"Order deny,allow\nDeny from all\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n");
        $idx = $dir.'/index.php'; if (!file_exists($idx)) @file_put_contents($idx,"<?php http_response_code(403); exit;\n");
    }
    return $dir;
}

function pw_store_private_upload($field, $owner_id, $kind = 'document', $worker_id = 0) {
    if (empty($_FILES[$field]) || empty($_FILES[$field]['tmp_name']) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return 0;
    $file = $_FILES[$field];
    if ((int)$file['size'] > 10 * 1024 * 1024) return new WP_Error('too_large','Datei ist größer als 10 MB.');
    $allowed = ['pdf'=>'application/pdf','doc'=>'application/msword','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','csv'=>'text/csv'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!isset($allowed[$ext])) return new WP_Error('type','Dateityp nicht erlaubt.');
    $dir = pw_private_dir();
    if (!is_dir($dir) || !is_writable($dir)) return new WP_Error('dir','Privates Upload-Verzeichnis ist nicht beschreibbar.');
    $name = wp_unique_filename($dir, $owner_id.'-'.time().'-'.sanitize_file_name($file['name']));
    $target = trailingslashit($dir).$name;
    if (!@move_uploaded_file($file['tmp_name'],$target)) return new WP_Error('move','Upload konnte nicht gespeichert werden.');
    $id = wp_insert_post(['post_type'=>'pw_file','post_status'=>'publish','post_author'=>(int)$owner_id,'post_title'=>sanitize_text_field($file['name'])]);
    if (is_wp_error($id)) { @unlink($target); return $id; }
    update_post_meta($id,'pw_path',$target);
    update_post_meta($id,'pw_kind',sanitize_key($kind));
    update_post_meta($id,'pw_mime',$allowed[$ext]);
    update_post_meta($id,'pw_worker_id',(int)$worker_id);
    return $id;
}

function pw_file_download_url($file_id) {
    return wp_nonce_url(admin_url('admin-post.php?action=pw_download_file&file='.(int)$file_id),'pw_download_'.(int)$file_id);
}

function pw_can_download_file_legacy47($file_id,$user_id=0) {
    if (!$user_id) $user_id = get_current_user_id();
    $post = get_post($file_id);
    if (!$post || $post->post_type !== 'pw_file') return false;
    if (user_can($user_id,'manage_options')) return true;
    if (!pw_account_active($user_id)) return false;
    if ((int)$post->post_author === (int)$user_id) return true;
    $worker_id = (int)pw_meta($file_id,'pw_worker_id',0);
    if (!$worker_id) return false;
    $subs = get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_worker_id','value'=>$worker_id]]]);
    foreach ($subs as $sid) {
        if (!pw_can_access_submission($sid,$user_id)) continue;
        $status = pw_meta($sid,'pw_status','submitted');
        if (pw_meta($sid,'pw_released','0') === '1' || in_array($status,['confirmed','planned'],true)) return true;
    }
    return false;
}

function pw_format_date($date) {
    if (!$date) return '–';
    $ts = is_numeric($date) ? (int)$date : strtotime($date);
    return $ts ? wp_date('d.m.Y',$ts) : '–';
}

function pw_initials($text) {
    $words = preg_split('/\s+/', trim((string)$text)); $out='';
    foreach (array_slice($words,0,2) as $w) $out .= pw_upper(pw_substr($w,0,1));
    return $out ?: 'PW';
}

function pw_metric($value,$label,$hint='',$tone='') {
    return '<div class="pw-metric '.esc_attr($tone).'"><div><strong>'.esc_html($value).'</strong><span>'.esc_html($label).'</span></div>'.($hint?'<small>'.esc_html($hint).'</small>':'').'</div>';
}
