<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.6 – AÜG lifecycle controls.
 *
 * The portal distinguishes between limited and unlimited permits. For limited
 * permits a valid expiry date is mandatory. A daily cron sends reminders and
 * blocks authentication after the stored expiry date. The operator still has
 * to verify the uploaded document; the software cannot replace the authority.
 */

function pw_aug_state($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    $role = pw_user_role($user_id);
    if ($role !== 'agency') {
        return ['applicable'=>false,'type'=>'','expiry'=>'','days'=>null,'expired'=>false,'warning'=>false,'missing'=>false,'status'=>'not_applicable'];
    }

    $type = pw_user_meta($user_id, 'pw_aug_type', 'limited');
    if (!in_array($type, ['limited','unlimited'], true)) $type = 'limited';
    if ($type === 'unlimited') {
        return ['applicable'=>true,'type'=>'unlimited','expiry'=>'','days'=>null,'expired'=>false,'warning'=>false,'missing'=>false,'status'=>'unlimited'];
    }

    $expiry = sanitize_text_field((string)pw_user_meta($user_id, 'pw_aug_expiry', ''));
    if (!$expiry || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiry)) {
        return ['applicable'=>true,'type'=>'limited','expiry'=>$expiry,'days'=>null,'expired'=>false,'warning'=>true,'missing'=>true,'status'=>'missing'];
    }

    $today = strtotime(wp_date('Y-m-d') . ' 00:00:00');
    $end   = strtotime($expiry . ' 23:59:59');
    if (!$today || !$end) {
        return ['applicable'=>true,'type'=>'limited','expiry'=>$expiry,'days'=>null,'expired'=>false,'warning'=>true,'missing'=>true,'status'=>'missing'];
    }
    $days = (int)floor(($end - $today) / DAY_IN_SECONDS);
    $expired = $days < 0;
    $warning = !$expired && $days <= 90;
    return [
        'applicable'=>true,
        'type'=>'limited',
        'expiry'=>$expiry,
        'days'=>$days,
        'expired'=>$expired,
        'warning'=>$warning,
        'missing'=>false,
        'status'=>$expired ? 'expired' : ($warning ? 'warning' : 'valid'),
    ];
}

function pw_aug_status_label($user_id = 0) {
    $s = pw_aug_state($user_id);
    if (!$s['applicable']) return ['Nicht erforderlich','muted'];
    if ($s['type'] === 'unlimited') return ['Unbefristet','success'];
    if ($s['missing']) return ['Ablaufdatum fehlt','warning'];
    if ($s['expired']) return ['Abgelaufen','danger'];
    if ($s['days'] <= 30) return ['Läuft in '.$s['days'].' Tagen ab','danger'];
    if ($s['days'] <= 90) return ['Läuft in '.$s['days'].' Tagen ab','warning'];
    return ['Gültig bis '.pw_format_date($s['expiry']),'success'];
}

function pw_aug_login_guard($user, $username, $password) {
    if (!($user instanceof WP_User)) return $user;
    if (user_can($user, 'manage_options') || pw_user_role($user->ID) !== 'agency') return $user;
    $state = pw_aug_state($user->ID);
    $locked = get_user_meta($user->ID, 'pw_aug_login_locked', true) === '1';
    if ($state['expired'] || $locked) {
        if ($state['expired']) {
            update_user_meta($user->ID, 'pw_aug_expired', '1');
            update_user_meta($user->ID, 'pw_aug_login_locked', '1');
            update_user_meta($user->ID, 'pw_aug_verified', '0');
            if (function_exists('pw_send_aug_expired_mail')) pw_send_aug_expired_mail($user->ID);
        }
        return new WP_Error('pw_aug_expired', 'Der Pure Work Zugang ist wegen der AÜG-Prüfung vorübergehend gesperrt. Bitte aktualisiere die AÜG-Unterlagen.');
    }
    return $user;
}
add_filter('authenticate', 'pw_aug_login_guard', 50, 3);

function pw_aug_reminder_key($expiry, $days) {
    return 'pw_aug_notice_' . md5($expiry . '|' . (int)$days);
}

function pw_send_aug_reminder($user_id, $days) {
    $user = get_userdata($user_id);
    $state = pw_aug_state($user_id);
    if (!$user || !$state['expiry'] || $state['expired']) return false;
    $key = pw_aug_reminder_key($state['expiry'], $days);
    if (get_user_meta($user_id, $key, true) === '1') return false;

    $company = pw_user_meta($user_id, 'pw_company', 'dein Unternehmen');
    if ($days >= 90) {
        $headline = 'AÜG-Erlaubnis: Verlängerung jetzt einplanen';
        $body = 'Die bei Pure Work hinterlegte befristete AÜG-Erlaubnis für '.$company.' läuft am '.pw_format_date($state['expiry']).' ab. Nach den Hinweisen der Bundesagentur für Arbeit sollte der Verlängerungsantrag spätestens drei Monate vor Ablauf gestellt werden. Bitte aktualisiere dein Dokument rechtzeitig im Portal.';
    } elseif ($days >= 30) {
        $headline = 'AÜG-Erlaubnis läuft bald ab';
        $body = 'Deine hinterlegte AÜG-Erlaubnis läuft am '.pw_format_date($state['expiry']).' ab. Bitte lade die verlängerte Erlaubnis rechtzeitig hoch, damit dein Pure Work Zugang ohne Unterbrechung genutzt werden kann.';
    } elseif ($days >= 7) {
        $headline = 'Dringend: AÜG-Erlaubnis aktualisieren';
        $body = 'Noch '.$days.' Tage bis zum Ablauf deiner hinterlegten AÜG-Erlaubnis am '.pw_format_date($state['expiry']).'. Nach Ablauf wird der Login automatisch gesperrt, bis aktuelle Unterlagen vorliegen.';
    } else {
        $headline = 'AÜG-Erlaubnis läuft in Kürze ab';
        $body = 'Deine hinterlegte AÜG-Erlaubnis läuft am '.pw_format_date($state['expiry']).' ab. Bitte aktualisiere die Unterlagen jetzt. Nach dem Ablauf wird der Zugang automatisch gesperrt.';
    }

    $ok = pw_send_mail($user->user_email, 'Pure Work – '.$headline, $headline, $body, 'AÜG-Unterlagen öffnen', pw_page_url('account', ['tab'=>'profile']));
    pw_create_notice($user_id, $headline, $body, pw_page_url('account', ['tab'=>'profile']));
    if ($ok) update_user_meta($user_id, $key, '1');
    return $ok;
}

function pw_send_aug_expired_mail($user_id) {
    $user = get_userdata($user_id);
    $state = pw_aug_state($user_id);
    if (!$user || !$state['expired']) return false;
    $key = 'pw_aug_expired_mail_' . md5($state['expiry']);
    if (get_user_meta($user_id, $key, true) === '1') return false;

    $url = pw_page_url('aug_renew', ['email'=>$user->user_email]);
    $body = 'Die bei Pure Work hinterlegte befristete AÜG-Erlaubnis ist am '.pw_format_date($state['expiry']).' abgelaufen. Aus Sicherheits- und Compliance-Gründen wurde der Portal-Login gesperrt. Fordere über den folgenden Link einen sicheren Aktualisierungslink an und lade die neue Erlaubnis hoch.';
    $ok = pw_send_mail($user->user_email, 'Pure Work – AÜG-Erlaubnis abgelaufen', 'Portalzugang vorübergehend gesperrt', $body, 'AÜG-Unterlagen aktualisieren', $url);
    if ($ok) update_user_meta($user_id, $key, '1');
    return $ok;
}

function pw_daily_aug_compliance_check() {
    $agencies = get_users(['role'=>'pw_agency','fields'=>['ID','user_email']]);
    foreach ($agencies as $u) {
        $state = pw_aug_state($u->ID);
        if (!$state['applicable'] || $state['type'] === 'unlimited' || $state['missing']) continue;

        if ($state['expired']) {
            update_user_meta($u->ID, 'pw_aug_expired', '1');
            update_user_meta($u->ID, 'pw_aug_login_locked', '1');
            update_user_meta($u->ID, 'pw_aug_verified', '0');
            pw_send_aug_expired_mail($u->ID);
            continue;
        }
        delete_user_meta($u->ID, 'pw_aug_expired');
        foreach ([90,30,7,1] as $threshold) {
            if ($state['days'] <= $threshold) pw_send_aug_reminder($u->ID, $threshold);
        }
    }
}
add_action('pw_compliance_daily_event', 'pw_daily_aug_compliance_check');

function pw_schedule_compliance_cron() {
    if (!wp_next_scheduled('pw_compliance_daily_event')) {
        wp_schedule_event(time() + 600, 'daily', 'pw_compliance_daily_event');
    }
}
add_action('init', 'pw_schedule_compliance_cron', 40);

function pw_aug_clear_reminder_flags($user_id) {
    $all = get_user_meta($user_id);
    foreach (array_keys($all) as $key) {
        if (strpos($key, 'pw_aug_notice_') === 0 || strpos($key, 'pw_aug_expired_mail_') === 0) {
            delete_user_meta($user_id, $key);
        }
    }
}

function pw_aug_refresh_lock_state($user_id) {
    $state = pw_aug_state($user_id);
    if ($state['expired']) {
        update_user_meta($user_id, 'pw_aug_expired', '1');
        update_user_meta($user_id, 'pw_aug_login_locked', '1');
        update_user_meta($user_id, 'pw_aug_verified', '0');
    } elseif (get_user_meta($user_id, 'pw_aug_login_locked', true) !== '1') {
        // Normal pre-expiry updates stay login-capable; a lock created by a real
        // expiry is cleared only by an administrator after the replacement document is checked.
        delete_user_meta($user_id, 'pw_aug_expired');
    }
}

function pw_aug_token_hash($token) {
    return hash_hmac('sha256', (string)$token, wp_salt('secure_auth'));
}

function pw_create_aug_renew_token($user_id) {
    try { $token = bin2hex(random_bytes(24)); }
    catch (Exception $e) { $token = wp_generate_password(48, false, false); }
    update_user_meta($user_id, 'pw_aug_renew_hash', pw_aug_token_hash($token));
    update_user_meta($user_id, 'pw_aug_renew_expires', time() + HOUR_IN_SECONDS);
    return $token;
}

function pw_validate_aug_renew_token($user_id, $token) {
    $hash = (string)get_user_meta($user_id, 'pw_aug_renew_hash', true);
    $exp  = (int)get_user_meta($user_id, 'pw_aug_renew_expires', true);
    return $hash && $exp >= time() && $token && hash_equals($hash, pw_aug_token_hash($token));
}

function pw_handle_aug_renew_request() {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), 'pw_aug_renew_request')) wp_die('Sicherheitsprüfung fehlgeschlagen.');
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $user = $email ? get_user_by('email', $email) : false;
    if ($user && pw_user_role($user->ID) === 'agency') {
        $token = pw_create_aug_renew_token($user->ID);
        $url = pw_page_url('aug_renew', ['uid'=>$user->ID,'token'=>$token]);
        pw_send_mail($user->user_email, 'Pure Work – AÜG-Unterlagen aktualisieren', 'Sicherer Link zur AÜG-Aktualisierung', 'Über diesen einmaligen Link kannst du neue AÜG-Unterlagen hochladen. Der Link ist 60 Minuten gültig.', 'AÜG aktualisieren', $url);
    }
    wp_safe_redirect(pw_page_url('aug_renew', ['sent'=>1]));
    exit;
}
add_action('admin_post_nopriv_pw_aug_renew_request', 'pw_handle_aug_renew_request');
add_action('admin_post_pw_aug_renew_request', 'pw_handle_aug_renew_request');

function pw_handle_aug_renew_submit() {
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), 'pw_aug_renew_submit')) wp_die('Sicherheitsprüfung fehlgeschlagen.');
    $uid = (int)($_POST['uid'] ?? 0);
    $token = sanitize_text_field(wp_unslash($_POST['token'] ?? ''));
    if (!$uid || !pw_validate_aug_renew_token($uid, $token) || pw_user_role($uid) !== 'agency') {
        wp_safe_redirect(pw_page_url('aug_renew', ['error'=>'token'])); exit;
    }

    $type = sanitize_key(wp_unslash($_POST['aug_type'] ?? 'limited'));
    if (!in_array($type, ['limited','unlimited'], true)) $type = 'limited';
    $expiry = $type === 'unlimited' ? '' : sanitize_text_field(wp_unslash($_POST['aug_expiry'] ?? ''));
    if ($type === 'limited') {
        $ts = $expiry ? strtotime($expiry.' 23:59:59') : false;
        if (!$ts || $ts < time()) { wp_safe_redirect(pw_page_url('aug_renew', ['uid'=>$uid,'token'=>$token,'error'=>'date'])); exit; }
    }
    if (empty($_FILES['aug_file']['tmp_name'])) { wp_safe_redirect(pw_page_url('aug_renew', ['uid'=>$uid,'token'=>$token,'error'=>'file'])); exit; }

    $fid = pw_store_private_upload('aug_file', $uid, 'aug', 0);
    if (is_wp_error($fid) || !$fid) { wp_safe_redirect(pw_page_url('aug_renew', ['uid'=>$uid,'token'=>$token,'error'=>'file'])); exit; }

    update_user_meta($uid, 'pw_aug_type', $type);
    update_user_meta($uid, 'pw_aug_expiry', $expiry);
    update_user_meta($uid, 'pw_aug_file', (int)$fid);
    update_user_meta($uid, 'pw_aug_verified', '0');
    update_user_meta($uid, 'pw_aug_updated_at', time());
    update_user_meta($uid, 'pw_aug_login_locked', '1');
    delete_user_meta($uid, 'pw_aug_expired');
    delete_user_meta($uid, 'pw_aug_renew_hash');
    delete_user_meta($uid, 'pw_aug_renew_expires');
    pw_aug_clear_reminder_flags($uid);

    $user = get_userdata($uid);
    if ($user) pw_send_mail($user->user_email, 'Pure Work – AÜG-Unterlagen eingegangen', 'Unterlagen erfolgreich aktualisiert', 'Deine neuen AÜG-Unterlagen wurden sicher gespeichert und warten auf die Portalprüfung. Du erhältst eine E-Mail, sobald die Prüfung abgeschlossen ist.', 'Zur Anmeldung', home_url('/'));
    $admin = get_option('admin_email');
    if (is_email($admin)) pw_send_mail($admin, 'Pure Work – Neue AÜG-Unterlagen', 'AÜG-Unterlagen müssen geprüft werden', pw_user_meta($uid,'pw_company','Ein Personaldienstleister').' hat neue AÜG-Unterlagen hochgeladen.', 'Im Backend prüfen', admin_url('admin.php?page=pure-work'));

    wp_safe_redirect(pw_page_url('aug_renew', ['updated'=>1]));
    exit;
}
add_action('admin_post_nopriv_pw_aug_renew_submit', 'pw_handle_aug_renew_submit');
add_action('admin_post_pw_aug_renew_submit', 'pw_handle_aug_renew_submit');

function pw_shortcode_aug_renew() {
    $uid = (int)($_GET['uid'] ?? 0);
    $token = sanitize_text_field(wp_unslash($_GET['token'] ?? ''));
    $email = sanitize_email(wp_unslash($_GET['email'] ?? ''));
    $valid = $uid && $token && pw_validate_aug_renew_token($uid, $token);
    ob_start();
    echo function_exists('pw_public_header') ? pw_public_header() : '';
    ?>
    <section class="pw-renew-page"><div class="pw-public-wrap"><div class="pw-renew-card">
      <a class="pw-brand" href="<?php echo esc_url(home_url('/')); ?>"><?php echo pw_brand(); ?></a>
      <?php if (isset($_GET['updated'])): ?>
        <span class="pw-kicker">AÜG AKTUALISIERT</span><h1>Unterlagen eingegangen.</h1><p>Die neue Erlaubnis wurde gespeichert und wartet auf die Portalprüfung. Du erhältst eine E-Mail, sobald sie freigegeben wurde.</p><a class="pw-btn primary full" href="<?php echo esc_url(home_url('/')); ?>">Zur Anmeldung</a>
      <?php elseif ($valid): ?>
        <span class="pw-kicker">SICHERE AKTUALISIERUNG</span><h1>AÜG-Erlaubnis erneuern</h1><p>Lade die aktuelle Erlaubnis hoch. Der Link ist einmalig und zeitlich begrenzt.</p>
        <?php if (($_GET['error'] ?? '') === 'date'): ?><div class="pw-alert danger"><div><strong>Datum prüfen</strong><span>Bei einer befristeten Erlaubnis muss ein zukünftiges Ablaufdatum hinterlegt werden.</span></div></div><?php endif; ?>
        <?php if (($_GET['error'] ?? '') === 'file'): ?><div class="pw-alert danger"><div><strong>Dokument erforderlich</strong><span>Bitte lade die aktuelle AÜG-Erlaubnis als PDF, JPG oder PNG hoch.</span></div></div><?php endif; ?>
        <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="pw_aug_renew_submit"><input type="hidden" name="uid" value="<?php echo (int)$uid; ?>"><input type="hidden" name="token" value="<?php echo esc_attr($token); ?>"><?php wp_nonce_field('pw_aug_renew_submit'); ?>
          <label>Gültigkeit<select name="aug_type" class="pw-aug-type"><option value="limited">Befristet</option><option value="unlimited">Unbefristet</option></select></label>
          <label class="pw-aug-expiry-field">Gültig bis<input type="date" name="aug_expiry"></label>
          <div class="pw-aug-unlimited-note" hidden><span class="pw-inline-info">✓ Unbefristete Erlaubnis – kein Ablaufdatum erforderlich.</span></div>
          <label>AÜG-Erlaubnis<input type="file" name="aug_file" accept=".pdf,.jpg,.jpeg,.png" required><small>Max. 10 MB · geschützte Speicherung.</small></label>
          <button class="pw-btn primary full xl" type="submit">Unterlagen sicher übermitteln</button>
        </form>
      <?php else: ?>
        <span class="pw-kicker">AÜG-ZUGANG</span><h1>Unterlagen aktualisieren</h1><p>Wenn deine befristete Erlaubnis abgelaufen ist, kannst du hier einen sicheren Aktualisierungslink anfordern.</p>
        <?php if(isset($_GET['sent'])): ?><div class="pw-alert success"><div><strong>E-Mail versendet</strong><span>Wenn ein passendes Zeitarbeitsfirmen-Konto existiert, wurde ein 60 Minuten gültiger Link versendet.</span></div></div><?php endif; ?>
        <?php if(($_GET['error'] ?? '')==='token'): ?><div class="pw-alert danger"><div><strong>Link ungültig</strong><span>Der Link ist abgelaufen oder wurde bereits ersetzt. Fordere einen neuen an.</span></div></div><?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_aug_renew_request"><?php wp_nonce_field('pw_aug_renew_request'); ?><label>Geschäftliche E-Mail<input type="email" name="email" required value="<?php echo esc_attr($email); ?>" placeholder="name@unternehmen.de"></label><button class="pw-btn primary full xl" type="submit">Sicheren Link anfordern</button></form>
        <p class="pw-v4-switch"><a href="<?php echo esc_url(home_url('/')); ?>">← Zur Anmeldung</a></p>
      <?php endif; ?>
    </div></div></section>
    <?php
    return ob_get_clean();
}
add_shortcode('pw_aug_renew', 'pw_shortcode_aug_renew');
