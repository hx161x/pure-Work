<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9.7 – Pure Assist Profilanlage.
 *
 * Einen Mitarbeiter anzulegen hieß bisher: 20 Felder von Hand ausfüllen. Wer den
 * Lebenslauf oder die Sprachnachricht des Bewerbers ohnehin vorliegen hat, soll
 * den Text einfach einfügen können. Pure Assist zerlegt ihn und füllt das
 * Formular vor – der Disponent prüft nur noch.
 *
 * Die Erkennung läuft vollständig auf dem eigenen Server gegen die im Theme
 * hinterlegten Kataloge (18.867 KldB-Berufsbezeichnungen, Qualifikationen,
 * Orte). Es werden keine Bewerberdaten an einen externen KI-Dienst gesendet –
 * bei Personendaten aus Lebensläufen wäre das ein Auftragsverarbeitungs-Thema,
 * das kein Disponent nebenbei lösen kann.
 */

function pw_assist_languages() {
    return ['Deutsch','Englisch','Polnisch','Rumänisch','Bulgarisch','Türkisch','Russisch','Ukrainisch',
            'Arabisch','Italienisch','Spanisch','Portugiesisch','Kroatisch','Serbisch','Ungarisch',
            'Tschechisch','Slowakisch','Griechisch','Französisch','Niederländisch','Albanisch'];
}

function pw_assist_shift_terms() {
    return [
        'Frühschicht'    => ['fruehschicht','frueh','frühschicht','early'],
        'Spätschicht'    => ['spaetschicht','spät','spaet','late'],
        'Nachtschicht'   => ['nachtschicht','nacht','night'],
        'Wechselschicht' => ['wechselschicht','schichtbereit','schichtbereitschaft'],
        '2-Schicht'      => ['2 schicht','zweischicht','2-schicht'],
        '3-Schicht'      => ['3 schicht','dreischicht','3-schicht'],
        'Tagschicht'     => ['tagschicht','tagdienst','normalschicht'],
        'Wochenende'     => ['wochenende','samstag','sonntag'],
    ];
}

/** Längste Katalogtreffer zuerst, damit "Staplerfahrer" nicht als "Fahrer" endet. */
function pw_assist_match_catalog($haystack, array $candidates, $limit = 0) {
    $found = [];
    foreach ($candidates as $candidate) {
        $candidate = trim((string)$candidate);
        if (strlen($candidate) < 4) continue;
        $needle = pw_normalize_text($candidate);
        if ($needle === '') continue;
        if (pw_contains($haystack, $needle)) $found[$candidate] = strlen($needle);
    }
    arsort($found);
    $found = array_keys($found);
    // Teilstrings entfernen: "Stapler" fliegt raus, wenn "Staplerschein" getroffen hat.
    $clean = [];
    foreach ($found as $item) {
        $isSub = false;
        foreach ($clean as $kept) {
            if (pw_contains(pw_normalize_text($kept), pw_normalize_text($item))) { $isSub = true; break; }
        }
        if (!$isSub) $clean[] = $item;
    }
    return $limit ? array_slice($clean, 0, $limit) : $clean;
}

function pw_assist_parse_profile($text) {
    $text = (string)$text;
    $hay  = pw_normalize_text($text);
    $out  = [
        'role' => '', 'experience' => '', 'location' => '', 'available_from' => '',
        'qualifications' => [], 'languages' => [], 'shifts' => [],
        'driver' => 0, 'car' => 0, 'full_name' => '', 'email' => '', 'phone' => '',
        'notes' => [],
    ];
    if ($hay === '') return $out;

    // --- Tätigkeit ---------------------------------------------------------
    $roles = function_exists('pw_catalog_roles') ? (array)pw_catalog_roles() : [];
    $hit = pw_assist_match_catalog($hay, $roles, 1);
    if ($hit) {
        $out['role'] = $hit[0];
    } elseif (function_exists('pw_catalog_search_official_occupations')) {
        // Fallback über die amtlichen Berufsbezeichnungen: das längste Wort im
        // Text als Suchbegriff, dann den besten Katalogtreffer nehmen.
        foreach (preg_split('/[\s,;\.\n]+/', $hay) as $word) {
            if (strlen($word) < 6) continue;
            $matches = pw_catalog_search_official_occupations($word, 5);
            foreach ((array)$matches as $m) {
                $label = is_array($m) ? ($m['label'] ?? $m['Berufsbezeichnung'] ?? reset($m)) : $m;
                if ($label && pw_contains($hay, pw_normalize_text($label))) { $out['role'] = $label; break 2; }
            }
        }
    }

    // --- Berufserfahrung ---------------------------------------------------
    if (preg_match('/(\d{1,2})\s*(?:\+)?\s*(?:jahre|jahren|j\b|years)/u', $hay, $m)) {
        $out['experience'] = min(50, (int)$m[1]);
    } elseif (preg_match('/seit\s*(\d{4})/u', $hay, $m)) {
        $years = (int)wp_date('Y') - (int)$m[1];
        if ($years > 0 && $years < 50) $out['experience'] = $years;
    }

    // --- Ort ---------------------------------------------------------------
    $locations = function_exists('pw_catalog_locations') ? (array)pw_catalog_locations() : [];
    $locHit = pw_assist_match_catalog($hay, $locations, 1);
    if ($locHit) $out['location'] = $locHit[0];
    if (preg_match('/\b(\d{5})\b/', $text, $m)) {
        $out['location'] = trim($m[1] . ' ' . $out['location']);
    }

    // --- Verfügbarkeit -----------------------------------------------------
    if (preg_match('/(ab sofort|sofort verfuegbar|sofort verfügbar|jederzeit)/u', $hay)) {
        $out['available_from'] = wp_date('Y-m-d');
    } elseif (preg_match('/(\d{1,2})\.(\d{1,2})\.(\d{4})/', $text, $m)) {
        $out['available_from'] = sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
    } elseif (preg_match('/(\d{4})-(\d{2})-(\d{2})/', $text, $m)) {
        $out['available_from'] = $m[0];
    }

    // --- Qualifikationen ---------------------------------------------------
    $quals = function_exists('pw_catalog_qualifications') ? (array)pw_catalog_qualifications() : [];
    $out['qualifications'] = pw_assist_match_catalog($hay, $quals, 12);

    // --- Sprachen ----------------------------------------------------------
    foreach (pw_assist_languages() as $lang) {
        if (pw_contains($hay, pw_normalize_text($lang))) $out['languages'][] = $lang;
    }

    // --- Schichten ---------------------------------------------------------
    foreach (pw_assist_shift_terms() as $label => $terms) {
        foreach ($terms as $t) {
            if (pw_contains($hay, pw_normalize_text($t))) { $out['shifts'][] = $label; break; }
        }
    }
    $out['shifts'] = array_values(array_unique($out['shifts']));

    // --- Mobilität ---------------------------------------------------------
    if (preg_match('/(fuehrerschein|führerschein|klasse b|fs klasse|driving licence|pkw schein)/u', $hay)) $out['driver'] = 1;
    if (preg_match('/(eigener pkw|eigenes auto|pkw vorhanden|fahrzeug vorhanden|mit pkw|eigenem pkw)/u', $hay)) { $out['car'] = 1; $out['driver'] = 1; }

    // --- Kontaktdaten ------------------------------------------------------
    if (preg_match('/[\w\.\-\+]+@[\w\-]+\.[a-zA-Z]{2,}/', $text, $m)) $out['email'] = sanitize_email($m[0]);
    if (preg_match('/(?:\+49|0)[\s\-\/\(\)]?\d[\d\s\-\/\(\)]{6,20}/', $text, $m)) $out['phone'] = trim($m[0]);

    // --- Name --------------------------------------------------------------
    if (preg_match('/name\s*:\s*([^\n\r]{3,60})/iu', $text, $m)) {
        $out['full_name'] = sanitize_text_field(trim($m[1]));
    } else {
        foreach (preg_split('/[\n\r]+/', trim($text)) as $line) {
            $line = trim($line);
            if ($line === '' || strlen($line) > 45) continue;
            if (preg_match('/^([A-ZÄÖÜ][a-zäöüß\-]{1,20})\s+([A-ZÄÖÜ][a-zäöüß\-]{1,25})$/u', $line)) {
                $out['full_name'] = sanitize_text_field($line);
            }
            break;
        }
    }

    // --- Rückmeldung für den Nutzer ---------------------------------------
    if (!$out['role']) $out['notes'][] = pw_t('Tätigkeit nicht sicher erkannt – bitte selbst auswählen.', 'Role not recognised reliably – please pick it yourself.');
    if (!$out['location']) $out['notes'][] = pw_t('Kein Ort gefunden. Ort oder Postleitzahl ergänzen.', 'No location found. Please add a city or postcode.');
    if (!$out['qualifications']) $out['notes'][] = pw_t('Keine Qualifikation erkannt. Scheine und Zertifikate lohnen sich hier besonders.', 'No qualification recognised. Licences and certificates pay off here.');

    return $out;
}

function pw_ajax_assist_parse_worker() {
    pw_ajax_guard();
    if (pw_user_role() !== 'agency' && !current_user_can('manage_options')) {
        wp_send_json_error(['message' => pw_t('Nur für Zeitarbeitsfirmen.', 'Staffing agencies only.')], 403);
    }
    if (function_exists('pw_can') && !pw_can('cv_assistant')) {
        wp_send_json_error(['message' => pw_t('Der CV-Assistent ist ab dem Pro-Tarif verfügbar.', 'The CV assistant is available from the Pro plan.')], 403);
    }
    $text = (string)wp_unslash($_POST['text'] ?? '');
    if (strlen(trim($text)) < 12) {
        wp_send_json_error(['message' => pw_t('Bitte etwas mehr Text einfügen.', 'Please paste a bit more text.')], 400);
    }
    $parsed = pw_assist_parse_profile($text);
    $filled = 0;
    foreach (['role','experience','location','available_from','full_name','email','phone'] as $k) if (!empty($parsed[$k])) $filled++;
    foreach (['qualifications','languages','shifts'] as $k) if (!empty($parsed[$k])) $filled++;
    $parsed['filled'] = $filled;
    wp_send_json_success($parsed);
}
add_action('wp_ajax_pw_assist_parse_worker', 'pw_ajax_assist_parse_worker');

/** Die Karte, die über dem Mitarbeiterformular steht. */
function pw_assist_worker_card() {
    if (function_exists('pw_can') && !pw_can('cv_assistant')) {
        return function_exists('pw_plan_gate') ? pw_plan_gate('cv_assistant') : '';
    }
    ob_start(); ?>
    <section class="pw-card pw-assist-intake">
      <div class="pw-card-head">
        <div>
          <span class="pw-kicker"><?php echo esc_html(pw_t('PURE ASSIST', 'PURE ASSIST')); ?></span>
          <h2><?php echo esc_html(pw_t('Formular automatisch ausfüllen lassen', 'Let the form fill itself')); ?></h2>
          <p class="pw-card-sub"><?php echo esc_html(pw_t('Lebenslauf, Notizzettel oder Nachricht des Bewerbers hier einfügen. Pure Assist erkennt Tätigkeit, Erfahrung, Ort, Scheine, Sprachen und Schichten und trägt alles unten ein. Du prüfst nur noch.', 'Paste a CV, a note or the applicant’s message. Pure Assist detects role, experience, location, licences, languages and shifts and fills everything in below. You just review it.')); ?></p>
        </div>
        <span class="pw-assist-orb"><?php echo pw_icon('spark'); ?></span>
      </div>
      <label class="full">
        <textarea data-pw-assist-input rows="5" placeholder="<?php echo esc_attr(pw_t("z. B.: Marek Kowalski, 34, wohnt in 68169 Mannheim. 6 Jahre Lager, Staplerschein und Kranschein, Deutsch und Polnisch, Führerschein B mit eigenem PKW, Früh- und Spätschicht, ab sofort verfügbar.", 'e.g. Marek Kowalski, lives in 68169 Mannheim. 6 years warehouse, forklift licence, German and Polish, driving licence with own car, early and late shift, available immediately.')); ?>"></textarea>
      </label>
      <div class="pw-form-actions">
        <button type="button" class="pw-btn primary" data-pw-assist-run><?php echo pw_icon('spark'); ?> <?php echo esc_html(pw_t('Felder ausfüllen', 'Fill the fields')); ?></button>
        <span class="pw-assist-result" data-pw-assist-result></span>
      </div>
      <p class="pw-privacy-promise"><b><?php echo pw_icon('lock'); ?> <?php echo esc_html(pw_t('Bleibt auf deinem Server', 'Stays on your server')); ?></b><span><?php echo esc_html(pw_t('Die Erkennung läuft gegen die Berufs- und Qualifikationskataloge dieser Installation. Bewerberdaten verlassen deine Website nicht.', 'Recognition runs against this installation’s occupation and qualification catalogues. Applicant data never leaves your website.')); ?></span></p>
    </section>
    <?php return ob_get_clean();
}
