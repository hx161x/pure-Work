<?php
if (!defined('ABSPATH')) exit;

/**
 * Public live labour-market signal from the Bundesagentur für Arbeit Jobsuche
 * service. These entries are NOT Pure Work customer requests and are always
 * labelled as an external public market feed.
 */
function pw_live_market_terms() {
    return [
        'Lagerhelfer','Produktionsmitarbeiter','Kommissionierer','Staplerfahrer','Gabelstaplerfahrer',
        'Fachkraft Lagerlogistik','Fachlagerist','Maschinenbediener','Montagemitarbeiter','Montagehelfer',
        'Versandmitarbeiter','Produktionshelfer','Logistikmitarbeiter','CNC Maschinenbediener','CNC Fräser',
        'CNC Dreher','Schweißer','Elektriker','Elektroniker','Industriemechaniker','Mechatroniker','Verpacker',
        'Qualitätsprüfer','Metallbearbeiter','Chemikant','Pharmakant','Produktionsfachkraft Chemie','Laborhelfer',
        'Reinigungskraft','Küchenhilfe','Servicekraft','Pflegehelfer','Pflegefachkraft','Erzieher','Fahrer',
        'LKW Fahrer','Bauhelfer','Maler','Trockenbauer','Maurer','Anlagenmechaniker SHK','Büroassistenz',
        'Sachbearbeiter','Callcenter Agent','Empfang','Verkäufer','Kassierer','Hausmeister','Haustechniker'
    ];
}


/**
 * Dated fallback snapshot. It keeps the market area useful when the external
 * BA endpoint is temporarily unavailable without pretending cached examples
 * are live customer requests. Every fallback item is explicitly labelled and
 * dated in the UI.
 */
function pw_market_employer_is_staffing($employer) {
    $n = pw_normalize_text((string)$employer);
    $needles = ['personaldienst','personalservice','personal service','personal management','personal solutions','personal gmbh','zeitarbeit','arbeitsvermittlung','randstad','tempton','orizon','hofmann','alphaconsult','alpha consult','temporatio','tempo ratio','jobs n people','persona service','dekra arbeit','abites hr','socco','manpower','adecco','iperdi','expertum','office people','unique personal','bindan','stegmann','akko','arwa','jobag','rübsam','rubsam','synergie personal','time experts','fara personal','certis personal','dahmen personal','martin martin personal','speer gmbh','bs wutow'];
    foreach ($needles as $needle) if (pw_contains($n, pw_normalize_text($needle))) return true;
    return false;
}

function pw_live_market_snapshot($what = '', $where = '', $size = 30, $page = 1, $include_staffing = null) {
    $file = PW_DIR . '/assets/data/market_snapshot_2026-08-16.csv';
    if (!is_readable($file)) return [];
    $handle = fopen($file, 'r');
    if (!$handle) return [];
    $header = fgetcsv($handle, 0, ';');
    if (!$header) { fclose($handle); return []; }
    $what_n = pw_normalize_text($what);
    $where_n = pw_normalize_text($where);
    $all = [];
    while (($row = fgetcsv($handle, 0, ';')) !== false) {
        if (count($row) < count($header)) continue;
        $data = array_combine($header, array_slice($row, 0, count($header)));
        if (!$data) continue;
        $hay = pw_normalize_text(($data['title']??'').' '.($data['query']??'').' '.($data['employer']??''));
        $loc = pw_normalize_text(($data['place']??'').' '.($data['zip']??''));
        if ($what_n && !pw_contains($hay, $what_n) && !pw_contains($what_n, pw_normalize_text($data['query']??''))) continue;
        if ($where_n && !pw_contains($loc, $where_n)) continue;
        $title = sanitize_text_field($data['title']??'Stellenangebot');
        $place = sanitize_text_field($data['place']??'');
        $query = sanitize_text_field($data['query']??$title);
        $is_staffing = pw_market_employer_is_staffing($data['employer']??'');
        if ($include_staffing === false && $is_staffing) continue;
        if ($include_staffing === true && !$is_staffing) continue;
        $all[] = [
            'title'=>$title,
            'employer'=>sanitize_text_field($data['employer']??'Arbeitgeber nicht genannt'),
            'place'=>$place,
            'zip'=>sanitize_text_field($data['zip']??''),
            'published'=>sanitize_text_field($data['published']??'2026-08-16'),
            'start'=>sanitize_text_field($data['start']??''),
            'url'=>add_query_arg(array_filter(['suchbereich'=>'jobs','was'=>$query,'wo'=>$place]), 'https://www.arbeitsagentur.de/jobsuche/suche'),
            'ref'=>'snapshot-20260816-'.substr(md5($title.'|'.($data['employer']??'').'|'.$place),0,12),
            'snapshot'=>true,
        ];
    }
    fclose($handle);
    // If a narrow query produced no local snapshot hits, show the most useful
    // general examples instead of leaving the page empty.
    if (!$all && $what_n) return pw_live_market_snapshot('', $where, $size, $page, $include_staffing);
    if (!$all && $where_n) return pw_live_market_snapshot('', '', $size, $page, $include_staffing);
    $offset = max(0, ($page-1) * $size);
    return array_slice($all, $offset, $size);
}

function pw_live_market_fallback($what, $where, $days, $size, $page, $source_url, $reason = '', $include_staffing = null) {
    $all = pw_live_market_snapshot($what, $where, 10000, 1, $include_staffing);
    $total = count($all);
    $offset = max(0, ($page - 1) * $size);
    $items = array_slice($all, $offset, $size);
    return [
        'ok'=>true,
        'items'=>$items,
        'total'=>$total,
        'page'=>$page,
        'size'=>$size,
        'has_more'=>($offset + count($items)) < $total,
        'source_url'=>$source_url,
        'fetched_at'=>time(),
        'snapshot'=>true,
        'snapshot_date'=>'2026-08-16',
        'fallback_reason'=>sanitize_text_field($reason),
    ];
}

function pw_live_market_fetch($what = '', $where = '', $days = 14, $size = 30, $page = 1, $include_staffing = true) {
    $what = sanitize_text_field((string)$what);
    $where = sanitize_text_field((string)$where);
    $days = max(0,min(100,(int)$days));
    $size = max(1,min(50,(int)$size));
    $page = max(1,(int)$page);
    $include_staffing = (bool)$include_staffing;
    $cache_key = 'pw_live_' . md5(pw_lower($what.'|'.$where.'|'.$days.'|'.$size.'|'.$page.'|'.($include_staffing?'staffing':'direct')));
    $cached = get_transient($cache_key);
    if (is_array($cached)) return $cached;

    $params = [
        'page'=>$page,
        'size'=>$size,
        'angebotsart'=>1,
        'veroeffentlichtseit'=>$days,
        'zeitarbeit'=>$include_staffing?'true':'false',
    ];
    if ($what !== '') $params['was']=$what;
    if ($where !== '') { $params['wo']=$where; $params['umkreis']=50; }
    $url = add_query_arg($params, 'https://rest.arbeitsagentur.de/jobboerse/jobsuche-service/pc/v6/jobs');
    $res = wp_remote_get($url, [
        'timeout'=>8,
        'redirection'=>2,
        'headers'=>[
            'X-API-Key'=>'jobboerse-jobsuche',
            'Accept'=>'application/json',
            'User-Agent'=>'PureWork/'.PW_VERSION.'; '.home_url('/'),
        ],
    ]);
    if (is_wp_error($res)) return pw_live_market_fallback($what,$where,$days,$size,$page,$url,$res->get_error_message(),$include_staffing);
    $code=(int)wp_remote_retrieve_response_code($res);
    $json=json_decode(wp_remote_retrieve_body($res),true);
    if ($code !== 200 || !is_array($json)) return pw_live_market_fallback($what,$where,$days,$size,$page,$url,'HTTP '.$code,$include_staffing);

    $raw = isset($json['stellenangebote']) && is_array($json['stellenangebote']) ? $json['stellenangebote'] : [];
    // Some hosts/proxies return a formally valid but empty payload. Never leave
    // the marketplace blank in that case: fall back to the dated official-market snapshot.
    if (!$raw) return pw_live_market_fallback($what,$where,$days,$size,$page,$url,'Leere Live-Antwort',$include_staffing);
    $items=[];
    foreach($raw as $row){
        if(!is_array($row))continue;
        $place='';$plz='';
        if(!empty($row['arbeitsort'])&&is_array($row['arbeitsort'])){
            $place=sanitize_text_field((string)($row['arbeitsort']['ort']??''));
            $plz=sanitize_text_field((string)($row['arbeitsort']['plz']??''));
        }
        $title=sanitize_text_field((string)($row['beruf']??$row['titel']??$row['stellenangebotsTitel']??'Stellenangebot'));
        $employer=sanitize_text_field((string)($row['arbeitgeber']??'Arbeitgeber nicht genannt'));
        $published=sanitize_text_field((string)($row['aktuelleVeroeffentlichungsdatum']??''));
        $start=sanitize_text_field((string)($row['eintrittsdatum']??''));
        $external=esc_url_raw((string)($row['externeUrl']??''));
        $ref=sanitize_text_field((string)($row['refnr']??''));
        if(!$external){
            $external=$ref ? 'https://www.arbeitsagentur.de/jobsuche/jobdetail/'.rawurlencode($ref) : add_query_arg(array_filter(['angebotsart'=>1,'was'=>$title,'wo'=>$place?:$where]),'https://www.arbeitsagentur.de/jobsuche/suche');
        }
        $items[]=[
            'title'=>$title,'employer'=>$employer,'place'=>$place,'zip'=>$plz,
            'published'=>$published,'start'=>$start,'url'=>$external,'ref'=>$ref,
        ];
    }
    $total=(int)($json['maxErgebnisse']??$json['gesamtErgebnisse']??$json['total']??count($items));
    if($total<count($items))$total=count($items);
    $out=['ok'=>true,'items'=>$items,'total'=>$total,'page'=>$page,'size'=>$size,'has_more'=>($page*$size)<$total || count($items)>=$size,'source_url'=>$url,'fetched_at'=>time(),'snapshot'=>false];
    set_transient($cache_key,$out,30*MINUTE_IN_SECONDS);
    return $out;
}

function pw_live_market_user_defaults($uid=0){
    if(!$uid)$uid=get_current_user_id();
    $city=pw_user_meta($uid,'pw_city','');
    if(!$city)$city='Mannheim';
    $industry=pw_user_meta($uid,'pw_industry','');
    $what='';
    $n=pw_normalize_text($industry);
    if(pw_contains($n,'logistik'))$what='Lagerhelfer';
    elseif(pw_contains($n,'produktion')||pw_contains($n,'industrie'))$what='Produktionsmitarbeiter';
    return [$what,$city];
}

function pw_live_market_card($item){
    $age='';
    if(!empty($item['published'])){
        $ts=strtotime($item['published']);
        if($ts){$d=max(0,(int)floor((time()-$ts)/DAY_IN_SECONDS));$age=$d===0?'heute':($d===1?'gestern':'vor '.$d.' Tagen');}
    }
    $uid=get_current_user_id();$role=pw_user_role($uid);
    ob_start(); ?>
    <article class="pw-live-job">
      <div class="pw-live-job-top"><span class="pw-live-dot"></span><small><?php echo !empty($item['snapshot']) ? 'BA JOBSUCHE · SNAPSHOT 16.08.2026' : 'ÖFFENTLICHER MARKT · BA JOBSUCHE'; ?></small><time><?php echo esc_html($age); ?></time></div>
      <h3><?php echo esc_html($item['title']); ?></h3>
      <p class="pw-live-employer"><?php echo esc_html($item['employer']); ?></p>
      <div class="pw-live-meta"><span><?php echo pw_icon('map'); ?> <?php echo esc_html(trim((!empty($item['zip'])?$item['zip'].' ':'').($item['place']??'')) ?: 'Deutschland'); ?></span><?php if(!empty($item['start'])):?><span><?php echo pw_icon('clock'); ?> Start <?php echo esc_html(pw_format_date($item['start'])); ?></span><?php endif;?></div>
      <div class="pw-live-actions">
        <?php if(is_user_logged_in()): ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="pw_crm_capture_market"><?php wp_nonce_field('pw_crm_capture_market'); ?>
          <input type="hidden" name="company" value="<?php echo esc_attr($item['employer']??''); ?>"><input type="hidden" name="job_title" value="<?php echo esc_attr($item['title']??''); ?>"><input type="hidden" name="city" value="<?php echo esc_attr($item['place']??''); ?>"><input type="hidden" name="job_ref" value="<?php echo esc_attr($item['ref']??''); ?>"><input type="hidden" name="source_url" value="<?php echo esc_attr($item['url']??''); ?>"><input type="hidden" name="market_published" value="<?php echo esc_attr($item['published']??''); ?>">
          <button class="pw-btn small primary" type="submit"><?php echo $role==='agency'?'Personal anbieten':'Im CRM speichern'; ?> <?php echo pw_icon('arrow'); ?></button>
        </form>
        <?php endif; ?>
        <a class="pw-btn small ghost" href="<?php echo esc_url($item['url']??''); ?>" target="_blank" rel="noopener noreferrer">Stellendetails <?php echo pw_icon('arrow'); ?></a>
      </div>
    </article>
    <?php return ob_get_clean();
}

/** Aggregate job results to market-company cards for Partner & Umgebung. */
function pw_market_company_leads($uid=0,$limit=24,$include_staffing=false){
    if(!$uid)$uid=get_current_user_id();
    list($what,$where)=pw_live_market_user_defaults($uid);
    // For company discovery use a broad query; the location keeps it relevant.
    $feed=pw_live_market_fetch('', $where, 30, 50, 1, $include_staffing);
    $items=!empty($feed['items'])?(array)$feed['items']:pw_live_market_snapshot('', $where, 50, 1, $include_staffing);
    $groups=[];
    foreach($items as $item){
        $company=trim((string)($item['employer']??''));if(!$company||$company==='Arbeitgeber nicht genannt')continue;
        $key=pw_normalize_text($company);
        if(!isset($groups[$key]))$groups[$key]=['company'=>$company,'place'=>(string)($item['place']??''),'jobs'=>[],'url'=>(string)($item['url']??''),'ref'=>(string)($item['ref']??''),'snapshot'=>!empty($item['snapshot'])];
        $groups[$key]['jobs'][]=$item;
        if(!$groups[$key]['place']&&!empty($item['place']))$groups[$key]['place']=$item['place'];
    }
    uasort($groups,function($a,$b){return count($b['jobs'])<=>count($a['jobs']);});
    return array_slice(array_values($groups),0,max(1,(int)$limit));
}

function pw_market_company_card($lead,$uid=0){
    if(!$uid)$uid=get_current_user_id();$first=!empty($lead['jobs'][0])?$lead['jobs'][0]:[];$roles=[];foreach((array)$lead['jobs'] as $j){$roles[]=$j['title']??'';}$roles=array_values(array_unique(array_filter($roles)));
    ob_start();?><article class="pw-market-company-card"><div class="pw-market-company-head"><span class="pw-company-logo"><?php echo esc_html(pw_initials($lead['company'])); ?></span><div><h3><?php echo esc_html($lead['company']); ?></h3><p><?php echo esc_html($lead['place']?:'Deutschland'); ?> · <?php echo count($lead['jobs']); ?> aktuelle Signale</p></div><span class="pw-market-signal"><i></i>MARKT</span></div><div class="pw-chip-list small"><?php foreach(array_slice($roles,0,3) as $r):?><span><?php echo esc_html(wp_trim_words($r,6,'…')); ?></span><?php endforeach;?></div><div class="pw-company-actions"><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_crm_capture_market"><?php wp_nonce_field('pw_crm_capture_market'); ?><input type="hidden" name="company" value="<?php echo esc_attr($lead['company']); ?>"><input type="hidden" name="job_title" value="<?php echo esc_attr($first['title']??'Aktueller Personalbedarf'); ?>"><input type="hidden" name="city" value="<?php echo esc_attr($lead['place']); ?>"><input type="hidden" name="job_ref" value="<?php echo esc_attr($first['ref']??''); ?>"><input type="hidden" name="source_url" value="<?php echo esc_attr($first['url']??''); ?>"><input type="hidden" name="market_published" value="<?php echo esc_attr($first['published']??''); ?>"><button class="pw-btn primary small"><?php echo pw_user_role($uid)==='agency'?'Als Lead übernehmen':'Im CRM speichern'; ?></button></form><?php if(!empty($first['url'])):?><a class="pw-btn ghost small" href="<?php echo esc_url($first['url']); ?>" target="_blank" rel="noopener noreferrer">Quelle</a><?php endif;?></div></article><?php return ob_get_clean();
}

function pw_live_market_dashboard_widget($uid=0){
    if(!$uid)$uid=get_current_user_id();
    [$what,$where]=pw_live_market_user_defaults($uid);
    $feed=pw_live_market_fetch($what,$where,7,6,1,pw_user_role($uid)!=='agency');
    ob_start(); ?>
    <section class="pw-card span2 pw-live-widget">
      <div class="pw-card-head"><div><span class="pw-kicker">MARKT LIVE</span><h2>Was gerade gesucht wird</h2><p>Aktuelle öffentliche Stellenanzeigen als Marktindikator – getrennt von echten Pure Work Personalanfragen.</p></div><a href="<?php echo esc_url(pw_page_url('market_live')); ?>">Live-Markt öffnen</a></div>
      <?php if(empty($feed['ok'])||empty($feed['items'])): ?>
        <div class="pw-live-offline"><span><?php echo pw_icon('search'); ?></span><div><b>Live-Markt wird geladen, sobald die externe Quelle erreichbar ist.</b><small>Deine Pure Work Personalanfragen funktionieren unabhängig davon.</small></div></div>
      <?php else: ?><?php if(!empty($feed['snapshot'])):?><div class="pw-live-snapshot-note">Live-Quelle derzeit nicht erreichbar · datierter BA-Marktsnapshot vom 16.08.2026</div><?php endif; ?><div class="pw-live-mini-list"><?php foreach(array_slice($feed['items'],0,4) as $item): ?><a href="<?php echo esc_url($item['url']); ?>" target="_blank" rel="noopener noreferrer"><span class="pw-live-dot"></span><div><b><?php echo esc_html($item['title']); ?></b><small><?php echo esc_html($item['place'].' · '.$item['employer']); ?></small></div><time><?php echo esc_html(pw_format_date($item['published'])); ?></time></a><?php endforeach; ?></div><?php endif; ?>
    </section>
    <?php return ob_get_clean();
}


function pw_public_market_preview() {
    // Keep the public landing page instant: use the dated snapshot here. The
    // authenticated Market Live area uses the live BA feed with caching.
    $items = pw_live_market_snapshot('', '', 6, 1);
    $feed = ['items'=>$items,'snapshot'=>true,'snapshot_date'=>'2026-08-16'];
    if (empty($feed['items'])) return '';
    ob_start(); ?>
    <section class="pw-section pw-public-market-preview"><div class="pw-public-wrap">
      <div class="pw-section-head"><span class="pw-kicker">MARKT PULS</span><h2>Sehen, was gerade gesucht wird.</h2><p>Öffentliche Stellenanzeigen aus der BA Jobsuche als Marktsignal – klar getrennt von echten Pure Work Personalanfragen.</p></div>
      <?php if(!empty($feed['snapshot'])):?><div class="pw-live-snapshot-note">Datierter Marktsnapshot 16.08.2026, falls der Live-Feed nicht erreichbar ist.</div><?php endif; ?>
      <div class="pw-public-market-grid"><?php foreach(array_slice($feed['items'],0,6) as $item): ?><article><span class="pw-live-dot"></span><div><b><?php echo esc_html($item['title']); ?></b><small><?php echo esc_html($item['place'].' · '.$item['employer']); ?></small></div></article><?php endforeach; ?></div>
      <div class="pw-public-market-actions"><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('register')); ?>">Kostenlos registrieren</a><span>Nach dem Login: Live-Markt, Filter und Pure Match.</span></div>
    </div></section>
    <?php return ob_get_clean();
}

function pw_shortcode_market_live(){
    if(!is_user_logged_in())return pw_require_login_html();
    $uid=get_current_user_id();
    [$defaultWhat,$defaultWhere]=pw_live_market_user_defaults($uid);
    $what=sanitize_text_field(wp_unslash($_GET['what']??$defaultWhat));
    $where=sanitize_text_field(wp_unslash($_GET['where']??$defaultWhere));
    $days=max(1,min(100,(int)($_GET['days']??14)));
    $marketPage=max(1,(int)($_GET['market_page']??1));
    $defaultMode=pw_user_role($uid)==='agency'?'direct':'staffing';
    $mode=sanitize_key(wp_unslash($_GET['market_mode']??$defaultMode));
    if(!in_array($mode,['staffing','direct'],true))$mode='staffing';
    $feed=pw_live_market_fetch($what,$where,$days,50,$marketPage,$mode==='staffing');
    ob_start();echo pw_portal_shell_start('Markt Live','Aktuelle öffentliche Nachfrage als zusätzlicher Vertriebs- und Dispositionsindikator');
    ?>
    <div class="pw-live-hero"><div><span class="pw-kicker">PURE WORK MARKET SIGNAL</span><h2>Aktuell gesuchte Arbeitskräfte.</h2><p>Live-Suche in öffentlichen Stellenanzeigen. Diese Daten sind Marktindikatoren und keine Pure Work Ausschreibungen.</p></div><div class="pw-live-pulse"><i></i><span>LIVE</span></div></div>
    <div class="pw-live-mode"><a class="<?php echo $mode==='staffing'?'active':''; ?>" href="<?php echo esc_url(pw_page_url('market_live',['what'=>$what,'where'=>$where,'days'=>$days,'market_mode'=>'staffing'])); ?>">Zeitarbeitsmarkt</a><a class="<?php echo $mode==='direct'?'active':''; ?>" href="<?php echo esc_url(pw_page_url('market_live',['what'=>$what,'where'=>$where,'days'=>$days,'market_mode'=>'direct'])); ?>">Direktmarkt / Zielkunden</a><span><?php echo $mode==='direct'?'Direkte Arbeitgebernachfrage als Vertriebsindikator – keine Aussage, dass das Unternehmen Zeitarbeit nutzt.':'Öffentliche Anzeigen inklusive Zeitarbeitsangeboten als Marktindikator.'; ?></span></div>
    <form class="pw-live-search" method="get"><input type="hidden" name="market_mode" value="<?php echo esc_attr($mode); ?>"><label>Was wird gesucht?<input name="what" list="pw-live-terms" value="<?php echo esc_attr($what); ?>" placeholder="z. B. Lagerhelfer"></label><label>Region<input name="where" list="pw-locations" value="<?php echo esc_attr($where); ?>" placeholder="z. B. Mannheim"></label><label>Veröffentlicht<select name="days"><option value="1" <?php selected($days,1); ?>>heute</option><option value="7" <?php selected($days,7); ?>>letzte 7 Tage</option><option value="14" <?php selected($days,14); ?>>letzte 14 Tage</option><option value="30" <?php selected($days,30); ?>>letzte 30 Tage</option></select></label><button class="pw-btn primary" type="submit">Live suchen <?php echo pw_icon('search'); ?></button></form>
    <datalist id="pw-live-terms"><?php foreach(pw_live_market_terms() as $term)echo '<option value="'.esc_attr($term).'">'; ?></datalist>
    <div class="pw-live-quick"><?php foreach(array_slice(pw_live_market_terms(),0,8) as $term):?><a href="<?php echo esc_url(pw_page_url('market_live',['what'=>$term,'where'=>$where,'days'=>$days,'market_mode'=>$mode])); ?>"><?php echo esc_html($term); ?></a><?php endforeach;?></div>
    <?php if(empty($feed['ok'])): ?><div class="pw-card pw-live-error"><span><?php echo pw_icon('search'); ?></span><div><h3>Externe Live-Daten gerade nicht erreichbar</h3><p>Der Pure Work Marktplatz selbst läuft normal weiter. Bitte später erneut laden.</p></div></div>
    <?php else: ?><div class="pw-live-result-head"><div><b><?php echo (int)($feed['total']??count($feed['items'])); ?></b><span><?php echo !empty($feed['snapshot'])?'Marktsignale im Snapshot':'Treffer im Live-Markt'; ?> · Seite <?php echo (int)$marketPage; ?></span></div><small><?php echo !empty($feed['snapshot']) ? 'Fallback: BA-Marktsnapshot vom 16.08.2026 · nicht als live zu verstehen' : 'Quelle: öffentliche BA Jobsuche · automatisch alle 30 Minuten aktualisiert'; ?></small></div><div class="pw-live-grid"><?php if(!$feed['items']):?><div class="pw-card pw-empty span-all"><h3>Keine Treffer für diese Suche</h3><p>Ändere Tätigkeit, Region oder Zeitraum.</p></div><?php else:foreach($feed['items'] as $item){ if(!empty($feed['snapshot'])) $item['snapshot']=true; echo pw_live_market_card($item); }endif;?></div>
    <?php if($marketPage>1 || !empty($feed['has_more'])): ?><nav class="pw-live-pagination"><?php if($marketPage>1): ?><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('market_live',['what'=>$what,'where'=>$where,'days'=>$days,'market_page'=>$marketPage-1,'market_mode'=>$mode])); ?>">← Neuere Treffer</a><?php endif; ?><span>Seite <?php echo (int)$marketPage; ?></span><?php if(!empty($feed['has_more'])): ?><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('market_live',['what'=>$what,'where'=>$where,'days'=>$days,'market_page'=>$marketPage+1,'market_mode'=>$mode])); ?>">Weitere Treffer →</a><?php endif; ?></nav><?php endif; ?>
    <?php endif; ?>
    <div class="pw-source-note"><b>Abgrenzung:</b> Öffentliche Stellenanzeigen werden nur als Marktindikator angezeigt. Echte Personalbedarfe deiner registrierten Auftraggeber stehen weiterhin unter „Personalanfragen“ und folgen dem anonymisierten Pure Work Workflow.</div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}
add_shortcode('pw_market_live','pw_shortcode_market_live');
