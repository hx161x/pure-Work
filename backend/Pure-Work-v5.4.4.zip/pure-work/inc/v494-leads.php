<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9.4 – Lead-Recherche & Datenpflege
 *
 * Ergänzt die geprüften öffentlichen AÜ-Vergabekontakte um einen sauberen Weg,
 * eigene recherchierte Geschäftskontakte zu pflegen:
 *   - CSV-Import in das eigene CRM (nur für das eigene Konto sichtbar)
 *   - Pflichtfeld Quelle + Prüfdatum, damit Art. 14 DSGVO beauskunftbar bleibt
 *   - Sperrliste (Widerspruch nach Art. 21 DSGVO) mit Re-Import-Schutz
 *   - Recherche-Leitfaden mit belastbaren, öffentlich zugänglichen Quellen
 *
 * Bewusst NICHT enthalten: automatisches Auslesen von Karriere-/Social-Netzwerken.
 * Das verstößt gegen deren Nutzungsbedingungen und verlagert das UWG-/DSGVO-Risiko
 * auf die anrufende Zeitarbeitsfirma.
 */

/* ==========================================================================
 * Sperrliste / Widerspruch
 * ======================================================================= */
function pw_lead_blocklist($uid = 0) {
    if (!$uid) $uid = get_current_user_id();
    $list = get_user_meta($uid, 'pw_lead_blocklist', true);
    return is_array($list) ? $list : [];
}

function pw_lead_block_key($company, $email = '') {
    $email = pw_lower(trim((string)$email));
    if ($email) return 'mail:' . $email;
    return 'firma:' . pw_normalize_text((string)$company);
}

function pw_lead_is_blocked($company, $email = '', $uid = 0) {
    $list = pw_lead_blocklist($uid);
    if (!$list) return false;
    foreach ([pw_lead_block_key($company, $email), pw_lead_block_key($company, '')] as $key) {
        if (isset($list[$key])) return true;
    }
    return false;
}

function pw_handle_lead_block_add() {
    if (!is_user_logged_in() || (pw_user_role() !== 'agency' && !current_user_can('manage_options'))) wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_lead_block_add');
    $uid = get_current_user_id();
    $company = sanitize_text_field(wp_unslash($_POST['company'] ?? ''));
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $reason = sanitize_text_field(wp_unslash($_POST['reason'] ?? ''));
    if (!$company && !$email) pw_form_redirect('market_live', ['tab' => 'rules', 'error' => 'block']);

    $list = pw_lead_blocklist($uid);
    $list[pw_lead_block_key($company, $email)] = [
        'company' => $company,
        'email'   => $email,
        'reason'  => $reason,
        'added'   => wp_date('Y-m-d'),
    ];
    update_user_meta($uid, 'pw_lead_blocklist', $list);

    // Ein Widerspruch wirkt sofort: bereits gespeicherte Datensätze werden entfernt.
    $removed = 0;
    $leads = get_posts([
        'post_type' => 'pw_crm_lead', 'post_status' => 'publish', 'author' => $uid,
        'posts_per_page' => -1, 'fields' => 'ids',
    ]);
    foreach ($leads as $lead_id) {
        $lc = (string)get_post_meta($lead_id, 'pw_crm_company', true);
        $le = (string)get_post_meta($lead_id, 'pw_crm_email', true);
        if (pw_lead_is_blocked($lc, $le, $uid)) { wp_trash_post((int)$lead_id); $removed++; }
    }
    if (function_exists('pw_audit_event')) pw_audit_event('lead_optout', $uid, 'crm', 0, $company . ' ' . $email);
    pw_form_redirect('market_live', ['tab' => 'rules', 'blocked' => 1, 'removed' => $removed]);
}
add_action('admin_post_pw_lead_block_add', 'pw_handle_lead_block_add');

function pw_handle_lead_block_remove() {
    if (!is_user_logged_in()) wp_die('Keine Berechtigung.');
    $key = (string)wp_unslash($_GET['key'] ?? '');
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'pw_lead_block_remove')) wp_die('Sicherheitsprüfung fehlgeschlagen.');
    $uid = get_current_user_id();
    $list = pw_lead_blocklist($uid);
    unset($list[$key]);
    update_user_meta($uid, 'pw_lead_blocklist', $list);
    pw_form_redirect('market_live', ['tab' => 'rules', 'unblocked' => 1]);
}
add_action('admin_post_pw_lead_block_remove', 'pw_handle_lead_block_remove');

/* ==========================================================================
 * CSV-Import eigener Recherche-Leads
 * ======================================================================= */
function pw_lead_import_columns() {
    return [
        'company'      => ['Unternehmen', true],
        'contact'      => ['Ansprechpartner (optional)', false],
        'contact_role' => ['Funktion / Abteilung', false],
        'email'        => ['Geschäftliche E-Mail', false],
        'phone'        => ['Geschäftliche Telefonnummer', false],
        'city'         => ['Ort', false],
        'industry'     => ['Branche', false],
        'source_url'   => ['Quelle (URL)', true],
        'verified_at'  => ['Geprüft am (JJJJ-MM-TT)', false],
        'notes'        => ['Notiz', false],
    ];
}

function pw_handle_lead_import_template() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    $cols = array_keys(pw_lead_import_columns());
    $rows = [
        implode(';', $cols),
        'Muster Logistik GmbH;Sabine Beispiel;Einkauf Dienstleistungen;einkauf@muster-logistik.de;+49 621 1234567;Mannheim;Logistik;https://www.muster-logistik.de/impressum;' . wp_date('Y-m-d') . ';Lieferantenportal, AÜ-Rahmenvertrag ausgeschrieben',
    ];
    nocache_headers();
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="pure-work-lead-import-vorlage.csv"');
    echo "\xEF\xBB\xBF" . implode("\r\n", $rows) . "\r\n";
    exit;
}
add_action('admin_post_pw_lead_import_template', 'pw_handle_lead_import_template');

function pw_handle_lead_import() {
    if (!is_user_logged_in() || (pw_user_role() !== 'agency' && !current_user_can('manage_options'))) wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_lead_import');
    if (empty($_FILES['lead_csv']['tmp_name'])) pw_form_redirect('market_live', ['tab' => 'own', 'error' => 'csv']);

    $handle = fopen($_FILES['lead_csv']['tmp_name'], 'r');
    if (!$handle) pw_form_redirect('market_live', ['tab' => 'own', 'error' => 'csv']);
    $first = fgets($handle);
    if ($first === false) { fclose($handle); pw_form_redirect('market_live', ['tab' => 'own', 'error' => 'csv']); }
    $first = preg_replace('/^\xEF\xBB\xBF/', '', $first);
    $delim = substr_count($first, ';') >= substr_count($first, ',') ? ';' : ',';
    $headers = array_map(function ($v) { return sanitize_key(trim($v)); }, str_getcsv($first, $delim));

    $uid = get_current_user_id();
    $imported = 0; $updated = 0; $skipped = 0; $blocked = 0; $rows = 0;

    while (($row = fgetcsv($handle, 0, $delim)) !== false && $rows < 2000) {
        $rows++;
        $d = [];
        foreach ($headers as $i => $key) $d[$key] = isset($row[$i]) ? trim((string)$row[$i]) : '';

        $company = sanitize_text_field($d['company'] ?? '');
        $email   = sanitize_email($d['email'] ?? '');
        $phone   = sanitize_text_field($d['phone'] ?? '');
        $source  = esc_url_raw($d['source_url'] ?? '');

        // Qualitätsregel: ohne Firma, ohne Kontaktweg oder ohne belegbare Quelle
        // wird nichts gespeichert. Damit bleibt jeder Datensatz auskunftsfähig.
        if (!$company || (!$email && !$phone) || !$source) { $skipped++; continue; }
        if (pw_lead_is_blocked($company, $email, $uid)) { $blocked++; continue; }

        $existing = get_posts([
            'post_type' => 'pw_crm_lead', 'post_status' => 'publish', 'author' => $uid,
            'posts_per_page' => 1, 'fields' => 'ids',
            'meta_query' => [['key' => 'pw_crm_company', 'value' => $company]],
        ]);
        $lead_id = $existing ? (int)$existing[0] : 0;

        $verified = sanitize_text_field($d['verified_at'] ?? '');
        if (!$verified || !strtotime($verified)) $verified = wp_date('Y-m-d');
        $note = sanitize_textarea_field($d['notes'] ?? '');
        $note = trim($note . "\n" . 'Eigene Recherche · Quelle geprüft am ' . $verified . '.');

        $result = pw_crm_create_or_update_lead($uid, [
            'company'      => $company,
            'contact'      => sanitize_text_field($d['contact'] ?? ''),
            'contact_role' => sanitize_text_field($d['contact_role'] ?? ''),
            'email'        => $email,
            'phone'        => $phone,
            'city'         => sanitize_text_field($d['city'] ?? ''),
            'industry'     => sanitize_text_field($d['industry'] ?? ''),
            'stage'        => $lead_id ? 'qualified' : 'new',
            'priority'     => 'warm',
            'source'       => 'Eigene Recherche (CSV-Import)',
            'source_url'   => $source,
            'verified_at'  => $verified,
            'notes'        => $note,
            'target_type'  => 'client',
        ], $lead_id);

        if (is_wp_error($result)) { $skipped++; continue; }
        if ($lead_id) $updated++; else $imported++;
    }
    fclose($handle);

    pw_form_redirect('market_live', [
        'tab' => 'own', 'imported' => $imported, 'updated' => $updated,
        'skipped' => $skipped, 'blocked_rows' => $blocked,
    ]);
}
add_action('admin_post_pw_lead_import', 'pw_handle_lead_import');

/* ==========================================================================
 * Panel: eigene Recherche
 * ======================================================================= */
function pw_leads_own_panel() {
    $uid = get_current_user_id();
    $own = get_posts([
        'post_type' => 'pw_crm_lead', 'post_status' => 'publish', 'author' => $uid,
        'posts_per_page' => 30, 'orderby' => 'modified', 'order' => 'DESC',
    ]);
    $imported = isset($_GET['imported']) ? (int)$_GET['imported'] : -1;

    ob_start(); ?>
    <section class="pw-card">
      <div class="pw-card-head"><div>
        <span class="pw-kicker"><?php echo esc_html(pw_t('EIGENE RECHERCHE', 'OWN RESEARCH')); ?></span>
        <h2><?php echo esc_html(pw_t('Eigene Geschäftskontakte importieren', 'Import your own business contacts')); ?></h2>
        <p class="pw-card-sub"><?php echo esc_html(pw_t('Deine recherchierten Kontakte landen direkt in deinem CRM und sind ausschließlich für dein Unternehmen sichtbar. Pflicht sind Firma, ein Kontaktweg und die Quelle – so kannst du jederzeit belegen, woher ein Kontakt stammt.', 'Your researched contacts go straight into your CRM and stay visible to your company only. Company, one contact channel and the source are mandatory, so you can always prove where a contact came from.')); ?></p>
      </div></div>

      <?php if ($imported >= 0): ?>
        <div class="pw-alert success"><div><strong><?php echo esc_html(pw_t('Import abgeschlossen', 'Import finished')); ?></strong><span>
          <?php echo esc_html(sprintf(
            pw_t('%1$d neu angelegt, %2$d aktualisiert, %3$d übersprungen (Pflichtfeld fehlte), %4$d wegen Sperrliste ignoriert.', '%1$d created, %2$d updated, %3$d skipped (mandatory field missing), %4$d ignored due to the block list.'),
            $imported, (int)($_GET['updated'] ?? 0), (int)($_GET['skipped'] ?? 0), (int)($_GET['blocked_rows'] ?? 0)
          )); ?>
        </span></div></div>
      <?php endif; ?>
      <?php if (isset($_GET['error']) && $_GET['error'] === 'csv'): ?>
        <div class="pw-alert danger"><div><strong><?php echo esc_html(pw_t('Datei nicht lesbar', 'File not readable')); ?></strong><span><?php echo esc_html(pw_t('Bitte eine CSV-Datei mit Semikolon oder Komma als Trennzeichen hochladen.', 'Please upload a CSV file separated by semicolon or comma.')); ?></span></div></div>
      <?php endif; ?>

      <form class="pw-form-grid two" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="pw_lead_import"><?php wp_nonce_field('pw_lead_import'); ?>
        <label class="full"><?php echo esc_html(pw_t('CSV-Datei', 'CSV file')); ?><input type="file" name="lead_csv" accept=".csv" required></label>
        <div class="full pw-form-actions">
          <a class="pw-btn ghost" href="<?php echo esc_url(admin_url('admin-post.php?action=pw_lead_import_template')); ?>"><?php echo esc_html(pw_t('Vorlage herunterladen', 'Download template')); ?></a>
          <button class="pw-btn primary" type="submit"><?php echo esc_html(pw_t('Kontakte importieren', 'Import contacts')); ?> <?php echo pw_icon('arrow'); ?></button>
        </div>
      </form>

      <div class="pw-anon-cv-block">
        <h3><?php echo esc_html(pw_t('Spalten der Vorlage', 'Template columns')); ?></h3>
        <div class="pw-chip-list">
          <?php foreach (pw_lead_import_columns() as $key => $col): ?>
            <span><?php echo esc_html($key . ($col[1] ? ' *' : '')); ?></span>
          <?php endforeach; ?>
        </div>
        <p class="pw-card-sub"><?php echo esc_html(pw_t('* Pflichtfeld. Zusätzlich muss E-Mail oder Telefon gefüllt sein.', '* Mandatory. In addition, e-mail or phone must be filled.')); ?></p>
      </div>
    </section>

    <section class="pw-card">
      <div class="pw-card-head"><div>
        <span class="pw-kicker"><?php echo esc_html(pw_t('ZULETZT GEPFLEGT', 'RECENTLY UPDATED')); ?></span>
        <h2><?php echo esc_html(count($own) . ' ' . pw_t('Einträge im CRM', 'entries in CRM')); ?></h2>
      </div><a href="<?php echo esc_url(pw_page_url('crm')); ?>"><?php echo esc_html(pw_t('CRM öffnen', 'Open CRM')); ?></a></div>
      <div class="pw-submission-list">
        <?php if (!$own): ?>
          <div class="pw-empty compact"><p><?php echo esc_html(pw_t('Noch keine eigenen Kontakte. Lade die Vorlage herunter, trage deine Recherche ein und importiere die Datei.', 'No own contacts yet. Download the template, add your research and import the file.')); ?></p></div>
        <?php else: foreach ($own as $lead): ?>
          <a href="<?php echo esc_url(pw_page_url('crm', ['lead' => $lead->ID])); ?>">
            <span class="pw-profile-code"><?php echo esc_html(pw_initials($lead->post_title)); ?></span>
            <div><b><?php echo esc_html($lead->post_title); ?></b><small><?php echo esc_html(trim(get_post_meta($lead->ID, 'pw_crm_contact_role', true) . ' · ' . get_post_meta($lead->ID, 'pw_crm_city', true), ' ·')); ?></small></div>
            <?php echo pw_icon('arrow'); ?>
          </a>
        <?php endforeach; endif; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

/* ==========================================================================
 * Panel: Regeln, Quellen, Sperrliste
 * ======================================================================= */
function pw_leads_rules_panel() {
    $uid = get_current_user_id();
    $list = pw_lead_blocklist($uid);

    $sources = [
        ['TED – Tenders Electronic Daily', 'Alle EU-weiten Vergaben oberhalb der Schwellenwerte. AÜ-Bedarfe stehen unter CPV 79620000 und benachbarten Codes. In der Bekanntmachung ist die zuständige Kontaktstelle mit Namen, E-Mail und Telefon veröffentlicht.', 'https://ted.europa.eu/'],
        ['Deutsche Vergabeportale', 'eVergabe des Bundes, DTVP, Vergabe24 und die Landesportale veröffentlichen nationale Ausschreibungen unterhalb der EU-Schwelle – dort sitzen die kleineren, oft besser erreichbaren Bedarfe.', 'https://www.evergabe-online.de/'],
        ['Lieferanten- und Einkaufsportale der Konzerne', 'Große Auftraggeber führen eigene Supplier-Portale mit dem offiziellen Weg zur Lieferantenregistrierung. Wer dort gelistet ist, wird bei AÜ-Rahmenverträgen automatisch angefragt.', ''],
        ['Impressum und Unternehmensregister', 'Rechtlich sichere Basis für Firmierung, Anschrift, Geschäftsführung und die zentrale Rufnummer. Handelsregisterauszüge liefern verlässliche Konzernstrukturen.', 'https://www.unternehmensregister.de/'],
        ['IHK-Firmendatenbanken und Branchenverbände', 'Regionale Mitgliederverzeichnisse mit Ansprechpartnerfunktionen – ideal, um im eigenen Umkreis systematisch abzuklappern.', ''],
        ['Presse, Bau- und Investitionsmeldungen', 'Neue Werke, Erweiterungen und Standortverlagerungen kündigen Personalbedarf zwölf bis achtzehn Monate im Voraus an. Der beste Zeitpunkt für einen Erstkontakt.', ''],
    ];

    ob_start(); ?>
    <section class="pw-card">
      <div class="pw-card-head"><div>
        <span class="pw-kicker"><?php echo esc_html(pw_t('SO ENTSTEHEN GUTE LEADS', 'HOW GOOD LEADS ARE BUILT')); ?></span>
        <h2><?php echo esc_html(pw_t('Sechs Quellen, die wirklich tragen', 'Six sources that actually hold up')); ?></h2>
        <p class="pw-card-sub"><?php echo esc_html(pw_t('Pure Work zieht keine Daten aus Karriere- oder Social-Netzwerken. Deren Nutzungsbedingungen verbieten das, und das Risiko einer Abmahnung nach §7 UWG träfe dich als anrufendes Unternehmen. Die folgenden Quellen sind für die geschäftliche Ansprache belastbar.', 'Pure Work does not pull data from career or social networks. Their terms forbid it, and the legal risk would land on you as the calling company. The sources below hold up for business outreach.')); ?></p>
      </div></div>
      <div class="pw-verification-steps">
        <?php foreach ($sources as $i => $s): ?>
          <div class="active">
            <i><?php echo (int)($i + 1); ?></i>
            <div>
              <b><?php echo esc_html($s[0]); ?></b>
              <span><?php echo esc_html($s[1]); ?></span>
              <?php if ($s[2]): ?><a class="pw-btn small ghost" href="<?php echo esc_url($s[2]); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(pw_t('Quelle öffnen', 'Open source')); ?> <?php echo pw_icon('arrow'); ?></a><?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="pw-card">
      <div class="pw-card-head"><div>
        <span class="pw-kicker"><?php echo esc_html(pw_t('GESPRÄCHSEINSTIEG', 'OPENING THE CALL')); ?></span>
        <h2><?php echo esc_html(pw_t('Von der Zentrale zum richtigen Menschen', 'From the switchboard to the right person')); ?></h2>
      </div></div>
      <div class="pw-anon-cv-block">
        <p class="pw-card-sub"><?php echo esc_html(pw_t('Die zentrale Rufnummer steht legal im Impressum. Frag dort nicht nach „HR“, sondern nach der Stelle, die Arbeitnehmerüberlassung tatsächlich beauftragt:', 'The switchboard number is published legally in the imprint. Do not ask for “HR” – ask for the function that actually commissions temporary staffing:')); ?></p>
        <div class="pw-chip-list">
          <span><?php echo esc_html(pw_t('Einkauf Dienstleistungen', 'Services procurement')); ?></span>
          <span><?php echo esc_html(pw_t('Fremdpersonalsteuerung', 'Contingent workforce management')); ?></span>
          <span><?php echo esc_html(pw_t('Personaldisposition', 'Workforce scheduling')); ?></span>
          <span><?php echo esc_html(pw_t('Schicht-/Werkleitung', 'Plant or shift management')); ?></span>
          <span><?php echo esc_html(pw_t('Vergabestelle', 'Procurement office')); ?></span>
        </div>
        <p class="pw-card-sub"><?php echo esc_html(pw_t('In Konzernen entscheidet fast immer der Einkauf über Rahmenverträge, im Mittelstand die Werk- oder Schichtleitung. Wer den Namen im Gespräch erfragt, hat ihn rechtssicher – ohne fremde Datenbank.', 'In large groups procurement almost always owns the framework agreement; in mid-sized companies it is plant or shift management. Asking for the name during the call gives you the contact lawfully, without any third-party database.')); ?></p>
      </div>
    </section>

    <section class="pw-card">
      <div class="pw-card-head"><div>
        <span class="pw-kicker"><?php echo esc_html(pw_t('SPERRLISTE', 'BLOCK LIST')); ?></span>
        <h2><?php echo esc_html(pw_t('Widerspruch sofort umsetzen', 'Act on objections immediately')); ?></h2>
        <p class="pw-card-sub"><?php echo esc_html(pw_t('Wenn jemand keine Ansprache mehr wünscht, trage ihn hier ein. Der Eintrag löscht vorhandene CRM-Datensätze und verhindert, dass derselbe Kontakt beim nächsten Import erneut angelegt wird.', 'If someone no longer wishes to be contacted, add them here. The entry deletes existing CRM records and prevents the same contact from being re-created on the next import.')); ?></p>
      </div></div>

      <?php if (isset($_GET['blocked'])): ?>
        <div class="pw-alert success"><div><strong><?php echo esc_html(pw_t('Eintrag gesperrt', 'Entry blocked')); ?></strong><span><?php echo esc_html(sprintf(pw_t('%d vorhandene CRM-Datensätze wurden entfernt.', '%d existing CRM records were removed.'), (int)($_GET['removed'] ?? 0))); ?></span></div></div>
      <?php endif; ?>

      <form class="pw-form-grid two" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="pw_lead_block_add"><?php wp_nonce_field('pw_lead_block_add'); ?>
        <label><?php echo esc_html(pw_t('Unternehmen', 'Company')); ?><input name="company" placeholder="Muster GmbH"></label>
        <label><?php echo esc_html(pw_t('E-Mail (optional, sperrt gezielter)', 'E-mail (optional, blocks more precisely)')); ?><input type="email" name="email"></label>
        <label class="full"><?php echo esc_html(pw_t('Grund / Notiz', 'Reason / note')); ?><input name="reason" placeholder="<?php echo esc_attr(pw_t('z. B. telefonischer Widerspruch am …', 'e.g. objection by phone on …')); ?>"></label>
        <div class="full pw-form-actions"><button class="pw-btn primary" type="submit"><?php echo esc_html(pw_t('Sperren', 'Block')); ?></button></div>
      </form>

      <div class="pw-submission-list">
        <?php if (!$list): ?>
          <div class="pw-empty compact"><p><?php echo esc_html(pw_t('Sperrliste ist leer.', 'Block list is empty.')); ?></p></div>
        <?php else: foreach ($list as $key => $entry): ?>
          <div class="pw-side-facts">
            <div><span><?php echo esc_html($entry['company'] ?: $entry['email']); ?></span><b><?php echo esc_html(trim(($entry['reason'] ?: pw_t('Widerspruch', 'Objection')) . ' · ' . $entry['added'])); ?></b></div>
            <a class="pw-btn ghost small" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_lead_block_remove&key=' . rawurlencode($key)), 'pw_lead_block_remove')); ?>"><?php echo esc_html(pw_t('Sperre aufheben', 'Unblock')); ?></a>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

/* ==========================================================================
 * Tab-Navigation für die Direkt-Leads-Seite
 * ======================================================================= */
function pw_leads_tab_nav($active) {
    $tabs = [
        'verified' => pw_t('Geprüfte AÜ-Bedarfe', 'Verified staffing demand'),
        'own'      => pw_t('Eigene Recherche', 'Own research'),
        'rules'    => pw_t('Quellen & Sperrliste', 'Sources & block list'),
    ];
    $html = '<nav class="pw-tabs">';
    foreach ($tabs as $key => $label) {
        $url = pw_page_url('market_live', $key === 'verified' ? [] : ['tab' => $key]);
        $html .= '<a class="' . ($active === $key ? 'active' : '') . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }
    return $html . '</nav>';
}
