<?php
if (!defined('ABSPATH')) exit;

function pw_tariff_rates_2026() {
    return [
        ['eg'=>'1','now'=>'14,96 €','sep'=>'15,33 €'],['eg'=>'2a','now'=>'15,29 €','sep'=>'15,67 €'],['eg'=>'2b','now'=>'15,69 €','sep'=>'16,08 €'],['eg'=>'3','now'=>'16,69 €','sep'=>'17,11 €'],['eg'=>'4','now'=>'17,65 €','sep'=>'18,09 €'],['eg'=>'5','now'=>'19,78 €','sep'=>'20,27 €'],['eg'=>'6','now'=>'21,97 €','sep'=>'22,52 €'],['eg'=>'7','now'=>'25,56 €','sep'=>'26,20 €'],['eg'=>'8','now'=>'27,36 €','sep'=>'28,04 €'],['eg'=>'9','now'=>'28,70 €','sep'=>'29,42 €'],
    ];
}

function pw_shortcode_knowledge(){
    if(!is_user_logged_in())return pw_require_login_html();
    ob_start();echo pw_portal_shell_start(pw_t('Wissen & Tarif','Knowledge & tariff'),pw_t('Praxiswissen für Arbeitnehmerüberlassung – kompakt im Arbeitsablauf.','Practical temporary staffing knowledge integrated into your workflow.'));
    ?>
    <div class="pw-knowledge-hero"><div><span class="pw-kicker">DGB / GVP · STAND JANUAR 2026</span><h2>Tarifwissen dort, wo Disposition passiert.</h2><p>Die Hinweise sind aus den vom Betreiber bereitgestellten Unterlagen zusammengefasst. Sie ersetzen keine Rechts- oder Tarifberatung und sollten bei Änderungen des Tarifwerks aktualisiert werden.</p></div><div class="pw-knowledge-badge"><b>4.8</b><span>Wissenscenter</span></div></div>
    <div class="pw-knowledge-grid">
      <section class="pw-card"><span class="pw-kicker">ARBEITSZEIT</span><h3>151,67 Std. / Monat</h3><p>Regelmäßige Vollzeit nach dem DGB/GVP-Manteltarif: durchschnittlich 35 Wochenstunden. In begründeten Fällen kann arbeitsvertraglich bis 40 Wochenstunden bzw. 173,34 Stunden monatlich vereinbart werden.</p></section>
      <section class="pw-card"><span class="pw-kicker">URLAUB</span><h3>25 · 27 · 30 Tage</h3><p>1. Beschäftigungsjahr: 25 Arbeitstage, 2. und 3. Jahr: 27 Arbeitstage, ab dem 4. Jahr: 30 Arbeitstage – bei einer 5-Tage-Woche.</p></section>
      <section class="pw-card"><span class="pw-kicker">ZUSCHLÄGE</span><h3>Mehrarbeit +25 %</h3><p>Mehrarbeitszuschlag nach Überschreiten des tariflichen Schwellenwerts. Nachtarbeit richtet sich nach dem Kundenbetrieb (max. 25 %), Sonntag max. 50 %, Feiertag max. 100 %.</p></section>
      <section class="pw-card"><span class="pw-kicker">SONDERZAHLUNG</span><h3>ab dem 7. Monat</h3><p>Nach dem sechsten Monat des ununterbrochenen Arbeitsverhältnisses entsteht tariflich Anspruch auf zusätzliches Urlaubs- und Weihnachtsgeld nach den jeweiligen Tabellen.</p></section>
      <section class="pw-card"><span class="pw-kicker">AÜG</span><h3>18 Monate</h3><p>Das BA-Merkblatt nennt grundsätzlich 18 Monate Überlassungshöchstdauer beim selben Entleiher; tarifliche oder betriebliche Abweichungen können möglich sein.</p></section>
      <section class="pw-card"><span class="pw-kicker">EQUAL PAY</span><h3>9-Monats-Marke beobachten</h3><p>Das BA-Merkblatt erläutert, dass vom Gleichstellungsgrundsatz in den ersten 9 Monaten durch Tarifvertrag abgewichen werden kann; Branchenzuschlagstarifverträge können Besonderheiten vorsehen.</p></section>
    </div>
    <section class="pw-card pw-tariff-table-card"><div class="pw-card-head"><div><span class="pw-kicker">ENTGELTTABELLE</span><h2>DGB/GVP – Grundstundenentgelte</h2><p>Aktuelle Tabelle 01.01.–31.08.2026 und bereits hinterlegte Folgetabelle ab 01.09.2026.</p></div><span class="pw-badge warning">Änderung 01.09.2026</span></div><div class="pw-data-table-wrap"><table class="pw-data-table"><thead><tr><th>Entgeltgruppe</th><th>bis 31.08.2026</th><th>ab 01.09.2026</th></tr></thead><tbody><?php foreach(pw_tariff_rates_2026() as $r):?><tr><td><strong>EG <?php echo esc_html($r['eg']); ?></strong></td><td><?php echo esc_html($r['now']); ?></td><td><strong><?php echo esc_html($r['sep']); ?></strong></td></tr><?php endforeach;?></tbody></table></div></section>
    <div class="pw-knowledge-process"><section class="pw-card"><span class="pw-kicker">EINSATZ-CHECK</span><h3>Vor einer Überlassung</h3><div class="pw-checklist"><span>✓ AÜG-Erlaubnis des Verleihers gültig</span><span>✓ Einsatz / Entleiher konkret dokumentieren</span><span>✓ Mitarbeiter vor Einsatz über Entleiher informieren</span><span>✓ Überlassungsdauer und vorherige Einsätze prüfen</span><span>✓ Tarif / Branchenzuschlag / Equal-Pay-Fristen prüfen</span><span>✓ Arbeitszeit, Zuschläge und Einsatzbedingungen dokumentieren</span></div></section><section class="pw-card"><span class="pw-kicker">DOKUMENTEN-WORKFLOW</span><h3>Typische Unterlagen</h3><p>Die bereitgestellten Vorlagen zeigen typische Prozesse wie Arbeitsvertrag, Einsatzinformation, Überlassungskonkretisierung, Personalfragebogen, Tätigkeitsnachweis, Urlaubsantrag, Abmahnung, Aufhebung/Kündigung und Rahmenvertrag mit dem Entleiher.</p><div class="pw-chip-list"><span>Arbeitsvertrag</span><span>Einsatzinformation</span><span>Überlassungskonkretisierung</span><span>Personalfragebogen</span><span>Tätigkeitsnachweis</span><span>Urlaub</span><span>Rahmenvertrag</span></div></section></div>
    <div class="pw-source-note"><b>Quelle im Projekt:</b> TV DGB/GVP, Stand Januar 2026, sowie Merkblatt für Leiharbeitnehmerinnen und Leiharbeitnehmer, Stand 03/2025 – aus dem vom Betreiber bereitgestellten Dokumentenpaket. Rechtliche und tarifliche Änderungen müssen vor Produktiventscheidungen geprüft werden.</div>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}
add_shortcode('pw_knowledge','pw_shortcode_knowledge');
