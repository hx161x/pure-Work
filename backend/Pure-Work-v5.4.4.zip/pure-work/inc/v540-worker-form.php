<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.4.0 – Mitarbeiter anlegen als echter Assistent.
 *
 * Vorher: 22 Eingabefelder auf einer Seite, dazu eine Fortschrittsanzeige
 * "1 – 2 – 3", die nichts steuerte. Sie war reine Dekoration; alle drei
 * Abschnitte lagen gleichzeitig untereinander. Wer zum ersten Mal einen
 * Mitarbeiter anlegt, sieht damit eine Wand aus Feldern und weiß nicht, was
 * davon Pflicht ist und was der Auftraggeber später überhaupt zu sehen bekommt.
 *
 * Jetzt: drei echte Schritte mit Weiter/Zurück, Prüfung je Schritt und einer
 * Live-Vorschau, die zeigt, was der Auftraggeber sieht – der wichtigste Punkt
 * dieser Plattform, vorher nur als Fließtext behauptet.
 *
 * Die Feldnamen sind unverändert. Der bestehende Speicher-Vorgang
 * (admin_post pw_worker_save) bleibt komplett wie er ist.
 */

function pw_v540_status_options() {
    return [
        'available' => [pw_t('Verfügbar', 'Available'), pw_t('Kann sofort oder ab dem genannten Datum eingesetzt werden', 'Can be placed now or from the stated date')],
        'reserved'  => [pw_t('Reserviert', 'Reserved'), pw_t('Für einen konkreten Auftrag vorgemerkt', 'Earmarked for a specific job')],
        'assigned'  => [pw_t('Im Einsatz', 'Assigned'), pw_t('Läuft aktuell beim Kunden', 'Currently placed with a client')],
        'inactive'  => [pw_t('Inaktiv', 'Inactive'), pw_t('Nicht im Marktplatz sichtbar', 'Not visible in the marketplace')],
    ];
}

function pw_worker_form_v540($worker_id = 0) {
    $tpl    = sanitize_key($_GET['template'] ?? '');
    $tpls   = function_exists('pw_worker_templates') ? pw_worker_templates() : [];
    $preset = (!$worker_id && isset($tpls[$tpl])) ? $tpls[$tpl] : [];

    $w = $worker_id ? pw_worker_fields($worker_id) : [
        'id' => 0, 'code' => '', 'role' => $preset['role'] ?? '', 'experience' => '',
        'location' => '', 'available_from' => '',
        'shifts' => pw_sanitize_csv_list($preset['shifts'] ?? ''),
        'qualifications' => pw_sanitize_csv_list($preset['qualifications'] ?? ''),
        'languages' => [], 'driver' => '0', 'car' => '0',
        'industries' => pw_sanitize_csv_list($preset['industries'] ?? ''),
        'last_assignment' => '', 'status' => 'available', 'full_name' => '', 'birth_date' => '',
        'email' => '', 'phone' => '', 'address' => '', 'cv_file' => 0, 'public_cv_file' => 0, 'docs_file' => 0,
    ];

    ob_start(); ?>
    <div class="pw-page-head-inline">
      <div>
        <a class="pw-back" href="<?php echo esc_url(pw_page_url('workers')); ?>">← <?php echo esc_html(pw_t('Meine Mitarbeiter', 'My employees')); ?></a>
        <h2><?php echo esc_html($worker_id ? pw_t('Mitarbeiter bearbeiten', 'Edit employee') : pw_t('Mitarbeiter anlegen', 'Add employee')); ?></h2>
        <p><?php echo esc_html(pw_t('Drei Schritte. Namen und Kontaktdaten bleiben immer intern.', 'Three steps. Names and contact details always stay internal.')); ?></p>
      </div>
    </div>

    <form class="pw-w540" enctype="multipart/form-data" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" data-worker-wizard>
      <input type="hidden" name="action" value="pw_worker_save">
      <input type="hidden" name="worker_id" value="<?php echo (int)$w['id']; ?>">
      <?php wp_nonce_field('pw_worker_save'); ?>

      <!-- Schrittleiste: klickbar, zeigt den tatsächlichen Stand -->
      <ol class="pw-w540-steps" data-wizard-steps>
        <li class="active" data-step-nav="1"><i>1</i><span><b><?php echo esc_html(pw_t('Person', 'Person')); ?></b><small><?php echo esc_html(pw_t('nur intern', 'internal only')); ?></small></span></li>
        <li data-step-nav="2"><i>2</i><span><b><?php echo esc_html(pw_t('Einsatzprofil', 'Placement profile')); ?></b><small><?php echo esc_html(pw_t('sieht der Auftraggeber', 'the client sees this')); ?></small></span></li>
        <li data-step-nav="3"><i>3</i><span><b><?php echo esc_html(pw_t('Feinheiten', 'Details')); ?></b><small><?php echo esc_html(pw_t('optional', 'optional')); ?></small></span></li>
      </ol>

      <div class="pw-w540-body">
        <div class="pw-w540-main">

          <!-- ============================ SCHRITT 1 ============================ -->
          <section class="pw-w540-step active" data-step="1">
            <?php if (function_exists('pw_assist_worker_card')) echo pw_assist_worker_card(); ?>

            <div class="pw-card pw-w540-card">
              <div class="pw-w540-card-head">
                <div>
                  <h3><?php echo esc_html(pw_t('Wer ist es?', 'Who is it?')); ?></h3>
                  <p><?php echo esc_html(pw_t('Diese Angaben verlassen dein Unternehmen nie – auch nach einer Zusage nicht.', 'This information never leaves your company – not even after a placement.')); ?></p>
                </div>
                <span class="pw-private-chip"><?php echo pw_icon('lock'); ?> <?php echo esc_html(pw_t('privat', 'private')); ?></span>
              </div>

              <div class="pw-form-grid two">
                <label class="full"><?php echo esc_html(pw_t('Vor- und Nachname', 'Full name')); ?>
                  <input name="full_name" required value="<?php echo esc_attr($w['full_name']); ?>" data-required-step="1" autocomplete="off">
                </label>
                <label><?php echo esc_html(pw_t('Telefon', 'Phone')); ?>
                  <input name="worker_phone" value="<?php echo esc_attr($w['phone']); ?>" placeholder="0621 …">
                </label>
                <label><?php echo esc_html(pw_t('E-Mail', 'E-mail')); ?>
                  <input type="email" name="worker_email" value="<?php echo esc_attr($w['email']); ?>">
                </label>
                <label><?php echo esc_html(pw_t('Geburtsdatum', 'Date of birth')); ?>
                  <input type="date" name="birth_date" value="<?php echo esc_attr($w['birth_date']); ?>">
                </label>
                <label><?php echo esc_html(pw_t('Anschrift', 'Address')); ?>
                  <input name="worker_address" value="<?php echo esc_attr($w['address']); ?>">
                </label>
              </div>

              <details class="pw-w540-files">
                <summary><?php echo pw_icon('upload'); ?> <?php echo esc_html(pw_t('Unterlagen hinterlegen (optional)', 'Attach documents (optional)')); ?></summary>
                <div class="pw-form-grid two">
                  <label><?php echo esc_html(pw_t('Original-Lebenslauf', 'Original CV')); ?>
                    <input type="file" name="cv_file" accept=".pdf,.doc,.docx">
                    <?php if ($w['cv_file']): ?><small><a href="<?php echo esc_url(pw_file_download_url((int)$w['cv_file'])); ?>"><?php echo esc_html(pw_t('Hinterlegte Datei öffnen', 'Open stored file')); ?></a></small><?php endif; ?>
                  </label>
                  <label><?php echo esc_html(pw_t('Nachweise, Scheine, Zeugnisse', 'Certificates and licences')); ?>
                    <input type="file" name="docs_file" accept=".pdf,.jpg,.jpeg,.png">
                    <?php if ($w['docs_file']): ?><small><a href="<?php echo esc_url(pw_file_download_url((int)$w['docs_file'])); ?>"><?php echo esc_html(pw_t('Nachweise öffnen', 'Open certificates')); ?></a></small><?php endif; ?>
                  </label>
                </div>
              </details>
            </div>
          </section>

          <!-- ============================ SCHRITT 2 ============================ -->
          <section class="pw-w540-step" data-step="2">
            <div class="pw-card pw-w540-card">
              <div class="pw-w540-card-head">
                <div>
                  <h3><?php echo esc_html(pw_t('Was kann er, ab wann, wo?', 'What can they do, from when, where?')); ?></h3>
                  <p><?php echo esc_html(pw_t('Genau diese Angaben landen im anonymen Profil rechts.', 'Exactly these details go into the anonymous profile on the right.')); ?></p>
                </div>
              </div>

              <div class="pw-form-grid two">
                <label class="full"><?php echo esc_html(pw_t('Tätigkeit', 'Role')); ?>
                  <input name="role" list="pw-roles" data-pw-occupation="1" required value="<?php echo esc_attr($w['role']); ?>" data-required-step="2" data-preview="role" placeholder="<?php echo esc_attr(pw_t('z. B. Staplerfahrer', 'e.g. forklift driver')); ?>">
                  <small><?php echo esc_html(pw_t('Tippen genügt – die Liste schlägt offizielle Berufsbezeichnungen vor.', 'Just type – the list suggests official occupation titles.')); ?></small>
                </label>
                <label><?php echo esc_html(pw_t('Berufserfahrung in Jahren', 'Years of experience')); ?>
                  <input type="number" min="0" max="60" name="experience" value="<?php echo esc_attr($w['experience']); ?>" data-preview="experience">
                </label>
                <label><?php echo esc_html(pw_t('Wohnort / Region', 'Residence / region')); ?>
                  <input name="location" list="pw-locations" value="<?php echo esc_attr($w['location']); ?>" placeholder="<?php echo esc_attr(pw_t('z. B. Mannheim', 'e.g. Mannheim')); ?>" data-preview="location">
                </label>
                <label><?php echo esc_html(pw_t('Verfügbar ab', 'Available from')); ?>
                  <input type="date" name="available_from" value="<?php echo esc_attr($w['available_from']); ?>" data-preview="available">
                </label>
                <label class="full"><?php echo esc_html(pw_t('Qualifikationen und Scheine', 'Qualifications and licences')); ?>
                  <input name="qualifications" list="pw-qualifications" value="<?php echo esc_attr(pw_list_string($w['qualifications'])); ?>" data-preview="qualifications" placeholder="<?php echo esc_attr(pw_t('Staplerschein, Gabelstapler, Kommissionierung', 'Forklift licence, order picking')); ?>">
                  <small><?php echo esc_html(pw_t('Mit Komma trennen.', 'Separate with commas.')); ?></small>
                </label>
              </div>

              <div class="pw-w540-status">
                <span class="pw-w540-label"><?php echo esc_html(pw_t('Aktueller Stand', 'Current status')); ?></span>
                <div class="pw-w540-radio-row">
                  <?php foreach (pw_v540_status_options() as $key => $opt): ?>
                    <label class="<?php echo $w['status'] === $key ? 'checked' : ''; ?>">
                      <input type="radio" name="status" value="<?php echo esc_attr($key); ?>" <?php checked($w['status'], $key); ?>>
                      <b><?php echo esc_html($opt[0]); ?></b>
                      <small><?php echo esc_html($opt[1]); ?></small>
                    </label>
                  <?php endforeach; ?>
                </div>
              </div>
            </div>
          </section>

          <!-- ============================ SCHRITT 3 ============================ -->
          <section class="pw-w540-step" data-step="3">
            <div class="pw-card pw-w540-card">
              <div class="pw-w540-card-head">
                <div>
                  <h3><?php echo esc_html(pw_t('Feinheiten für bessere Treffer', 'Details for better matches')); ?></h3>
                  <p><?php echo esc_html(pw_t('Alles hier ist freiwillig. Je mehr ausgefüllt ist, desto genauer schlägt Pure Work passende Ausschreibungen vor.', 'Everything here is optional. The more you fill in, the more precisely Pure Work suggests matching jobs.')); ?></p>
                </div>
              </div>

              <div class="pw-form-grid two">
                <label><?php echo esc_html(pw_t('Schichten', 'Shifts')); ?>
                  <input name="shifts" list="pw-shifts" value="<?php echo esc_attr(pw_list_string($w['shifts'])); ?>" data-preview="shifts">
                </label>
                <label><?php echo esc_html(pw_t('Branchenerfahrung', 'Industry experience')); ?>
                  <input name="industries" list="pw-industries" value="<?php echo esc_attr(pw_list_string($w['industries'])); ?>" data-preview="industries">
                </label>
                <label><?php echo esc_html(pw_t('Sprachen', 'Languages')); ?>
                  <input name="languages" list="pw-languages" value="<?php echo esc_attr(pw_list_string($w['languages'])); ?>" data-preview="languages">
                </label>
                <label><?php echo esc_html(pw_t('Letzter Einsatz – ohne Kundennamen', 'Last assignment – no client name')); ?>
                  <input name="last_assignment" value="<?php echo esc_attr($w['last_assignment']); ?>" placeholder="<?php echo esc_attr(pw_t('z. B. Lagerlogistik, 8 Monate', 'e.g. warehouse logistics, 8 months')); ?>">
                </label>
              </div>

              <div class="pw-w540-toggles">
                <label class="pw-w540-toggle <?php echo $w['driver'] === '1' ? 'on' : ''; ?>">
                  <input type="checkbox" name="driver" value="1" <?php checked($w['driver'], '1'); ?> data-preview-toggle="driver">
                  <i></i><span><b><?php echo esc_html(pw_t('Führerschein', 'Driving licence')); ?></b><small><?php echo esc_html(pw_t('Klasse B oder höher', 'Class B or above')); ?></small></span>
                </label>
                <label class="pw-w540-toggle <?php echo $w['car'] === '1' ? 'on' : ''; ?>">
                  <input type="checkbox" name="car" value="1" <?php checked($w['car'], '1'); ?> data-preview-toggle="car">
                  <i></i><span><b><?php echo esc_html(pw_t('Eigener PKW', 'Own car')); ?></b><small><?php echo esc_html(pw_t('Erreicht auch Einsätze ohne Anbindung', 'Can reach sites without public transport')); ?></small></span>
                </label>
              </div>

              <details class="pw-w540-files">
                <summary><?php echo pw_icon('plus'); ?> <?php echo esc_html(pw_t('Anonymisierten Lebenslauf hochladen', 'Upload an anonymised CV')); ?></summary>
                <label><?php echo esc_html(pw_t('Marktplatz-Lebenslauf', 'Marketplace CV')); ?>
                  <input type="file" name="public_cv_file" accept=".pdf,.doc,.docx">
                  <small><?php echo esc_html(pw_t('Bitte ohne Name, Geburtsdatum, E-Mail, Telefon und Anschrift.', 'Please without name, date of birth, e-mail, phone or address.')); ?></small>
                  <?php if ($w['public_cv_file']): ?><small><a href="<?php echo esc_url(pw_file_download_url((int)$w['public_cv_file'])); ?>"><?php echo esc_html(pw_t('Hinterlegte Datei öffnen', 'Open stored file')); ?></a></small><?php endif; ?>
                </label>
              </details>
            </div>
          </section>
        </div>

        <!-- ===================== LIVE-VORSCHAU ===================== -->
        <aside class="pw-w540-preview">
          <div class="pw-w540-preview-inner">
            <span class="pw-kicker"><?php echo esc_html(pw_t('SO SIEHT ES DER AUFTRAGGEBER', 'WHAT THE CLIENT SEES')); ?></span>
            <div class="pw-w540-preview-card">
              <div class="pw-w540-preview-top">
                <span class="pw-profile-code" data-preview-out="code"><?php echo esc_html($w['code'] ?: '––'); ?></span>
                <div>
                  <b data-preview-out="role"><?php echo esc_html($w['role'] ?: pw_t('Tätigkeit fehlt noch', 'Role still missing')); ?></b>
                  <small data-preview-out="meta"><?php echo esc_html(trim(($w['location'] ?: '—') . ' · ' . ((int)$w['experience']) . ' ' . pw_t('Jahre', 'years'))); ?></small>
                </div>
              </div>
              <div class="pw-w540-preview-row"><span><?php echo esc_html(pw_t('Verfügbar ab', 'Available from')); ?></span><b data-preview-out="available"><?php echo esc_html($w['available_from'] ? pw_format_date($w['available_from']) : pw_t('sofort', 'immediately')); ?></b></div>
              <div class="pw-w540-preview-chips" data-preview-out="chips">
                <?php foreach (array_slice((array)$w['qualifications'], 0, 6) as $q) echo '<span>' . esc_html($q) . '</span>'; ?>
              </div>
              <div class="pw-w540-preview-flags" data-preview-out="flags"></div>
            </div>
            <p class="pw-w540-preview-note"><?php echo pw_icon('lock'); ?> <?php echo esc_html(pw_t('Name, Geburtsdatum, Anschrift und Kontaktdaten stehen bewusst nicht in dieser Karte.', 'Name, date of birth, address and contact details are deliberately absent from this card.')); ?></p>

            <div class="pw-w540-fill">
              <span><?php echo esc_html(pw_t('Profilstärke', 'Profile strength')); ?></span>
              <i><b data-preview-out="fillbar" style="width:0%"></b></i>
              <em data-preview-out="fillnum">0 %</em>
            </div>
          </div>
        </aside>
      </div>

      <!-- ===================== NAVIGATION ===================== -->
      <div class="pw-w540-nav">
        <a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('workers')); ?>"><?php echo esc_html(pw_t('Abbrechen', 'Cancel')); ?></a>
        <div>
          <button type="button" class="pw-btn ghost" data-wizard-back hidden><?php echo esc_html(pw_t('Zurück', 'Back')); ?></button>
          <button type="button" class="pw-btn primary" data-wizard-next><?php echo esc_html(pw_t('Weiter', 'Next')); ?> <?php echo pw_icon('arrow'); ?></button>
          <button type="submit" class="pw-btn primary" data-wizard-save hidden><?php echo pw_icon('check'); ?> <?php echo esc_html($worker_id ? pw_t('Änderungen speichern', 'Save changes') : pw_t('Mitarbeiter speichern', 'Save employee')); ?></button>
        </div>
      </div>
    </form>
    <?php return ob_get_clean();
}
