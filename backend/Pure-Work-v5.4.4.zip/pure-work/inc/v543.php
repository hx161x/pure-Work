<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.4.3
 * Digitale Firmen-Visitenkarten im Live-Chat.
 */
function pw_v543_business_card_for_user($uid, $sid = 0) {
    $u = get_userdata($uid);
    if (!$u) return [];
    $role = pw_user_role($uid);
    $company = trim((string)pw_user_meta($uid, 'pw_company', $u->display_name));
    $contact = trim((string)pw_user_meta($uid, 'pw_contact', $u->display_name));
    $phone = trim((string)pw_user_meta($uid, 'pw_phone', ''));
    $zip = trim((string)pw_user_meta($uid, 'pw_zip', ''));
    $city = trim((string)pw_user_meta($uid, 'pw_city', ''));
    $industry = trim((string)pw_user_meta($uid, 'pw_industry', ''));
    $company_verified = pw_user_meta($uid, 'pw_company_verified', '0') === '1';
    $aug_verified = $role === 'agency' && pw_user_meta($uid, 'pw_aug_verified', '0') === '1';
    $badge = $aug_verified ? pw_t('AÜG geprüft', 'AÜG verified') : ($company_verified ? pw_t('Unternehmen geprüft', 'Company verified') : pw_t('Pure Work Kontakt', 'Pure Work contact'));
    return [
        'company' => $company,
        'contact' => $contact,
        'email' => sanitize_email($u->user_email),
        'phone' => $phone,
        'zip' => $zip,
        'city' => $city,
        'industry' => $industry,
        'role' => $role === 'agency' ? pw_t('Personaldienstleister', 'Staffing provider') : pw_t('Auftraggeber', 'Client'),
        'badge' => $badge,
        'initials' => function_exists('pw_initials') ? pw_initials($company ?: $contact) : strtoupper(substr($company ?: $contact, 0, 2)),
        'submission_id' => (int)$sid,
    ];
}

function pw_v543_card_from_message($mid, $viewer_uid = 0) {
    $raw = get_post_meta($mid, 'pw_business_card', true);
    if (!$raw) return null;
    $card = is_array($raw) ? $raw : json_decode((string)$raw, true);
    if (!is_array($card)) return null;
    $card = array_map(static function($v){ return is_scalar($v) ? (string)$v : ''; }, $card);
    $card['download_url'] = wp_nonce_url(admin_url('admin-post.php?action=pw_v543_vcard&message='.(int)$mid), 'pw_v543_vcard_'.(int)$mid);
    return $card;
}

function pw_v543_card_html($card, $mine = false) {
    if (!$card) return '';
    $place = trim(($card['zip'] ?? '') . ' ' . ($card['city'] ?? ''));
    ob_start(); ?>
    <article class="pw-v543-business-card<?php echo $mine ? ' is-mine' : ''; ?>">
      <header>
        <span class="pw-v543-card-avatar"><?php echo esc_html($card['initials'] ?? 'PW'); ?></span>
        <div><small><?php echo esc_html($card['badge'] ?? pw_t('Pure Work Kontakt','Pure Work contact')); ?></small><h4><?php echo esc_html($card['company'] ?? ''); ?></h4><p><?php echo esc_html($card['role'] ?? ''); ?></p></div>
        <span class="pw-v543-card-mark">PW</span>
      </header>
      <div class="pw-v543-card-contact">
        <?php if (!empty($card['contact'])): ?><div><?php echo pw_icon('users'); ?><span><small><?php echo esc_html(pw_t('Ansprechpartner','Contact')); ?></small><b><?php echo esc_html($card['contact']); ?></b></span></div><?php endif; ?>
        <?php if (!empty($card['phone'])): ?><div><?php echo pw_icon('phone'); ?><span><small><?php echo esc_html(pw_t('Telefon','Phone')); ?></small><b><?php echo esc_html($card['phone']); ?></b></span></div><?php endif; ?>
        <?php if (!empty($card['email'])): ?><div><?php echo pw_icon('message'); ?><span><small><?php echo esc_html(pw_t('E-Mail','Email')); ?></small><b><?php echo esc_html($card['email']); ?></b></span></div><?php endif; ?>
        <?php if ($place): ?><div><?php echo pw_icon('map'); ?><span><small><?php echo esc_html(pw_t('Standort','Location')); ?></small><b><?php echo esc_html($place); ?></b></span></div><?php endif; ?>
      </div>
      <?php if (!empty($card['industry'])): ?><p class="pw-v543-card-industry"><?php echo esc_html($card['industry']); ?></p><?php endif; ?>
      <footer>
        <?php if (!empty($card['phone'])): ?><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9\+]/','',$card['phone'])); ?>"><?php echo pw_icon('phone'); ?> <?php echo esc_html(pw_t('Anrufen','Call')); ?></a><?php endif; ?>
        <?php if (!empty($card['email'])): ?><a href="mailto:<?php echo esc_attr($card['email']); ?>"><?php echo pw_icon('message'); ?> <?php echo esc_html(pw_t('E-Mail','Email')); ?></a><?php endif; ?>
        <?php if (!empty($card['download_url'])): ?><a href="<?php echo esc_url($card['download_url']); ?>"><?php echo pw_icon('card'); ?> <?php echo esc_html(pw_t('Kontakt speichern','Save contact')); ?></a><?php endif; ?>
      </footer>
    </article>
    <?php return ob_get_clean();
}

function pw_ajax_v543_send_card() {
    pw_ajax_guard();
    $uid = get_current_user_id();
    $sid = (int)($_POST['submission_id'] ?? 0);
    if (!pw_v520_chat_can($sid, $uid)) wp_send_json_error(['message'=>pw_t('Chat nicht verfügbar.','Chat unavailable.')], 403);
    $card = pw_v543_business_card_for_user($uid, $sid);
    if (empty($card['company']) || empty($card['contact'])) wp_send_json_error(['message'=>pw_t('Bitte ergänze zuerst Firmenname und Ansprechpartner in deinem Konto.','Please complete company name and contact person in your account first.')], 400);
    $text = pw_t('Digitale Visitenkarte', 'Digital business card') . ' · ' . $card['company'];
    $id = pw_v520_store_message($sid, $uid, $text, ['pw_business_card'=>wp_json_encode($card, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
    if (is_wp_error($id)) wp_send_json_error(['message'=>$id->get_error_message()], 500);
    wp_send_json_success(['item'=>pw_v520_message_payload(get_post($id), $uid)]);
}
add_action('wp_ajax_pw_v543_send_card','pw_ajax_v543_send_card');

function pw_v543_vcard_escape($value) {
    $value = str_replace(["\\", ";", ",", "\r", "\n"], ["\\\\", "\\;", "\\,", '', "\\n"], (string)$value);
    return $value;
}
function pw_handle_v543_vcard() {
    if (!is_user_logged_in()) auth_redirect();
    $mid = (int)($_GET['message'] ?? 0);
    check_admin_referer('pw_v543_vcard_'.$mid);
    $sid = (int)pw_meta($mid, 'pw_submission_id', 0);
    if (!$mid || !$sid || !pw_can_access_submission($sid, get_current_user_id())) wp_die(esc_html(pw_t('Kein Zugriff.','No access.')));
    $card = pw_v543_card_from_message($mid, get_current_user_id());
    if (!$card) wp_die(esc_html(pw_t('Visitenkarte nicht gefunden.','Business card not found.')));
    $fn = $card['contact'] ?: $card['company'];
    $lines = ['BEGIN:VCARD','VERSION:3.0','FN:'.pw_v543_vcard_escape($fn),'ORG:'.pw_v543_vcard_escape($card['company'] ?? '')];
    if (!empty($card['role'])) $lines[]='TITLE:'.pw_v543_vcard_escape($card['role']);
    if (!empty($card['phone'])) $lines[]='TEL;TYPE=WORK,VOICE:'.pw_v543_vcard_escape($card['phone']);
    if (!empty($card['email'])) $lines[]='EMAIL;TYPE=INTERNET,WORK:'.pw_v543_vcard_escape($card['email']);
    if (!empty($card['city']) || !empty($card['zip'])) $lines[]='ADR;TYPE=WORK:;;;'.pw_v543_vcard_escape($card['city'] ?? '').';;'.pw_v543_vcard_escape($card['zip'] ?? '').';Germany';
    if (!empty($card['industry'])) $lines[]='NOTE:'.pw_v543_vcard_escape(pw_t('Branche: ','Industry: ').$card['industry'].' · Pure Work');
    $lines[]='END:VCARD';
    $filename = sanitize_file_name(($card['company'] ?: 'Pure-Work-Kontakt').'.vcf');
    nocache_headers(); header('Content-Type: text/vcard; charset=utf-8'); header('Content-Disposition: attachment; filename="'.$filename.'"');
    echo implode("\r\n", $lines); exit;
}
add_action('admin_post_pw_v543_vcard','pw_handle_v543_vcard');
