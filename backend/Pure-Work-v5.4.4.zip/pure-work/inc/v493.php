<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 4.9.3 – usability and account-recovery layer.
 *
 * Everything in this file is additive: no markup, class name or colour of the
 * existing design is changed. It closes the functional gaps that made the
 * portal feel unfinished:
 *   - changing your password while logged in was impossible
 *   - operators had no visible warning when outgoing mail was broken
 *   - new companies had no guided first run
 */

/* --------------------------------------------------------------------------
 * Password change for a signed-in user
 * ----------------------------------------------------------------------- */
function pw_handle_password_change() {
    if (!is_user_logged_in()) wp_die('Nicht angemeldet.');
    pw_require_post_nonce('pw_password_change');

    $user = wp_get_current_user();
    $current = (string)($_POST['current_password'] ?? '');
    $new = (string)($_POST['new_password'] ?? '');
    $confirm = (string)($_POST['new_password_confirm'] ?? '');

    if (!$current || !wp_check_password($current, $user->user_pass, $user->ID)) {
        pw_form_redirect('account', ['tab' => 'security', 'pw_error' => 'current']);
    }
    if (strlen($new) < 8 || $new !== $confirm) {
        pw_form_redirect('account', ['tab' => 'security', 'pw_error' => 'weak']);
    }

    wp_set_password($new, $user->ID);
    // wp_set_password() destroys the session, so sign the user straight back in
    // instead of dropping them on a login screen without explanation.
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, true, is_ssl());

    pw_send_mail(
        $user->user_email,
        'Pure Work – Passwort geändert',
        'Passwort erfolgreich geändert',
        'Das Passwort deines Pure Work Kontos wurde soeben im Portal geändert. Falls du das nicht warst, setze dein Passwort umgehend zurück und informiere den Portalbetreiber.',
        'Konto öffnen',
        pw_page_url('account', ['tab' => 'security'])
    );
    if (function_exists('pw_audit_event')) pw_audit_event('password_change', $user->ID, 'user', $user->ID, 'Passwort im Portal geändert');

    pw_form_redirect('account', ['tab' => 'security', 'pw_changed' => 1]);
}
add_action('admin_post_pw_password_change', 'pw_handle_password_change');

/* --------------------------------------------------------------------------
 * Guided first run
 * ----------------------------------------------------------------------- */
/**
 * A three-step checklist shown on the dashboard until the company is actually
 * up and running. It disappears on its own – no dead weight for daily users.
 */
function pw_onboarding_guide($user_id = 0, $role = '') {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return '';
    if (!$role) $role = pw_user_role($user_id);
    if (!in_array($role, ['agency', 'client'], true)) return '';

    $state = pw_verification_state($user_id);
    $steps = [];

    $steps[] = [
        'done'  => !empty($state['email']),
        'title' => pw_t('E-Mail-Adresse bestätigen', 'Confirm your e-mail address'),
        'text'  => pw_t('Öffne den Aktivierungslink aus deiner Bestätigungs-E-Mail.', 'Open the activation link from your confirmation e-mail.'),
        'url'   => pw_page_url('account', ['tab' => 'verification']),
        'cta'   => pw_t('Status ansehen', 'View status'),
    ];

    if ($role === 'agency') {
        $workers = (int)(new WP_Query([
            'post_type' => 'pw_worker', 'post_status' => 'publish', 'author' => $user_id,
            'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => false,
        ]))->found_posts;
        $submissions = (int)(new WP_Query([
            'post_type' => 'pw_submission', 'post_status' => 'publish', 'posts_per_page' => 1,
            'fields' => 'ids', 'meta_query' => [['key' => 'pw_agency_id', 'value' => $user_id]],
        ]))->found_posts;

        $steps[] = [
            'done'  => $workers > 0,
            'title' => pw_t('Ersten Mitarbeiter anlegen', 'Add your first employee'),
            'text'  => pw_t('Namen und Kontaktdaten sieht ausschließlich dein Unternehmen. Mehrere Profile gehen per CSV-Import.', 'Names and contact details stay visible to your company only. Use the CSV import for several profiles at once.'),
            'url'   => pw_page_url('workers', ['new' => 1]),
            'cta'   => pw_t('Mitarbeiter anlegen', 'Add employee'),
        ];
        $steps[] = [
            'done'  => $submissions > 0,
            'title' => pw_t('Profil einer Ausschreibung zuordnen', 'Match a profile to a job'),
            'text'  => pw_t('Öffne eine offene Ausschreibung und ordne ein passendes Profil zu. Der Auftraggeber wird sofort informiert.', 'Open a published job and match a suitable profile. The client is notified immediately.'),
            'url'   => pw_page_url('vacancies'),
            'cta'   => pw_t('Ausschreibungen ansehen', 'Browse jobs'),
        ];
    } else {
        $jobs = (int)(new WP_Query([
            'post_type' => 'pw_vacancy', 'post_status' => 'publish', 'author' => $user_id,
            'posts_per_page' => 1, 'fields' => 'ids',
        ]))->found_posts;
        $company_filled = pw_user_meta($user_id, 'pw_city', '') !== '' && pw_user_meta($user_id, 'pw_phone', '') !== '';

        $steps[] = [
            'done'  => (bool)$company_filled,
            'title' => pw_t('Firmendaten vervollständigen', 'Complete your company data'),
            'text'  => pw_t('Ort und Telefonnummer helfen bei der Unternehmensprüfung und beim Umkreis-Matching.', 'City and phone number help with company verification and radius matching.'),
            'url'   => pw_page_url('account', ['tab' => 'profile']),
            'cta'   => pw_t('Daten ergänzen', 'Complete data'),
        ];
        $steps[] = [
            'done'  => $jobs > 0,
            'title' => pw_t('Ersten Personalbedarf veröffentlichen', 'Publish your first staffing need'),
            'text'  => pw_t('In drei Schritten ausgefüllt. Dein Firmenname bleibt anonym, bis du ihn selbst freigibst.', 'Filled in three steps. Your company name stays anonymous until you release it yourself.'),
            'url'   => pw_page_url('vacancies', ['new' => 1]),
            'cta'   => pw_t('Auftrag anlegen', 'Create job'),
        ];
    }

    $open = array_values(array_filter($steps, function ($s) { return empty($s['done']); }));
    if (!$open) return '';
    $done_count = count($steps) - count($open);

    ob_start(); ?>
    <section class="pw-card pw-onboarding-guide">
      <div class="pw-card-head">
        <div>
          <span class="pw-kicker"><?php echo esc_html(pw_t('ERSTE SCHRITTE', 'GETTING STARTED')); ?></span>
          <h2><?php echo esc_html(pw_t('In drei Schritten startklar', 'Ready in three steps')); ?></h2>
          <p class="pw-card-sub"><?php echo esc_html(sprintf(pw_t('%1$d von %2$d erledigt. Diese Hilfe verschwindet automatisch, sobald alles steht.', '%1$d of %2$d done. This guide disappears automatically once everything is set.'), $done_count, count($steps))); ?></p>
        </div>
      </div>
      <div class="pw-verification-steps pw-onboarding-steps">
        <?php foreach ($steps as $i => $step): ?>
          <div class="<?php echo !empty($step['done']) ? 'done' : 'active'; ?>">
            <i><?php echo !empty($step['done']) ? '✓' : (int)($i + 1); ?></i>
            <div>
              <b><?php echo esc_html($step['title']); ?></b>
              <span><?php echo esc_html($step['text']); ?></span>
              <?php if (empty($step['done'])): ?>
                <a class="pw-btn small ghost" href="<?php echo esc_url($step['url']); ?>"><?php echo esc_html($step['cta']); ?> <?php echo pw_icon('arrow'); ?></a>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

/* --------------------------------------------------------------------------
 * Operator warning when outgoing mail is broken
 * ----------------------------------------------------------------------- */
/**
 * Registration and password reset both depend on wp_mail(). If that fails the
 * portal looks broken to every visitor while the admin sees nothing, so we
 * surface it prominently in the WordPress backend.
 */
function pw_mail_health_notice() {
    if (!current_user_can('manage_options')) return;
    if (get_option('pw_last_mail_status', '') !== 'error') return;
    $error = (string)get_option('pw_last_mail_error', '');
    echo '<div class="notice notice-error"><p><strong>Pure Work: E-Mail-Versand fehlgeschlagen.</strong> '
       . 'Bestätigungs- und Passwort-Reset-Mails erreichen deine Nutzer aktuell nicht. '
       . '<a href="' . esc_url(admin_url('admin.php?page=pure-work&tab=settings')) . '">SMTP-Einstellungen prüfen</a>.'
       . ($error ? '<br><code>' . esc_html($error) . '</code>' : '')
       . '</p></div>';
}
add_action('admin_notices', 'pw_mail_health_notice');

/**
 * Keeps the pw_smtp_* option pairs in sync if an older screen or a migration
 * only wrote one of the two historical names.
 */
function pw_sync_smtp_option_aliases() {
    if (get_option('pw_smtp_alias_synced_493', '0') === '1') return;
    $user = trim((string)get_option('pw_smtp_username', '')) ?: trim((string)get_option('pw_smtp_user', ''));
    $pass = (string)get_option('pw_smtp_password', '') ?: (string)get_option('pw_smtp_pass', '');
    if ($user !== '') { update_option('pw_smtp_username', $user, false); update_option('pw_smtp_user', $user, false); }
    if ($pass !== '') { update_option('pw_smtp_password', $pass, false); update_option('pw_smtp_pass', $pass, false); }
    update_option('pw_smtp_alias_synced_493', '1', false);
}
add_action('init', 'pw_sync_smtp_option_aliases', 46);
