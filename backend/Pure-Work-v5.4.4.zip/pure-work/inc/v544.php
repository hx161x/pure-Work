<?php
if (!defined('ABSPATH')) exit;

/**
 * Pure Work 5.4.4
 * Built-in Pure Connect integration for Pure Office.
 * Compatible with Pure Office 1.0.0 handshake:
 *   POST /wp-json/pure-office/v1/handshake
 *   workspace_id + one-time code + remote_url
 */

function pw_v544_clean_office_url($url){
    $url = esc_url_raw(trim((string)$url));
    if (!$url || !preg_match('#^https?://#i', $url)) return '';
    return trailingslashit($url);
}

function pw_v544_connect_state($uid=0){
    $uid = $uid ?: get_current_user_id();
    if (!$uid) return ['connected'=>false];
    $tokenEnc = (string)pw_user_meta($uid,'pw_pure_connect_token','');
    return [
        'connected'    => pw_user_meta($uid,'pw_pure_connect_connected','0') === '1' && $tokenEnc !== '',
        'office_url'   => (string)pw_user_meta($uid,'pw_pure_office_url',''),
        'workspace_id' => (string)pw_user_meta($uid,'pw_pure_workspace_id',''),
        'company'      => (string)pw_user_meta($uid,'pw_pure_office_company',''),
        'connected_at' => (int)pw_user_meta($uid,'pw_pure_connect_connected_at',0),
        'last_checked' => (int)pw_user_meta($uid,'pw_pure_connect_last_checked',0),
        'last_status'  => (string)pw_user_meta($uid,'pw_pure_connect_last_status',''),
        'token'        => $tokenEnc ? (string)pw_decrypt_sensitive($tokenEnc) : '',
    ];
}

function pw_v544_connect_tabs($active='connect'){
    $role = pw_user_role();
    $tabs = [
        'profile'      => pw_t('Unternehmen','Company'),
        'verification' => pw_t('Verifizierung','Verification'),
    ];
    if ($role === 'agency') {
        $tabs['notifications'] = pw_t('Benachrichtigungen','Notifications');
        $tabs['billing'] = pw_t('Abo & Zahlung','Subscription & payment');
    }
    $tabs['connect'] = 'Pure Connect';
    $tabs['security'] = pw_t('Sicherheit','Security');
    $html='<nav class="pw-tabs">';
    foreach($tabs as $k=>$label){
        $html.='<a class="'.($active===$k?'active':'').'" href="'.esc_url(pw_page_url('account',['tab'=>$k])).'">'.esc_html($label).'</a>';
    }
    return $html.'</nav>';
}

function pw_v544_inject_connect_tab($html,$active){
    if (strpos($html,'class="pw-tabs"')===false || strpos($html,'tab=connect')!==false) return $html;
    $link='<a class="'.($active==='connect'?'active':'').'" href="'.esc_url(pw_page_url('account',['tab'=>'connect'])).'">Pure Connect</a>';
    return preg_replace('/(<nav class="pw-tabs">.*?)(<\/nav>)/s','$1'.$link.'$2',$html,1);
}

function pw_v544_pure_connect_panel($uid){
    $s = pw_v544_connect_state($uid);
    $company = pw_user_meta($uid,'pw_company',wp_get_current_user()->display_name);
    $flash = sanitize_key(wp_unslash($_GET['connect_state']??''));
    $error = get_transient('pw_v544_connect_error_'.$uid);
    if ($error) delete_transient('pw_v544_connect_error_'.$uid);
    ob_start();
    ?>
    <section class="pw544-connect-hero <?php echo $s['connected']?'is-connected':''; ?>">
      <div class="pw544-connect-copy">
        <span class="pw-kicker">PURE CONNECT</span>
        <h2><?php echo esc_html(pw_t('Pure Work + Pure Office. Ein Unternehmen.','Pure Work + Pure Office. One company.')); ?></h2>
        <p><?php echo esc_html(pw_t('Verknüpfe beide Schwesterprodukte über die Workspace-ID aus Pure Office. Danach teilen beide Systeme dieselbe Pure ID – ohne Konten zusammenzuwerfen.','Link both sister products with the Workspace ID from Pure Office. Both systems then share the same Pure ID without merging accounts.')); ?></p>
        <div class="pw544-connect-status <?php echo $s['connected']?'online':'offline'; ?>"><i></i><div><b><?php echo esc_html($s['connected']?pw_t('Pure Office verbunden','Pure Office connected'):pw_t('Noch nicht verbunden','Not connected yet')); ?></b><small><?php echo $s['connected']?esc_html(($s['company']?:'Pure Office').' · '.$s['workspace_id']):esc_html(pw_t('Die Kopplung dauert weniger als eine Minute.','Linking takes less than a minute.')); ?></small></div></div>
      </div>
      <div class="pw544-ecosystem-visual" aria-hidden="true">
        <div class="pw544-app work"><span>PW</span><div><small>PURE WORK</small><b><?php echo esc_html(pw_t('Personal','Staffing')); ?></b></div></div>
        <div class="pw544-link-line"><i></i><span><?php echo pw_icon('handshake'); ?></span><i></i></div>
        <div class="pw544-app office"><span>PO</span><div><small>PURE OFFICE</small><b><?php echo esc_html(pw_t('Büro','Office')); ?></b></div></div>
      </div>
    </section>

    <?php if($flash==='connected'): ?><div class="pw-alert success"><div><strong><?php echo esc_html(pw_t('Verbindung hergestellt','Connection established')); ?></strong><span><?php echo esc_html(pw_t('Pure Work und Pure Office kennen jetzt dieselbe Unternehmensidentität.','Pure Work and Pure Office now share the same company identity.')); ?></span></div></div><?php endif; ?>
    <?php if($flash==='checked'): ?><div class="pw-alert success"><div><strong><?php echo esc_html(pw_t('Verbindung geprüft','Connection checked')); ?></strong><span><?php echo esc_html(pw_t('Pure Office hat die Verbindung bestätigt.','Pure Office confirmed the connection.')); ?></span></div></div><?php endif; ?>
    <?php if($flash==='disconnected'): ?><div class="pw-alert info"><div><strong><?php echo esc_html(pw_t('Verbindung getrennt','Connection disconnected')); ?></strong><span><?php echo esc_html(pw_t('Die lokale Pure-Work-Verknüpfung wurde entfernt.','The local Pure Work link was removed.')); ?></span></div></div><?php endif; ?>
    <?php if($error): ?><div class="pw-alert danger"><div><strong><?php echo esc_html(pw_t('Pure Connect konnte nicht verbinden','Pure Connect could not connect')); ?></strong><span><?php echo esc_html($error); ?></span></div></div><?php endif; ?>

    <?php if(!$s['connected']): ?>
      <section class="pw544-connect-grid">
        <div class="pw544-connect-steps">
          <article><em>01</em><div><b><?php echo esc_html(pw_t('Pure Office öffnen','Open Pure Office')); ?></b><p><?php echo esc_html(pw_t('Gehe dort zu „Pure Connect“. Dort stehen Workspace-ID und einmaliger Verbindungscode.','Open “Pure Connect” there. You will find the Workspace ID and one-time connection code.')); ?></p></div></article>
          <article><em>02</em><div><b><?php echo esc_html(pw_t('Daten hier eintragen','Enter the details here')); ?></b><p><?php echo esc_html(pw_t('Pure Work prüft den Einmalcode direkt bei Pure Office.','Pure Work validates the one-time code directly with Pure Office.')); ?></p></div></article>
          <article><em>03</em><div><b><?php echo esc_html(pw_t('Fertig','Done')); ?></b><p><?php echo esc_html(pw_t('Der Code wird nach erfolgreicher Kopplung automatisch ungültig und Pure Work speichert nur das sichere Verbindungstoken.','The code is automatically invalidated after successful linking and Pure Work stores only the secure connection token.')); ?></p></div></article>
        </div>
        <form class="pw544-connect-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="pw_v544_connect_office"><?php wp_nonce_field('pw_v544_connect_office'); ?>
          <div class="pw544-form-head"><span><?php echo pw_icon('handshake'); ?></span><div><small>PURE OFFICE</small><h3><?php echo esc_html(pw_t('Workspace verknüpfen','Link workspace')); ?></h3></div></div>
          <label><?php echo esc_html(pw_t('Pure-Office-Adresse','Pure Office address')); ?><input type="url" name="office_url" placeholder="https://office.deine-domain.de/" required autocomplete="url"></label>
          <label><?php echo esc_html(pw_t('Workspace-ID','Workspace ID')); ?><input type="text" name="workspace_id" placeholder="PO-XXXX-XXXX" required autocomplete="off" inputmode="text" maxlength="24"></label>
          <label><?php echo esc_html(pw_t('Einmaliger Verbindungscode','One-time connection code')); ?><input type="text" name="code" placeholder="XXXXXXXX" required autocomplete="one-time-code" maxlength="32"></label>
          <button class="pw-btn primary full" type="submit"><?php echo pw_icon('handshake'); ?> <?php echo esc_html(pw_t('Mit Pure Office verbinden','Connect Pure Office')); ?></button>
          <small><?php echo esc_html(pw_t('Die Zugangsdaten deines Pure-Office-Kontos werden nicht an Pure Work übertragen.','Your Pure Office login credentials are never sent to Pure Work.')); ?></small>
        </form>
      </section>
    <?php else: ?>
      <section class="pw544-connected-workspace">
        <div class="pw544-id-card">
          <div class="pw544-id-top"><span class="pw544-id-mark">P</span><div><small><?php echo esc_html(pw_t('GEMEINSAME PURE ID','SHARED PURE ID')); ?></small><h3><?php echo esc_html($s['workspace_id']); ?></h3></div><span class="pw-badge success"><?php echo esc_html(pw_t('VERBUNDEN','CONNECTED')); ?></span></div>
          <p><?php echo esc_html(sprintf(pw_t('%s ist über diese ID mit Pure Office verknüpft.','%s is linked to Pure Office through this ID.'),$company)); ?></p>
          <div class="pw544-id-facts">
            <div><small><?php echo esc_html(pw_t('PURE OFFICE WORKSPACE','PURE OFFICE WORKSPACE')); ?></small><b><?php echo esc_html($s['company']?:'Pure Office'); ?></b></div>
            <div><small><?php echo esc_html(pw_t('VERBUNDEN SEIT','CONNECTED SINCE')); ?></small><b><?php echo $s['connected_at']?esc_html(wp_date('d.m.Y · H:i',$s['connected_at'])):'–'; ?></b></div>
            <div><small><?php echo esc_html(pw_t('LETZTER CHECK','LAST CHECK')); ?></small><b><?php echo $s['last_checked']?esc_html(wp_date('d.m.Y · H:i',$s['last_checked'])):esc_html(pw_t('bei Verbindung','on connection')); ?></b></div>
          </div>
          <div class="pw544-connect-actions">
            <a class="pw-btn primary" href="<?php echo esc_url($s['office_url']); ?>" target="_blank" rel="noopener"><?php echo pw_icon('arrow'); ?> <?php echo esc_html(pw_t('Pure Office öffnen','Open Pure Office')); ?></a>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_v544_check_office"><?php wp_nonce_field('pw_v544_check_office'); ?><button class="pw-btn ghost" type="submit"><?php echo pw_icon('check'); ?> <?php echo esc_html(pw_t('Verbindung prüfen','Check connection')); ?></button></form>
          </div>
        </div>
        <div class="pw544-capabilities">
          <span class="pw-kicker"><?php echo esc_html(pw_t('PURE ÖKOSYSTEM','PURE ECOSYSTEM')); ?></span>
          <h3><?php echo esc_html(pw_t('Die technische Brücke steht.','The technical bridge is ready.')); ?></h3>
          <p><?php echo esc_html(pw_t('Die Verbindung identifiziert beide Workspaces als dasselbe Unternehmen und bildet die sichere Grundlage für spätere gezielte Übergaben zwischen den Produkten.','The link identifies both workspaces as the same company and provides the secure foundation for future targeted handoffs between products.')); ?></p>
          <div class="pw544-cap-list"><span><?php echo pw_icon('building'); ?> <?php echo esc_html(pw_t('Unternehmensidentität','Company identity')); ?></span><span><?php echo pw_icon('bell'); ?> <?php echo esc_html(pw_t('Benachrichtigungen vorbereitet','Notifications ready')); ?></span><span><?php echo pw_icon('document'); ?> <?php echo esc_html(pw_t('Dokumentreferenzen vorbereitet','Document references ready')); ?></span><span><?php echo pw_icon('handshake'); ?> <?php echo esc_html(pw_t('Sichere Token-Verbindung','Secure token link')); ?></span></div>
        </div>
      </section>
      <details class="pw544-disconnect"><summary><?php echo esc_html(pw_t('Verbindung verwalten','Manage connection')); ?></summary><div><p><?php echo esc_html(pw_t('Beim Trennen werden Workspace-ID und Verbindungstoken aus diesem Pure-Work-Konto entfernt. Du kannst später jederzeit mit einem neuen Einmalcode erneut verbinden.','Disconnecting removes the Workspace ID and connection token from this Pure Work account. You can reconnect later with a new one-time code.')); ?></p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('<?php echo esc_js(pw_t('Pure Office wirklich trennen?','Disconnect Pure Office?')); ?>')"><input type="hidden" name="action" value="pw_v544_disconnect_office"><?php wp_nonce_field('pw_v544_disconnect_office'); ?><button class="pw-btn ghost small" type="submit"><?php echo esc_html(pw_t('Pure Office trennen','Disconnect Pure Office')); ?></button></form></div></details>
    <?php endif; ?>
    <?php
    return ob_get_clean();
}

function pw_shortcode_account_v544(){
    if(!is_user_logged_in()) return pw_require_login_html();
    $uid=get_current_user_id();
    $tab=sanitize_key($_GET['tab']??'profile');
    if($tab!=='connect'){
        $html = function_exists('pw_shortcode_account_v542') ? pw_shortcode_account_v542() : pw_shortcode_account();
        return pw_v544_inject_connect_tab($html,$tab);
    }
    ob_start();
    echo pw_portal_shell_start(pw_t('Konto & Einstellungen','Account & settings'),pw_t('Unternehmen, Zugang und verbundene Pure-Produkte verwalten.','Manage company, access and connected Pure products.'));
    echo pw_flash_messages();
    echo pw_v544_connect_tabs('connect');
    echo pw_v544_pure_connect_panel($uid);
    echo pw_portal_shell_end();
    return ob_get_clean();
}

function pw_v544_connect_error($uid,$message){
    set_transient('pw_v544_connect_error_'.$uid,wp_strip_all_tags((string)$message),90);
    wp_safe_redirect(pw_page_url('account',['tab'=>'connect','connect_state'=>'error']));exit;
}

function pw_handle_v544_connect_office(){
    if(!is_user_logged_in()) auth_redirect();
    check_admin_referer('pw_v544_connect_office');
    $uid=get_current_user_id();
    if(!in_array(pw_user_role($uid),['agency','client'],true) && !current_user_can('manage_options')) wp_die(esc_html(pw_t('Keine Berechtigung.','Not allowed.')));
    $office=pw_v544_clean_office_url(wp_unslash($_POST['office_url']??''));
    $workspace=strtoupper(sanitize_text_field(wp_unslash($_POST['workspace_id']??'')));
    $code=strtoupper(sanitize_text_field(wp_unslash($_POST['code']??'')));
    if(!$office) pw_v544_connect_error($uid,pw_t('Bitte eine gültige Pure-Office-Adresse eintragen.','Please enter a valid Pure Office address.'));
    if(!preg_match('/^PO-[A-Z0-9]{4}-[A-Z0-9]{4}$/',$workspace)) pw_v544_connect_error($uid,pw_t('Die Workspace-ID muss dem Format PO-XXXX-XXXX entsprechen.','The Workspace ID must use the format PO-XXXX-XXXX.'));
    if(strlen($code)<6) pw_v544_connect_error($uid,pw_t('Der Verbindungscode ist zu kurz.','The connection code is too short.'));
    $endpoint=$office.'wp-json/pure-office/v1/handshake';
    $response=wp_remote_post($endpoint,[
        'timeout'=>20,
        'redirection'=>2,
        'headers'=>['Accept'=>'application/json'],
        'body'=>['workspace_id'=>$workspace,'code'=>$code,'remote_url'=>home_url('/')],
    ]);
    if(is_wp_error($response)) pw_v544_connect_error($uid,pw_t('Pure Office ist nicht erreichbar: ','Pure Office is unavailable: ').$response->get_error_message());
    $http=(int)wp_remote_retrieve_response_code($response);
    $body=json_decode((string)wp_remote_retrieve_body($response),true);
    if($http<200||$http>=300||empty($body['ok'])||empty($body['token'])) pw_v544_connect_error($uid,$body['message']??sprintf(pw_t('Verbindung fehlgeschlagen (HTTP %d).','Connection failed (HTTP %d).'),$http));
    $token=pw_encrypt_sensitive(sanitize_text_field((string)$body['token']));
    if(!$token) pw_v544_connect_error($uid,pw_t('Das Verbindungstoken konnte nicht sicher gespeichert werden.','The connection token could not be stored securely.'));
    update_user_meta($uid,'pw_pure_connect_connected','1');
    update_user_meta($uid,'pw_pure_office_url',$office);
    update_user_meta($uid,'pw_pure_workspace_id',sanitize_text_field((string)($body['workspace_id']??$workspace)));
    update_user_meta($uid,'pw_pure_office_company',sanitize_text_field((string)($body['company']??'Pure Office')));
    update_user_meta($uid,'pw_pure_connect_token',$token);
    update_user_meta($uid,'pw_pure_connect_connected_at',time());
    update_user_meta($uid,'pw_pure_connect_last_checked',time());
    update_user_meta($uid,'pw_pure_connect_last_status','online');
    if(function_exists('pw_audit_event')) pw_audit_event('pure_connect_linked',$uid,'user',$uid,'Pure Office Workspace '.$workspace.' verbunden');
    wp_safe_redirect(pw_page_url('account',['tab'=>'connect','connect_state'=>'connected']));exit;
}
add_action('admin_post_pw_v544_connect_office','pw_handle_v544_connect_office');

function pw_handle_v544_check_office(){
    if(!is_user_logged_in()) auth_redirect();
    check_admin_referer('pw_v544_check_office');
    $uid=get_current_user_id();$s=pw_v544_connect_state($uid);
    if(empty($s['connected'])||empty($s['office_url'])||empty($s['workspace_id'])||empty($s['token'])) pw_v544_connect_error($uid,pw_t('Es besteht noch keine vollständige Pure-Office-Verbindung.','There is no complete Pure Office connection yet.'));
    $endpoint=$s['office_url'].'wp-json/pure-office/v1/status?workspace_id='.rawurlencode($s['workspace_id']);
    $response=wp_remote_get($endpoint,['timeout'=>15,'redirection'=>2,'headers'=>['Accept'=>'application/json','X-Pure-Token'=>$s['token']]]);
    if(is_wp_error($response)) {update_user_meta($uid,'pw_pure_connect_last_status','offline');pw_v544_connect_error($uid,pw_t('Pure Office ist derzeit nicht erreichbar: ','Pure Office is currently unavailable: ').$response->get_error_message());}
    $http=(int)wp_remote_retrieve_response_code($response);$body=json_decode((string)wp_remote_retrieve_body($response),true);
    if($http<200||$http>=300||empty($body['ok'])) {update_user_meta($uid,'pw_pure_connect_last_status','offline');pw_v544_connect_error($uid,pw_t('Pure Office hat das Verbindungstoken nicht bestätigt. Verbinde die Workspaces bei Bedarf erneut.','Pure Office did not confirm the connection token. Reconnect the workspaces if needed.'));}
    update_user_meta($uid,'pw_pure_connect_last_checked',time());update_user_meta($uid,'pw_pure_connect_last_status','online');
    wp_safe_redirect(pw_page_url('account',['tab'=>'connect','connect_state'=>'checked']));exit;
}
add_action('admin_post_pw_v544_check_office','pw_handle_v544_check_office');

function pw_handle_v544_disconnect_office(){
    if(!is_user_logged_in()) auth_redirect();
    check_admin_referer('pw_v544_disconnect_office');
    $uid=get_current_user_id();
    foreach(['pw_pure_connect_connected','pw_pure_office_url','pw_pure_workspace_id','pw_pure_office_company','pw_pure_connect_token','pw_pure_connect_connected_at','pw_pure_connect_last_checked','pw_pure_connect_last_status'] as $key) delete_user_meta($uid,$key);
    if(function_exists('pw_audit_event')) pw_audit_event('pure_connect_unlinked',$uid,'user',$uid,'Pure Office Verbindung getrennt');
    wp_safe_redirect(pw_page_url('account',['tab'=>'connect','connect_state'=>'disconnected']));exit;
}
add_action('admin_post_pw_v544_disconnect_office','pw_handle_v544_disconnect_office');

/**
 * Counterpart status endpoint for future Pure Office -> Pure Work handoffs.
 * Uses the token returned by Pure Office during the handshake and stored per company.
 */
function pw_v544_register_connect_api(){
    if(function_exists('pcb_status')) return; // keep compatibility when the historical bridge plugin is active
    register_rest_route('pure-connect/v1','/status',['methods'=>'GET','callback'=>'pw_v544_rest_connect_status','permission_callback'=>'__return_true']);
}
add_action('rest_api_init','pw_v544_register_connect_api');
function pw_v544_rest_connect_status(WP_REST_Request $r){
    $workspace=strtoupper(sanitize_text_field((string)$r->get_param('workspace_id')));$token=(string)$r->get_header('x-pure-token');
    if(!$workspace||!$token) return new WP_REST_Response(['ok'=>false],403);
    $users=get_users(['meta_key'=>'pw_pure_workspace_id','meta_value'=>$workspace,'number'=>5]);
    foreach($users as $u){$s=pw_v544_connect_state($u->ID);if(!empty($s['connected'])&&!empty($s['token'])&&hash_equals($s['token'],$token))return ['ok'=>true,'product'=>'pure-work','version'=>PW_VERSION,'workspace_id'=>$workspace,'company'=>pw_user_meta($u->ID,'pw_company',$u->display_name),'site'=>home_url('/'),'time'=>time()];}
    return new WP_REST_Response(['ok'=>false],403);
}

function pw_v544_register(){remove_shortcode('pw_account');add_shortcode('pw_account','pw_shortcode_account_v544');}
add_action('init','pw_v544_register',5440);
