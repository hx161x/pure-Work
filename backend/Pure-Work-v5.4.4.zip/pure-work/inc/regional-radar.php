<?php
if (!defined('ABSPATH')) exit;

/** Pure Work 4.9.2 – Rhein-Neckar buyer intelligence. */

function pw_regional_staffing_signals_path(){
    return PW_DIR.'/assets/data/regional_staffing_signals_2026-08-16.csv';
}
function pw_regional_account_catalog_491(){
    return [
        'roche'=>['company'=>'Roche Diagnostics GmbH','aliases'=>['roche diagnostics','roche mannheim'],'city'=>'Mannheim','region'=>'Rhein-Neckar','sector'=>'Pharma / Diagnostics','contact_role'=>'Supplier Enquiries','contact_url'=>'https://www.roche.com/contact','scope'=>'supplier_portal','quality'=>91],
        'daimler'=>['company'=>'Daimler Truck AG','aliases'=>['daimler truck'],'city'=>'Mannheim','region'=>'Rhein-Neckar','sector'=>'Automotive / Nutzfahrzeuge','contact_role'=>'Global Procurement / Supplier Portal','contact_url'=>'https://www.daimlertruck.com/en/supplier-portal','scope'=>'supplier_portal','quality'=>91],
        'basf'=>['company'=>'BASF SE','aliases'=>['basf se','basf ludwigshafen'],'city'=>'Ludwigshafen am Rhein','region'=>'Rhein-Neckar','sector'=>'Chemie','contact_role'=>'BASF Procurement / externe Dienstleistungen','contact_url'=>'https://www.procurement.basf.com/','scope'=>'supplier_portal','quality'=>92],
        'fuchs'=>['company'=>'FUCHS LUBRICANTS GERMANY GmbH','aliases'=>['fuchs lubricants','fuchs lubricant'],'city'=>'Mannheim','region'=>'Rhein-Neckar','sector'=>'Chemie / Schmierstoffe','contact_role'=>'Öffentlicher Unternehmenskontakt','contact_url'=>'https://www.fuchs.com/de/de/kontakt/','email'=>'zentrale-flg@fuchs.com','phone'=>'+49 621 3701-0','scope'=>'general_business','quality'=>88],
        'deere'=>['company'=>'John Deere GmbH & Co. KG','aliases'=>['john deere'],'city'=>'Mannheim','region'=>'Rhein-Neckar','sector'=>'Maschinenbau / Landtechnik','contact_role'=>'John Deere Supply Network','contact_url'=>'https://jdsn.deere.com/prospective-suppliers','scope'=>'supplier_portal','quality'=>94],
        'mvv'=>['company'=>'MVV Energie AG','aliases'=>['mvv energie'],'city'=>'Mannheim','region'=>'Rhein-Neckar','sector'=>'Energie','contact_role'=>'Zentraleinkauf / eSourcing','contact_url'=>'https://www.mvv.de/partner/lieferanten/zentraleinkauf/esourcing','scope'=>'supplier_portal','quality'=>91],
        'eisenstahl'=>['company'=>'EISEN + STAHL Service Center GmbH','aliases'=>['eisen+stahl service center','eisen stahl service center'],'city'=>'Mannheim','region'=>'Rhein-Neckar','sector'=>'Stahl / Logistik','contact_role'=>'Offizieller Unternehmenskontakt','contact_url'=>'https://eisen-stahl.de/','scope'=>'general_business','quality'=>86],
        'abb'=>['company'=>'ABB AG','aliases'=>['abb ag','abb mannheim'],'city'=>'Mannheim','region'=>'Rhein-Neckar','sector'=>'Elektrotechnik / Automation','contact_role'=>'Supplier / Procurement','contact_url'=>'https://www.abb.com/global/en/company/about/supplying','scope'=>'supplier_portal','quality'=>86],
        'hitachi'=>['company'=>'Hitachi Energy Germany AG','aliases'=>['hitachi energy'],'city'=>'Mannheim','region'=>'Rhein-Neckar','sector'=>'Energietechnik','contact_role'=>'Supplier / Procurement','contact_url'=>'https://www.hitachienergy.com/company/supplying','scope'=>'supplier_portal','quality'=>86],
        'siemens'=>['company'=>'Siemens AG / Siemens Mobility','aliases'=>['siemens ag','siemens mobility'],'city'=>'Mannheim / Region','region'=>'Rhein-Neckar','sector'=>'Industrie / Mobilität','contact_role'=>'Supplier / Procurement','contact_url'=>'https://www.siemens.com/de-de/company/about/supply-chain-management/siemens-collaboration/','scope'=>'supplier_portal','quality'=>84],
        'pepperl'=>['company'=>'Pepperl+Fuchs Gruppe','aliases'=>['pepperl+fuchs','pepperl fuchs'],'city'=>'Mannheim','region'=>'Rhein-Neckar','sector'=>'Automation / Sensorik','contact_role'=>'Öffentlicher Unternehmenskontakt','contact_url'=>'https://www.pepperl-fuchs.com/global/en/contact.htm','scope'=>'general_business','quality'=>82],
        'heidelbergmaterials'=>['company'=>'Heidelberg Materials AG','aliases'=>['heidelberg materials'],'city'=>'Heidelberg','region'=>'Rhein-Neckar','sector'=>'Baustoffe','contact_role'=>'Öffentlicher Unternehmenskontakt','contact_url'=>'https://www.heidelbergmaterials.com/','scope'=>'general_business','quality'=>80],
        'freudenberg'=>['company'=>'Freudenberg Group','aliases'=>['freudenberg group','freudenberg'],'city'=>'Weinheim','region'=>'Rhein-Neckar','sector'=>'Industrie / Technologie','contact_role'=>'Öffentlicher Unternehmenskontakt','contact_url'=>'https://www.freudenberg.com/en','scope'=>'general_business','quality'=>80],
    ];
}

/**
 * Lightweight regional live enrichment from the official BA Jobsuche feed.
 * It deliberately does NOT turn every agency job into a buyer. A signal is
 * added only when the published title/employer explicitly names one of the
 * regional customer accounts in our verified company catalogue.
 */
function pw_regional_live_au_signals_491(){
    $cached=get_transient('pw_regional_au_live_491');
    if(is_array($cached)) return $cached;
    if(!function_exists('pw_live_market_fetch')) return [];
    $catalog=pw_regional_account_catalog_491();$out=[];$seen=[];
    foreach(['Mannheim','Ludwigshafen am Rhein','Heidelberg'] as $where){
        $feed=pw_live_market_fetch('', $where, 30, 50, 1, true);
        foreach((array)($feed['items']??[]) as $item){
            $ref=(string)($item['ref']??'');
            if($ref && isset($seen[$ref])) continue;
            if($ref)$seen[$ref]=1;
            $hay=pw_normalize_text((string)($item['title']??'').' '.(string)($item['employer']??''));
            foreach($catalog as $key=>$a){
                $matched=false;
                foreach($a['aliases'] as $alias){if(pw_contains($hay,pw_normalize_text($alias))){$matched=true;break;}}
                if(!$matched)continue;
                $id='PWLIVE-'.strtoupper(substr(md5($key.'|'.$ref.'|'.($item['title']??'')),0,14));
                $out[$id]=[
                    'signal_id'=>$id,'company'=>$a['company'],'city'=>($item['place']??'')?:$a['city'],'region'=>$a['region'],
                    'role'=>sanitize_text_field($item['title']??'Aktueller AÜ-Bedarf'),'published'=>sanitize_text_field($item['published']??''),
                    'signal_type'=>'live_au_job','evidence_source'=>!empty($item['snapshot'])?'BA Jobsuche · datierter Marktsnapshot':'Bundesagentur für Arbeit · Live-AÜ-Signal',
                    'evidence_url'=>esc_url_raw($item['url']??''),'official_contact_name'=>'','official_contact_role'=>$a['contact_role'],
                    'official_email'=>$a['email']??'','official_phone'=>$a['phone']??'','official_contact_url'=>$a['contact_url'],
                    'contact_scope'=>$a['scope'],'verified_at'=>wp_date('Y-m-d'),'quality'=>(string)$a['quality'],'sector'=>$a['sector'],
                    'summary'=>'Aktuelles öffentliches Arbeitnehmerüberlassungs-Signal, in dem der regionale Kunden-/Einsatzbetrieb namentlich erkennbar ist. Der Kontaktkanal ist separat nach seiner tatsächlichen Qualität gekennzeichnet.',
                    'status'=>'current'
                ];
                break;
            }
        }
    }
    set_transient('pw_regional_au_live_491',$out,30*MINUTE_IN_SECONDS);
    return $out;
}

function pw_regional_staffing_signals(){
    static $rows=null;
    if($rows!==null) return $rows;
    $rows=[];$path=pw_regional_staffing_signals_path();
    if(is_readable($path)){
        $h=fopen($path,'r');
        if($h){
            $headers=fgetcsv($h,0,';');
            if($headers){
                $headers=array_map('trim',$headers);
                while(($r=fgetcsv($h,0,';'))!==false){
                    if(!array_filter($r,'strlen')) continue;
                    $r=array_pad($r,count($headers),'');$item=[];
                    foreach($headers as $i=>$k)$item[$k]=isset($r[$i])?trim($r[$i]):'';
                    if(!empty($item['signal_id']))$rows[$item['signal_id']]=$item;
                }
            }
            fclose($h);
        }
    }
    foreach(pw_regional_live_au_signals_491() as $id=>$item){if(!isset($rows[$id]))$rows[$id]=$item;}
    return $rows;
}
function pw_regional_account_key($company){return 'pwa-'.substr(md5(pw_normalize_text($company)),0,12);}
function pw_regional_staffing_accounts($args=[]){
    $q=pw_normalize_text((string)($args['q']??''));
    $where=pw_normalize_text((string)($args['where']??''));
    $sector=pw_normalize_text((string)($args['sector']??''));
    $status=sanitize_key((string)($args['status']??'current'));
    $accounts=[];
    foreach(pw_regional_staffing_signals() as $s){
        if($status && $status!=='all' && ($s['status']??'')!==$status) continue;
        $company=$s['company']??''; if(!$company)continue;
        $key=pw_regional_account_key($company);
        if(!isset($accounts[$key]))$accounts[$key]=[
            'account_key'=>$key,'company'=>$company,'city'=>$s['city']??'','region'=>$s['region']??'','sector'=>$s['sector']??'',
            'quality'=>(int)($s['quality']??0),'contact_name'=>$s['official_contact_name']??'','contact_role'=>$s['official_contact_role']??'',
            'email'=>$s['official_email']??'','phone'=>$s['official_phone']??'','contact_url'=>$s['official_contact_url']??'',
            'contact_scope'=>$s['contact_scope']??'supplier_portal','verified_at'=>$s['verified_at']??'','summary'=>$s['summary']??'',
            'signals'=>[],'status'=>$s['status']??'current'
        ];
        $a=&$accounts[$key];
        $a['signals'][]=$s;
        $a['quality']=max($a['quality'],(int)($s['quality']??0));
        foreach(['contact_name'=>'official_contact_name','contact_role'=>'official_contact_role','email'=>'official_email','phone'=>'official_phone','contact_url'=>'official_contact_url'] as $out=>$in){
            if(!$a[$out]&&!empty($s[$in]))$a[$out]=$s[$in];
        }
        if(($s['contact_scope']??'')==='direct_buyer')$a['contact_scope']='direct_buyer';
        elseif($a['contact_scope']!=='direct_buyer'&&($s['contact_scope']??'')==='procurement_contact')$a['contact_scope']='procurement_contact';
        unset($a);
    }
    foreach($accounts as $key=>$a){
        $roles=implode(' ',array_map(function($s){return $s['role']??'';},$a['signals']));
        $hay=pw_normalize_text($a['company'].' '.$a['city'].' '.$a['region'].' '.$a['sector'].' '.$roles.' '.$a['summary']);
        if($q&&!pw_contains($hay,$q)){unset($accounts[$key]);continue;}
        if($where&&!pw_contains(pw_normalize_text($a['city'].' '.$a['region']),$where)){unset($accounts[$key]);continue;}
        if($sector&&!pw_contains(pw_normalize_text($a['sector']),$sector)){unset($accounts[$key]);continue;}
    }
    uasort($accounts,function($a,$b){
        $aLocal=(stripos($a['region'],'Rhein-Neckar')!==false||stripos($a['city'],'Mannheim')!==false)?1:0;
        $bLocal=(stripos($b['region'],'Rhein-Neckar')!==false||stripos($b['city'],'Mannheim')!==false)?1:0;
        if($aLocal!==$bLocal)return $bLocal<=>$aLocal;
        if(count($a['signals'])!==count($b['signals']))return count($b['signals'])<=>count($a['signals']);
        return $b['quality']<=>$a['quality'];
    });
    return $accounts;
}
function pw_regional_account_get($key){$a=pw_regional_staffing_accounts(['status'=>'all']);return $a[$key]??null;}
function pw_regional_scope_label($scope){
    if($scope==='direct_buyer')return [pw_t('Direkter AÜ-/Vergabekontakt','Direct staffing/procurement contact'),'direct'];
    if($scope==='procurement_contact')return [pw_t('Öffentlicher Procurement-Kontakt','Public procurement contact'),'procurement'];
    if($scope==='supplier_portal')return [pw_t('Offizieller Supplier-/Procurement-Kanal','Official supplier/procurement channel'),'portal'];
    return [pw_t('Öffentlicher Unternehmenskontakt','Public company contact'),'general'];
}
function pw_regional_account_card($a){
    $scope=pw_regional_scope_label($a['contact_scope']??'');
    $signals=$a['signals']??[];$roles=[];$sources=[];
    foreach($signals as $s){if(!empty($s['role']))$roles[$s['role']]=$s['role'];if(!empty($s['evidence_url']))$sources[]=$s;}
    $roles=array_slice(array_values($roles),0,8);$sources=array_slice($sources,0,3);
    $email=sanitize_email($a['email']??'');$phone=sanitize_text_field($a['phone']??'');$contactUrl=esc_url($a['contact_url']??'');
    $subject='Pure Work – Arbeitnehmerüberlassung / Personalbedarf';
    $body="Guten Tag,\n\nwir sind Personaldienstleister und sehen in Ihrer Organisation aktuelle Signale für Arbeitnehmerüberlassung. Gerne würden wir prüfen, ob wir Sie mit passenden Mitarbeitenden unterstützen können.\n\nFreundliche Grüße";
    ob_start();?>
    <article class="pw-account-card">
      <div class="pw-account-head"><span class="pw-company-logo small"><?php echo esc_html(pw_initials($a['company']));?></span><div><h3><?php echo esc_html($a['company']);?></h3><p><?php echo esc_html($a['city'].($a['sector']?' · '.$a['sector']:''));?></p></div><span class="pw-signal-count"><b><?php echo count($signals);?></b><?php echo pw_t('Signale','signals');?></span></div>
      <div class="pw-contact-scope pw-scope-<?php echo esc_attr($scope[1]);?>"><i></i><span><?php echo esc_html($scope[0]);?></span><b><?php echo (int)$a['quality'];?>%</b></div>
      <div class="pw-signal-chips"><?php foreach($roles as $role):?><span><?php echo esc_html($role);?></span><?php endforeach;?></div>
      <p class="pw-account-summary"><?php echo esc_html($a['summary']);?></p>
      <div class="pw-account-contact">
        <?php if(!empty($a['contact_name'])):?><b><?php echo esc_html($a['contact_name']);?></b><?php endif;?>
        <?php if(!empty($a['contact_role'])):?><span><?php echo esc_html($a['contact_role']);?></span><?php endif;?>
        <div><?php if($email):?><a href="mailto:<?php echo esc_attr($email);?>?subject=<?php echo rawurlencode($subject);?>&body=<?php echo rawurlencode($body);?>"><?php echo pw_icon('message');?><?php echo esc_html($email);?></a><?php endif;?><?php if($phone):?><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone));?>"><?php echo pw_icon('phone');?><?php echo esc_html($phone);?></a><?php endif;?></div>
        <?php if(!$email&&!$phone&&$contactUrl):?><small><?php echo pw_t('Kein namentlicher AÜ-Einkäufer öffentlich veröffentlicht. Nutze den offiziellen Lieferanten-/Beschaffungskanal.','No named staffing buyer is publicly published. Use the official supplier/procurement channel.');?></small><?php endif;?>
      </div>
      <div class="pw-source-proof"><span>✓ <?php echo pw_t('AÜ-Nutzung/Bedarf öffentlich belegt','Public staffing use/demand verified');?></span><small><?php echo pw_t('Geprüft','Checked');?> <?php echo esc_html(pw_format_date($a['verified_at']));?></small></div>
      <details class="pw-account-evidence"><summary><?php echo count($signals);?> <?php echo pw_t('Nachweise & aktuelle Bedarfe','evidence & current demand');?></summary><div><?php foreach($sources as $s):?><a href="<?php echo esc_url($s['evidence_url']);?>" target="_blank" rel="noopener noreferrer"><b><?php echo esc_html($s['role']);?></b><span><?php echo esc_html($s['evidence_source']);?></span></a><?php endforeach;?></div></details>
      <div class="pw-direct-actions">
        <?php if(pw_user_role()==='agency'||current_user_can('manage_options')):?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="pw_staffing_account_capture"><input type="hidden" name="account_key" value="<?php echo esc_attr($a['account_key']);?>"><?php wp_nonce_field('pw_staffing_account_capture');?><button class="pw-btn primary small" type="submit"><?php echo pw_icon('briefcase');?> <?php echo pw_t('Ins CRM übernehmen','Add to CRM');?></button></form><?php endif;?>
        <?php if($email):?><a class="pw-btn ghost small" href="mailto:<?php echo esc_attr($email);?>?subject=<?php echo rawurlencode($subject);?>&body=<?php echo rawurlencode($body);?>"><?php echo pw_t('Direkt mailen','Email now');?></a><?php elseif($contactUrl):?><a class="pw-btn ghost small" href="<?php echo esc_url($contactUrl);?>" target="_blank" rel="noopener noreferrer"><?php echo pw_t('Supplier-Kanal öffnen','Open supplier channel');?> <?php echo pw_icon('arrow');?></a><?php endif;?>
      </div>
    </article>
    <?php return ob_get_clean();
}
function pw_market_radar_stats(){
    $current=pw_regional_staffing_accounts(['status'=>'current']);$history=pw_regional_staffing_accounts(['status'=>'history']);$watch=pw_regional_staffing_accounts(['status'=>'watch']);
    return ['accounts'=>count($current),'signals'=>array_sum(array_map(function($a){return count($a['signals']);},$current)),'history'=>count($history)+count($watch)];
}

function pw_shortcode_market_radar_492(){
    if(!is_user_logged_in())return pw_require_login_html();
    $uid=get_current_user_id();$role=pw_user_role($uid);
    ob_start();echo pw_portal_shell_start(pw_t('Direkt-Leads & AÜ-Radar','Direct leads & staffing radar'),pw_t('Offizielle Vergaben plus verifizierte AÜ-Nutzer in Rhein-Neckar','Official procurements plus verified staffing users in Rhine-Neckar'));echo pw_flash_messages();
    if($role!=='agency'&&!current_user_can('manage_options')){echo '<section class="pw-card pw-direct-client-info"><span class="pw-kicker">AÜ-RADAR</span><h2>'.esc_html(pw_t('Vertriebsbereich für Personaldienstleister','Sales area for staffing agencies')).'</h2><p>'.esc_html(pw_t('Auftraggeber verwalten ihre eigenen Ausschreibungen unter „Aufträge“.','Clients manage their own jobs under “Jobs”.')).'</p></section>';echo pw_portal_shell_end();return ob_get_clean();}
    $gate=current_user_can('manage_options')?'':pw_verified_gate(pw_t('AÜ-Radar öffnen','Open staffing radar'));if($gate){echo $gate;echo pw_portal_shell_end();return ob_get_clean();}
    $tab=sanitize_key($_GET['radar']??'local');if(!in_array($tab,['local','direct','regional','history'],true))$tab='local';
    $q=sanitize_text_field(wp_unslash($_GET['q']??''));$where=sanitize_text_field(wp_unslash($_GET['where']??''));$sector=sanitize_text_field(wp_unslash($_GET['sector']??''));
    $dstats=pw_direct_leads_stats(array_values(pw_direct_leads_all()));$rstats=pw_market_radar_stats();$lstats=pw_local_direct_contacts_stats_492();$sync=pw_ted_staffing_sync_status();
    ?>
    <section class="pw-radar-hero"><div><span class="pw-kicker">PURE WORK · RHEIN-NECKAR</span><h2><?php echo pw_t('148 direkte Arbeitgeberkontakte. Ein Klick bis zum Telefon.','148 direct employer contacts. One tap to the phone.');?></h2><p><?php echo pw_t('Mannheim steht zuerst: Handel, Möbel, Lager, Logistik, Industrie, Chemie, Gesundheit, Hotels und weitere personalintensive Arbeitgeber. AÜ-Nachweise und aktuelle Recruiting-Signale werden separat markiert, damit aus einem Kontakt keine erfundene Nachfrage wird.','Mannheim comes first: retail, furniture, warehousing, logistics, industry, chemicals, healthcare, hotels and other staffing-intensive employers. Staffing evidence and current hiring signals are labelled separately so a contact is never misrepresented as demand.');?></p></div><div class="pw-radar-orb"><b>LIVE</b><span></span><i></i></div></section>
    <div class="pw-radar-overview"><div><b><?php echo (int)$lstats['total'];?></b><span><?php echo pw_t('Direktkontakte Rhein-Neckar','Rhine-Neckar direct contacts');?></span></div><div><b><?php echo (int)$lstats['mannheim'];?></b><span><?php echo pw_t('davon Mannheim','in Mannheim');?></span></div><div><b><?php echo (int)$lstats['phone'];?></b><span><?php echo pw_t('mit öffentlicher Telefonnummer','with public phone');?></span></div><div><b><?php echo (int)$dstats['total'];?></b><span><?php echo pw_t('offene AÜ-Vergaben','open staffing procurements');?></span></div></div>
    <nav class="pw-radar-tabs"><a class="<?php echo $tab==='local'?'active':'';?>" href="<?php echo esc_url(add_query_arg('radar','local',pw_page_url('market_live')));?>"><?php echo pw_t('Direktkontakte Rhein-Neckar','Rhine-Neckar contacts');?></a><a class="<?php echo $tab==='regional'?'active':'';?>" href="<?php echo esc_url(add_query_arg('radar','regional',pw_page_url('market_live')));?>"><?php echo pw_t('AÜ bestätigt','Staffing confirmed');?></a><a class="<?php echo $tab==='direct'?'active':'';?>" href="<?php echo esc_url(add_query_arg('radar','direct',pw_page_url('market_live')));?>"><?php echo pw_t('Offene AÜ-Vergaben','Open staffing procurements');?></a><a class="<?php echo $tab==='history'?'active':'';?>" href="<?php echo esc_url(add_query_arg('radar','history',pw_page_url('market_live')));?>"><?php echo pw_t('Watchlist','Watchlist');?></a></nav>
    <form class="pw-direct-filter pw-radar-filter" method="get"><input type="hidden" name="radar" value="<?php echo esc_attr($tab);?>"><label><?php echo pw_icon('search');?><input name="q" value="<?php echo esc_attr($q);?>" placeholder="<?php echo esc_attr(pw_t('Tätigkeit, Unternehmen, Skill…','Role, company, skill…'));?>"></label><label><?php echo pw_icon('map');?><input name="where" value="<?php echo esc_attr($where);?>" placeholder="<?php echo esc_attr(pw_t('Mannheim, Ludwigshafen, Heidelberg…','Mannheim, Ludwigshafen, Heidelberg…'));?>"></label><label><input name="sector" value="<?php echo esc_attr($sector);?>" placeholder="<?php echo esc_attr(pw_t('Branche','Sector'));?>"></label><?php if($tab==='local'):?><label class="pw-radar-select"><select name="proof"><option value=""><?php echo pw_t('Alle Qualitätsstufen','All quality levels');?></option><option value="confirmed" <?php selected($_GET['proof']??'','confirmed');?>><?php echo pw_t('AÜ/ANÜ belegt','Staffing evidenced');?></option><option value="live" <?php selected($_GET['proof']??'','live');?>><?php echo pw_t('Aktuelles Recruiting-Signal','Current hiring signal');?></option></select></label><?php endif;?><button class="pw-btn primary" type="submit"><?php echo pw_t('Radar filtern','Filter radar');?></button></form>
    <?php if($tab==='local'):
        $proof=sanitize_key($_GET['proof']??'');$contacts=pw_local_direct_contacts_search_492(['q'=>$q,'where'=>$where,'sector'=>$sector,'proof'=>$proof]);?>
        <div class="pw-radar-explainer"><b><?php echo pw_t('Direkt nutzbar – sauber gekennzeichnet','Ready to use — clearly labelled');?></b><p><?php echo pw_t('Diese Ebene enthält geprüfte öffentliche Geschäftskontakte aus Mannheim und der Metropolregion. „AÜ/ANÜ belegt“ wird nur gezeigt, wenn dafür ein öffentlicher Nachweis vorhanden ist. Alle anderen Kontakte sind als Arbeitgeber-/Standortkontakte gekennzeichnet und werden nicht als bestätigte Zeitarbeitsnutzer ausgegeben.','This layer contains checked public business contacts from Mannheim and the metro region. “Staffing evidenced” only appears where public evidence exists. Other entries are labelled employer/location contacts and are not presented as confirmed staffing buyers.');?></p></div>
        <div class="pw-direct-result-head"><div><b><?php echo count($contacts);?></b><span><?php echo pw_t('passende Direktkontakte','matching direct contacts');?></span></div><small><?php echo pw_t('Telefon, E-Mail, CRM und aktuelle Recruiting-Signale wo verfügbar.','Phone, email, CRM and current hiring signals where available.');?></small></div><div class="pw-local-contact-grid"><?php if(!$contacts):?><div class="pw-card pw-empty span-all"><h3><?php echo pw_t('Keine Kontakte für diesen Filter','No contacts for this filter');?></h3></div><?php else:foreach($contacts as $c)echo pw_local_direct_contact_card_492($c);endif;?></div>
    <?php elseif($tab==='direct'):
        $leads=pw_direct_lead_search(['q'=>$q,'where'=>$where,'sector'=>$sector]);?>
        <div class="pw-live-sync"><div><i></i><b><?php echo pw_t('Offizieller TED-Sync','Official TED sync');?></b><span><?php echo !empty($sync['last_sync'])?esc_html(pw_format_date(substr($sync['last_sync'],0,10))):pw_t('wartet auf ersten Server-Sync','waiting for first server sync');?></span></div><p><?php echo pw_t('Pure Work prüft täglich die offene TED-Beschaffung nach Personaldienstleistungs-/AÜ-CPV-Codes. Ein Treffer wird erst als Direkt-Lead gezeigt, wenn im veröffentlichten Vergabedokument eine geschäftliche Kontaktstelle gefunden wurde.','Pure Work checks open TED procurement daily for staffing CPV codes. A result is only shown as a direct lead once a business contact is found in the published notice.');?></p></div>
        <div class="pw-direct-result-head"><div><b><?php echo count($leads);?></b><span><?php echo pw_t('passende aktive Vergaben','matching active procurements');?></span></div><small><?php echo pw_t('Keine allgemeinen Jobanzeigen in dieser Ebene.','No generic job ads in this layer.');?></small></div><div class="pw-direct-grid"><?php if(!$leads):?><div class="pw-card pw-empty span-all"><h3><?php echo pw_t('Keine aktive Direktvergabe für diesen Filter','No active direct procurement for this filter');?></h3><p><?php echo pw_t('Wechsle zum AÜ-Nutzer-Radar für aktuell belegte Nachfrage in der Region.','Switch to the staffing-user radar for current verified demand in the region.');?></p></div><?php else:foreach($leads as $l)echo pw_direct_lead_card($l);endif;?></div>
    <?php elseif($tab==='regional'):
        $accounts=pw_regional_staffing_accounts(['q'=>$q,'where'=>$where,'sector'=>$sector,'status'=>'current']);?>
        <div class="pw-radar-explainer"><b><?php echo pw_t('Qualitätsregel','Quality rule');?></b><p><?php echo pw_t('„AÜ-Nutzer“ bedeutet hier: Ein aktueller öffentlicher Nachweis nennt das Unternehmen als Einsatz-/Kundenbetrieb einer Arbeitnehmerüberlassung oder es gibt eine aktive AÜ-Beschaffung. Ein allgemeiner Supplier-Kanal wird niemals als „Leiter Zeitarbeit“ ausgegeben.','“Staffing user” here means: current public evidence names the company as the host/client of temporary staffing or there is an active staffing procurement. A generic supplier channel is never presented as the “head of temp staffing”.');?></p></div>
        <div class="pw-direct-result-head"><div><b><?php echo count($accounts);?></b><span><?php echo pw_t('qualifizierte regionale Accounts','qualified regional accounts');?></span></div><small><?php echo pw_t('Mannheim & Rhein-Neckar priorisiert.','Mannheim & Rhine-Neckar prioritized.');?></small></div><div class="pw-account-radar-grid"><?php foreach($accounts as $a)echo pw_regional_account_card($a);?></div>
    <?php else:
        $history=array_merge(pw_regional_staffing_accounts(['q'=>$q,'where'=>$where,'sector'=>$sector,'status'=>'history']),pw_regional_staffing_accounts(['q'=>$q,'where'=>$where,'sector'=>$sector,'status'=>'watch']));?>
        <div class="pw-radar-explainer warning"><b><?php echo pw_t('Nicht als offene Anfrage behandeln','Do not treat as open demand');?></b><p><?php echo pw_t('Diese Unternehmen haben eine belegte AÜ-/Beschaffungs-Historie oder eine relevante Procurement-Struktur. Abgelaufene oder bereits vergebene Verfahren werden ausdrücklich nicht als aktive Leads dargestellt.','These organisations have verified staffing/procurement history or a relevant procurement structure. Expired or awarded procedures are explicitly not shown as active leads.');?></p></div><div class="pw-account-radar-grid"><?php foreach($history as $a)echo pw_regional_account_card($a);?></div>
    <?php endif;?>
<?php echo pw_portal_shell_end();return ob_get_clean();
}

function pw_regional_radar_register_shortcode(){remove_shortcode('pw_market_live');add_shortcode('pw_market_live','pw_shortcode_market_radar_492');}
add_action('init','pw_regional_radar_register_shortcode',120);

function pw_handle_staffing_account_capture(){
    if(!is_user_logged_in()||(pw_user_role()!=='agency'&&!current_user_can('manage_options')))wp_die('Keine Berechtigung.');
    pw_require_post_nonce('pw_staffing_account_capture');
    $key=sanitize_text_field(wp_unslash($_POST['account_key']??''));$a=pw_regional_account_get($key);if(!$a)pw_form_redirect('market_live',['error'=>'account']);
    $uid=get_current_user_id();$existing=get_posts(['post_type'=>'pw_crm_lead','post_status'=>'publish','author'=>$uid,'posts_per_page'=>1,'fields'=>'ids','meta_query'=>[['key'=>'pw_crm_staffing_account_key','value'=>$key]]]);$crm=$existing?(int)$existing[0]:0;
    $roles=array_values(array_unique(array_filter(array_map(function($s){return $s['role']??'';},$a['signals']))));
    $notes='Pure Work AÜ-Nutzer-Radar. '.count($a['signals']).' öffentlich geprüfte Bedarfssignale. Kontaktart: '.pw_regional_scope_label($a['contact_scope'])[0].'. Rollen: '.implode(', ',array_slice($roles,0,12)).'. Keine Behauptung eines direkten AÜ-Entscheiders, sofern die Quelle ihn nicht ausdrücklich nennt.';
    $first=$a['signals'][0]??[];
    $data=['company'=>$a['company'],'contact'=>$a['contact_name'],'contact_role'=>$a['contact_role'],'email'=>$a['email'],'phone'=>$a['phone'],'city'=>$a['city'],'industry'=>$a['sector'],'stage'=>'qualified','source'=>'Pure Work AÜ-Nutzer-Radar','source_url'=>$a['contact_url']?:($first['evidence_url']??''),'job_title'=>implode(', ',array_slice($roles,0,4)),'job_ref'=>$key,'priority'=>'hot','next_followup'=>wp_date('Y-m-d',strtotime('+1 day')),'notes'=>$notes,'target_type'=>'staffing_account','lead_quality'=>(string)$a['quality'],'verified_at'=>$a['verified_at']];
    $crm=pw_crm_create_or_update_lead($uid,$data,$crm);if(is_wp_error($crm))pw_form_redirect('market_live',['error'=>'crm']);
    update_post_meta($crm,'pw_crm_staffing_account_key',$key);update_post_meta($crm,'pw_crm_contact_scope',$a['contact_scope']);update_post_meta($crm,'pw_crm_signal_count',count($a['signals']));
    pw_crm_add_activity($crm,$uid,'buyer_signal','AÜ-Nutzer-Radar übernommen: '.count($a['signals']).' verifizierte Signale.');
    pw_form_redirect('crm',['lead'=>$crm,'saved'=>1]);
}
add_action('admin_post_pw_staffing_account_capture','pw_handle_staffing_account_capture');
