<?php
if (!defined('ABSPATH')) exit;

function pw_flash_messages_legacy47() {
    $msgs=[];
    if (isset($_GET['saved'])) $msgs[]=['success','Gespeichert','Deine Änderungen wurden gespeichert.'];
    if (isset($_GET['registered'])) $msgs[]=['success','Konto erstellt','Bestätige deine geschäftliche E-Mail-Adresse und melde dich danach hier an.'];
    if (isset($_GET['submitted'])) $msgs[]=['success','Profil eingereicht','Das Mitarbeiterprofil wurde an den Auftraggeber übermittelt.'];
    if (isset($_GET['requested'])) $msgs[]=['success','Anfrage gesendet','Die Zeitarbeitsfirma wurde über deine Personalanfrage informiert.'];
    if (isset($_GET['released'])) $msgs[]=['success','Daten freigegeben','Die erweiterten Profildaten wurden freigegeben.'];
    if (isset($_GET['deleted'])) $msgs[]=['success','Gelöscht','Der Eintrag wurde entfernt.'];
    if (isset($_GET['imported'])) $msgs[]=['success','Import abgeschlossen',(int)$_GET['imported'].' Talentprofile wurden importiert.'];
    if (isset($_GET['error'])) {
        $err=sanitize_key(wp_unslash($_GET['error']));
        if($err==='limit') $msgs[]=['danger','Aktion nicht möglich','Bitte prüfe deine Angaben und versuche es erneut.'];
        else $msgs[]=['danger','Aktion nicht möglich','Bitte prüfe deine Angaben und versuche es erneut.'];
    }
    $html=''; foreach($msgs as $m) $html.='<div class="pw-alert '.$m[0].'"><div><strong>'.esc_html($m[1]).'</strong><span>'.esc_html($m[2]).'</span></div></div>';
    return $html;
}

function pw_public_header($dark=false) {
    ob_start(); ?>
    <header class="pw-public-header <?php echo $dark?'dark':''; ?>">
      <div class="pw-public-wrap row">
        <a class="pw-brand" href="<?php echo esc_url(home_url('/')); ?>"><?php echo pw_brand(); ?></a>
        <nav><a href="<?php echo esc_url(home_url('/#so-funktionierts')); ?>">So funktioniert&apos;s</a><a href="<?php echo esc_url(home_url('/#auftraggeber')); ?>">Auftraggeber</a><a href="<?php echo esc_url(home_url('/#zeitarbeitsfirmen')); ?>">Zeitarbeitsfirmen</a><a href="<?php echo esc_url(home_url('/#tarife')); ?>">Modelle &amp; Tarife</a></nav>
        <div class="pw-public-actions">
          <?php echo pw_language_switcher(true); ?>
          <?php if (in_array(pw_user_role(), ['agency','client'], true)): ?>
            <a class="pw-btn small ghost" href="<?php echo esc_url(pw_page_url('dashboard')); ?>">Puls</a>
            <a class="pw-btn small primary" href="<?php echo esc_url(pw_logout_url()); ?>">Abmelden</a>
          <?php else: ?>
            <a class="pw-btn small ghost" href="<?php echo esc_url(pw_page_url('login')); ?>">Anmelden</a>
            <a class="pw-btn small primary" href="<?php echo esc_url(pw_page_url('register')); ?>">Kostenlos registrieren</a>
          <?php endif; ?>
        </div>
      </div>
    </header>
    <?php return ob_get_clean();
}

function pw_shortcode_landing() {
    ob_start(); echo pw_public_header(); ?>
    <div class="pw-landing">
      <section class="pw-hero">
        <div class="pw-public-wrap pw-hero-grid">
          <div class="pw-hero-copy">
            <div class="pw-eyebrow"><span></span> B2B Personalplattform für Zeitarbeit</div>
            <h1>Personalbedarf trifft<br><em>Verfügbarkeit.</em></h1>
            <p>Pure Work verbindet Auftraggeber und verifizierte Personaldienstleister in einem gemeinsamen, anonymisierten Workflow – von der Personalanfrage bis zum geplanten Einsatz.</p>
            <div class="pw-hero-actions"><a class="pw-btn primary xl" href="<?php echo esc_url(pw_page_url('register')); ?>">Kostenlos ausprobieren <?php echo pw_icon('arrow'); ?></a><a class="pw-btn xl ghost" href="#so-funktionierts">Ablauf ansehen</a></div>
            <div class="pw-trust-row"><span><?php echo pw_icon('check'); ?> Auftraggeber kostenlos</span><span><?php echo pw_icon('check'); ?> AÜG-Verifizierung</span><span><?php echo pw_icon('check'); ?> Stufenweise Datenfreigabe</span></div>
          </div>
          <div class="pw-hero-product">
            <div class="pw-product-window">
              <div class="pw-window-top"><span></span><span></span><span></span><b>pure work / dashboard</b></div>
              <div class="pw-demo-shell">
                <div class="pw-demo-side"><div class="pw-demo-logo"></div><i class="active"></i><i></i><i></i><i></i><i></i></div>
                <div class="pw-demo-main">
                  <div class="pw-demo-head"><div><small>Guten Morgen</small><strong>Deine Geschäftschancen</strong></div><div class="pw-demo-avatar">PW</div></div>
                  <div class="pw-demo-metrics"><div><b>14</b><span>passende Personalanfragen</span></div><div><b>38</b><span>verfügbare Talente</span></div><div class="accent"><b>11</b><span>Pure Matches</span></div></div>
                  <div class="pw-demo-content"><div class="pw-demo-card wide"><span class="pw-demo-label">NEUE PERSONALANFRAGEN</span><div class="pw-demo-row"><i>92%</i><b>10 Lagerhelfer</b><span>Mannheim · 12 km</span></div><div class="pw-demo-row"><i>86%</i><b>6 Produktionsmitarbeiter</b><span>Ludwigshafen · 18 km</span></div><div class="pw-demo-row"><i>79%</i><b>4 Staplerfahrer</b><span>Heidelberg · 24 km</span></div></div><div class="pw-demo-card"><span class="pw-demo-label">PURE MATCH</span><div class="pw-match-ring"><b>92</b><span>Match Score</span></div><small>4 deiner Mitarbeiter passen</small></div></div>
                </div>
              </div>
            </div>
            <div class="pw-float-card one"><span class="pw-dot success"></span><div><b>Profil angefragt</b><small>vor 2 Minuten</small></div></div>
            <div class="pw-float-card two"><?php echo pw_icon('spark'); ?><div><b>Neue Übereinstimmung</b><small>92% Match Score</small></div></div>
          </div>
        </div>
      </section>

      <section class="pw-logo-strip"><div class="pw-public-wrap"><span>Ein zentraler Workflow für</span><div><b>DISPOSITION</b><b>HR</b><b>EINKAUF</b><b>PRODUKTION</b><b>LOGISTIK</b><b>INDUSTRIE</b></div></div></section>

      <section id="so-funktionierts" class="pw-section pw-how"><div class="pw-public-wrap"><div class="pw-section-head"><span class="pw-kicker">EINFACHER ABLAUF</span><h2>Von Bedarf zu Besetzung.<br>Ohne E-Mail-Chaos.</h2><p>Beide Seiten arbeiten im selben Prozess und sehen jederzeit den aktuellen Status.</p></div><div class="pw-steps">
        <article><em>01</em><?php echo pw_icon('briefcase'); ?><h3>Bedarf melden</h3><p>Auftraggeber erfassen Einsatzort, Anzahl, Start, Schichtmodell und Muss-Kriterien strukturiert.</p></article>
        <article><em>02</em><?php echo pw_icon('bell'); ?><h3>Passende Firmen informieren</h3><p>Radius, Region, Branche und individuelle Filter steuern, welche Personaldienstleister benachrichtigt werden.</p></article>
        <article><em>03</em><?php echo pw_icon('spark'); ?><h3>Pure Match</h3><p>Das System vergleicht verfügbare Talente mit der Personalanfrage und erklärt nachvollziehbar, warum ein Profil passt.</p></article>
        <article><em>04</em><?php echo pw_icon('check'); ?><h3>Auswählen & anfragen</h3><p>Anonymisierte Profile vergleichen, vormerken, anfragen und Daten stufenweise freigeben.</p></article>
      </div></div></section>

      <section id="funktionen" class="pw-section pw-features"><div class="pw-public-wrap"><div class="pw-section-head narrow"><span class="pw-kicker">EINE PLATTFORM</span><h2>Mehr als eine Stellenbörse.</h2><p>Pure Work ist Marktplatz, Dispositionswerkzeug und Kommunikationskanal in einem.</p></div><div class="pw-feature-grid">
        <article class="large dark"><div class="pw-feature-icon"><?php echo pw_icon('spark'); ?></div><span>PURE MATCH</span><h3>Passende Profile automatisch erkennen.</h3><p>Regelbasiertes Matching nach Entfernung, Tätigkeit, Verfügbarkeit, Schicht, Qualifikationen, Sprache und Mobilität.</p><div class="pw-mini-match"><div><b>PW-84K2LQ</b><span>Produktionsmitarbeiter</span></div><strong>94%</strong></div><div class="pw-mini-match"><div><b>PW-R7N3XQ</b><span>Lagerhelfer</span></div><strong>88%</strong></div></article>
        <article><div class="pw-feature-icon"><?php echo pw_icon('users'); ?></div><span>TALENT POOL</span><h3>Verfügbarkeit sichtbar machen.</h3><p>Strukturierte, anonymisierte Profile statt unübersichtlicher Lebenslauf-Ordner. CSV-Massenimport inklusive.</p></article>
        <article><div class="pw-feature-icon"><?php echo pw_icon('map'); ?></div><span>RADIUSFILTER</span><h3>Nur relevante Anfragen.</h3><p>Personalanfragen nach Umkreis, Region, Branche und bevorzugten Auftraggebern filtern.</p></article>
        <article><div class="pw-feature-icon"><?php echo pw_icon('lock'); ?></div><span>PRIVACY BY DESIGN</span><h3>Identität erst bei Freigabe.</h3><p>Name, Kontaktdaten und sensible Dokumente bleiben bis zur definierten Freigabestufe verborgen.</p></article>
        <article><div class="pw-feature-icon"><?php echo pw_icon('bell'); ?></div><span>BENACHRICHTIGUNGEN</span><h3>Nur das, was wirklich relevant ist.</h3><p>Sofortige Hinweise oder tägliche Zusammenfassungen – steuerbar nach Radius, Region, Branche und bevorzugten Auftraggebern.</p></article>
        <article class="wide"><div><div class="pw-feature-icon"><?php echo pw_icon('message'); ?></div><span>STATUS & CHAT</span><h3>Jeder weiß, was als Nächstes passiert.</h3><p>Eingereicht → Angesehen → Vorgemerkt → Angefragt → Bestätigt → Einsatz geplant. Nachrichten bleiben der konkreten Anfrage zugeordnet.</p></div><div class="pw-status-flow"><i>eingereicht</i><i>angesehen</i><i>vorgemerkt</i><i class="active">angefragt</i><i>bestätigt</i></div></article>
      </div></div></section>

      <section class="pw-section pw-two-sided"><div class="pw-public-wrap"><div class="pw-section-head"><span class="pw-kicker">ZWEI MARKTPLATZ-RICHTUNGEN</span><h2>Personal gesucht.<br>Personal verfügbar.</h2></div><div class="pw-side-cards"><article id="auftraggeber"><div class="pw-role-chip client">AUFTRAGGEBER</div><h3>Bedarf in Minuten veröffentlichen.</h3><ul><li>Personalanfragen strukturiert ausschreiben</li><li>Profile vergleichen und vormerken</li><li>Gezielt Personaldienstleister auswählen</li><li>Talent Pool aktiv durchsuchen</li><li>Kostenlos nutzen</li></ul><a href="<?php echo esc_url(pw_page_url('register',['type'=>'client'])); ?>">Als Auftraggeber starten <?php echo pw_icon('arrow'); ?></a></article><article id="zeitarbeitsfirmen"><div class="pw-role-chip agency">ZEITARBEITSFIRMA</div><h3>Verfügbare Mitarbeiter schneller besetzen.</h3><ul><li>Eigener Talent Pool</li><li>Passende Personalanfragen automatisch erhalten</li><li>Profile mit wenigen Klicks einreichen</li><li>Radius- und Kundenfilter festlegen</li><li>Status jeder Einreichung verfolgen</li></ul><a href="<?php echo esc_url(pw_page_url('register',['type'=>'agency'])); ?>">Als Personaldienstleister starten <?php echo pw_icon('arrow'); ?></a></article></div></div></section>

      <?php if(function_exists('pw_public_direct_leads_preview')) echo pw_public_direct_leads_preview(); ?>

      <section id="tarife" class="pw-section pw-pricing-public"><div class="pw-public-wrap"><div class="pw-section-head narrow"><span class="pw-kicker">ZUGÄNGE & TARIFE</span><h2>Einfach starten.<br>Passend skalieren.</h2><p>Auftraggeber starten dauerhaft kostenlos. Zeitarbeitsfirmen wählen Basic, Pro oder Max; eine verfügbare Einführungsaktion wird automatisch berücksichtigt.</p></div><?php echo function_exists('pw_v501_pricing_cards')?pw_v501_pricing_cards(false):pw_pricing_cards(false); ?></div></section>

      <section class="pw-cta"><div class="pw-public-wrap"><div><span class="pw-kicker light">BEREIT FÜR DEN NÄCHSTEN EINSATZ?</span><h2>Weniger suchen.<br>Mehr besetzen.</h2><p>Registriere dein Unternehmen und starte mit dem zentralen B2B-Workflow für Zeitarbeit.</p><a class="pw-btn white xl" href="<?php echo esc_url(pw_page_url('register')); ?>">Pure Work starten <?php echo pw_icon('arrow'); ?></a></div></div></section>
    </div>
    <footer class="pw-public-footer"><div class="pw-public-wrap"><a class="pw-brand" href="<?php echo esc_url(home_url('/')); ?>"><?php echo pw_brand(); ?></a><p>Digitale B2B-Plattform für Personalbedarf, Matching, Profilvorschläge und Besetzung.</p><div><a href="<?php echo esc_url(pw_page_url('legal')); ?>">Nutzungsbedingungen</a><a href="<?php echo esc_url(pw_page_url('privacy')); ?>">Datenschutz</a><a href="<?php echo esc_url(pw_page_url('login')); ?>">Login</a></div></div></footer>
    <?php return ob_get_clean();
}
add_shortcode('pw_landing','pw_shortcode_landing');

function pw_shortcode_login() {
    if (in_array(pw_user_role(), ['agency','client'], true)) return '<section class="pw-auth-gate"><a class="pw-brand" href="'.esc_url(home_url('/')).'">'.pw_brand().'</a><div class="pw-auth-card"><span class="pw-kicker">BEREITS ANGEMELDET</span><h1>Du bist eingeloggt</h1><p>Öffne deinen Pure Work Puls.</p><a class="pw-btn primary full" href="'.esc_url(pw_page_url('dashboard')).'">Zum Puls</a></div></section>';
    $email = sanitize_email(wp_unslash($_GET['email'] ?? ''));
    $error = sanitize_key(wp_unslash($_GET['error'] ?? ''));
    $redirect_to = esc_url_raw(wp_unslash($_GET['redirect_to'] ?? ''));
    ob_start(); ?>
    <section class="pw-auth-page"><div class="pw-auth-visual"><a class="pw-brand light" href="<?php echo esc_url(home_url('/')); ?>"><?php echo pw_brand(); ?></a><div><span class="pw-kicker light">PURE WORK</span><h2>Ein Login.<br>Der ganze Personalprozess.</h2><p>Personalanfragen, Talent Pool, Pure Match, Status und Nachrichten in einem geschützten B2B-Portal.</p><div class="pw-auth-feature-list"><span><?php echo pw_icon('check'); ?> E-Mail-Verifizierung</span><span><?php echo pw_icon('check'); ?> Unternehmensprüfung</span><span><?php echo pw_icon('check'); ?> geschützte Mitarbeiterdaten</span></div></div></div><div class="pw-auth-form-wrap"><div class="pw-auth-lang"><?php echo pw_language_switcher(); ?></div><div class="pw-auth-form"><span class="pw-kicker">SICHERER ZUGANG</span><h1>Anmelden</h1><p>Mit deiner geschäftlichen E-Mail-Adresse und deinem Passwort.</p>
    
    <?php if (isset($_GET['registered'])): ?><div class="pw-alert success"><div><strong>Konto erstellt</strong><span>Wir haben dir einen Bestätigungslink geschickt. Erst nach der Bestätigung kannst du dich anmelden.</span></div></div><?php endif; ?>
    <?php if (!empty($_GET['mail_error'])): ?><div class="pw-alert danger"><div><strong>Bestätigungs-E-Mail noch nicht versendet</strong><span>Dein Konto wurde angelegt, aber der Mailserver hat die Nachricht nicht angenommen. Nutze unten „Link erneut senden“ oder prüfe als Betreiber die SMTP-Einstellungen.</span></div></div><?php endif; ?>
    <?php if (isset($_GET['password_reset'])): ?><div class="pw-alert success"><div><strong>Neues Passwort gespeichert</strong><span>Melde dich jetzt mit deiner E-Mail-Adresse und dem neuen Passwort an.</span></div></div><?php endif; ?>
    <?php if (isset($_GET['verified'])): ?><div class="pw-alert success"><div><strong>E-Mail bestätigt</strong><span>Dein Zugang ist aktiviert. Du kannst dich jetzt mit E-Mail-Adresse und Passwort anmelden.</span></div></div><?php endif; ?>
    <?php if (isset($_GET['resent'])): ?><div class="pw-alert info"><div><strong>Bestätigungs-Mail angefordert</strong><span>Wenn für diese E-Mail-Adresse ein unbestätigtes Konto existiert, wurde ein neuer Link versendet.</span></div></div><?php endif; ?>
    <?php if ($error==='aug_expired'): ?><div class="pw-alert danger pw-aug-login-alert"><div><strong>AÜG-Erlaubnis abgelaufen</strong><span>Dein Portalzugang ist vorübergehend gesperrt. Aktualisiere die AÜG-Unterlagen über den sicheren Prozess; danach kann die Erlaubnis erneut geprüft werden.</span><a class="pw-btn small white" href="<?php echo esc_url(pw_page_url('aug_renew',['email'=>$email])); ?>">AÜG aktualisieren</a></div></div>
    <?php elseif ($error==='unverified'): ?><div class="pw-alert warning"><div><strong>E-Mail noch nicht bestätigt</strong><span>Bitte öffne zuerst den Bestätigungslink aus deiner E-Mail. Danach ist die Anmeldung freigeschaltet.</span></div></div>
    <?php elseif ($error==='missing'): ?><div class="pw-alert danger"><div><strong>Angaben fehlen</strong><span>Bitte gib E-Mail-Adresse und Passwort vollständig ein.</span></div></div>
    <?php elseif ($error): ?><div class="pw-alert danger"><div><strong>Anmeldung fehlgeschlagen</strong><span>E-Mail-Adresse oder Passwort ist nicht korrekt.</span></div></div><?php endif; ?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_login"><input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>"><?php wp_nonce_field('pw_login'); ?><label>E-Mail-Adresse<input type="email" name="email" required autocomplete="email" value="<?php echo esc_attr($email); ?>" placeholder="name@unternehmen.de"></label><label>Passwort<input type="password" name="password" required autocomplete="current-password" placeholder="••••••••" data-pw-toggle="1"></label><div class="pw-form-inline"><label class="pw-check"><input type="checkbox" name="remember" value="1"><span></span>Angemeldet bleiben</label><a href="<?php echo esc_url(pw_page_url('password')); ?>">Passwort vergessen?</a></div><button class="pw-btn primary full xl" type="submit" name="pw_login_submit" value="1">Sicher anmelden <?php echo pw_icon('arrow'); ?></button></form>
    <div class="pw-resend-box"><b>Keine Bestätigungs-Mail erhalten?</b><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_resend_verification"><?php wp_nonce_field('pw_resend_verification'); ?><input type="email" name="email" required value="<?php echo esc_attr($email); ?>" placeholder="E-Mail-Adresse"><button class="pw-btn small ghost" type="submit">Link erneut senden</button></form></div>
    <div class="pw-auth-bottom">Noch kein Konto? <a href="<?php echo esc_url(pw_page_url('register')); ?>">Kostenlos registrieren</a></div></div></div></section>
    <?php return ob_get_clean();
}
add_shortcode('pw_login','pw_shortcode_login');

function pw_shortcode_register() {
    if (in_array(pw_user_role(), ['agency','client'], true)) return '<section class="pw-auth-gate"><a class="pw-brand" href="'.esc_url(home_url('/')).'">'.pw_brand().'</a><div class="pw-auth-card"><span class="pw-kicker">BEREITS ANGEMELDET</span><h1>Du bist eingeloggt</h1><p>Öffne deinen Pure Work Puls.</p><a class="pw-btn primary full" href="'.esc_url(pw_page_url('dashboard')).'">Zum Puls</a></div></section>';
    $pre = sanitize_key($_GET['type'] ?? '');
    $selected_plan = sanitize_key($_GET['plan'] ?? '');
    if (!in_array($selected_plan,['client','basic','professional','enterprise'],true)) $selected_plan='';
    ob_start(); echo pw_public_header(); ?>
    <section class="pw-register-page"><div class="pw-public-wrap small"><div class="pw-register-head"><span class="pw-kicker">IN WENIGEN MINUTEN STARTKLAR</span><h1>Pure Work Konto erstellen</h1><p>Registrieren, geschäftliche E-Mail bestätigen und anschließend in deinen persönlichen Pure Work Puls einloggen.</p></div><?php if($selected_plan): ?><div class="pw-selected-plan"><span><?php echo pw_icon('spark'); ?></span><div><b>Gewählter Zugang: <?php echo esc_html($selected_plan==='client'?'Auftraggeber':($selected_plan==='professional'?'Pro':($selected_plan==='enterprise'?'Max':ucfirst($selected_plan)))); ?></b><small>Der gewählte Zugang wird nach der Registrierung deinem Konto zugeordnet. Eine verfügbare Einführungsaktion wird automatisch berücksichtigt.</small></div></div><?php endif; ?>
    <div class="pw-register-progress"><span class="active"><i>1</i><b>Unternehmen</b></span><span><i>2</i><b>Zugangsdaten</b></span><span><i>3</i><b>Puls</b></span></div>
    <?php if(isset($_GET['error'])) { $regerr=sanitize_key(wp_unslash($_GET['error'])); $regmsg=$regerr==='aug'?'Bei einer befristeten AÜG-Erlaubnis ist ein zukünftiges Ablaufdatum erforderlich.':($regerr==='aug_file'?'Zeitarbeitsfirmen müssen die aktuelle AÜG-Erlaubnis zur geschützten Prüfung hochladen.':'Bitte prüfe die Angaben. Die E-Mail-Adresse darf noch nicht registriert sein und das Passwort muss mindestens 8 Zeichen haben.'); echo '<div class="pw-alert danger"><div><strong>Registrierung nicht möglich</strong><span>'.esc_html($regmsg).'</span></div></div>'; } ?>
    <form class="pw-register-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_register"><input type="hidden" name="selected_plan" value="<?php echo esc_attr($selected_plan); ?>"><?php wp_nonce_field('pw_register'); ?><div class="pw-role-select"><label><input type="radio" name="role" value="client" <?php checked($pre!=='agency'); ?> required><span><?php echo pw_icon('building'); ?><b>Auftraggeber</b><small>Personalbedarf melden, Profile prüfen und Personal anfragen.</small><em>Kostenlos</em></span></label><label><input type="radio" name="role" value="agency" <?php checked($pre==='agency'); ?> required><span><?php echo pw_icon('users'); ?><b>Zeitarbeitsfirma</b><small>Ausschreibungen sehen, Mitarbeiter-Pool pflegen und Profile anbieten.</small><em>Tarif wählen</em></span></label></div><div class="pw-form-card"><h3>Unternehmensdaten</h3><div class="pw-form-grid two"><label>Firmenname<input name="company" required autocomplete="organization" placeholder="Muster GmbH"></label><label>Ansprechpartner<input name="contact" required autocomplete="name" placeholder="Vor- und Nachname"></label><label>E-Mail-Adresse<input type="email" name="email" required autocomplete="email" placeholder="name@unternehmen.de"></label><label>Telefon<input name="phone" autocomplete="tel" placeholder="+49 …"></label><label>PLZ<input name="zip" autocomplete="postal-code" placeholder="68161"></label><label>Ort<input name="city" list="pw-locations" autocomplete="address-level2" placeholder="Mannheim"></label><label class="full">Branche / Schwerpunkt<input name="industry" list="pw-industries" placeholder="z. B. Logistik, Industrie, Automotive"></label><label class="full">Passwort<input type="password" name="password" minlength="8" required autocomplete="new-password" placeholder="Mindestens 8 Zeichen" data-pw-strength="1" data-pw-toggle="1"></label></div></div><div class="pw-form-card pw-agency-only"><h3>AÜG-Verifizierung</h3><p>Für Personaldienstleister. Hinterlege die Gültigkeit deiner Erlaubnis und lade das Dokument zur Prüfung hoch.</p><div class="pw-form-grid two"><label>Gültigkeit der AÜG-Erlaubnis<select name="aug_type" class="pw-aug-type"><option value="limited">Befristet</option><option value="unlimited">Unbefristet</option></select></label><label class="pw-aug-expiry-field">Gültig bis<input type="date" name="aug_expiry" data-agency-required="1"></label><div class="full pw-aug-unlimited-note" hidden><span class="pw-inline-info">✓ Unbefristete Erlaubnis – kein Ablaufdatum erforderlich.</span></div><label class="full">AÜG-Erlaubnis hochladen<input type="file" name="aug_file" accept=".pdf,.jpg,.jpeg,.png" data-agency-required="1"><small>PDF/JPG/PNG, max. 10 MB. Speicherung im geschützten Portalbereich.</small></label></div></div><label class="pw-check legal"><input type="checkbox" name="accept_terms" value="1" required><span></span>Ich akzeptiere die <a href="<?php echo esc_url(pw_page_url('legal')); ?>" target="_blank">Nutzungsbedingungen</a> und habe die <a href="<?php echo esc_url(pw_page_url('privacy')); ?>" target="_blank">Datenschutzhinweise</a> gelesen.</label><button class="pw-btn primary xl full" type="submit">Registrieren & starten <?php echo pw_icon('arrow'); ?></button><p class="pw-form-note">Bereits registriert? <a href="<?php echo esc_url(pw_page_url('login')); ?>">Anmelden</a></p></form></div></section>
    <?php return ob_get_clean();
}
add_shortcode('pw_register','pw_shortcode_register');

function pw_shortcode_verify_email() {
    if (is_user_logged_in()) return '<section class="pw-auth-gate"><a class="pw-brand" href="'.esc_url(home_url('/')).'">'.pw_brand().'</a><div class="pw-auth-card"><span class="pw-kicker">E-MAIL BESTÄTIGT</span><h1>Du bist bereits angemeldet</h1><a class="pw-btn primary full" href="'.esc_url(pw_page_url('dashboard')).'">Zum Puls</a></div></section>';
    $state = sanitize_key(wp_unslash($_GET['state'] ?? ''));
    ob_start(); echo pw_public_header(); ?>
    <section class="pw-simple-public"><div class="pw-public-wrap small"><div class="pw-auth-card pw-verify-card"><?php echo pw_icon($state ? 'lock' : 'check'); ?><span class="pw-kicker">KONTOAKTIVIERUNG</span><h1><?php echo $state === 'expired' ? 'Bestätigungslink abgelaufen' : ($state === 'invalid' ? 'Link nicht gültig' : 'E-Mail-Adresse bestätigen'); ?></h1><p><?php echo $state ? 'Fordere auf der Anmeldeseite einfach einen neuen Bestätigungslink an.' : 'Öffne den Link aus deiner Bestätigungs-E-Mail. Erst nach erfolgreicher Bestätigung ist die Anmeldung mit deinem Pure Work Konto freigeschaltet.'; ?></p><a class="pw-btn primary full" href="<?php echo esc_url(pw_page_url('login')); ?>">Zur Anmeldung</a></div></div></section>
    <?php return ob_get_clean();
}
add_shortcode('pw_verify_email','pw_shortcode_verify_email');

function pw_dashboard_notifications_panel() {
    $uid=get_current_user_id();
    $notices=get_posts(['post_type'=>'pw_notice','post_status'=>'publish','author'=>$uid,'posts_per_page'=>30,'orderby'=>'date','order'=>'DESC']);
    ob_start(); ?><div class="pw-page-head-inline"><div><h2>Benachrichtigungen</h2><p>Alle wichtigen Aktivitäten in deinem Pure Work Konto.</p></div><?php if($notices): ?><a class="pw-btn small ghost" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_mark_notices'),'pw_mark_notices')); ?>">Alle als gelesen markieren</a><?php endif; ?></div><div class="pw-list-card notifications"><?php if(!$notices): ?><div class="pw-empty"><?php echo pw_icon('bell'); ?><h3>Noch keine Benachrichtigungen</h3><p>Neue Personalanfragen, Anfragen und Statusänderungen erscheinen hier.</p></div><?php else: foreach($notices as $n): $read=pw_meta($n->ID,'pw_read','0'); ?><a class="pw-notice <?php echo $read==='1'?'':'unread'; ?>" href="<?php echo esc_url(pw_meta($n->ID,'pw_url',pw_page_url('dashboard'))); ?>"><span></span><div><b><?php echo esc_html($n->post_title); ?></b><p><?php echo esc_html(wp_strip_all_tags($n->post_content)); ?></p><small><?php echo esc_html(human_time_diff(get_post_time('U',true,$n),current_time('timestamp')).' her'); ?></small></div></a><?php endforeach; endif; ?></div><?php return ob_get_clean();
}


function pw_dashboard_greeting() {
    $hour=(int)wp_date('G');
    if($hour<11) return 'Guten Morgen';
    if($hour<17) return 'Guten Tag';
    return 'Guten Abend';
}

function pw_pure_assist_widget($uid) {
    $role=pw_user_role($uid);
    $items=[];
    $vstate=pw_verification_state($uid);
    if(!$vstate['email']) $items[]=['E-Mail bestätigen','Bestätige deine geschäftliche E-Mail-Adresse für den vollständigen Verifizierungsstatus.',pw_page_url('account',['tab'=>'verification']),'check'];
    if(!$vstate['company']) $items[]=['Unternehmensprüfung abschließen','Deine Firmenangaben warten auf Prüfung. Der geschlossene Marktplatz wird danach freigegeben.',pw_page_url('account',['tab'=>'verification']),'building'];

    if($role==='agency') {
        $aug=function_exists('pw_aug_state')?pw_aug_state($uid):null;
        if($aug && !empty($aug['warning']) && empty($aug['expired']) && !$aug['missing']) {
            $items[]=['AÜG rechtzeitig verlängern','Die hinterlegte Erlaubnis läuft in '.(int)$aug['days'].' Tagen ab. Aktualisiere sie frühzeitig.',pw_page_url('account',['tab'=>'profile']),'clock'];
        }
        if(!$vstate['aug']) $items[]=['AÜG-Prüfung offen','Deine AÜG-Unterlagen müssen geprüft sein, bevor sensible Marktplatzfunktionen freigeschaltet werden.',pw_page_url('account',['tab'=>'verification']),'lock'];

        $workers=get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']);
        if(!$workers) {
            $items[]=['Talent Pool aufbauen','Lege dein erstes Talentprofil an oder importiere mehrere Profile per CSV.',pw_page_url('workers',['new'=>1]),'users'];
        } else {
            $matches=pw_best_vacancies_for_agency($uid,1);
            if($matches) $items[]=['Beste Chance prüfen','Pure Match hat eine passende Personalanfrage für deinen Talent Pool gefunden.',pw_page_url('matches'),'spark'];
            else $items[]=['Direkt-Leads ansehen','Nutze geprüfte AÜ-Bedarfe mit direkter Vergabe-/Beschaffungskontaktstelle.',pw_page_url('market_live'),'search'];
        }
    } elseif($role==='client') {
        $open=get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>1,'fields'=>'ids','meta_query'=>[['key'=>'pw_status','value'=>'open']]]);
        if(!$open) $items[]=['Personalbedarf veröffentlichen','Erstelle deine erste Personalanfrage und erreiche passende Personaldienstleister.',pw_page_url('vacancies',['new'=>1]),'plus'];
        $subs=pw_client_submissions($uid);
        $requested=0;
        foreach($subs as $sub) if(pw_meta($sub->ID,'pw_status','submitted')==='submitted') $requested++;
        if($requested) $items[]=['Neue Profile prüfen',$requested.' neue Profile warten auf deine Sichtung.',pw_page_url('vacancies'),'users'];
        if(!$items) $items[]=['Pure Match öffnen','Vergleiche passende Talentprofile für deine offenen Personalanfragen.',pw_page_url('matches'),'spark'];
    }
    $items=array_slice($items,0,3);
    ob_start(); ?>
    <section class="pw-card pw-assist-card">
      <div class="pw-card-head"><div><span class="pw-kicker">PURE ASSIST</span><h2>Deine nächsten sinnvollen Schritte</h2><p class="pw-card-sub">Smarte Hinweise aus deinen eigenen Portal-Daten – ohne Talentdaten an einen externen KI-Dienst zu senden.</p></div><span class="pw-assist-orb"><?php echo pw_icon('spark'); ?></span></div>
      <div class="pw-assist-list">
        <?php foreach($items as $item): ?><a href="<?php echo esc_url($item[2]); ?>"><span><?php echo pw_icon($item[3]); ?></span><div><b><?php echo esc_html($item[0]); ?></b><small><?php echo esc_html($item[1]); ?></small></div><?php echo pw_icon('arrow'); ?></a><?php endforeach; ?>
      </div>
    </section>
    <?php return ob_get_clean();
}

function pw_talent_pool_health_widget($uid) {
    if(pw_user_role($uid)!=='agency') return '';
    $ids=get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids']);
    $total=count($ids);$available=0;$reserved=0;$assigned=0;$stale=0;
    foreach($ids as $id){
        $st=pw_meta($id,'pw_status','available');
        if($st==='available')$available++;
        elseif($st==='reserved')$reserved++;
        elseif($st==='assigned')$assigned++;
        $modified=get_post_modified_time('U',true,$id);
        if($modified && $modified < time()-30*DAY_IN_SECONDS)$stale++;
    }
    $health=$total?max(0,min(100,(int)round((($available+$reserved)/$total)*80 + (($total-$stale)/$total)*20))):0;
    ob_start(); ?>
    <section class="pw-card pw-talent-health">
      <div class="pw-card-head"><div><span class="pw-kicker">TALENT POOL HEALTH</span><h2><?php echo $total?esc_html($health.'% aktuell'):'Noch keine Talente'; ?></h2></div><a href="<?php echo esc_url(pw_page_url('workers')); ?>">Talent Pool öffnen</a></div>
      <div class="pw-health-bar"><i style="width:<?php echo (int)$health; ?>%"></i></div>
      <div class="pw-health-stats"><div><b><?php echo (int)$available; ?></b><span>verfügbar</span></div><div><b><?php echo (int)$reserved; ?></b><span>reserviert</span></div><div><b><?php echo (int)$assigned; ?></b><span>im Einsatz</span></div><div><b><?php echo (int)$stale; ?></b><span>älter als 30 Tage</span></div></div>
      <?php if($stale): ?><p class="pw-card-sub"><?php echo (int)$stale; ?> Profile sollten auf Verfügbarkeit und Aktualität geprüft werden.</p><?php endif; ?>
    </section>
    <?php return ob_get_clean();
}


function pw_network_pulse_widget($uid) {
    $agency_q = new WP_User_Query(['role'=>'pw_agency','fields'=>'ID','number'=>-1]);
    $client_q = new WP_User_Query(['role'=>'pw_client','fields'=>'ID','number'=>-1]);
    $workers = new WP_Query(['post_type'=>'pw_worker','post_status'=>'publish','posts_per_page'=>1,'fields'=>'ids','meta_query'=>[['key'=>'pw_status','value'=>'available']]]);
    $since = wp_date('Y-m-d H:i:s', time()-7*DAY_IN_SECONDS);
    $vac = new WP_Query(['post_type'=>'pw_vacancy','post_status'=>'publish','posts_per_page'=>1,'fields'=>'ids','date_query'=>[['after'=>$since,'inclusive'=>true]]]);
    $company_total = (int)$agency_q->get_total() + (int)$client_q->get_total();
    ob_start(); ?>
    <section class="pw-network-pulse">
      <div class="pw-network-orbit"><i></i><i></i><i></i><span>PW</span></div>
      <div class="pw-network-copy"><span class="pw-kicker">PURE WORK PULS</span><h2>Die Plattform wächst mit jedem Unternehmen.</h2><p>Registrierte Firmen, veröffentlichte Personalanfragen und Talentprofile werden im eigenen WordPress-Datenbestand aufgebaut. Marktdaten von außen bleiben klar getrennt.</p></div>
      <div class="pw-network-stats"><div><b><?php echo (int)$company_total; ?></b><span>Unternehmen im Netzwerk</span></div><div><b><?php echo (int)$workers->found_posts; ?></b><span>verfügbare Talente</span></div><div><b><?php echo (int)$vac->found_posts; ?></b><span>neue Anfragen · 7 Tage</span></div></div>
    </section>
    <?php return ob_get_clean();
}

function pw_shortcode_dashboard_legacy47() {
    if(!is_user_logged_in()) return pw_require_login_html();
    $uid=get_current_user_id();$role=pw_user_role();$company=pw_user_meta($uid,'pw_company','');
    $subtitle=$role==='agency'?'Dein Vertriebs- und Dispositionscockpit':'Dein zentraler Überblick über Personalbedarf und Profile';
    ob_start(); echo pw_portal_shell_start(pw_dashboard_greeting().', '.(pw_user_meta($uid,'pw_contact',wp_get_current_user()->display_name) ?: $company),$subtitle); echo pw_flash_messages();
    if(isset($_GET['panel']) && $_GET['panel']==='notifications'){ echo pw_dashboard_notifications_panel(); echo pw_portal_shell_end(); return ob_get_clean(); }
    echo pw_network_pulse_widget($uid);
    if(!pw_email_is_verified($uid)) echo '<div class="pw-onboarding-banner"><div>'.pw_icon('check').'<div><span class="pw-kicker">E-MAIL NOCH OFFEN</span><h3>Bestätige deine geschäftliche E-Mail-Adresse.</h3><p>Dein Login ist aktiv. Für sensible Marktplatzfunktionen müssen anschließend die Unternehmens- und – bei Zeitarbeitsfirmen – AÜG-Prüfung abgeschlossen sein.</p></div></div><a class="pw-btn white small" href="'.esc_url(pw_page_url('account',['tab'=>'verification'])).'">Verifizierung öffnen</a></div>';
    echo '<div class="pw-dashboard-smart-row">'.pw_pure_assist_widget($uid).pw_talent_pool_health_widget($uid).'</div>';

    if($role==='agency'){
        $openMatches=pw_best_vacancies_for_agency($uid,50);$workers=new WP_Query(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>1]);
        $avail=new WP_Query(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>1,'meta_query'=>[['key'=>'pw_status','value'=>'available']]]);
        $subs=new WP_Query(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>1,'meta_query'=>[['key'=>'pw_agency_id','value'=>$uid]]]);
        $requested=new WP_Query(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>1,'meta_query'=>[['key'=>'pw_agency_id','value'=>$uid],['key'=>'pw_status','value'=>'requested']]]);
        $confirmed=new WP_Query(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>1,'meta_query'=>[['key'=>'pw_agency_id','value'=>$uid],['key'=>'pw_status','value'=>['confirmed','planned'],'compare'=>'IN']]]);
        echo '<div class="pw-metrics-grid">'.pw_metric(count($openMatches),'passende Personalanfragen','nach deinen Filtern','brand').pw_metric($avail->found_posts,'verfügbare Talente',$workers->found_posts.' Profile insgesamt').pw_metric($subs->found_posts,'Profile eingereicht','aktuelle Historie').pw_metric($requested->found_posts,'Mitarbeiter angefragt','jetzt reagieren','warning').pw_metric($confirmed->found_posts,'bestätigte Einsätze','erfolgreich','success').'</div>';
        ?>
        <div class="pw-dashboard-grid"><section class="pw-card span2"><div class="pw-card-head"><div><span class="pw-kicker">PURE MATCH</span><h2>Beste Chancen für deinen Pool</h2></div><a href="<?php echo esc_url(pw_page_url('matches')); ?>">Alle Matches</a></div><?php if(!$openMatches): ?><div class="pw-empty compact"><?php echo pw_icon('spark'); ?><h3>Noch keine passenden Personalanfragen</h3><p>Sobald passende Anfragen veröffentlicht werden, erscheinen sie hier.</p></div><?php else: ?><div class="pw-match-list"><?php foreach(array_slice($openMatches,0,4) as $item):$v=pw_vacancy_fields($item['vacancy']->ID);?><a href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$v['id']])); ?>" class="pw-match-item"><div class="pw-score <?php echo $item['best_score']>=85?'high':''; ?>"><strong><?php echo (int)$item['best_score']; ?>%</strong><small>Match</small></div><div class="pw-match-main"><b><?php echo esc_html($v['title']); ?></b><span><?php echo esc_html($v['location']); ?> · <?php echo (int)$v['qty']; ?> Personen · Start <?php echo esc_html(pw_format_date($v['start_date'])); ?></span><div><?php foreach(array_slice($item['workers'],0,3) as $w) echo '<i>'.esc_html(pw_meta($w['worker']->ID,'pw_code','')).' '.$w['match']['score'].'%</i>'; ?></div></div><?php echo pw_icon('arrow'); ?></a><?php endforeach; ?></div><?php endif; ?></section>
        <section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker">SCHNELLZUGRIFF</span><h2>Was möchtest du tun?</h2></div></div><div class="pw-quick-grid"><a href="<?php echo esc_url(pw_page_url('workers',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?><b>Talent anlegen</b><span>Profil & CV hinzufügen</span></a><a href="<?php echo esc_url(pw_page_url('vacancies')); ?>"><?php echo pw_icon('search'); ?><b>Personalanfragen suchen</b><span>Neue Aufträge finden</span></a><a href="<?php echo esc_url(pw_page_url('matches')); ?>"><?php echo pw_icon('spark'); ?><b>Pure Match öffnen</b><span>Beste Treffer prüfen</span></a><a href="<?php echo esc_url(pw_page_url('companies')); ?>"><?php echo pw_icon('building'); ?><b>Auftraggeber</b><span>Firmen im Radius</span></a></div></section>
        </div>
        <?php
    } else {
        $vac=new WP_Query(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>1]);
        $open=new WP_Query(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>1,'meta_query'=>[['key'=>'pw_status','value'=>'open']]]);
        $subs=pw_client_submissions($uid);
        $short=0;$req=0;$conf=0;foreach($subs as $s){$st=pw_meta($s->ID,'pw_status','submitted');if($st==='shortlisted')$short++;if($st==='requested')$req++;if(in_array($st,['confirmed','planned'],true))$conf++;}
        echo '<div class="pw-metrics-grid">'.pw_metric($open->found_posts,'offene Personalanfragen',$vac->found_posts.' insgesamt','brand').pw_metric(count($subs),'eingegangene Profile','über alle Personalanfragen').pw_metric($short,'vorgemerkte Profile','für die Auswahl').pw_metric($req,'aktive Anfragen','warte auf Freigabe','warning').pw_metric($conf,'bestätigte Einsätze','erfolgreich','success').'</div>';
        $recent=array_slice($subs,0,5);
        ?>
        <div class="pw-dashboard-grid"><section class="pw-card span2"><div class="pw-card-head"><div><span class="pw-kicker">NEUE PROFILE</span><h2>Zu deinen Personalanfragen eingereicht</h2></div><a href="<?php echo esc_url(pw_page_url('vacancies')); ?>">Alle ansehen</a></div><?php if(!$recent): ?><div class="pw-empty compact"><?php echo pw_icon('users'); ?><h3>Noch keine Profile eingegangen</h3><p>Erstelle eine Personalanfrage oder durchsuche den Talent Pool aktiv.</p><a class="pw-btn small primary" href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1])); ?>">Personalanfrage erstellen</a></div><?php else:?><div class="pw-submission-list"><?php foreach($recent as $s){$wid=(int)pw_meta($s->ID,'pw_worker_id',0);$vid=(int)pw_meta($s->ID,'pw_vacancy_id',0);$w=pw_worker_fields($wid);?><a href="<?php echo esc_url(pw_page_url('vacancies',['submission'=>$s->ID])); ?>"><span class="pw-profile-code"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><b><?php echo esc_html($w['role']); ?> · <?php echo esc_html($w['code']); ?></b><small><?php echo esc_html(get_the_title($vid)); ?> · <?php echo esc_html($w['experience']); ?> Jahre Erfahrung</small></div><?php echo pw_status_badge(pw_meta($s->ID,'pw_status','submitted')); ?><?php echo pw_icon('arrow'); ?></a><?php } ?></div><?php endif;?></section><section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker">SCHNELLZUGRIFF</span><h2>Personal finden</h2></div></div><div class="pw-quick-grid"><a href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?><b>Personalanfrage erstellen</b><span>Bedarf veröffentlichen</span></a><a href="<?php echo esc_url(pw_page_url('workers')); ?>"><?php echo pw_icon('search'); ?><b>Talent Pool</b><span>Verfügbare Profile</span></a><a href="<?php echo esc_url(pw_page_url('matches')); ?>"><?php echo pw_icon('spark'); ?><b>Pure Match</b><span>Automatische Treffer</span></a><a href="<?php echo esc_url(pw_page_url('companies')); ?>"><?php echo pw_icon('building'); ?><b>Partner</b><span>Dienstleister entdecken</span></a></div></section></div>
        <?php
    }
    echo '<div class="pw-dashboard-grid pw-dashboard-crm-row">'.pw_crm_dashboard_widget($uid).'</div>';
    echo '<div class="pw-dashboard-grid pw-dashboard-live-row">'.pw_live_market_dashboard_widget($uid).'</div>';
    echo pw_portal_shell_end(); return ob_get_clean();
}
add_shortcode('pw_dashboard','pw_shortcode_dashboard');

function pw_client_submissions($client_id) {
    $vac_ids=get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$client_id,'posts_per_page'=>-1,'fields'=>'ids']);
    if(!$vac_ids) return [];
    return get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC','meta_query'=>[['key'=>'pw_vacancy_id','value'=>$vac_ids,'compare'=>'IN']]]);
}

function pw_vacancy_form_legacy47($vacancy_id=0){
    $v=$vacancy_id?pw_vacancy_fields($vacancy_id):['id'=>0,'title'=>'','description'=>'','qty'=>1,'location'=>'','start_date'=>'','duration'=>'','hours'=>'','shift'=>'','industry'=>'','must_quals'=>[],'nice_quals'=>[],'language'=>'','driver'=>'0','rate_max'=>'','deadline'=>'','target_mode'=>'all','target_agencies'=>[],'status'=>'open'];
    $agencies=array_values(array_filter(get_users(['role'=>'pw_agency','number'=>100]),function($a){return pw_account_active($a->ID) && pw_is_demo_user($a->ID)===pw_is_demo_user(get_current_user_id());}));
    ob_start(); ?><div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('vacancies')); ?>">← Zurück</a><h2><?php echo $vacancy_id?'Personalanfrage bearbeiten':'Neue Personalanfrage erstellen'; ?></h2><p>Strukturierte Angaben verbessern Matching und Profilqualität.</p></div></div><form class="pw-form-stack" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_vacancy_save"><input type="hidden" name="vacancy_id" value="<?php echo (int)$v['id']; ?>"><?php wp_nonce_field('pw_vacancy_save'); ?><section class="pw-form-card"><div class="pw-form-section-title"><span>01</span><div><h3>Personalbedarf</h3><p>Was wird wann und wo benötigt?</p></div></div><div class="pw-form-grid two"><label class="full">Berufsbezeichnung / Tätigkeit<input name="title" list="pw-roles" data-pw-occupation="1" autocomplete="off" required value="<?php echo esc_attr($v['title']); ?>" placeholder="z. B. Lagerhelfer"></label><label>Anzahl Mitarbeiter<input type="number" min="1" name="qty" required value="<?php echo esc_attr($v['qty']); ?>"></label><label>Einsatzort<input name="location" list="pw-locations" required value="<?php echo esc_attr($v['location']); ?>" placeholder="68161 Mannheim"></label><label>Startdatum<input type="date" name="start_date" value="<?php echo esc_attr($v['start_date']); ?>"></label><label>Geplante Einsatzdauer<input name="duration" value="<?php echo esc_attr($v['duration']); ?>" placeholder="z. B. 3 Monate"></label><label>Wochenstunden<input name="hours" value="<?php echo esc_attr($v['hours']); ?>" placeholder="z. B. 40"></label><label>Schichtmodell<input name="shift" list="pw-shifts" value="<?php echo esc_attr($v['shift']); ?>" placeholder="z. B. 2-Schicht"></label><label>Branche<input name="industry" list="pw-industries" value="<?php echo esc_attr($v['industry']); ?>" placeholder="z. B. Logistik"></label><label class="full pw-smart-description-field"><span class="pw-label-row"><span>Tätigkeitsbeschreibung</span><button type="button" class="pw-assist-button" data-pw-smart-description><?php echo pw_icon('spark'); ?> Pure Assist Vorschlag</button></span><textarea name="description" rows="5" placeholder="Aufgaben, Arbeitsumfeld, Besonderheiten…"><?php echo esc_textarea($v['description']); ?></textarea><small>Erstellt lokal einen strukturierten Vorschlag aus deinen Formularangaben. Es werden keine Talentdaten an einen externen KI-Dienst übertragen.</small></label></div></section><section class="pw-form-card"><div class="pw-form-section-title"><span>02</span><div><h3>Anforderungen</h3><p>Muss- und Kann-Kriterien für Pure Match.</p></div></div><div class="pw-form-grid two"><label>Muss-Qualifikationen<input name="must_quals" list="pw-qualifications" value="<?php echo esc_attr(pw_list_string($v['must_quals'])); ?>" placeholder="Staplerschein, Führerschein B"></label><label>Kann-Qualifikationen<input name="nice_quals" list="pw-qualifications" value="<?php echo esc_attr(pw_list_string($v['nice_quals'])); ?>" placeholder="SAP, Automotive-Erfahrung"></label><label>Sprachkenntnisse<input name="language" list="pw-languages" value="<?php echo esc_attr($v['language']); ?>" placeholder="z. B. Deutsch B1"></label><label class="pw-toggle-label"><input type="checkbox" name="driver" value="1" <?php checked($v['driver'],'1'); ?>><span></span>Führerschein erforderlich</label></div></section><section class="pw-form-card"><div class="pw-form-section-title"><span>03</span><div><h3>Konditionen & Zielgruppe</h3><p>Optionaler Verrechnungssatz und Empfängerkreis.</p></div></div><div class="pw-form-grid two"><label>Max. Verrechnungssatz (optional)<input name="rate_max" value="<?php echo esc_attr($v['rate_max']); ?>" placeholder="z. B. 31,50 €"></label><label>Frist für Profilabgabe<input type="date" name="deadline" value="<?php echo esc_attr($v['deadline']); ?>"></label><label>Status<select name="status"><option value="open" <?php selected($v['status'],'open'); ?>>Offen</option><option value="paused" <?php selected($v['status'],'paused'); ?>>Pausiert</option><option value="filled" <?php selected($v['status'],'filled'); ?>>Besetzt</option></select></label><label>Wer soll die Personalanfrage sehen?<select name="target_mode" class="pw-target-mode"><option value="all" <?php selected($v['target_mode'],'all'); ?>>Alle passenden Personaldienstleister</option><option value="favorites" <?php selected($v['target_mode'],'favorites'); ?>>Nur Favoriten</option><option value="selected" <?php selected($v['target_mode'],'selected'); ?>>Gezielt ausgewählte</option></select></label><div class="full pw-target-agencies"><span class="pw-field-label">Ausgewählte Personaldienstleister</span><div class="pw-checkbox-grid"><?php foreach($agencies as $a): if(!pw_account_active($a->ID)) continue; ?><label class="pw-choice"><input type="checkbox" name="target_agencies[]" value="<?php echo (int)$a->ID; ?>" <?php checked(in_array($a->ID,(array)$v['target_agencies'],true)); ?>><span><b><?php echo esc_html(pw_company_alias($a->ID)); ?></b><small><?php echo esc_html(pw_user_meta($a->ID,'pw_city','')); ?> · <?php echo get_user_meta($a->ID,'pw_aug_verified',true)?'AÜG geprüft':'Verifizierung'; ?></small></span></label><?php endforeach; ?></div></div></div></section><div class="pw-form-actions"><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('vacancies')); ?>">Abbrechen</a><button class="pw-btn primary" type="submit"><?php echo $vacancy_id?'Änderungen speichern':'Personalanfrage veröffentlichen'; ?> <?php echo pw_icon('arrow'); ?></button></div></form><?php return ob_get_clean();
}

function pw_vacancy_detail_legacy47($id){
    $v=pw_vacancy_fields($id);$uid=get_current_user_id();$role=pw_user_role();
    if($role==='client' && $v['author']!==$uid && !current_user_can('manage_options')) return '<div class="pw-alert danger"><div><strong>Kein Zugriff</strong><span>Diese Personalanfrage gehört zu einem anderen Auftraggeber.</span></div></div>';
    if($role==='agency' && !pw_agency_can_see_vacancy($uid,$id)) return '<div class="pw-alert danger"><div><strong>Nicht verfügbar</strong><span>Diese Personalanfrage passt nicht zu deinen Freigaben oder Filtern.</span></div></div>';
    $clientName=pw_company_display_name($v['author'],$uid,true);$distance=pw_user_distance_to_location($uid,(float)$v['lat'],(float)$v['lng']);
    ob_start(); ?><div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('vacancies')); ?>">← Alle Personalanfragen</a><div class="pw-title-line"><h2><?php echo esc_html($v['title']); ?></h2><span class="pw-badge <?php echo $v['status']==='open'?'success':'muted'; ?>"><?php echo esc_html($v['status']==='open'?'Offen':($v['status']==='filled'?'Besetzt':'Pausiert')); ?></span></div><p><?php echo esc_html($clientName); ?> · veröffentlicht <?php echo esc_html(human_time_diff(get_post_time('U',true,$id),current_time('timestamp')).' her'); ?></p></div><?php if($role==='client'): ?><div class="pw-head-actions"><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('vacancies',['edit'=>$id])); ?>">Bearbeiten</a><a class="pw-btn danger-ghost small pw-confirm" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_vacancy_delete&id='.$id),'pw_delete_vacancy_'.$id)); ?>">Löschen</a></div><?php endif; ?></div><div class="pw-detail-grid"><section class="pw-card span2"><div class="pw-vacancy-hero"><div class="pw-vacancy-icon"><?php echo pw_icon('briefcase'); ?></div><div class="pw-keyfacts"><div><span>Bedarf</span><b><?php echo (int)$v['qty']; ?> Mitarbeiter</b></div><div><span>Einsatzort</span><b><?php echo esc_html($v['location']); ?><?php echo $distance!==null?' · '.round($distance).' km':''; ?></b></div><div><span>Start</span><b><?php echo esc_html(pw_format_date($v['start_date'])); ?></b></div><div><span>Schicht</span><b><?php echo esc_html($v['shift']?:'flexibel'); ?></b></div></div></div><hr><div class="pw-description"><h3>Aufgaben & Einsatz</h3><p><?php echo nl2br(esc_html($v['description']?:'Keine zusätzliche Tätigkeitsbeschreibung hinterlegt.')); ?></p></div><div class="pw-criteria"><div><h3>Muss-Kriterien</h3><div><?php if($v['must_quals'])foreach($v['must_quals'] as $q)echo '<span>'.pw_icon('check').esc_html($q).'</span>';else echo '<small>Keine Muss-Kriterien</small>'; ?><?php if($v['language'])echo '<span>'.pw_icon('check').esc_html($v['language']).'</span>'; ?><?php if($v['driver'])echo '<span>'.pw_icon('check').'Führerschein</span>'; ?></div></div><div><h3>Kann-Kriterien</h3><div><?php if($v['nice_quals'])foreach($v['nice_quals'] as $q)echo '<span class="soft">'.esc_html($q).'</span>';else echo '<small>Keine zusätzlichen Kriterien</small>'; ?></div></div></div></section><aside class="pw-card"><span class="pw-kicker">RAHMENDATEN</span><div class="pw-side-facts"><div><span>Branche</span><b><?php echo esc_html($v['industry']?:'–'); ?></b></div><div><span>Einsatzdauer</span><b><?php echo esc_html($v['duration']?:'–'); ?></b></div><div><span>Wochenstunden</span><b><?php echo esc_html($v['hours']?:'–'); ?></b></div><div><span>Profilfrist</span><b><?php echo esc_html(pw_format_date($v['deadline'])); ?></b></div><div><span>Max. Satz</span><b><?php echo esc_html($v['rate_max']?:'nicht angegeben'); ?></b></div></div></aside></div><?php
    if($role==='agency'){
        $matches=pw_best_workers_for_vacancy($id,$uid,20);echo '<section class="pw-card pw-detail-section"><div class="pw-card-head"><div><span class="pw-kicker">PURE MATCH</span><h2>'.count($matches).' passende Profile aus deinem Pool</h2></div><a href="'.esc_url(pw_page_url('workers',['new'=>1])).'">+ Profil anlegen</a></div>';
        if(!$matches)echo '<div class="pw-empty compact">'.pw_icon('users').'<h3>Kein passendes Profil gefunden</h3><p>Lege weitere Talentprofile an oder prüfe die Anforderungen.</p></div>'; else {echo '<div class="pw-worker-match-grid">';foreach($matches as $item){$w=pw_worker_fields($item['worker']->ID);$exists=pw_submission_exists($id,$w['id']);?><article><div class="pw-worker-match-top"><span class="pw-profile-code"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><b><?php echo esc_html($w['role']); ?></b><small><?php echo esc_html($w['code']); ?> · <?php echo (int)$w['experience']; ?> Jahre</small></div><div class="pw-score small <?php echo $item['match']['score']>=85?'high':''; ?>"><strong><?php echo (int)$item['match']['score']; ?>%</strong></div></div><div class="pw-reasons"><?php foreach($item['match']['reasons'] as $r)echo '<span>'.pw_icon('check').esc_html($r).'</span>'; ?></div><?php if($exists): ?><div class="pw-already-submitted">✓ Bereits eingereicht</div><?php else: ?><form class="pw-inline-submit" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_submit_profile"><input type="hidden" name="vacancy_id" value="<?php echo (int)$id; ?>"><input type="hidden" name="worker_id" value="<?php echo (int)$w['id']; ?>"><?php wp_nonce_field('pw_submit_profile'); ?><div><label>Verrechnungssatz<input name="rate" placeholder="z. B. 31,50 €"></label><label>Frühester Start<input type="date" name="earliest" value="<?php echo esc_attr($w['available_from']); ?>"></label></div><label>Hinweis<textarea name="note" rows="2" placeholder="Optionaler Hinweis"></textarea></label><button class="pw-btn primary full small">Profil einreichen</button></form><?php endif; ?></article><?php }echo '</div>';}
        echo '</section>';
    } else {
        $subs=get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC','meta_query'=>[['key'=>'pw_vacancy_id','value'=>$id]]]);
        echo '<section class="pw-card pw-detail-section"><div class="pw-card-head"><div><span class="pw-kicker">EINGEGANGENE PROFILE</span><h2>'.count($subs).' Angebote</h2></div></div>';
        if(!$subs)echo '<div class="pw-empty compact">'.pw_icon('users').'<h3>Noch keine Profile</h3><p>Passende Personaldienstleister wurden informiert. Du kannst zusätzlich den Talent Pool durchsuchen.</p><a class="pw-btn small primary" href="'.esc_url(pw_page_url('workers')).'">Talent Pool öffnen</a></div>'; else {echo '<div class="pw-submission-table"><div class="head"><span>Profil</span><span>Erfahrung</span><span>Entfernung</span><span>Verfügbar</span><span>Preis</span><span>Status</span><span></span></div>';foreach($subs as $s){$w=pw_worker_fields((int)pw_meta($s->ID,'pw_worker_id',0));$match=pw_match_worker_to_vacancy($w['id'],$id);?><a class="row" href="<?php echo esc_url(pw_page_url('vacancies',['submission'=>$s->ID])); ?>"><span><b><?php echo esc_html($w['code']); ?></b><small><?php echo esc_html($w['role']); ?></small></span><span><?php echo (int)$w['experience']; ?> Jahre</span><span><?php echo $match['distance']!==null?round($match['distance']).' km':'–'; ?></span><span><?php echo esc_html(pw_format_date($w['available_from'])); ?></span><span><?php echo esc_html(pw_meta($s->ID,'pw_rate','–')?:'–'); ?></span><span><?php echo pw_status_badge(pw_meta($s->ID,'pw_status','submitted')); ?></span><span><?php echo pw_icon('arrow'); ?></span></a><?php }echo '</div>';}
        echo '</section>';
    }
    return ob_get_clean();
}

function pw_submission_detail_legacy47($sid){
    if(!pw_can_access_submission($sid)) return '<div class="pw-alert danger"><div><strong>Kein Zugriff</strong><span>Du bist an dieser Anfrage nicht beteiligt.</span></div></div>';
    pw_mark_submission_viewed($sid);$wid=(int)pw_meta($sid,'pw_worker_id',0);$vid=(int)pw_meta($sid,'pw_vacancy_id',0);$w=pw_worker_fields($wid);$v=pw_vacancy_fields($vid);$role=pw_user_role();$status=pw_meta($sid,'pw_status','submitted');$released=pw_meta($sid,'pw_released','0')==='1'||in_array($status,['confirmed','planned'],true);$match=pw_match_worker_to_vacancy($wid,$vid);$agency=(int)pw_meta($sid,'pw_agency_id',0);
    ob_start(); ?><div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$vid])); ?>">← Zur Personalanfrage</a><h2><?php echo esc_html($w['role'].' · '.$w['code']); ?></h2><p>Eingereicht auf „<?php echo esc_html($v['title']); ?>“ · <?php echo esc_html(pw_company_display_name($agency,get_current_user_id(),false)); ?></p></div><?php echo pw_status_badge($status); ?></div><div class="pw-profile-detail-grid"><section class="pw-card span2"><div class="pw-profile-hero"><div class="pw-profile-code large"><?php echo esc_html(pw_initials($w['role'])); ?></div><div><span class="pw-kicker">ANONYMISIERTES PROFIL</span><h2><?php echo esc_html($w['role']); ?></h2><p><?php echo esc_html($w['experience']); ?> Jahre Erfahrung · <?php echo esc_html($w['location']); ?></p></div><div class="pw-match-ring small"><b><?php echo (int)$match['score']; ?></b><span>Match</span></div></div><div class="pw-profile-facts"><div><span>Verfügbarkeit</span><b><?php echo esc_html(pw_format_date($w['available_from'])); ?></b></div><div><span>Schichten</span><b><?php echo esc_html(pw_list_string($w['shifts'])?:'–'); ?></b></div><div><span>Mobilität</span><b><?php echo $w['car']?'PKW vorhanden':($w['driver']?'Führerschein':'–'); ?></b></div><div><span>Letzter Einsatz</span><b><?php echo esc_html($w['last_assignment']?:'–'); ?></b></div></div><div class="pw-profile-sections"><div><h3>Qualifikationen</h3><div class="pw-chip-list"><?php foreach($w['qualifications'] as $q)echo '<span>'.esc_html($q).'</span>'; ?></div></div><div><h3>Sprachen</h3><div class="pw-chip-list"><?php foreach($w['languages'] as $q)echo '<span>'.esc_html($q).'</span>'; ?></div></div><div><h3>Branchenerfahrung</h3><div class="pw-chip-list"><?php foreach($w['industries'] as $q)echo '<span>'.esc_html($q).'</span>'; ?></div></div></div><?php if($released): ?><div class="pw-release-box"><div class="pw-release-title"><?php echo pw_icon('lock'); ?><div><span class="pw-kicker">DATEN FREIGEGEBEN</span><h3>Identität & Kontaktdaten</h3></div></div><div class="pw-profile-facts private"><div><span>Name</span><b><?php echo esc_html($w['full_name']?:'nicht hinterlegt'); ?></b></div><div><span>E-Mail</span><b><?php echo esc_html($w['email']?:'–'); ?></b></div><div><span>Telefon</span><b><?php echo esc_html($w['phone']?:'–'); ?></b></div><div><span>Anschrift</span><b><?php echo esc_html($w['address']?:'–'); ?></b></div></div><div class="pw-file-links"><?php if($w['cv_file'])echo '<a class="pw-btn small ghost" href="'.esc_url(pw_file_download_url((int)$w['cv_file'])).'">Lebenslauf herunterladen</a>'; ?><?php if($w['docs_file'])echo '<a class="pw-btn small ghost" href="'.esc_url(pw_file_download_url((int)$w['docs_file'])).'">Nachweise herunterladen</a>'; ?></div></div><?php else: ?><div class="pw-anon-note"><?php echo pw_icon('lock'); ?><div><b>Identität geschützt</b><p>Name, Kontaktdaten, genaue Anschrift und Originaldokumente bleiben bis zur Freigabe verborgen.</p></div></div><?php endif; ?></section><aside class="pw-card"><span class="pw-kicker">ANGEBOT</span><div class="pw-side-facts"><div><span>Verrechnungssatz</span><b><?php echo esc_html(pw_meta($sid,'pw_rate','–')?:'–'); ?></b></div><div><span>Frühester Start</span><b><?php echo esc_html(pw_format_date(pw_meta($sid,'pw_earliest',''))); ?></b></div><div><span>Hinweis</span><b><?php echo esc_html(pw_meta($sid,'pw_note','–')?:'–'); ?></b></div></div><?php if($role==='client'): ?><hr><div class="pw-status-actions"><span>Status ändern</span><?php foreach(['shortlisted','requested','confirmed','planned','rejected'] as $st){$lbl=pw_status_labels()[$st][0];?><button class="pw-status-btn <?php echo $status===$st?'active':''; ?>" data-submission="<?php echo (int)$sid; ?>" data-status="<?php echo esc_attr($st); ?>"><?php echo esc_html($lbl); ?></button><?php } ?></div><?php else: if($status==='requested'&&!$released): ?><hr><div class="pw-release-action"><b>Konkrete Anfrage erhalten</b><p>Du kannst jetzt die für den weiteren Prozess erforderlichen Profildaten freigeben.</p><a class="pw-btn primary full small" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_release_profile&submission='.$sid),'pw_release_'.$sid)); ?>">Profildaten freigeben</a></div><?php endif; endif; ?><hr><a class="pw-btn ghost full small" href="<?php echo esc_url(pw_page_url('messages',['thread'=>$sid])); ?>"><?php echo pw_icon('message'); ?> Chat öffnen</a></aside></div><?php return ob_get_clean();
}

function pw_shortcode_vacancies_legacy47(){
    if(!is_user_logged_in())return pw_require_login_html();$role=pw_user_role();$uid=get_current_user_id();
    ob_start();echo pw_portal_shell_start('Personalanfragen',$role==='client'?'Personalbedarf erstellen und Profile vergleichen':'Passende Personalbedarfe in deinem Einsatzgebiet');echo pw_flash_messages();
    $access_gate=current_user_can('manage_options')?'':pw_verified_gate($role==='client'?'Personalanfragen veröffentlichen und Profile vergleichen':'passende Personalanfragen sehen und Profile einreichen');
    if($access_gate){echo $access_gate;echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['submission'])){echo pw_submission_detail((int)$_GET['submission']);echo pw_portal_shell_end();return ob_get_clean();}
    if($role==='client'&&(isset($_GET['new'])||isset($_GET['edit']))){echo pw_vacancy_form(isset($_GET['edit'])?(int)$_GET['edit']:0);echo pw_portal_shell_end();return ob_get_clean();}
    if(isset($_GET['view'])){echo pw_vacancy_detail((int)$_GET['view']);echo pw_portal_shell_end();return ob_get_clean();}
    ?><div class="pw-list-toolbar"><form method="get" class="pw-search-bar"><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($_GET['q']??''); ?>" placeholder="Tätigkeit, Ort oder Branche suchen"><button>Suche</button></form><div class="pw-toolbar-actions"><?php if($role==='client'): ?><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?> Neue Personalanfrage</a><?php else: ?><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('matches')); ?>"><?php echo pw_icon('spark'); ?> Pure Match</a><?php endif; ?></div></div><?php
    $search=sanitize_text_field(wp_unslash($_GET['q']??''));$args=['post_type'=>'pw_vacancy','post_status'=>'publish','posts_per_page'=>50,'orderby'=>'date','order'=>'DESC'];if($role==='client')$args['author']=$uid;if($search)$args['s']=$search;$q=new WP_Query($args);$posts=$q->posts;if($role==='agency')$posts=array_values(array_filter($posts,function($p)use($uid){return pw_agency_can_see_vacancy($uid,$p->ID);}));
    echo '<div class="pw-vacancy-list">';if(!$posts)echo '<div class="pw-card pw-empty">'.pw_icon('briefcase').'<h3>Keine Personalanfragen gefunden</h3><p>'.($role==='client'?'Erstelle deinen ersten Personalbedarf und erreiche passende Personaldienstleister.':'Passe deine Filter an oder ergänze deinen Talent Pool.').'</p></div>';else foreach($posts as $p){$v=pw_vacancy_fields($p->ID);$distance=pw_user_distance_to_location($uid,(float)$v['lat'],(float)$v['lng']);$subCount=count(get_posts(['post_type'=>'pw_submission','post_status'=>'publish','fields'=>'ids','posts_per_page'=>-1,'meta_query'=>[['key'=>'pw_vacancy_id','value'=>$p->ID]]]));$best=$role==='agency'?pw_best_workers_for_vacancy($p->ID,$uid,5):[];?><a class="pw-vacancy-card" href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$p->ID])); ?>"><div class="pw-vacancy-card-main"><div class="pw-vacancy-card-top"><span class="pw-vacancy-icon small"><?php echo pw_icon('briefcase'); ?></span><div><h3><?php echo esc_html($v['title']); ?></h3><p><?php echo esc_html(pw_company_display_name($v['author'],$uid,true)); ?> · <?php echo esc_html($v['location']); ?><?php echo $distance!==null?' · '.round($distance).' km':''; ?></p></div></div><div class="pw-vacancy-tags"><span><?php echo (int)$v['qty']; ?> Personen</span><span>Start <?php echo esc_html(pw_format_date($v['start_date'])); ?></span><?php if($v['shift']):?><span><?php echo esc_html($v['shift']); ?></span><?php endif;?><?php if($v['industry']):?><span><?php echo esc_html($v['industry']); ?></span><?php endif;?></div></div><div class="pw-vacancy-card-side"><?php if($role==='agency'): $bestScore=$best?$best[0]['match']['score']:0;?><div class="pw-score small <?php echo $bestScore>=85?'high':''; ?>"><strong><?php echo (int)$bestScore; ?>%</strong><small>Best Match</small></div><span><?php echo count($best); ?> passende Profile</span><?php else:?><strong><?php echo (int)$subCount; ?></strong><span>eingegangene Profile</span><?php endif;?><?php echo pw_icon('arrow'); ?></div></a><?php }echo '</div>';
    if($role==='agency'){
        list($marketWhat,$marketWhere)=pw_live_market_user_defaults($uid);
        $marketFeed=pw_live_market_fetch($search?:'', $marketWhere, 30, 12, 1, false);
        echo '<section class="pw-market-opportunities"><div class="pw-card-head"><div><span class="pw-kicker">AKTUELLE MARKTCHANCEN</span><h2>Öffentlicher Personalbedarf in deiner Region</h2><p>Zusätzlich zum wachsenden Pure Work Netzwerk siehst du aktuelle öffentliche Stellenanzeigen. Mit einem Klick übernimmst du das Unternehmen ins CRM und bereitest ein Personalangebot vor.</p></div><a href="'.esc_url(pw_page_url('market_live',['market_mode'=>'direct'])).'">Alle Marktchancen</a></div><div class="pw-live-grid compact">';
        if(empty($marketFeed['items'])) echo '<div class="pw-card pw-empty span-all"><h3>Marktdaten werden aufgebaut</h3><p>Setze deinen Standort im Konto oder öffne Markt Live.</p></div>'; else foreach(array_slice($marketFeed['items'],0,8) as $mi){if(!empty($marketFeed['snapshot']))$mi['snapshot']=true;echo pw_live_market_card($mi);} echo '</div><div class="pw-source-note"><b>Wichtig:</b> Diese Anzeigen sind öffentliche Marktsignale und keine internen Pure Work Personalanfragen. Direkte Profileinreichung innerhalb Pure Work ist möglich, sobald der Auftraggeber registriert ist; externe Chancen kannst du im CRM bearbeiten.</div></section>';
    }
    echo pw_portal_shell_end();return ob_get_clean();
}
add_shortcode('pw_vacancies','pw_shortcode_vacancies');


function pw_worker_templates() {
    return [
        'warehouse'=>['label'=>'Lagerhelfer','role'=>'Lagerhelfer','shifts'=>'2-Schicht, 3-Schicht','qualifications'=>'Kommissionierung','industries'=>'Logistik'],
        'production'=>['label'=>'Produktionsmitarbeiter','role'=>'Produktionsmitarbeiter','shifts'=>'3-Schicht','qualifications'=>'Qualitätskontrolle','industries'=>'Industrie, Produktion'],
        'forklift'=>['label'=>'Staplerfahrer','role'=>'Staplerfahrer','shifts'=>'2-Schicht, 3-Schicht','qualifications'=>'Staplerschein','industries'=>'Logistik, Automotive'],
        'picker'=>['label'=>'Kommissionierer','role'=>'Kommissionierer','shifts'=>'Frühschicht, Spätschicht','qualifications'=>'Kommissionierung, Scanner','industries'=>'Logistik'],
        'machine'=>['label'=>'Maschinenbediener','role'=>'Maschinenbediener','shifts'=>'3-Schicht','qualifications'=>'Maschinenbedienung, Qualitätsprüfung','industries'=>'Produktion'],
        'welder'=>['label'=>'Schweißer','role'=>'Schweißer','shifts'=>'Tagschicht, 2-Schicht','qualifications'=>'Schweißerpass','industries'=>'Metall, Industrie'],
    ];
}

function pw_worker_template_cards() {
    $html='<div class="pw-template-starter"><div><span class="pw-kicker">SCHNELLSTART</span><h3>Talentprofil aus Vorlage starten</h3><p>Die Vorlagen legen keine fiktiven Mitarbeiter an. Sie füllen nur typische Zeitarbeitsfelder vor, damit dein echter Talent Pool schneller aufgebaut ist.</p></div><div class="pw-template-grid">';
    foreach(pw_worker_templates() as $key=>$tpl){
        $html.='<a href="'.esc_url(pw_page_url('workers',['new'=>1,'template'=>$key])).'"><span>'.pw_icon('plus').'</span><b>'.esc_html($tpl['label']).'</b><small>Profil vorbereiten</small></a>';
    }
    return $html.'</div></div>';
}

function pw_worker_form_legacy47($worker_id=0){
    $w=$worker_id?pw_worker_fields($worker_id):['id'=>0,'code'=>'','role'=>'','experience'=>0,'location'=>'','available_from'=>'','shifts'=>[],'qualifications'=>[],'languages'=>[],'driver'=>'0','car'=>'0','industries'=>[],'last_assignment'=>'','status'=>'available','cv_file'=>0,'docs_file'=>0,'full_name'=>'','email'=>'','phone'=>'','address'=>''];
    if(!$worker_id){ $template=sanitize_key(wp_unslash($_GET['template']??'')); $templates=pw_worker_templates(); if($template && isset($templates[$template])){ $tpl=$templates[$template]; $w['role']=$tpl['role']; $w['shifts']=pw_sanitize_csv_list($tpl['shifts']); $w['qualifications']=pw_sanitize_csv_list($tpl['qualifications']); $w['industries']=pw_sanitize_csv_list($tpl['industries']); $w['location']=pw_user_meta(get_current_user_id(),'pw_city',''); $w['available_from']=wp_date('Y-m-d'); }}
    ob_start(); ?><div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('workers')); ?>">← Zurück</a><h2><?php echo $worker_id?'Mitarbeiterprofil bearbeiten':'Mitarbeiterprofil anlegen'; ?></h2><p>Strukturierte Angaben sind die Grundlage für Pure Match. Private Daten bleiben geschützt.</p></div></div><form class="pw-form-stack" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_worker_save"><input type="hidden" name="worker_id" value="<?php echo (int)$w['id']; ?>"><?php wp_nonce_field('pw_worker_save'); ?><section class="pw-form-card"><div class="pw-form-section-title"><span>01</span><div><h3>Anonymisiertes Profil</h3><p>Diese Angaben sind im Marktplatz sichtbar.</p></div></div><div class="pw-form-grid two"><label>Beruf / Zielposition<input name="role" list="pw-roles" data-pw-occupation="1" autocomplete="off" required value="<?php echo esc_attr($w['role']); ?>" placeholder="z. B. Produktionsmitarbeiter"></label><label>Berufserfahrung (Jahre)<input type="number" min="0" max="60" name="experience" value="<?php echo esc_attr($w['experience']); ?>"></label><label>Region / Einsatzgebiet<input name="location" list="pw-locations" value="<?php echo esc_attr($w['location']); ?>" placeholder="z. B. Mannheim"></label><label>Verfügbar ab<input type="date" name="available_from" value="<?php echo esc_attr($w['available_from']); ?>"></label><label>Schichtbereitschaft<input name="shifts" list="pw-shifts" value="<?php echo esc_attr(pw_list_string($w['shifts'])); ?>" placeholder="2-Schicht, 3-Schicht, Nacht"></label><label>Status<select name="status"><option value="available" <?php selected($w['status'],'available'); ?>>Sofort verfügbar</option><option value="reserved" <?php selected($w['status'],'reserved'); ?>>Für Anfrage reserviert</option><option value="assigned" <?php selected($w['status'],'assigned'); ?>>Aktuell im Einsatz</option><option value="inactive" <?php selected($w['status'],'inactive'); ?>>Inaktiv</option></select></label><label class="full">Qualifikationen<input name="qualifications" list="pw-qualifications" value="<?php echo esc_attr(pw_list_string($w['qualifications'])); ?>" placeholder="Staplerschein, Schweißerpass, CNC"></label><label>Sprachen<input name="languages" list="pw-languages" value="<?php echo esc_attr(pw_list_string($w['languages'])); ?>" placeholder="Deutsch B2, Englisch A2"></label><label>Branchenkenntnisse<input name="industries" list="pw-industries" value="<?php echo esc_attr(pw_list_string($w['industries'])); ?>" placeholder="Automotive, Logistik"></label><label>Letzter Einsatz (anonym)<input name="last_assignment" value="<?php echo esc_attr($w['last_assignment']); ?>" placeholder="z. B. Automobilzulieferer, 8 Monate"></label><div class="pw-toggle-row"><label class="pw-toggle-label"><input type="checkbox" name="driver" value="1" <?php checked($w['driver'],'1'); ?>><span></span>Führerschein B</label><label class="pw-toggle-label"><input type="checkbox" name="car" value="1" <?php checked($w['car'],'1'); ?>><span></span>PKW vorhanden</label></div></div></section><section class="pw-form-card private-zone"><div class="pw-form-section-title"><span><?php echo pw_icon('lock'); ?></span><div><h3>Private Identitätsdaten</h3><p>Diese Daten werden erst in der definierten Freigabestufe sichtbar.</p></div></div><div class="pw-form-grid two"><label>Vollständiger Name<input name="full_name" value="<?php echo esc_attr($w['full_name']); ?>"></label><label>E-Mail<input type="email" name="worker_email" value="<?php echo esc_attr($w['email']); ?>"></label><label>Telefon<input name="worker_phone" value="<?php echo esc_attr($w['phone']); ?>"></label><label>Anschrift<input name="worker_address" value="<?php echo esc_attr($w['address']); ?>"></label><label>Lebenslauf<input type="file" name="cv_file" accept=".pdf,.doc,.docx"><?php if($w['cv_file']): ?><small>Vorhanden: <a href="<?php echo esc_url(pw_file_download_url((int)$w['cv_file'])); ?>">Datei öffnen</a></small><?php else:?><small>PDF/DOC/DOCX, max. 10 MB</small><?php endif; ?></label><label>Qualifikationsnachweise<input type="file" name="docs_file" accept=".pdf,.jpg,.jpeg,.png"><?php if($w['docs_file']): ?><small>Vorhanden: <a href="<?php echo esc_url(pw_file_download_url((int)$w['docs_file'])); ?>">Datei öffnen</a></small><?php else:?><small>PDF/JPG/PNG, max. 10 MB</small><?php endif; ?></label></div></section><div class="pw-form-actions"><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('workers')); ?>">Abbrechen</a><button class="pw-btn primary" type="submit">Profil speichern <?php echo pw_icon('arrow'); ?></button></div></form><?php return ob_get_clean();
}

function pw_worker_agency_detail_legacy47($id){
    $w=pw_worker_fields($id);if($w['author']!==get_current_user_id()&&!current_user_can('manage_options'))return '<div class="pw-alert danger"><div><strong>Kein Zugriff</strong><span>Dieses Profil gehört zu einer anderen Zeitarbeitsfirma.</span></div></div>';
    $subs=get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC','meta_query'=>[['key'=>'pw_worker_id','value'=>$id]]]);
    ob_start(); ?><div class="pw-page-head-inline"><div><a class="pw-back" href="<?php echo esc_url(pw_page_url('workers')); ?>">← Talent Pool</a><div class="pw-title-line"><h2><?php echo esc_html($w['role']); ?> · <?php echo esc_html($w['code']); ?></h2><?php echo pw_worker_status_badge($w['status']); ?></div><p><?php echo esc_html($w['location']); ?> · <?php echo (int)$w['experience']; ?> Jahre Erfahrung</p></div><div class="pw-head-actions"><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('workers',['edit'=>$id])); ?>">Bearbeiten</a><a class="pw-btn danger-ghost small pw-confirm" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_worker_delete&id='.$id),'pw_delete_worker_'.$id)); ?>">Löschen</a></div></div><div class="pw-profile-detail-grid"><section class="pw-card span2"><div class="pw-profile-hero"><div class="pw-profile-code large"><?php echo esc_html(pw_initials($w['role'])); ?></div><div><span class="pw-kicker">MITARBEITERPROFIL</span><h2><?php echo esc_html($w['role']); ?></h2><p><?php echo esc_html($w['code']); ?> · intern verwaltet</p></div></div><div class="pw-profile-facts"><div><span>Verfügbar ab</span><b><?php echo esc_html(pw_format_date($w['available_from'])); ?></b></div><div><span>Schicht</span><b><?php echo esc_html(pw_list_string($w['shifts'])?:'–'); ?></b></div><div><span>Mobilität</span><b><?php echo $w['car']?'PKW vorhanden':($w['driver']?'Führerschein':'–'); ?></b></div><div><span>Letzter Einsatz</span><b><?php echo esc_html($w['last_assignment']?:'–'); ?></b></div></div><div class="pw-profile-sections"><div><h3>Qualifikationen</h3><div class="pw-chip-list"><?php foreach($w['qualifications'] as $q)echo '<span>'.esc_html($q).'</span>'; ?></div></div><div><h3>Sprachen</h3><div class="pw-chip-list"><?php foreach($w['languages'] as $q)echo '<span>'.esc_html($q).'</span>'; ?></div></div><div><h3>Branchen</h3><div class="pw-chip-list"><?php foreach($w['industries'] as $q)echo '<span>'.esc_html($q).'</span>'; ?></div></div></div><div class="pw-release-box internal"><div class="pw-release-title"><?php echo pw_icon('lock'); ?><div><span class="pw-kicker">NUR INTERN</span><h3>Identität & Dokumente</h3></div></div><div class="pw-profile-facts private"><div><span>Name</span><b><?php echo esc_html($w['full_name']?:'–'); ?></b></div><div><span>E-Mail</span><b><?php echo esc_html($w['email']?:'–'); ?></b></div><div><span>Telefon</span><b><?php echo esc_html($w['phone']?:'–'); ?></b></div><div><span>Anschrift</span><b><?php echo esc_html($w['address']?:'–'); ?></b></div></div><div class="pw-file-links"><?php if($w['cv_file'])echo '<a class="pw-btn small ghost" href="'.esc_url(pw_file_download_url((int)$w['cv_file'])).'">Lebenslauf</a>'; ?><?php if($w['docs_file'])echo '<a class="pw-btn small ghost" href="'.esc_url(pw_file_download_url((int)$w['docs_file'])).'">Nachweise</a>'; ?></div></div></section><aside class="pw-card"><span class="pw-kicker">EINREICHUNGEN</span><div class="pw-big-number"><?php echo count($subs); ?></div><p>Personalanfragen, auf die dieses Profil angeboten wurde.</p><?php if($subs): ?><div class="pw-mini-history"><?php foreach(array_slice($subs,0,6) as $s):$vid=(int)pw_meta($s->ID,'pw_vacancy_id',0);?><a href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$vid])); ?>"><div><b><?php echo esc_html(get_the_title($vid)); ?></b><small><?php echo esc_html(pw_format_date(get_post_time('Y-m-d',true,$s))); ?></small></div><?php echo pw_status_badge(pw_meta($s->ID,'pw_status','submitted')); ?></a><?php endforeach; ?></div><?php endif; ?></aside></div><?php return ob_get_clean();
}

function pw_client_worker_card($post,$vacancies){
    $w=pw_worker_fields($post->ID);$uid=get_current_user_id();$distance=pw_user_distance_to_location($uid,(float)$w['lat'],(float)$w['lng']);
    ob_start(); ?><article class="pw-pool-card"><div class="pw-pool-head"><span class="pw-profile-code"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><h3><?php echo esc_html($w['role']); ?></h3><p><?php echo esc_html($w['code']); ?> · <?php echo esc_html(pw_company_alias($w['author'])); ?></p></div><?php echo pw_worker_status_badge($w['status']); ?></div><div class="pw-pool-facts"><span><?php echo pw_icon('map'); ?> <?php echo esc_html($w['location']?:'Region offen'); ?><?php echo $distance!==null?' · '.round($distance).' km':''; ?></span><span><?php echo pw_icon('clock'); ?> ab <?php echo esc_html(pw_format_date($w['available_from'])); ?></span><span><?php echo pw_icon('briefcase'); ?> <?php echo (int)$w['experience']; ?> Jahre</span></div><div class="pw-chip-list small"><?php foreach(array_slice($w['qualifications'],0,4) as $q)echo '<span>'.esc_html($q).'</span>'; ?></div><div class="pw-pool-actions"><?php if($vacancies): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_client_pool_request"><input type="hidden" name="worker_id" value="<?php echo (int)$w['id']; ?>"><?php wp_nonce_field('pw_client_pool_request'); ?><select name="vacancy_id" required><option value="">Für Personalanfrage auswählen…</option><?php foreach($vacancies as $vid)echo '<option value="'.(int)$vid.'">'.esc_html(get_the_title($vid)).'</option>'; ?></select><button class="pw-btn primary small">Personal anfragen</button></form><?php else: ?><a class="pw-btn primary small" href="<?php echo esc_url(pw_page_url('vacancies',['new'=>1])); ?>">Erst Personalanfrage erstellen</a><?php endif; ?><button class="pw-favorite-btn" data-company="<?php echo (int)$w['author']; ?>" aria-label="Personaldienstleister favorisieren">♡</button></div></article><?php return ob_get_clean();
}

function pw_shortcode_workers_legacy47(){
    if(!is_user_logged_in())return pw_require_login_html();$role=pw_user_role();$uid=get_current_user_id();$title=$role==='agency'?'Talent Pool':'Talent Pool';$subtitle=$role==='agency'?'Verfügbare Mitarbeiter zentral verwalten':'Anonymisierte, verfügbare Profile durchsuchen';
    ob_start();echo pw_portal_shell_start($title,$subtitle);echo pw_flash_messages();
    $access_gate=current_user_can('manage_options')?'':pw_verified_gate($role==='agency'?'Talentprofile verwalten und anbieten':'den Talent Pool durchsuchen und Personal anfragen');
    if($access_gate){echo $access_gate;echo pw_portal_shell_end();return ob_get_clean();}
    if($role==='agency'){
        if(isset($_GET['new'])||isset($_GET['edit'])){echo pw_worker_form(isset($_GET['edit'])?(int)$_GET['edit']:0);echo pw_portal_shell_end();return ob_get_clean();}
        if(isset($_GET['view'])){echo pw_worker_agency_detail((int)$_GET['view']);echo pw_portal_shell_end();return ob_get_clean();}
        ?><div class="pw-list-toolbar"><form method="get" class="pw-search-bar"><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($_GET['q']??''); ?>" placeholder="Beruf, Qualifikation oder Region suchen"><button>Suche</button></form><div class="pw-toolbar-actions"><button class="pw-btn ghost" data-modal-open="pw-import-modal"><?php echo pw_icon('upload'); ?> CSV importieren</button><a class="pw-btn primary" href="<?php echo esc_url(pw_page_url('workers',['new'=>1])); ?>"><?php echo pw_icon('plus'); ?> Talent anlegen</a></div></div><?php
        $search=sanitize_text_field(wp_unslash($_GET['q']??''));$args=['post_type'=>'pw_worker','post_status'=>'publish','author'=>$uid,'posts_per_page'=>100,'orderby'=>'date','order'=>'DESC'];if($search)$args['s']=$search;$q=new WP_Query($args);$counts=['available'=>0,'reserved'=>0,'assigned'=>0,'inactive'=>0];foreach($q->posts as $p){$st=pw_meta($p->ID,'pw_status','available');if(isset($counts[$st]))$counts[$st]++;}
        echo '<div class="pw-mini-stats">'.pw_metric(count($q->posts),'Profile insgesamt').pw_metric($counts['available'],'sofort verfügbar','','success').pw_metric($counts['reserved'],'reserviert','','warning').pw_metric($counts['assigned'],'im Einsatz','','info').'</div><div class="pw-worker-list">';if(!$q->posts){ echo '<div class="pw-card pw-empty">'.pw_icon('users').'<h3>Dein Talent Pool ist noch leer</h3><p>Lege einzelne Profile an, starte mit einer typischen Vorlage oder importiere mehrere Mitarbeiter per CSV.</p><a class="pw-btn primary small" href="'.esc_url(pw_page_url('workers',['new'=>1])).'">Erstes Profil anlegen</a></div>'; echo pw_worker_template_cards(); }else foreach($q->posts as $p){$w=pw_worker_fields($p->ID);$subCount=count(get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_worker_id','value'=>$p->ID]]]));?><a class="pw-worker-row" href="<?php echo esc_url(pw_page_url('workers',['view'=>$p->ID])); ?>"><span class="pw-profile-code"><?php echo esc_html(pw_initials($w['role'])); ?></span><div class="pw-worker-row-main"><h3><?php echo esc_html($w['role']); ?> <small><?php echo esc_html($w['code']); ?></small></h3><p><?php echo esc_html($w['location']?:'Keine Region'); ?> · <?php echo (int)$w['experience']; ?> Jahre · <?php echo esc_html(pw_list_string(array_slice($w['qualifications'],0,3))); ?></p></div><div><span class="pw-worker-date">ab <?php echo esc_html(pw_format_date($w['available_from'])); ?></span><?php echo pw_worker_status_badge($w['status']); ?></div><div class="pw-worker-subcount"><b><?php echo (int)$subCount; ?></b><span>Einreichungen</span></div><?php echo pw_icon('arrow'); ?></a><?php }echo '</div>'; ?>
        <div class="pw-modal" id="pw-import-modal" aria-hidden="true"><div class="pw-modal-backdrop" data-modal-close></div><div class="pw-modal-card"><button class="pw-modal-x" data-modal-close>×</button><span class="pw-kicker">MASSENIMPORT</span><h2>Mitarbeiter per CSV importieren</h2><p>Bis zu 500 Profile auf einmal. Verwende die Spalten: <code>role, experience, location, available_from, shifts, qualifications, languages, driver, car, industries, last_assignment, full_name, email, phone, address</code>.</p><a class="pw-btn ghost full small" href="<?php echo esc_url(PW_URI . '/assets/sample-import.csv'); ?>" download>Beispiel-CSV herunterladen</a><form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_worker_import"><?php wp_nonce_field('pw_worker_import'); ?><label>CSV-Datei<input type="file" name="csv_file" accept=".csv,text/csv" required></label><button class="pw-btn primary full">CSV importieren</button></form></div></div>
        <?php
    }else{
        $vacancies=get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_status','value'=>'open']]]);
        $search=sanitize_text_field(wp_unslash($_GET['q']??''));$loc=sanitize_text_field(wp_unslash($_GET['loc']??''));$q=new WP_Query(['post_type'=>'pw_worker','post_status'=>'publish','posts_per_page'=>100,'orderby'=>'date','order'=>'DESC','meta_query'=>[['key'=>'pw_status','value'=>['available','reserved'],'compare'=>'IN']]]);
        $posts=array_values(array_filter($q->posts,function($p)use($search,$loc,$uid){$w=pw_worker_fields($p->ID);if(pw_is_demo_user($w['author'])!==pw_is_demo_user($uid))return false;if(!pw_agency_has_access($w['author']))return false;$hay=pw_normalize_text($w['role'].' '.pw_list_string($w['qualifications']).' '.pw_list_string($w['industries']));if($search&&!pw_contains($hay,pw_normalize_text($search)))return false;if($loc&&!pw_contains(pw_normalize_text($w['location']),pw_normalize_text($loc)))return false;return pw_account_active($w['author']);}));
        ?><div class="pw-pool-filter"><form method="get"><label><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($search); ?>" placeholder="Beruf oder Qualifikation"></label><label><?php echo pw_icon('map'); ?><input name="loc" value="<?php echo esc_attr($loc); ?>" placeholder="Region / Ort"></label><button class="pw-btn primary">Profile suchen</button></form></div><div class="pw-pool-headline"><div><h2><?php echo count($posts); ?> verfügbare Profile</h2><p>Identitäten und direkte Kontaktdaten bleiben bis zur Freigabe anonymisiert.</p></div><span class="pw-privacy-pill"><?php echo pw_icon('lock'); ?> geschützt</span></div><div class="pw-pool-grid"><?php if(!$posts)echo '<div class="pw-card pw-empty span-all">'.pw_icon('search').'<h3>Noch keine passenden Netzwerkprofile</h3><p>Pure Work zeigt ausschließlich echte Profile registrierter Personaldienstleister. Erstelle jetzt eine Personalanfrage oder nutze Direkt-Leads mit geprüften AÜ-Bedarfen.</p><div class="pw-empty-actions"><a class="pw-btn primary small" href="'.esc_url(pw_page_url('vacancies',['new'=>1])).'">Personalanfrage erstellen</a><a class="pw-btn ghost small" href="'.esc_url(pw_page_url('market_live')).'">Direkt-Leads öffnen</a></div></div>';else foreach($posts as $p)echo pw_client_worker_card($p,$vacancies); ?></div><?php
    }
    echo pw_portal_shell_end();return ob_get_clean();
}
add_shortcode('pw_workers','pw_shortcode_workers');

function pw_shortcode_matches_legacy47(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();$role=pw_user_role();ob_start();echo pw_portal_shell_start('Pure Match','Nachvollziehbares Matching statt Blackbox');echo pw_flash_messages();
    $access_gate=current_user_can('manage_options')?'':pw_verified_gate('Pure Match vollständig nutzen');
    if($access_gate){echo $access_gate;echo pw_portal_shell_end();return ob_get_clean();}
    ?><div class="pw-match-intro"><div><span class="pw-kicker">REGELBASIERT & TRANSPARENT</span><h2>Warum passt ein Profil?</h2><p>Pure Match bewertet Entfernung, Tätigkeit, Verfügbarkeit, Schichtbereitschaft, Muss-Qualifikationen, Sprache, Mobilität und Branchenerfahrung.</p></div><div class="pw-match-scale"><span>0</span><div><i style="width:78%"></i></div><strong>78%</strong></div></div><?php
    if($role==='agency'){
        $items=pw_best_vacancies_for_agency($uid,100);if(!$items)echo '<div class="pw-card pw-empty">'.pw_icon('spark').'<h3>Noch keine Matches</h3><p>Ergänze deinen Talent Pool und die Einsatzregion. Neue passende Personalanfragen erscheinen automatisch.</p><a class="pw-btn primary small" href="'.esc_url(pw_page_url('workers',['new'=>1])).'">Talent anlegen</a></div>';else {echo '<div class="pw-match-board">';foreach($items as $item){$v=pw_vacancy_fields($item['vacancy']->ID);?><article class="pw-match-vacancy"><div class="pw-match-vacancy-head"><div><span class="pw-kicker">PERSONALANFRAGE</span><h3><?php echo esc_html($v['title']); ?></h3><p><?php echo esc_html($v['location']); ?> · <?php echo (int)$v['qty']; ?> Personen · Start <?php echo esc_html(pw_format_date($v['start_date'])); ?></p></div><div class="pw-score <?php echo $item['best_score']>=85?'high':''; ?>"><strong><?php echo (int)$item['best_score']; ?>%</strong><small>Best Match</small></div></div><div class="pw-match-workers"><?php foreach(array_slice($item['workers'],0,4) as $m){$w=pw_worker_fields($m['worker']->ID);?><div><span class="pw-profile-code small"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><b><?php echo esc_html($w['code'].' · '.$w['role']); ?></b><small><?php echo esc_html(implode(' · ',$m['match']['reasons'])); ?></small></div><strong><?php echo (int)$m['match']['score']; ?>%</strong></div><?php } ?></div><a class="pw-btn ghost full small" href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$v['id']])); ?>">Personalanfrage öffnen & Profile einreichen <?php echo pw_icon('arrow'); ?></a></article><?php }echo '</div>';}
    }else{
        $vacancies=get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'meta_query'=>[['key'=>'pw_status','value'=>'open']]]);if(!$vacancies)echo '<div class="pw-card pw-empty">'.pw_icon('briefcase').'<h3>Erstelle zuerst eine offene Personalanfrage</h3><p>Pure Match vergleicht danach automatisch alle verfügbaren Profile mit deinen Anforderungen.</p><a class="pw-btn primary small" href="'.esc_url(pw_page_url('vacancies',['new'=>1])).'">Personalanfrage erstellen</a></div>';else {echo '<div class="pw-match-board">';foreach($vacancies as $vac){$matches=pw_best_workers_for_vacancy($vac->ID,0,20);$matches=array_values(array_filter($matches,function($m){return pw_account_active((int)$m['worker']->post_author);}));$v=pw_vacancy_fields($vac->ID);?><article class="pw-match-vacancy"><div class="pw-match-vacancy-head"><div><span class="pw-kicker">DEINE PERSONALANFRAGE</span><h3><?php echo esc_html($v['title']); ?></h3><p><?php echo esc_html($v['location']); ?> · <?php echo count($matches); ?> mögliche Profile</p></div><a class="pw-btn ghost small" href="<?php echo esc_url(pw_page_url('vacancies',['view'=>$v['id']])); ?>">Personalanfrage öffnen</a></div><div class="pw-match-workers client"><?php if(!$matches)echo '<p class="pw-muted">Noch keine passenden Profile gefunden.</p>';else foreach(array_slice($matches,0,6) as $m){$w=pw_worker_fields($m['worker']->ID);?><div><span class="pw-profile-code small"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><b><?php echo esc_html($w['code'].' · '.$w['role']); ?></b><small><?php echo esc_html(implode(' · ',$m['match']['reasons'])); ?></small></div><strong><?php echo (int)$m['match']['score']; ?>%</strong></div><?php } ?></div></article><?php }echo '</div>';}
    }
    echo pw_portal_shell_end();return ob_get_clean();
}
add_shortcode('pw_matches','pw_shortcode_matches');

function pw_user_threads($uid){
    if(pw_user_role($uid)==='agency') return get_posts(['post_type'=>'pw_submission','post_status'=>'publish','posts_per_page'=>100,'orderby'=>'modified','order'=>'DESC','meta_query'=>[['key'=>'pw_agency_id','value'=>$uid]]]);
    return pw_client_submissions($uid);
}

function pw_thread_messages($sid){
    return get_posts(['post_type'=>'pw_message','post_status'=>'publish','posts_per_page'=>200,'orderby'=>'date','order'=>'ASC','meta_query'=>[['key'=>'pw_submission_id','value'=>$sid]]]);
}

function pw_shortcode_messages_legacy47(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();
    if(!current_user_can('manage_options')){$access_gate=pw_verified_gate('Nachrichten und laufende Personalanfragen öffnen');if($access_gate){ob_start();echo pw_portal_shell_start('Nachrichten','Kommunikation direkt an Personalanfrage und Profil gebunden');echo $access_gate;echo pw_portal_shell_end();return ob_get_clean();}}
    $threads=pw_user_threads($uid);$threadId=(int)($_GET['thread']??($threads?$threads[0]->ID:0));if($threadId&&!pw_can_access_submission($threadId,$uid))$threadId=0;
    if($threadId){foreach(pw_thread_messages($threadId) as $m){if((int)pw_meta($m->ID,'pw_recipient',0)===$uid)update_post_meta($m->ID,'pw_read','1');}}
    ob_start();echo pw_portal_shell_start('Nachrichten','Kommunikation direkt an Personalanfrage und Profil gebunden');echo pw_flash_messages();?><div class="pw-chat-layout"><aside class="pw-chat-sidebar"><div class="pw-chat-search"><?php echo pw_icon('search'); ?><input placeholder="Unterhaltung suchen" data-thread-filter></div><div class="pw-thread-list"><?php if(!$threads):?><div class="pw-empty tiny"><p>Noch keine Unterhaltungen.</p></div><?php else:foreach($threads as $t):$wid=(int)pw_meta($t->ID,'pw_worker_id',0);$vid=(int)pw_meta($t->ID,'pw_vacancy_id',0);$w=pw_worker_fields($wid);[$agency,$client]=pw_submission_parties($t->ID);$other=$uid===$agency?$client:$agency;$last=pw_thread_messages($t->ID);$last=end($last);$unread=0;if($last&&(int)pw_meta($last->ID,'pw_recipient',0)===$uid&&pw_meta($last->ID,'pw_read','0')==='0')$unread=1;?><a class="pw-thread <?php echo $threadId===$t->ID?'active':''; ?> <?php echo $unread?'unread':''; ?>" href="<?php echo esc_url(pw_page_url('messages',['thread'=>$t->ID])); ?>"><span class="pw-profile-code small"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><b><?php echo esc_html($w['code'].' · '.$w['role']); ?></b><span><?php echo esc_html(get_the_title($vid)); ?></span><small><?php echo $last?esc_html(wp_trim_words($last->post_content,7,'…')):'Noch keine Nachricht'; ?></small></div><?php if($unread):?><i></i><?php endif;?></a><?php endforeach;endif;?></div></aside><section class="pw-chat-main"><?php if(!$threadId):?><div class="pw-empty chat-empty"><?php echo pw_icon('message'); ?><h3>Noch keine aktive Unterhaltung</h3><p>Chats entstehen, sobald ein Profil eingereicht oder angefragt wurde.</p></div><?php else:$wid=(int)pw_meta($threadId,'pw_worker_id',0);$vid=(int)pw_meta($threadId,'pw_vacancy_id',0);$w=pw_worker_fields($wid);[$agency,$client]=pw_submission_parties($threadId);$other=$uid===$agency?$client:$agency;$status=pw_meta($threadId,'pw_status','submitted');$released=pw_meta($threadId,'pw_released','0')==='1';?><header class="pw-chat-head"><div><span class="pw-profile-code small"><?php echo esc_html(pw_initials($w['role'])); ?></span><div><h3><?php echo esc_html($w['code'].' · '.$w['role']); ?></h3><p><?php echo esc_html(get_the_title($vid)); ?> · <?php echo esc_html(pw_company_display_name($other,$uid,false)); ?></p></div></div><?php echo pw_status_badge($status); ?></header><div class="pw-chat-messages" data-thread="<?php echo (int)$threadId; ?>"><?php $messages=pw_thread_messages($threadId);if(!$messages):?><div class="pw-chat-system"><span>Unterhaltung gestartet</span><p>Nachrichten in diesem Chat sind der konkreten Profilanfrage zugeordnet.</p></div><?php else:foreach($messages as $m):$mine=(int)$m->post_author===$uid;?><div class="pw-message <?php echo $mine?'mine':'theirs'; ?>"><div><?php echo nl2br(esc_html($m->post_content)); ?><small><?php echo esc_html(wp_date('d.m. · H:i',get_post_time('U',true,$m))); ?></small></div></div><?php endforeach;endif;?></div><form class="pw-chat-compose" data-chat-form><input type="hidden" name="submission_id" value="<?php echo (int)$threadId; ?>"><textarea name="message" rows="1" placeholder="Nachricht schreiben…" required></textarea><button class="pw-btn primary small" type="submit">Senden <?php echo pw_icon('arrow'); ?></button></form><?php if(pw_user_role()==='agency'&&$status==='requested'&&!$released):?><div class="pw-chat-release"><div><?php echo pw_icon('lock'); ?><div><b>Personalanfrage erhalten</b><span>Gib die erweiterten Profildaten frei, wenn du fortfahren möchtest.</span></div></div><a class="pw-btn small" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_release_profile&submission='.$threadId),'pw_release_'.$threadId)); ?>">Daten freigeben</a></div><?php endif;endif;?></section></div><?php echo pw_portal_shell_end();return ob_get_clean();
}
add_shortcode('pw_messages','pw_shortcode_messages');

function pw_shortcode_companies(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();$role=pw_user_role();$targetRole=$role==='agency'?'pw_client':'pw_agency';$title=$role==='agency'?'Auftraggeber':'Personaldienstleister';$subtitle=$role==='agency'?'Unternehmen, Marktchancen und Partner in deinem Einsatzgebiet':'Personaldienstleister und Partner für deinen Personalbedarf';
    ob_start();echo pw_portal_shell_start($title,$subtitle);
    $access_gate=current_user_can('manage_options')?'':pw_verified_gate('Unternehmen im Marktplatz entdecken');
    if($access_gate){echo $access_gate;echo pw_portal_shell_end();return ob_get_clean();}
    $search=sanitize_text_field(wp_unslash($_GET['q']??''));$users=get_users(['role'=>$targetRole,'number'=>200]);$users=array_values(array_filter($users,function($u)use($search,$uid){if(!pw_account_active($u->ID))return false;if(pw_user_role($u->ID)==='agency'&&!pw_agency_has_access($u->ID))return false;if(pw_is_demo_user($u->ID)!==pw_is_demo_user($uid))return false;if(!$search)return true;$hay=pw_normalize_text(pw_user_meta($u->ID,'pw_city','').' '.pw_user_meta($u->ID,'pw_industry','').' '.pw_company_alias($u->ID));return pw_contains($hay,pw_normalize_text($search));}));usort($users,function($a,$b)use($uid){$da=pw_distance_km((float)pw_user_meta($uid,'pw_lat',0),(float)pw_user_meta($uid,'pw_lng',0),(float)pw_user_meta($a->ID,'pw_lat',0),(float)pw_user_meta($a->ID,'pw_lng',0));$db=pw_distance_km((float)pw_user_meta($uid,'pw_lat',0),(float)pw_user_meta($uid,'pw_lng',0),(float)pw_user_meta($b->ID,'pw_lat',0),(float)pw_user_meta($b->ID,'pw_lng',0));return ($da??99999)<=>($db??99999);});$favs=array_map('intval',(array)pw_user_meta($uid,'pw_favorites',[]));$blocked=array_map('intval',(array)pw_user_meta($uid,'pw_blocked_companies',[]));
    $marketLeads=$role==='agency'?array_slice(array_values(pw_direct_leads_all()),0,24):[];
    ?><div class="pw-list-toolbar"><form method="get" class="pw-search-bar"><?php echo pw_icon('search'); ?><input name="q" value="<?php echo esc_attr($search); ?>" placeholder="Ort, Branche oder Unternehmen suchen"><button>Suche</button></form><div class="pw-toolbar-actions"><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('crm')); ?>">CRM öffnen</a><span class="pw-result-count"><?php echo count($users); ?> Pure Work Partner<?php if($role==='agency'):?> · <?php echo count($marketLeads); ?> Direkt-Leads<?php endif;?></span></div></div>
    <div class="pw-company-radar"><div><span class="pw-kicker">UNTERNEHMENSRADAR</span><h2>Partner & Marktchancen in deiner Umgebung</h2><p>Registrierte Pure Work Unternehmen und geprüfte AÜ-Direkt-Leads werden klar getrennt. Keine beliebigen Stellenanzeigen, sondern konkrete Arbeitnehmerüberlassungs-Bedarfe mit veröffentlichter Kontaktstelle.</p></div><div class="pw-radar-visual"><i></i><i></i><i></i><span class="center">PW</span><?php $radarCount=max(count($users),count($marketLeads));for($i=0;$i<min(5,$radarCount);$i++):?><span class="dot d<?php echo $i+1; ?>"></span><?php endfor;?></div></div>
    <section class="pw-partner-section"><div class="pw-card-head"><div><span class="pw-kicker">PURE WORK NETZWERK</span><h2><?php echo $role==='agency'?'Registrierte Auftraggeber':'Verifizierte Personaldienstleister'; ?></h2><p>Diese Unternehmen sind echte Pure Work Nutzer. Direkte Zusammenarbeit, Profilanfragen und Nachrichten laufen innerhalb der Plattform.</p></div></div><div class="pw-company-grid"><?php if(!$users):?><div class="pw-card pw-community-growing span-all"><div class="pw-community-orbit"><i></i><i></i><span>PW</span></div><div><h3>Das Netzwerk wächst gerade.</h3><p>Noch kein passender registrierter Partner in deiner Suche. Darunter findest du geprüfte AÜ-Direkt-Leads mit zuständiger Vergabe-/Beschaffungskontaktstelle.</p></div></div><?php else:foreach($users as $u):$distance=pw_distance_km((float)pw_user_meta($uid,'pw_lat',0),(float)pw_user_meta($uid,'pw_lng',0),(float)pw_user_meta($u->ID,'pw_lat',0),(float)pw_user_meta($u->ID,'pw_lng',0));$isFav=in_array($u->ID,$favs,true);$isBlocked=in_array($u->ID,$blocked,true);?><article class="pw-company-card <?php echo $isBlocked?'blocked':''; ?>"><div class="pw-company-logo"><?php echo esc_html(pw_initials(pw_company_alias($u->ID))); ?></div><div class="pw-company-title"><div><h3><?php echo esc_html(pw_company_display_name($u->ID,$uid,true)); ?></h3><p><?php echo esc_html(pw_user_meta($u->ID,'pw_city','Standort offen')); ?><?php echo $distance!==null?' · '.round($distance).' km':''; ?></p></div><?php if($targetRole==='pw_agency'&&get_user_meta($u->ID,'pw_aug_verified',true)):?><span class="pw-verified">✓ AÜG geprüft</span><?php endif;?></div><div class="pw-company-body"><span><?php echo esc_html(pw_user_meta($u->ID,'pw_industry','Branchenübergreifend')); ?></span><div class="pw-company-metrics"><div><b><?php echo $targetRole==='pw_agency'?count(get_posts(['post_type'=>'pw_worker','post_status'=>'publish','author'=>$u->ID,'posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_status','value'=>'available']]])):count(get_posts(['post_type'=>'pw_vacancy','post_status'=>'publish','author'=>$u->ID,'posts_per_page'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'pw_status','value'=>'open']]])); ?></b><small><?php echo $targetRole==='pw_agency'?'verfügbare Profile':'offene Personalanfragen'; ?></small></div><div><b><?php echo esc_html(pw_user_meta($u->ID,'pw_response_time','–')); ?></b><small>Reaktionszeit</small></div></div></div><div class="pw-company-actions"><button class="pw-btn small <?php echo $isFav?'primary':'ghost'; ?> pw-favorite-btn" data-company="<?php echo (int)$u->ID; ?>"><?php echo $isFav?'★ Favorit':'☆ Favorisieren'; ?></button><button class="pw-more-btn pw-block-btn" data-company="<?php echo (int)$u->ID; ?>" title="<?php echo $isBlocked?'Entsperren':'Stummschalten'; ?>">•••</button></div></article><?php endforeach;endif;?></div></section>
    <?php if($role==='agency') echo pw_direct_leads_widget($uid,6,'partners'); else echo '<section class="pw-card pw-community-growing"><div><span class="pw-kicker">PURE WORK NETZWERK</span><h3>Dein Partnernetzwerk wächst mit jeder Registrierung.</h3><p>Als Auftraggeber findest du hier registrierte und verifizierte Personaldienstleister. Öffentliche AÜ-Direkt-Leads sind ein Vertriebswerkzeug für Zeitarbeitsfirmen.</p></div></section>'; ?>
    <?php echo pw_portal_shell_end();return ob_get_clean();
}

add_shortcode('pw_companies','pw_shortcode_companies');

function pw_account_tabs($active){
    $tabs=['profile'=>'Unternehmen','verification'=>'Verifizierung'];if(pw_user_role()==='agency'){$tabs['notifications']='Benachrichtigungen';}$tabs['security']='Sicherheit';$html='<nav class="pw-tabs">';foreach($tabs as $key=>$label)$html.='<a class="'.($active===$key?'active':'').'" href="'.esc_url(pw_page_url('account',['tab'=>$key])).'">'.esc_html($label).'</a>';$html.='</nav>';return $html;
}

function pw_shortcode_account_legacy47(){
    if(!is_user_logged_in())return pw_require_login_html();$uid=get_current_user_id();$role=pw_user_role();$tab=sanitize_key($_GET['tab']??'profile');ob_start();echo pw_portal_shell_start('Konto & Einstellungen','Unternehmen, Benachrichtigungen und Datenschutz verwalten');echo pw_flash_messages();echo pw_account_tabs($tab);
    if($tab==='profile'){?><form class="pw-account-grid" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_account_save"><?php wp_nonce_field('pw_account_save'); ?><section class="pw-form-card"><span class="pw-kicker">UNTERNEHMEN</span><h2>Stammdaten</h2><div class="pw-form-grid two"><label>Firmenname<input name="company" value="<?php echo esc_attr(pw_user_meta($uid,'pw_company','')); ?>" required></label><label>Ansprechpartner<input name="contact" value="<?php echo esc_attr(pw_user_meta($uid,'pw_contact','')); ?>" required></label><label>E-Mail<input value="<?php echo esc_attr(wp_get_current_user()->user_email); ?>" disabled><small>Die Login-E-Mail kann nur durch einen Administrator geändert werden.</small></label><label>Telefon<input name="phone" value="<?php echo esc_attr(pw_user_meta($uid,'pw_phone','')); ?>"></label><label>PLZ<input name="zip" value="<?php echo esc_attr(pw_user_meta($uid,'pw_zip','')); ?>"></label><label>Ort<input name="city" list="pw-locations" value="<?php echo esc_attr(pw_user_meta($uid,'pw_city','')); ?>"></label><label class="full">Branche / Schwerpunkt<input name="industry" list="pw-industries" value="<?php echo esc_attr(pw_user_meta($uid,'pw_industry','')); ?>"></label></div></section><?php if($role==='agency'):?><section class="pw-form-card"><span class="pw-kicker">PERSONALDIENSTLEISTER</span><h2>AÜG-Daten</h2><?php $augType=pw_user_meta($uid,'pw_aug_type','limited'); $augState=function_exists('pw_aug_state')?pw_aug_state($uid):null; $augLabel=function_exists('pw_aug_status_label')?pw_aug_status_label($uid):['Status offen','warning']; ?><div class="pw-aug-status-card <?php echo esc_attr($augLabel[1]); ?>"><span><?php echo pw_icon($augState && !empty($augState['expired'])?'lock':'clock'); ?></span><div><b><?php echo esc_html($augLabel[0]); ?></b><small><?php echo ($augState && $augState['type']==='limited' && !$augState['missing'] && !$augState['expired'] && $augState['days']<=90)?'Pure Work erinnert dich automatisch vor Ablauf. Für Verlängerungen solltest du frühzeitig handeln.':'Befristete und unbefristete Erlaubnisse werden getrennt verwaltet.'; ?></small></div></div><div class="pw-form-grid two"><label>Gültigkeit der AÜG-Erlaubnis<select name="aug_type" class="pw-aug-type"><option value="limited" <?php selected($augType,'limited'); ?>>Befristet</option><option value="unlimited" <?php selected($augType,'unlimited'); ?>>Unbefristet</option></select></label><label class="pw-aug-expiry-field">Gültig bis<input type="date" name="aug_expiry" data-agency-required="1" value="<?php echo esc_attr(pw_user_meta($uid,'pw_aug_expiry','')); ?>"></label><div class="full pw-aug-unlimited-note" hidden><span class="pw-inline-info">✓ Unbefristete Erlaubnis – kein Ablaufdatum erforderlich.</span></div><label class="full">Neue AÜG-Datei hochladen<input type="file" name="aug_file" accept=".pdf,.jpg,.jpeg,.png"><?php $fid=(int)pw_user_meta($uid,'pw_aug_file',0);if($fid):?><small><a href="<?php echo esc_url(pw_file_download_url($fid)); ?>">Aktuelle Datei herunterladen</a></small><?php endif;?></label></div></section><?php endif;?><div class="pw-form-actions full"><button class="pw-btn primary">Änderungen speichern</button></div></form><?php
    }elseif($tab==='verification'){
        $state=pw_verification_state($uid);$verified=$state['ready'];?><div class="pw-verification-layout"><section class="pw-card"><div class="pw-verification-status <?php echo $verified?'done':'pending'; ?>"><?php echo $verified?pw_icon('check'):pw_icon('clock'); ?><div><span class="pw-kicker">ZUGANGSSTATUS</span><h2><?php echo $verified?'Unternehmen vollständig verifiziert':'Konto aktiv – Marktplatzfreigabe noch offen'; ?></h2><p><?php echo $verified?'Dein Unternehmen ist vollständig verifiziert. Pure Work ist für dich aktiv.':'Du kannst dich jederzeit an- und abmelden und dein Dashboard nutzen. Sensible Marktplatzfunktionen werden nach E-Mail-, Unternehmens- und gegebenenfalls AÜG-Prüfung freigegeben.'; ?></p></div></div><div class="pw-verification-steps"><div class="<?php echo $state['email']?'done':'active'; ?>"><i><?php echo $state['email']?'✓':'1'; ?></i><div><b>E-Mail bestätigt</b><span>Geschäftliche E-Mail-Adresse wurde verifiziert</span></div></div><div class="<?php echo $state['company']?'done':($state['email']?'active':''); ?>"><i><?php echo $state['company']?'✓':'2'; ?></i><div><b>Unternehmen geprüft</b><span>Firmenangaben und Ansprechpartner</span></div></div><?php if($role==='agency'):?><div class="<?php echo $state['aug']?'done':($state['company']?'active':''); ?>"><i><?php echo $state['aug']?'✓':'3'; ?></i><div><b>AÜG geprüft</b><span>Erlaubnis, Gültigkeit und Dokument</span></div></div><?php endif;?><div class="<?php echo $verified?'done':''; ?>"><i><?php echo $verified?'✓':($role==='agency'?'4':'3'); ?></i><div><b>Marktplatz freigegeben</b><span>Personalanfragen, Matching und Kommunikation nach erfolgreicher Prüfung</span></div></div></div></section><aside class="pw-card"><span class="pw-kicker">SICHERHEIT</span><h3>Warum wir verifizieren</h3><p>Im Portal werden Talentprofile und sensible geschäftliche Informationen verarbeitet. Unternehmensverifizierung reduziert Missbrauch und schützt beide Seiten.</p><div class="pw-security-list"><span><?php echo pw_icon('lock'); ?> geschlossener B2B-Bereich</span><span><?php echo pw_icon('check'); ?> E-Mail- und Unternehmensprüfung</span><span><?php echo pw_icon('check'); ?> stufenweise Datenfreigabe</span></div></aside></div><?php
    }elseif($tab==='notifications'&&$role==='agency'){?><form class="pw-account-grid" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="pw_account_save"><?php wp_nonce_field('pw_account_save'); ?><input type="hidden" name="company" value="<?php echo esc_attr(pw_user_meta($uid,'pw_company','')); ?>"><input type="hidden" name="contact" value="<?php echo esc_attr(pw_user_meta($uid,'pw_contact','')); ?>"><input type="hidden" name="phone" value="<?php echo esc_attr(pw_user_meta($uid,'pw_phone','')); ?>"><input type="hidden" name="zip" value="<?php echo esc_attr(pw_user_meta($uid,'pw_zip','')); ?>"><input type="hidden" name="city" list="pw-locations" value="<?php echo esc_attr(pw_user_meta($uid,'pw_city','')); ?>"><input type="hidden" name="industry" list="pw-industries" value="<?php echo esc_attr(pw_user_meta($uid,'pw_industry','')); ?>"><section class="pw-form-card"><span class="pw-kicker">PERSONALANFRAGE-FILTER</span><h2>Nur relevante Anfragen erhalten</h2><div class="pw-form-grid two"><label>Radius in Kilometern<input type="number" min="0" max="500" name="notify_radius" value="<?php echo esc_attr(pw_user_meta($uid,'pw_notify_radius',50)); ?>"><small>0 = kein Entfernungsfilter</small></label><label>Benachrichtigungsart<select name="notify_frequency"><option value="immediate" <?php selected(pw_user_meta($uid,'pw_notify_frequency','immediate'),'immediate'); ?>>Sofort per E-Mail + Portal</option><option value="daily" <?php selected(pw_user_meta($uid,'pw_notify_frequency','immediate'),'daily'); ?>>Tägliche Zusammenfassung</option><option value="portal" <?php selected(pw_user_meta($uid,'pw_notify_frequency','immediate'),'portal'); ?>>Nur Portal</option></select></label><label class="full">Branchenfilter<input name="notify_industries" list="pw-industries" value="<?php echo esc_attr(pw_list_string((array)pw_user_meta($uid,'pw_notify_industries',[]))); ?>" placeholder="Logistik, Produktion, Automotive"><small>Leer lassen, um alle Branchen zu erhalten.</small></label><label>Auftraggeber<select name="notify_clients"><option value="all" <?php selected(pw_user_meta($uid,'pw_notify_clients','all'),'all'); ?>>Alle passenden Auftraggeber</option><option value="favorites" <?php selected(pw_user_meta($uid,'pw_notify_clients','all'),'favorites'); ?>>Nur meine Favoriten</option></select></label></div></section><section class="pw-card"><span class="pw-kicker">ERKLÄRUNG</span><h3>So entscheidet Pure Work</h3><p>Bei einer neuen Personalanfrage prüft das Portal zuerst, ob du zur Zielgruppe gehörst. Danach werden Radius, Branche, Favoriten und Stummlisten berücksichtigt.</p><div class="pw-filter-flow"><span>Zielgruppe</span><b>→</b><span>Region</span><b>→</b><span>Branche</span><b>→</b><span>Favoriten</span><b>→</b><span>Benachrichtigung</span></div></section><div class="pw-form-actions full"><button class="pw-btn primary">Filter speichern</button></div></form><?php
    }elseif($tab==='security'){?><div class="pw-security-grid"><section class="pw-card"><span class="pw-kicker">PASSWORT</span><h2>Zugang schützen</h2><p>Fordere einen sicheren Reset-Link an und ändere dein Passwort.</p><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('password')); ?>">Passwort ändern</a></section><section class="pw-card"><span class="pw-kicker">DATENEXPORT</span><h2>Meine Portal-Daten</h2><p>Lade eine maschinenlesbare Kopie deiner Konto-, Unternehmens- und Pure-Work-Daten als JSON herunter.</p><a class="pw-btn ghost" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_data_export'),'pw_data_export')); ?>">Datenexport herunterladen</a></section><section class="pw-card"><span class="pw-kicker">LÖSCHANFRAGE</span><h2>Konto löschen lassen</h2><p>Stelle eine Löschanfrage. Vor endgültiger Löschung werden mögliche gesetzliche oder vertragliche Aufbewahrungspflichten geprüft.</p><?php if(pw_user_meta($uid,'pw_delete_requested_at',0)): ?><span class="pw-badge warning">Anfrage bereits gestellt</span><?php else: ?><a class="pw-btn danger-ghost pw-confirm" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=pw_delete_request'),'pw_delete_request')); ?>">Löschanfrage stellen</a><?php endif; ?></section><section class="pw-card"><span class="pw-kicker">SESSION</span><h2>Abmelden</h2><p>Beende deine aktuelle Sitzung auf diesem Gerät. Deine Zugangsdaten bleiben erhalten.</p><a class="pw-btn danger-ghost" href="<?php echo esc_url(pw_logout_url()); ?>">Sicher abmelden</a></section></div><?php }
    echo pw_portal_shell_end();return ob_get_clean();
}
add_shortcode('pw_account','pw_shortcode_account');

function pw_pricing_cards_legacy47($inside=true){
    $basic = esc_html(get_option('pw_basic_price','49'));
    $pro = esc_html(get_option('pw_pro_price','119'));
    $register = function($type, $plan='') use ($inside) {
        if ($inside) return pw_page_url('dashboard');
        $args = ['type'=>$type];
        if ($plan) $args['plan']=$plan;
        return pw_page_url('register',$args);
    };
    ob_start(); ?>
    <div class="pw-launch-banner"><span><?php echo pw_icon('spark'); ?></span><div><b>Startphase: alle Zugänge 0 €</b><small>Du kannst dich jetzt kostenlos registrieren und Pure Work vollständig nutzen. Die späteren Preise dienen nur der Orientierung.</small></div></div>
    <div class="pw-pricing-grid pw-pricing-grid-four">
      <article class="client-plan"><span>AUFTRAGGEBER</span><h3><b>0 €</b><small> dauerhaft vorgesehen</small></h3><p>Für Unternehmen, die kurzfristig oder regelmäßig externes Personal benötigen.</p><ul><li>Personalanfragen veröffentlichen</li><li>Anonymisierte Profile vergleichen</li><li>Talent Pool durchsuchen</li><li>Status & Chat</li><li>Mehrere Standorte verwalten</li></ul><a class="pw-btn ghost full" href="<?php echo esc_url($register('client','client')); ?>"><?php echo $inside?'Zum Dashboard':'Kostenlos registrieren'; ?></a></article>
      <article><span>BASIC</span><div class="pw-free-now">JETZT 0 €</div><h3><b>0 €</b><small> aktuell</small></h3><p>Der einfache Einstieg für kleinere Personaldienstleister und einzelne Niederlassungen.</p><ul><li>Talent Pool</li><li>Personalanfragen sehen</li><li>Profile einreichen</li><li>Basis-Matching</li><li>Status & Nachrichten</li></ul><div class="pw-future-price">Später geplant: ca. <?php echo $basic; ?> € / Monat</div><a class="pw-btn ghost full" href="<?php echo esc_url($register('agency','basic')); ?>"><?php echo $inside?'Zum Dashboard':'Basic kostenlos nutzen'; ?></a></article>
      <article class="featured"><div class="pw-popular">EMPFOHLEN</div><span>PRO</span><div class="pw-free-now">JETZT 0 €</div><h3><b>0 €</b><small> aktuell</small></h3><p>Für aktive Disposition mit mehr Profilen, Filtern und mehreren Nutzern.</p><ul><li>Alle Basic-Funktionen</li><li>Pure Match</li><li>Radius- & Kundenfilter</li><li>Mehr Nutzer / Disponenten</li><li>Statistiken & Priorisierung</li></ul><div class="pw-future-price">Später geplant: ca. <?php echo $pro; ?> € / Monat</div><a class="pw-btn primary full" href="<?php echo esc_url($register('agency','professional')); ?>"><?php echo $inside?'Zum Dashboard':'Pro kostenlos nutzen'; ?></a></article>
      <article><span>MAX</span><div class="pw-free-now">JETZT 0 €</div><h3><b>0 €</b><small> aktuell</small></h3><p>Für größere Personaldienstleister mit mehreren Standorten und komplexeren Strukturen.</p><ul><li>Alle Pro-Funktionen</li><li>Mehrere Niederlassungen</li><li>Erweitertes Rollenmodell</li><li>Reporting</li><li>API / Integrationen später</li></ul><div class="pw-future-price">Später geplant: individuell</div><a class="pw-btn ghost full" href="<?php echo esc_url($register('agency','enterprise')); ?>"><?php echo $inside?'Zum Dashboard':'Max kostenlos nutzen'; ?></a></article>
    </div>
    <?php return ob_get_clean();
}
function pw_shortcode_pricing_legacy47(){ob_start();echo pw_public_header();?><section class="pw-simple-public pw-pricing-page"><div class="pw-public-wrap"><div class="pw-section-head narrow"><span class="pw-kicker">ZUGÄNGE & TARIFE</span><h1>Alle Modelle sichtbar. Aktuell alle kostenlos.</h1><p>Wähle den Zugang, der später zu deinem Unternehmen passen soll. In Pure Work 4.7 ist die Nutzung derzeit ohne Zahlung freigeschaltet.</p></div><?php echo pw_pricing_cards(false); ?></div></section><?php return ob_get_clean();}
add_shortcode('pw_pricing','pw_shortcode_pricing');

function pw_shortcode_legal(){ob_start();echo pw_public_header();?><section class="pw-legal-page"><div class="pw-public-wrap small"><span class="pw-kicker">RECHTLICHES</span><h1>Nutzungsbedingungen</h1><div class="pw-legal-warning"><strong>Entwurfsfassung – vor Produktivstart juristisch prüfen.</strong><p>Diese Seite ist technisch vorbereitet, ersetzt aber keine individuelle Rechtsberatung. Insbesondere AÜG-Prozess, Plattformrolle, Umgehungsschutz, Vertragsabschluss und Haftung müssen vor Live-Betrieb fachanwaltlich ausgestaltet werden.</p></div><h2>1. Gegenstand</h2><p>Pure Work stellt eine digitale B2B-Plattform bereit, auf der verifizierte Auftraggeber Personalbedarf veröffentlichen und verifizierte Personaldienstleister anonymisierte Talentprofile anbieten können.</p><h2>2. Unternehmensverifizierung</h2><p>Der Zugang zu Marktplatzdaten kann von einer erfolgreichen Prüfung des Unternehmens und – bei Personaldienstleistern – der hinterlegten Arbeitnehmerüberlassungserlaubnis abhängig gemacht werden.</p><h2>3. Datenfreigabe</h2><p>Identitäts- und Kontaktdaten von Talentprofilen werden grundsätzlich stufenweise freigegeben. Nutzer dürfen technische Schutzmechanismen nicht umgehen.</p><h2>4. Verantwortlichkeit der Unternehmen</h2><p>Die einstellenden Unternehmen sind für Richtigkeit, Aktualität und rechtliche Zulässigkeit ihrer Angaben, Dokumente und Profile verantwortlich. Vor dem Produktivstart sind die konkreten Rollen des Plattformbetreibers rechtlich zu definieren.</p><h2>5. Vergütung</h2><p>Auftraggeber können Pure Work kostenlos nutzen. Für Personaldienstleister gelten die im Portal ausgewiesenen Basic-, Pro- oder Max-Tarife. Zeitlich begrenzte Einführungsaktionen und die konkrete Zahlungsabwicklung richten sich nach dem beim Konto hinterlegten Tarif.</p><h2>6. Schutz des Vermittlungswegs</h2><p>Regelungen zum Schutz vor Umgehung des Portals oder zu Schutzzeiträumen müssen angemessen und rechtlich wirksam in die endgültigen Nutzungsbedingungen aufgenommen werden.</p></div></section><?php return ob_get_clean();}
add_shortcode('pw_legal','pw_shortcode_legal');

function pw_shortcode_privacy(){ob_start();echo pw_public_header();?><section class="pw-legal-page"><div class="pw-public-wrap small"><span class="pw-kicker">DATENSCHUTZ</span><h1>Datenschutzhinweise</h1><div class="pw-legal-warning"><strong>Entwurfsfassung – DSGVO-Konzept juristisch finalisieren.</strong><p>Pure Work verarbeitet Unternehmens-, Nutzer- sowie Bewerber-/Mitarbeiterdaten. Vor dem Produktivstart müssen Rechtsgrundlagen, Verantwortlichkeiten, Auftragsverarbeitungen, Löschfristen, Einwilligungs-/Freigabelogik und Informationspflichten konkret geprüft und dokumentiert werden.</p></div><h2>Welche Daten das Portal technisch verarbeitet</h2><p>Kontodaten, Unternehmensdaten, Verifizierungsangaben, Personalanfragen, strukturierte Talentprofile, Kommunikations- und Statusdaten sowie – sofern hochgeladen – Lebensläufe und Qualifikationsnachweise.</p><h2>Anonymisierung und Zugriff</h2><p>Marktplatzansichten zeigen Mitarbeiter zunächst anonymisiert. Identifizierende Angaben und private Dokumente sind nur in definierten Freigabestufen und für beteiligte Unternehmen vorgesehen.</p><h2>Protokollierung</h2><p>Das System protokolliert sicherheits- und prozessrelevante Ereignisse wie An- und Abmeldungen, Statusänderungen und Nachrichten. Der Pure-Work-Auditlog speichert dabei bewusst keine IP-Adresse.</p><h2>Löschung, Export und Aufbewahrung</h2><p>Nutzer können im Konto einen Datenexport herunterladen und eine Löschanfrage stellen. Kurzlebige Verifizierungs- und AÜG-Aktualisierungstokens werden automatisch bereinigt. Geschäftsdaten werden nicht pauschal nach einer erfundenen Frist gelöscht; konkrete Lösch- und Aufbewahrungsfristen sind entsprechend des finalen Datenschutzkonzepts festzulegen.</p><h2>Externe Geokodierung</h2><p>Wenn die Geokodierungsfunktion aktiviert ist, kann das Portal Unternehmens- und Einsatzorte an einen Geokodierungsdienst übermitteln, um Entfernungen und Radiusfilter zu berechnen. Der Betreiber kann diese Funktion im Backend deaktivieren.</p></div></section><?php return ob_get_clean();}
add_shortcode('pw_privacy','pw_shortcode_privacy');

/** Pure Work 4.8: production access screen with verified WordPress accounts. */
function pw_shortcode_access(){
    // Kept for backward compatibility. The homepage itself uses pw_landing.
    if(in_array(pw_user_role(), ['agency','client'], true)) return pw_shortcode_landing();

    $mode=sanitize_key(wp_unslash($_GET['mode']??'login'));
    $email=sanitize_email(wp_unslash($_GET['email']??''));
    $error=sanitize_key(wp_unslash($_GET['error']??''));

    ob_start(); ?>
    <section class="pw-v4-access">
      <div class="pw-v4-left">
        <a class="pw-brand light" href="<?php echo esc_url(home_url('/')); ?>"><?php echo pw_brand(); ?></a>
        <div class="pw-v4-pitch">
          <span class="pw-kicker light">DIE B2B-PLATTFORM FÜR ZEITARBEIT</span>
          <h1>Anmelden.<br>Personal finden.<br><em>Einsätze besetzen.</em></h1>
          <p>Auftraggeber und Zeitarbeitsfirmen arbeiten in einem gemeinsamen System – mit Personalanfragen, Talent Pool, Pure Match, Chat, Status und automatisierten E-Mail-Benachrichtigungen.</p>
          <div class="pw-v4-proof">
            <span><?php echo pw_icon('check'); ?> echte Unternehmenskonten</span>
            <span><?php echo pw_icon('check'); ?> E-Mail-Bestätigung</span>
            <span><?php echo pw_icon('check'); ?> geschützte Mitarbeiterdaten</span>
            <span><?php echo pw_icon('check'); ?> Auftraggeber kostenlos</span>
          </div>
        </div>
        <div class="pw-v4-dataset">
          <b><?php echo count(pw_catalog_roles()); ?>+</b><span>Tätigkeiten</span>
          <b><?php echo count(pw_catalog_qualifications()); ?>+</b><span>Qualifikationen</span>
          <b><?php echo count(pw_catalog_locations()); ?>+</b><span>Standorte</span>
        </div>
      </div>

      <div class="pw-v4-authwrap">
        <div class="pw-v4-authbox">
          <div class="pw-v4-tabs">
            <a class="<?php echo $mode!=='register'?'active':''; ?>" href="<?php echo esc_url(home_url('/')); ?>">Anmelden</a>
            <a class="<?php echo $mode==='register'?'active':''; ?>" href="<?php echo esc_url(add_query_arg('mode','register',home_url('/'))); ?>">Registrieren</a>
          </div>

          <?php if($mode!=='register'): ?>
            <div class="pw-v4-pane">
              <span class="pw-kicker">SICHERER ZUGANG</span>
              <h2>Bei Pure Work anmelden</h2>
              <p>Mit deiner geschäftlichen E-Mail-Adresse und deinem Passwort.</p>

              <?php if(isset($_GET['registered'])): ?>
                <div class="pw-alert success"><div><strong>Konto erstellt</strong><span>Dein Pure Work Konto wurde angelegt. Bestätige deine geschäftliche E-Mail-Adresse und melde dich danach hier an.</span></div></div>
              <?php endif; ?>
              <?php if(isset($_GET['mail_error'])): ?>
                <div class="pw-alert warning"><div><strong>Bestätigungs-E-Mail noch nicht versendet</strong><span>Der Account besteht, aber der Mailserver hat die Nachricht nicht angenommen. Nutze unten „Erneut senden“ oder prüfe als Administrator die SMTP-Einstellungen.</span></div></div>
              <?php endif; ?>
              <?php if(isset($_GET['verified'])): ?>
                <div class="pw-alert success"><div><strong>E-Mail bestätigt</strong><span>Deine E-Mail-Adresse ist jetzt verifiziert. Du kannst dich wie gewohnt anmelden.</span></div></div>
              <?php endif; ?>
              <?php if(isset($_GET['password_reset'])): ?>
                <div class="pw-alert success"><div><strong>Passwort geändert</strong><span>Du kannst dich jetzt mit deinem neuen Passwort anmelden.</span></div></div>
              <?php endif; ?>
              <?php if(isset($_GET['logged_out'])): ?>
                <div class="pw-alert info"><div><strong>Erfolgreich abgemeldet</strong><span>Deine Sitzung wurde beendet.</span></div></div>
              <?php endif; ?>
              <?php if(isset($_GET['resent'])): ?>
                <div class="pw-alert info"><div><strong>Bestätigungslink angefordert</strong><span>Wenn ein unbestätigtes Konto existiert, wurde eine neue E-Mail versendet.</span></div></div>
              <?php endif; ?>
              <?php if($error==='unverified'): ?>
                <div class="pw-alert warning"><div><strong>E-Mail noch nicht bestätigt</strong><span>Bestätige zuerst deine geschäftliche E-Mail-Adresse. Danach ist der Login freigeschaltet.</span></div></div>
              <?php elseif($error): ?>
                <div class="pw-alert danger"><div><strong>Anmeldung nicht möglich</strong><span>E-Mail-Adresse oder Passwort ist nicht korrekt.</span></div></div>
              <?php endif; ?>

              <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="pw_login"><?php wp_nonce_field('pw_login'); ?>
                <label>E-Mail-Adresse<input type="email" name="email" required autocomplete="email" value="<?php echo esc_attr($email); ?>" placeholder="name@unternehmen.de"></label>
                <label>Passwort<input type="password" name="password" required autocomplete="current-password" placeholder="Dein Passwort"></label>
                <div class="pw-form-inline">
                  <label class="pw-check"><input type="checkbox" name="remember" value="1"><span></span>Angemeldet bleiben</label>
                  <a href="<?php echo esc_url(pw_page_url('password')); ?>">Passwort vergessen?</a>
                </div>
                <button class="pw-btn primary xl full" type="submit" name="pw_login_submit" value="1">Anmelden <?php echo pw_icon('arrow'); ?></button>
              </form>

              <?php if($error==='unverified' || isset($_GET['registered'])): ?>
                <div class="pw-resend-box">
                  <b>Bestätigungs-E-Mail nicht angekommen?</b>
                  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="pw_resend_verification"><?php wp_nonce_field('pw_resend_verification'); ?>
                    <input type="email" name="email" required value="<?php echo esc_attr($email); ?>" placeholder="E-Mail-Adresse">
                    <button class="pw-btn small ghost" type="submit">Erneut senden</button>
                  </form>
                </div>
              <?php endif; ?>

              <p class="pw-v4-switch">Noch kein Konto? <a href="<?php echo esc_url(add_query_arg('mode','register',home_url('/'))); ?>">Jetzt registrieren</a></p>
            </div>
          <?php else: ?>
            <div class="pw-v4-pane">
              <span class="pw-kicker">UNTERNEHMENSKONTO ERSTELLEN</span>
              <h2>Bei Pure Work registrieren</h2>
              <p>Wähle deine Rolle, hinterlege die Unternehmensdaten und bestätige anschließend deine geschäftliche E-Mail-Adresse.</p>

              <?php if(isset($_GET['error'])): ?>
                <div class="pw-alert danger"><div><strong>Registrierung nicht möglich</strong><span>Bitte Pflichtfelder prüfen. Die E-Mail-Adresse darf noch nicht registriert sein und das Passwort muss mindestens 8 Zeichen haben.</span></div></div>
              <?php endif; ?>

              <form class="pw-register-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="pw_register"><?php wp_nonce_field('pw_register'); ?>

                <div class="pw-v4-role">
                  <label><input type="radio" name="role" value="client" checked><span><?php echo pw_icon('building'); ?><b>Auftraggeber</b><small>Personal suchen · kostenlos</small></span></label>
                  <label><input type="radio" name="role" value="agency"><span><?php echo pw_icon('users'); ?><b>Zeitarbeitsfirma</b><small>Mitarbeiter anbieten</small></span></label>
                </div>

                <div class="pw-form-grid two">
                  <label>Unternehmen<input name="company" required autocomplete="organization" placeholder="Unternehmen GmbH"></label>
                  <label>Ansprechpartner<input name="contact" required autocomplete="name" placeholder="Vor- und Nachname"></label>
                  <label class="full">Geschäftliche E-Mail<input type="email" name="email" required autocomplete="email" placeholder="name@unternehmen.de"></label>
                  <label>Telefon<input name="phone" autocomplete="tel" placeholder="+49 …"></label>
                  <label>PLZ<input name="zip" autocomplete="postal-code" placeholder="68161"></label>
                  <label>Ort<input name="city" list="pw-locations" autocomplete="address-level2" placeholder="Mannheim"></label>
                  <label>Branche<input name="industry" list="pw-industries" placeholder="z. B. Logistik"></label>
                  <label>Passwort<input type="password" name="password" minlength="8" required autocomplete="new-password" placeholder="Mindestens 8 Zeichen"></label>
                </div>

                <div class="pw-v41-agency pw-agency-only">
                  <div class="pw-v41-divider"><span>AÜG-ANGABEN FÜR ZEITARBEITSFIRMEN</span></div>
                  <div class="pw-form-grid two">
                    <label>Gültigkeit der AÜG-Erlaubnis<select name="aug_type" class="pw-aug-type"><option value="limited">Befristet</option><option value="unlimited">Unbefristet</option></select></label>
                    <label class="pw-aug-expiry-field">Gültig bis<input type="date" name="aug_expiry" data-agency-required="1"></label>
                    <div class="full pw-aug-unlimited-note" hidden><span class="pw-inline-info">✓ Unbefristete Erlaubnis – kein Ablaufdatum erforderlich.</span></div>
                    <label class="full">AÜG-Erlaubnis hochladen<input type="file" name="aug_file" accept=".pdf,.jpg,.jpeg,.png" data-agency-required="1"><small>PDF/JPG/PNG, max. 10 MB. Nur für die Portalprüfung sichtbar.</small></label>
                  </div>
                </div>

                <label class="pw-check legal"><input type="checkbox" name="accept_terms" value="1" required><span></span>Ich akzeptiere die <a href="<?php echo esc_url(pw_page_url('legal')); ?>" target="_blank">Nutzungsbedingungen</a> und habe die <a href="<?php echo esc_url(pw_page_url('privacy')); ?>" target="_blank">Datenschutzhinweise</a> gelesen.</label>
                <button class="pw-btn primary xl full" type="submit">Konto erstellen <?php echo pw_icon('arrow'); ?></button>
              </form>

              <p class="pw-v4-switch">Schon registriert? <a href="<?php echo esc_url(home_url('/')); ?>">Anmelden</a></p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('pw_access','pw_shortcode_access');


function pw_shortcode_password(){
    if(is_user_logged_in()) {
        return '<section class="pw-auth-gate"><a class="pw-brand" href="'.esc_url(home_url('/')).'">'.pw_brand().'</a><div class="pw-auth-card"><span class="pw-kicker">KONTO</span><h1>Du bist angemeldet</h1><p>Dein Passwort kannst du über einen sicheren Reset-Link ändern.</p><a class="pw-btn primary full" href="'.esc_url(pw_page_url('account',['tab'=>'security'])).'">Zu den Sicherheitseinstellungen</a><a class="pw-btn ghost full" href="'.esc_url(pw_logout_url()).'">Abmelden</a></div></section>';
    }

    $mode=sanitize_key(wp_unslash($_GET['mode']??'request'));
    $key=sanitize_text_field(wp_unslash($_GET['key']??''));
    $login=sanitize_text_field(wp_unslash($_GET['login']??''));
    $error=sanitize_key(wp_unslash($_GET['error']??''));

    ob_start(); ?>
    <section class="pw-auth-page">
      <div class="pw-auth-visual">
        <a class="pw-brand light" href="<?php echo esc_url(home_url('/')); ?>"><?php echo pw_brand(); ?></a>
        <div><span class="pw-kicker light">KONTOSICHERHEIT</span><h2>Zurück zu deinem<br>Pure Work Konto.</h2><p>Passwortänderungen laufen vollständig über den geschützten Pure Work Prozess.</p></div>
      </div>
      <div class="pw-auth-form-wrap">
        <div class="pw-auth-lang"><?php echo pw_language_switcher(); ?></div>
        <div class="pw-auth-form">
          <?php if($mode==='reset' && $key && $login): ?>
            <span class="pw-kicker">NEUES PASSWORT</span><h1>Passwort festlegen</h1><p>Wähle ein neues Passwort mit mindestens 8 Zeichen.</p>
            <?php if($error==='password'): ?><div class="pw-alert danger"><div><strong>Passwörter prüfen</strong><span>Beide Eingaben müssen übereinstimmen und mindestens 8 Zeichen lang sein.</span></div></div><?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
              <input type="hidden" name="action" value="pw_password_reset">
              <input type="hidden" name="key" value="<?php echo esc_attr($key); ?>">
              <input type="hidden" name="login" value="<?php echo esc_attr($login); ?>">
              <?php wp_nonce_field('pw_password_reset'); ?>
              <label>Neues Passwort<input type="password" name="password" minlength="8" required autocomplete="new-password" data-pw-strength="1" data-pw-toggle="1"></label>
              <label>Passwort wiederholen<input type="password" name="password_confirm" minlength="8" required autocomplete="new-password" data-pw-toggle="1"></label>
              <button class="pw-btn primary full xl" type="submit">Passwort speichern <?php echo pw_icon('arrow'); ?></button>
            </form>
          <?php else: ?>
            <span class="pw-kicker">PASSWORT VERGESSEN</span><h1>Zugang wiederherstellen</h1><p>Gib deine geschäftliche E-Mail-Adresse ein. Wir senden dir einen sicheren Link zum Zurücksetzen.</p>
            <?php if(isset($_GET['sent'])): ?><div class="pw-alert success"><div><strong>E-Mail versendet</strong><span>Wenn zu dieser Adresse ein Pure Work Konto existiert, wurde ein Reset-Link verschickt. Der Link ist 24 Stunden gültig – schau bitte auch im Spam-Ordner nach.</span></div></div><?php endif; ?>
            <?php if(!empty($_GET['mail_error'])): ?><div class="pw-alert danger"><div><strong>Der Mailserver hat die Nachricht nicht angenommen</strong><span>Bitte wende dich an den Portalbetreiber. Als Betreiber prüfst du die SMTP-Einstellungen unter „Pure Work → Einstellungen &amp; E-Mail“.</span></div></div><?php endif; ?>
            <?php if($error==='invalid'): ?><div class="pw-alert danger"><div><strong>Link nicht gültig</strong><span>Der Reset-Link ist ungültig oder abgelaufen. Fordere einfach einen neuen an.</span></div></div><?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
              <input type="hidden" name="action" value="pw_password_request"><?php wp_nonce_field('pw_password_request'); ?>
              <label>E-Mail-Adresse<input type="email" name="email" required autocomplete="email" placeholder="name@unternehmen.de"></label>
              <button class="pw-btn primary full xl" type="submit">Reset-Link senden <?php echo pw_icon('arrow'); ?></button>
            </form>
          <?php endif; ?>
          <div class="pw-auth-bottom"><a href="<?php echo esc_url(home_url('/')); ?>">← Zur Anmeldung</a></div>
        </div>
      </div>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('pw_password','pw_shortcode_password');

function pw_shortcode_marketdata(){
    if(!is_user_logged_in()) return pw_require_login_html();

    $occupation_q = sanitize_text_field(wp_unslash($_GET['occupation_q'] ?? ''));
    $company_q = sanitize_text_field(wp_unslash($_GET['company_q'] ?? ''));
    $occupation_results = $occupation_q !== '' ? pw_catalog_search_official_occupations($occupation_q, 80) : [];
    $company_results = pw_catalog_market_companies($company_q, $company_q !== '' ? 100 : 36);

    ob_start();
    echo pw_portal_shell_start(pw_t('Berufe & Daten','Occupations & data'),pw_t('Amtliche Berufsbezeichnungen, Qualifikationen und Marktreferenzen zum Nachschlagen.','Official occupation titles, qualifications and market references for reference.'));
    if(function_exists('pw_can')&&!pw_can('marketdata')){echo pw_plan_gate('marketdata');echo pw_portal_shell_end();return ob_get_clean();}

    $stats=pw_catalog_stats();
    echo '<div class="pw-metrics-grid pw-market-metrics">';
    foreach($stats as $k=>$v) echo pw_metric(number_format_i18n($v),$k,'in Pure Work hinterlegt');
    echo '</div>';

    ?>
    <div class="pw-source-banner">
      <div><?php echo pw_icon('spark'); ?><div><span class="pw-kicker">PURE WORK DATASET 4.8</span><h3>18.867 offizielle Berufsbezeichnungen integriert</h3><p>Der vollständige Berufs- und Tätigkeitskatalog basiert auf der KldB 2010 – überarbeitete Fassung 2020 der Statistik der Bundesagentur für Arbeit, Stand 01.01.2026.</p></div></div>
      <a class="pw-btn ghost small" href="https://statistik.arbeitsagentur.de/DE/Navigation/Grundlagen/Klassifikationen/Klassifikation-der-Berufe/KldB2010-Fassung2020/KldB2010-Fassung2020-Nav.html" target="_blank" rel="noopener">Quelle öffnen</a>
    </div>

    <div class="pw-marketdata-grid">
      <section class="pw-card pw-marketdata-main">
        <div class="pw-card-head"><div><span class="pw-kicker">BERUFSDATENBANK</span><h2>Alle Berufsbezeichnungen durchsuchen</h2><p class="pw-card-sub">Suche nach Berufsbezeichnung oder KldB-Code. Die Datenbank enthält 18.867 Einträge.</p></div><span>BA · 01/2026</span></div>
        <form method="get" class="pw-market-search">
          <input type="hidden" name="occupation_q" value="">
          <?php echo pw_icon('search'); ?>
          <input name="occupation_q" value="<?php echo esc_attr($occupation_q); ?>" placeholder="z. B. Schweißer, Lager, Elektroniker oder 26112">
          <button class="pw-btn primary small">Suchen</button>
        </form>
        <?php if($occupation_q !== ''): ?>
          <div class="pw-market-results-head"><b><?php echo count($occupation_results); ?> Treffer</b><span>für „<?php echo esc_html($occupation_q); ?>“</span></div>
          <?php if(!$occupation_results): ?>
            <div class="pw-empty compact"><?php echo pw_icon('search'); ?><h3>Keine Berufsbezeichnung gefunden</h3><p>Versuche einen kürzeren Suchbegriff oder einen KldB-Code.</p></div>
          <?php else: ?>
            <div class="pw-data-table-wrap"><table class="pw-data-table"><thead><tr><th>Berufsbezeichnung</th><th>KldB</th></tr></thead><tbody>
              <?php foreach($occupation_results as $item): ?><tr><td><strong><?php echo esc_html($item['label']); ?></strong></td><td><code><?php echo esc_html($item['code']); ?></code></td></tr><?php endforeach; ?>
            </tbody></table></div>
          <?php endif; ?>
        <?php else: ?>
          <div class="pw-market-hint"><b>Tipp:</b> In den Formularen „Personalanfrage erstellen“ und „Mitarbeiterprofil“ greift die Berufssuche ebenfalls auf diese Datenbank zu.</div>
        <?php endif; ?>
      </section>

      <section class="pw-card pw-marketdata-main">
        <div class="pw-card-head"><div><span class="pw-kicker">UNTERNEHMENS-MARKTREFERENZ</span><h2>100 große deutsche Arbeitgeber & Unternehmen</h2><p class="pw-card-sub">Für Vertriebs- und Marktrecherche. Diese Einträge sind keine Pure-Work-Konten und keine Aussage darüber, ob ein Unternehmen aktuell Zeitarbeit nutzt.</p></div><span>100 Einträge</span></div>
        <form method="get" class="pw-market-search">
          <?php echo pw_icon('search'); ?>
          <input name="company_q" value="<?php echo esc_attr($company_q); ?>" placeholder="Unternehmen, Sitz oder Branche suchen">
          <button class="pw-btn primary small">Suchen</button>
        </form>
        <div class="pw-market-company-grid">
          <?php foreach($company_results as $item): ?>
            <article><span class="pw-market-rank">#<?php echo (int)$item['rank']; ?></span><div><b><?php echo esc_html($item['company']); ?></b><small><?php echo esc_html($item['city']); ?> · <?php echo esc_html($item['industry']); ?></small></div></article>
          <?php endforeach; ?>
        </div>
        <div class="pw-market-disclaimer">Marktreferenz aus einem Top-100-Unternehmensranking (Umsätze 2023). Nicht als Nachweis eines aktuellen Zeitarbeitseinsatzes verwenden.</div>
      </section>
    </div>

    <div class="pw-data-grid pw-data-grid-44">
    <?php
      $groups=[
        'Zeitarbeits-Tätigkeiten'=>pw_catalog_roles(),
        'Branchen'=>pw_catalog_industries(),
        'Qualifikationen'=>pw_catalog_qualifications(),
        'Standorte'=>pw_catalog_locations(),
        'Typische Zielkundentypen'=>pw_catalog_customer_segments()
      ];
      foreach($groups as $title=>$vals){
        echo '<section class="pw-card"><div class="pw-card-head"><div><span class="pw-kicker">SCHNELLKATALOG</span><h2>'.esc_html($title).'</h2></div><span>'.count($vals).' Einträge</span></div><div class="pw-chip-cloud">';
        foreach(array_slice($vals,0,120) as $v) echo '<span>'.esc_html($v).'</span>';
        echo '</div></section>';
      }
    ?>
    </div>

    <div class="pw-source-grid">
      <section class="pw-card"><span class="pw-kicker">AMTLICHE PRÜFQUELLE</span><h3>AÜG-Erlaubnisinhaber</h3><p>Die Bundesagentur für Arbeit stellt ein tagesaktuell gepflegtes öffentliches Verzeichnis der Inhaber einer Arbeitnehmerüberlassungserlaubnis bereit.</p><a class="pw-btn ghost small" href="https://www.spitzenverbaende.arbeitsagentur.de/" target="_blank" rel="noopener">BA-Verzeichnis öffnen</a></section>
      <section class="pw-card"><span class="pw-kicker">DATENINTEGRITÄT</span><h3>Keine erfundenen Marktplatzdaten</h3><p>Unternehmens-Marktreferenzen und Berufskataloge sind klar von echten registrierten Pure-Work-Konten und echten Personalanfragen getrennt. So bleibt der produktive Marktplatz sauber.</p></section>
    </div>
    <?php

    echo pw_portal_shell_end();
    return ob_get_clean();
}
add_shortcode('pw_marketdata','pw_shortcode_marketdata');
