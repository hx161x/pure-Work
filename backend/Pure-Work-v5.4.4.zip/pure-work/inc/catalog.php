<?php
if (!defined('ABSPATH')) exit;

function pw_catalog_industries() {
    return [
        'Automotive','Automobilzulieferer','Bau & Handwerk','Baustoffe','Chemie','E-Commerce','Elektrotechnik','Energie','Entsorgung & Recycling','Facility Management','Food & Beverage','Getränkeindustrie','Gesundheitswesen','Großhandel','Handel','Holz & Möbel','Industrie','IT & Technik','Kautschuk','Kliniken & Pflege','Kunststoff','Lager & Logistik','Lebensmittelproduktion','Luftfahrt','Maschinenbau','Metall','Medizintechnik','Messe & Event','Papier & Druck','Pharma','Produktion','Reinigung','Retail','Spedition','Textil','Transport & Verkehr','Verpackung','Versand & Fulfillment','Werkstatt & Instandhaltung','Gastronomie','Hotellerie','Call Center','Kaufmännisch','Öffentlicher Sektor','Landwirtschaft','Elektronikfertigung','Halbleiter','Solar & Photovoltaik','Windenergie','Schienenverkehr','Hafen & Terminal','Kühlhauslogistik','Kontraktlogistik','Kommissionierung','FMCG','Kosmetik','Möbellogistik','Baulogistik','Sanitär & SHK','Schweißtechnik','Oberflächentechnik','Gießerei','Stahlbau','Werkzeugbau','Montage','Qualitätssicherung','Labor','Medienproduktion','Sicherheitsdienste','Post & Paket','Telekommunikation','Rechenzentrum','Customer Service','Backoffice','Banking Operations','Versicherung Operations','Sonstige Dienstleistungen'
    ];
}

function pw_catalog_roles() {
    return [
        'Lagerhelfer','Lagermitarbeiter','Kommissionierer','Verpacker','Versandmitarbeiter','Wareneingangsmitarbeiter','Warenausgangsmitarbeiter','Fachkraft für Lagerlogistik','Fachlagerist','Gabelstaplerfahrer','Staplerfahrer','Schubmaststaplerfahrer','Hochregalstaplerfahrer','Frontstaplerfahrer','Ameisenfahrer','Verlader','LKW-Be- und Entlader','Sortierer','Retourenmitarbeiter','Inventurhelfer','Warenverräumer','Paket-Sortierer','Kurierfahrer','Fahrer Klasse B','Fahrer Klasse C','Fahrer Klasse CE','Berufskraftfahrer','Rangierer','Disponent Logistik','Speditionskaufmann','Produktionshelfer','Produktionsmitarbeiter','Montagehelfer','Montagemitarbeiter','Maschinenbediener','Maschinenführer','Maschinen- und Anlagenführer','Anlagenbediener','Abfüller','Abpacker','Etikettierer','Linienführer','Produktionsfachkraft','Fertigungsmitarbeiter','Qualitätsprüfer','Qualitätskontrolleur','Sichtprüfer','Nacharbeiter','Prüfer Automotive','Industriemechaniker','Mechatroniker','Betriebsschlosser','Schlosser','Metallbauer','Konstruktionsmechaniker','Zerspanungsmechaniker','CNC-Dreher','CNC-Fräser','CNC-Bediener','Werkzeugmechaniker','Feinwerkmechaniker','Schweißer MAG','Schweißer MIG','Schweißer WIG','Schweißhelfer','Rohrschlosser','Anlagenmechaniker','Servicetechniker','Instandhalter','Elektriker','Industrieelektriker','Betriebselektriker','Elektroniker','Elektrohelfer','Kabelmonteur','Schaltschrankverdrahter','Mechatroniker Kältetechnik','SHK-Monteur','Heizungsbauer','Sanitärinstallateur','Bauhelfer','Hochbauhelfer','Tiefbauhelfer','Abbruchhelfer','Trockenbauhelfer','Malerhelfer','Maler und Lackierer','Maurer','Betonbauer','Betonfertigteilbauer','Gerüstbauhelfer','Dachdeckerhelfer','Straßenbauhelfer','Gartenbauhelfer','Reinigungskraft','Industriereiniger','Gebäudereiniger','Housekeeping-Mitarbeiter','Zimmermädchen / Roomboy','Küchenhilfe','Spüler','Servicekraft','Kellner','Barista','Koch','Beikoch','Bäckereimitarbeiter','Metzgereimitarbeiter','Lebensmittelproduktionshelfer','Pflegehelfer','Altenpflegehelfer','Krankenpflegehelfer','Stationshilfe','Patiententransport','Sterilisationsassistent','Pharma-Produktionsmitarbeiter','Laborhelfer','Reinraummitarbeiter','GMP-Mitarbeiter','Chemiehelfer','Chemikant','Produktionsfachkraft Chemie','Kunststoffhelfer','Verfahrensmechaniker Kunststoff','Spritzgussmitarbeiter','Gießereihelfer','Gießer','Oberflächenbeschichter','Lackierer','Pulverbeschichter','Sandstrahler','Karosseriebauer','Kfz-Mechatroniker','Reifenmonteur','Fahrzeugaufbereiter','Automotive-Montagemitarbeiter','Empfangsmitarbeiter','Rezeptionist','Kaufmännische Assistenz','Sachbearbeiter','Datenerfasser','Bürokraft','Auftragssachbearbeiter','Einkaufssachbearbeiter','Vertriebsinnendienst','Customer-Service-Agent','Call-Center-Agent','Telefonischer Kundenberater','Backoffice-Mitarbeiter','HR-Sachbearbeiter','Recruiter','Payroll-Sachbearbeiter','Buchhaltungshelfer','Debitorenbuchhalter','Kreditorenbuchhalter','IT-Support','Helpdesk-Mitarbeiter','Rollout-Techniker','Field-Service-Techniker','Datacenter-Techniker','Netzwerktechniker','PC-Techniker','Messebauer','Eventhelfer','Stagehand','Security-Mitarbeiter','Pförtner','Empfang / Werkschutz','Poststellenmitarbeiter','Druckereimitarbeiter','Maschinenbediener Druck','Verpackungsmaschinenführer','Textilproduktionsmitarbeiter','Näher','Landwirtschaftlicher Helfer','Erntehelfer','Solar-Monteur','Photovoltaik-Monteur','Windkraft-Servicetechniker','Hafenarbeiter','Terminalmitarbeiter','Bodenverkehrsdienst Flughafen','Gepäckabfertiger','Ramp Agent','Flugzeugabfertiger'
    ];
}

function pw_catalog_qualifications() {
    return [
        'Staplerschein','Schubmaststapler-Erfahrung','Hochregal-Erfahrung','Kranführerschein','Brückenkran','Hubarbeitsbühne','Führerschein B','Führerschein BE','Führerschein C','Führerschein CE','Fahrerkarte','Module 95','ADR-Schein','Ladungssicherung','Scanner-Erfahrung','Pick-by-Voice','Pick-by-Light','SAP EWM','SAP WM','SAP MM','WMS-Erfahrung','Kommissioniererfahrung','Verpackerfahrung','Wareneingang','Warenausgang','Inventurerfahrung','2-Schicht-Erfahrung','3-Schicht-Erfahrung','Kontischicht-Erfahrung','Nachtschicht-Erfahrung','Wochenendarbeit möglich','Montageerfahrung','Maschinenbedienung','CNC-Kenntnisse','Siemens Sinumerik','Heidenhain','Fanuc','MAG-Schweißen','MIG-Schweißen','WIG-Schweißen','Schweißerpass','Rohrschweißen','Elektrofachkraft','Elektrofachkraft für festgelegte Tätigkeiten','DGUV V3','SPS-Kenntnisse','Siemens S7','TIA Portal','Hydraulik','Pneumatik','Mechanische Instandhaltung','Elektrische Instandhaltung','Qualitätsprüfung','Messmittelkenntnisse','SAP QM','Automotive-Erfahrung','VDA 6.3','IATF 16949','GMP-Kenntnisse','Reinraumerfahrung','HACCP','Infektionsschutzbelehrung §43 IfSG','Lebensmittelproduktion','Chemie-Erfahrung','Gefahrstoffunterweisung','ESD-Unterweisung','PSA-Kenntnisse','Sicherheitsunterweisung','Erste Hilfe','Brandschutzhelfer','SCC','SCP','Arbeitssicherheit','Baustellenerfahrung','Gerüstbau-Erfahrung','Abbruch-Erfahrung','Kabelzug','Schaltschrankbau','Löterfahrung','SMD-Erfahrung','Lackiererfahrung','Pulverbeschichtung','Sandstrahlen','Spritzguss','Extrusion','Werkzeugwechsel','Kunststoffverarbeitung','Führungszeugnis möglich','Zuverlässigkeitsüberprüfung ZÜP','Luftsicherheitsschulung','MS Office','Excel','Outlook','DATEV','Lexware','SAP FI','SAP SD','Navision / Dynamics','Salesforce','CRM-Erfahrung','Telefonie-Erfahrung','Kundenservice','Datenerfassung','Deutsch A1','Deutsch A2','Deutsch B1','Deutsch B2','Deutsch C1','Deutsch C2','Englisch A1','Englisch A2','Englisch B1','Englisch B2','Englisch C1','Französisch','Italienisch','Spanisch','Türkisch','Arabisch','Polnisch','Rumänisch','Bulgarisch','Ukrainisch','Russisch'
    ];
}

function pw_catalog_locations() {
    return [
        'Mannheim','Ludwigshafen am Rhein','Heidelberg','Schwetzingen','Hockenheim','Walldorf','Wiesloch','Weinheim','Viernheim','Speyer','Worms','Frankenthal (Pfalz)','Landau in der Pfalz','Neustadt an der Weinstraße','Kaiserslautern','Karlsruhe','Bruchsal','Bretten','Rastatt','Baden-Baden','Pforzheim','Stuttgart','Ludwigsburg','Esslingen am Neckar','Sindelfingen','Böblingen','Waiblingen','Heilbronn','Schwäbisch Hall','Ulm','Reutlingen','Tübingen','Freiburg im Breisgau','Offenburg','Lörrach','Darmstadt','Frankfurt am Main','Offenbach am Main','Hanau','Rüsselsheim am Main','Wiesbaden','Mainz','Bingen am Rhein','Koblenz','Trier','Saarbrücken','Köln','Bonn','Düsseldorf','Neuss','Krefeld','Mönchengladbach','Duisburg','Essen','Oberhausen','Gelsenkirchen','Bochum','Dortmund','Hagen','Wuppertal','Solingen','Leverkusen','Aachen','Münster','Bielefeld','Paderborn','Siegen','Nürnberg','Fürth','Erlangen','Bamberg','Würzburg','Regensburg','Ingolstadt','Augsburg','München','Landshut','Rosenheim','Passau','Leipzig','Dresden','Chemnitz','Zwickau','Halle (Saale)','Magdeburg','Erfurt','Jena','Gera','Berlin','Potsdam','Cottbus','Hamburg','Bremen','Bremerhaven','Hannover','Braunschweig','Wolfsburg','Salzgitter','Osnabrück','Oldenburg','Göttingen','Kiel','Lübeck','Rostock','Schwerin'
    ];
}

function pw_catalog_languages(){return ['Deutsch A1','Deutsch A2','Deutsch B1','Deutsch B2','Deutsch C1','Deutsch C2','Englisch A1','Englisch A2','Englisch B1','Englisch B2','Englisch C1','Französisch','Italienisch','Spanisch','Türkisch','Arabisch','Polnisch','Rumänisch','Bulgarisch','Ukrainisch','Russisch'];}
function pw_catalog_shifts(){return ['Tagschicht','Frühschicht','Spätschicht','Nachtschicht','2-Schicht','3-Schicht','4-Schicht','Kontischicht','Wochenendschicht','Dauernachtschicht','Wechselschicht','Gleitzeit'];}
function pw_catalog_customer_segments(){return ['Automobilwerk','Automobilzulieferer Tier 1','Automobilzulieferer Tier 2','Kontraktlogistiker','Spedition','E-Commerce-Fulfillment-Center','Paketzentrum','Großlager','Lebensmittelwerk','Getränkeabfüller','Pharmaproduktion','Chemiewerk','Kunststoffverarbeiter','Metallverarbeiter','Maschinenbauer','Elektronikfertiger','Baustoffhersteller','Möbelhersteller','Druckerei','Verpackungshersteller','Recyclingbetrieb','Entsorgungsbetrieb','Kühlhaus','Großhandel','Einzelhandelslager','Klinik','Pflegeeinrichtung','Hotelgruppe','Cateringbetrieb','Messegesellschaft','Eventdienstleister','Facility-Management-Unternehmen','Gebäudereinigung','Bauunternehmen','Montagebetrieb','Solarunternehmen','Windenergieunternehmen','Hafenbetrieb','Flughafendienstleister','Callcenter','Shared-Service-Center','Rechenzentrum','Telekommunikationsdienstleister','Werkstattkette','Reifenservice','Landwirtschaftlicher Betrieb'];}

function pw_catalog_dataset_path($filename){
    $filename = basename((string)$filename);
    return PW_DIR . '/assets/data/' . $filename;
}

function pw_catalog_official_occupation_count(){ return 18867; }

function pw_catalog_search_official_occupations($query, $limit = 40){
    $query = trim((string)$query);
    $limit = max(1, min(100, (int)$limit));
    if (strlen($query) < 2) return [];
    $path = pw_catalog_dataset_path('kldb_occupations.csv');
    if (!is_readable($path)) return [];
    $needle = function_exists('mb_strtolower') ? mb_strtolower($query, 'UTF-8') : strtolower($query);
    $out = [];
    $fh = fopen($path, 'r');
    if (!$fh) return [];
    $header = fgetcsv($fh, 0, ';');
    while (($row = fgetcsv($fh, 0, ';')) !== false) {
        if (count($row) < 2) continue;
        $label = trim((string)$row[0]);
        $code = trim((string)$row[1]);
        $hay = function_exists('mb_strtolower') ? mb_strtolower($label, 'UTF-8') : strtolower($label);
        if (strpos($hay, $needle) !== false || strpos($code, $query) === 0) {
            $out[] = ['label'=>$label,'code'=>$code];
            if (count($out) >= $limit) break;
        }
    }
    fclose($fh);
    return $out;
}

function pw_catalog_market_companies($query = '', $limit = 100){
    $path = pw_catalog_dataset_path('market_companies_top100.csv');
    if (!is_readable($path)) return [];
    $limit = max(1, min(100, (int)$limit));
    $needle = trim((string)$query);
    $needleLower = function_exists('mb_strtolower') ? mb_strtolower($needle, 'UTF-8') : strtolower($needle);
    $out = [];
    $fh = fopen($path, 'r');
    if (!$fh) return [];
    fgetcsv($fh, 0, ';');
    while (($row = fgetcsv($fh, 0, ';')) !== false) {
        if (count($row) < 5) continue;
        $item = ['rank'=>(int)$row[0],'company'=>trim((string)$row[1]),'city'=>trim((string)$row[2]),'industry'=>trim((string)$row[3]),'note'=>trim((string)$row[4])];
        if ($needleLower !== '') {
            $hay = $item['company'].' '.$item['city'].' '.$item['industry'];
            $hay = function_exists('mb_strtolower') ? mb_strtolower($hay, 'UTF-8') : strtolower($hay);
            if (strpos($hay, $needleLower) === false) continue;
        }
        $out[] = $item;
        if (count($out) >= $limit) break;
    }
    fclose($fh);
    return $out;
}

function pw_catalog_stats(){
    return [
        'Berufsbezeichnungen (KldB)'=>pw_catalog_official_occupation_count(),
        'Zeitarbeits-Tätigkeiten'=>count(pw_catalog_roles()),
        'Branchen'=>count(pw_catalog_industries()),
        'Qualifikationen'=>count(pw_catalog_qualifications()),
        'Standorte'=>count(pw_catalog_locations()),
        'Zielkundentypen'=>count(pw_catalog_customer_segments()),
        'Unternehmens-Marktreferenzen'=>100,
    ];
}

function pw_catalog_datalists(){if(is_admin())return; $sets=['pw-industries'=>pw_catalog_industries(),'pw-roles'=>pw_catalog_roles(),'pw-qualifications'=>pw_catalog_qualifications(),'pw-locations'=>pw_catalog_locations(),'pw-languages'=>pw_catalog_languages(),'pw-shifts'=>pw_catalog_shifts()]; foreach($sets as $id=>$vals){echo '<datalist id="'.esc_attr($id).'">';foreach($vals as $v)echo '<option value="'.esc_attr($v).'">';echo '</datalist>';}}
add_action('wp_footer','pw_catalog_datalists',50);
