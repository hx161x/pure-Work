PURE WORK 4.9.8
================

Installation/Update
1. ZIP in WordPress unter Design > Themes hochladen.
2. Bestehendes Pure-Work-Theme durch diese Version ersetzen.
3. Die Versionsmigration legt fehlende verwaltete Portal-Seiten automatisch an.

Wichtig
- SMTP/WordPress-Mailversand muss für echte E-Mails konfiguriert sein.
- Stripe/Checkout-Links müssen für produktive Abrechnung in den Pure-Work-Einstellungen hinterlegt sein.
- Pure Assist arbeitet ohne externen KI-Dienst mit den Portal-/Profildaten und der bestehenden Profilerkennung.
