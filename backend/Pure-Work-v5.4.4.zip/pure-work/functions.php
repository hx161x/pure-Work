<?php
if (!defined('ABSPATH')) exit;

define('PW_VERSION', '5.4.4');
define('PW_DIR', get_template_directory());
define('PW_URI', get_template_directory_uri());

require_once PW_DIR . '/inc/i18n.php';
require_once PW_DIR . '/inc/security.php';
require_once PW_DIR . '/inc/setup.php';
require_once PW_DIR . '/inc/data.php';
require_once PW_DIR . '/inc/workflow.php';
require_once PW_DIR . '/inc/auth.php';
require_once PW_DIR . '/inc/compliance.php';
require_once PW_DIR . '/inc/billing.php';
require_once PW_DIR . '/inc/live-market.php';
require_once PW_DIR . '/inc/privacy-tools.php';
require_once PW_DIR . '/inc/catalog.php';
require_once PW_DIR . '/inc/forms.php';
require_once PW_DIR . '/inc/crm.php';
require_once PW_DIR . '/inc/knowledge.php';
require_once PW_DIR . '/inc/shortcodes.php';
require_once PW_DIR . '/inc/ajax.php';
require_once PW_DIR . '/inc/admin.php';
require_once PW_DIR . '/inc/v48-overrides.php';
require_once PW_DIR . '/inc/procurement-radar.php';
require_once PW_DIR . '/inc/direct-leads.php';
require_once PW_DIR . '/inc/local-direct-contacts.php';
require_once PW_DIR . '/inc/regional-radar.php';
require_once PW_DIR . '/inc/v493.php';
require_once PW_DIR . '/inc/v494-leads.php';
require_once PW_DIR . '/inc/v495-lead-quality.php';
require_once PW_DIR . '/inc/v497-plans.php';
require_once PW_DIR . '/inc/v497-assist.php';
require_once PW_DIR . '/inc/v498.php';
require_once PW_DIR . '/inc/v499.php';

require_once PW_DIR . '/inc/v500.php';
require_once PW_DIR . '/inc/v501.php';
require_once PW_DIR . '/inc/v502.php';

require_once PW_DIR . '/inc/v503.php';

require_once PW_DIR . '/inc/v510.php';

require_once PW_DIR . '/inc/v511.php';

require_once PW_DIR . '/inc/v512.php';

require_once PW_DIR . '/inc/v520-chat.php';
require_once PW_DIR . '/inc/v520-chat-ui.php';

require_once PW_DIR . '/inc/v540-leads.php';
require_once PW_DIR . '/inc/v540-worker-form.php';
require_once PW_DIR . '/inc/v540-automations.php';

require_once PW_DIR . '/inc/v541.php';

require_once PW_DIR . '/inc/v542.php';

require_once PW_DIR . '/inc/v543.php';

require_once PW_DIR . '/inc/v544.php';
