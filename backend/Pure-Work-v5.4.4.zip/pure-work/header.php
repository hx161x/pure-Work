<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="pw-page-loader" class="pw-page-loader" role="status" aria-live="polite" aria-label="<?php echo esc_attr(pw_t('Pure Work lädt','Pure Work is loading')); ?>">
  <div class="pw-loader-inner">
    <img src="<?php echo esc_url(PW_URI . '/assets/pure-work-logo.svg'); ?>" alt="Pure Work">
    <div class="pw-loader-track"><i></i></div>
    <span><?php echo esc_html(pw_t('Arbeitsbereich wird vorbereitet','Preparing your workspace')); ?></span>
  </div>
</div>
<noscript><style>#pw-page-loader{display:none!important}</style></noscript>
