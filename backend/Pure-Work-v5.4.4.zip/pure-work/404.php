<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main class="pw-simple-public">
  <div class="pw-public-wrap small" style="text-align:center;padding-top:70px">
    <span class="pw-kicker">404</span>
    <h1 style="font-size:48px;letter-spacing:-2px;margin:12px 0">Diese Seite gibt es nicht.</h1>
    <p style="color:#667085;line-height:1.7">Zurück zu Pure Work oder direkt ins Dashboard.</p>
    <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:24px">
      <a class="pw-btn primary" href="<?php echo esc_url(home_url('/')); ?>">Zur Startseite</a>
      <?php if (is_user_logged_in()): ?><a class="pw-btn ghost" href="<?php echo esc_url(pw_page_url('dashboard')); ?>">Zum Dashboard</a><?php endif; ?>
    </div>
  </div>
</main>
<?php get_footer(); ?>
