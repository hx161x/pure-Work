<?php
if (!defined('ABSPATH')) exit;
get_header();

// The domain always opens the public Pure Work landing page.
// The dashboard is a separate protected page and is never rendered as the homepage.
if (function_exists('pw_shortcode_landing')) {
    echo pw_shortcode_landing();
} else {
    echo '<main style="min-height:100vh;display:grid;place-items:center;font-family:system-ui;padding:40px"><div><h1>Pure Work</h1><p>Portal wird initialisiert.</p></div></main>';
}

get_footer();
