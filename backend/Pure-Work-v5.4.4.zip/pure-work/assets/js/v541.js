(() => {
  const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
  const root=$('[data-pw541-vacancy]');
  if(root){
    const form=$('[data-pw541-vacancy-form]',root), steps=$$('[data-step]',root), tabs=$$('[data-step-tab]',root), back=$('[data-v541-back]',root), next=$('[data-v541-next]',root), save=$('[data-v541-save]',root);
    let current=1;
    const show=(n)=>{current=Math.max(1,Math.min(3,n));steps.forEach(el=>el.classList.toggle('active',+el.dataset.step===current));tabs.forEach(el=>{const n=+el.dataset.stepTab;el.classList.toggle('active',n===current);el.classList.toggle('done',n<current)});back.hidden=current===1;next.hidden=current===3;save.hidden=current!==3;window.scrollTo({top:Math.max(0,root.getBoundingClientRect().top+window.scrollY-90),behavior:'smooth'});};
    const valid=()=>{const sec=$(`[data-step="${current}"]`,root);let ok=true;$$('[required]',sec).forEach(el=>{el.classList.remove('pw-invalid');if(!el.value.trim()){el.classList.add('pw-invalid');ok=false;}});return ok;};
    next?.addEventListener('click',()=>{if(valid())show(current+1)});back?.addEventListener('click',()=>show(current-1));tabs.forEach(t=>t.addEventListener('click',()=>{const n=+t.dataset.stepTab;if(n<current||valid())show(n)}));
    const out=(k,v)=>{const el=$(`[data-v541-out="${k}"]`,root);if(el)el.textContent=v||'—'};
    const preview=()=>{const title=$('[name="title"]',form)?.value||'Tätigkeit fehlt noch',loc=$('[name="location"]',form)?.value||'—',qty=$('[name="qty"]',form)?.value||'1',start=$('[name="start_date"]',form)?.value,dur=$('[name="duration"]',form)?.value||'Dauer noch offen';out('title',title);out('location',loc);out('qty',qty);out('start',start?new Date(start+'T12:00:00').toLocaleDateString(document.documentElement.lang==='en-US'?'en-GB':'de-DE'):'offen');out('duration',dur)};
    $$('[data-v541-preview]',root).forEach(el=>el.addEventListener('input',preview));
    const presets={
      lager:{title:'Lagerhelfer / Kommissionierer',industry:'Logistik',shift:'2-Schicht',hours:'35'},
      produktion:{title:'Produktionsmitarbeiter',industry:'Produktion',shift:'3-Schicht',hours:'35'},
      technik:{title:'Elektroniker / Technischer Mitarbeiter',industry:'Industrie',shift:'Tagschicht',hours:'40'},
      office:{title:'Kaufmännischer Mitarbeiter',industry:'Kaufmännisch',shift:'Tagschicht',hours:'40'}
    };
    $$('[data-preset]',root).forEach(btn=>btn.addEventListener('click',()=>{const p=presets[btn.dataset.preset];if(!p)return;Object.entries(p).forEach(([k,v])=>{const el=$(`[name="${k}"]`,form);if(el&&!el.value)el.value=v});preview();const title=$('[name="title"]',form);title?.focus()}));
    preview();
  }
})();
