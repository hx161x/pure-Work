(() => {
  const q = (s, r=document) => r.querySelector(s);
  const riskBtn = q('[data-pw542-risk-toggle]');
  const board = q('.pw-v499-board-grid');
  if (riskBtn && board) {
    riskBtn.addEventListener('click', () => {
      const active = board.classList.toggle('pw542-risk-only');
      riskBtn.classList.toggle('active', active);
      riskBtn.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
  }
})();
