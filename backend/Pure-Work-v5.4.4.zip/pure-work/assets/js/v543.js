(() => {
  const q=(s,r=document)=>r.querySelector(s);
  const panel=q('[data-pw-business-card-panel]');
  const toggle=q('[data-pw-business-card-toggle]');
  const close=q('[data-pw-business-card-close]');
  const send=q('[data-pw-business-card-send]');
  const form=q('[data-chat-form]');
  if(!panel||!toggle||!send||!form||!window.PW_APP) return;
  const thread=q('input[name="submission_id"]',form)?.value||'';
  const open=()=>{panel.hidden=false;panel.scrollIntoView({behavior:'smooth',block:'nearest'});};
  const shut=()=>{panel.hidden=true;};
  toggle.addEventListener('click',()=>panel.hidden?open():shut()); close?.addEventListener('click',shut);
  send.addEventListener('click',async()=>{
    send.disabled=true; const old=send.innerHTML; send.textContent=document.documentElement.lang.startsWith('en')?'Sending…':'Wird gesendet…';
    try{
      const body=new URLSearchParams({action:'pw_v543_send_card',nonce:PW_APP.nonce,submission_id:thread});
      const res=await fetch(PW_APP.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body});
      const json=await res.json(); if(!json.success) throw new Error(json?.data?.message||PW_APP.i18n.error);
      shut();
      // app.js polls in sub-second intervals; trigger immediate refresh by focusing the chat.
      window.dispatchEvent(new Event('focus'));
      const msg=q('.pw-chat-messages'); if(msg) setTimeout(()=>{msg.scrollTop=msg.scrollHeight;},250);
    }catch(e){ window.alert(e.message||PW_APP.i18n.error); }
    finally{send.disabled=false;send.innerHTML=old;}
  });
})();
