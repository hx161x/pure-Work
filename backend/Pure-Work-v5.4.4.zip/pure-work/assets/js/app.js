(function(){
  'use strict';
  if (typeof window.PW_APP === 'undefined') { window.PW_APP = {ajax:'',nonce:'',role:'',i18n:{saving:'Wird gespeichert…',saved:'Gespeichert',error:'Das hat nicht geklappt.',confirmDelete:'Wirklich löschen?'}}; }

  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

  function toast(message, type='success') {
    let stack = $('.pw-toast-stack');
    if (!stack) {
      stack = document.createElement('div');
      stack.className = 'pw-toast-stack';
      document.body.appendChild(stack);
    }
    const el = document.createElement('div');
    el.className = 'pw-toast ' + type;
    el.textContent = message;
    stack.appendChild(el);
    requestAnimationFrame(()=>el.classList.add('show'));
    setTimeout(()=>{ el.classList.remove('show'); setTimeout(()=>el.remove(),250); },3200);
  }

  async function ajax(action, data={}) {
    const body = new URLSearchParams();
    body.set('action', action);
    body.set('nonce', PW_APP.nonce);
    Object.entries(data).forEach(([k,v])=>body.set(k,v));
    const res = await fetch(PW_APP.ajax, {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}, body:body.toString()});
    const json = await res.json();
    if (!json.success) throw new Error((json.data && json.data.message) || PW_APP.i18n.error);
    return json.data;
  }

  function refreshAgencyRequirements(){
    const checked = $('input[name="role"]:checked');
    const isAgency = !!checked && checked.value === 'agency';
    const augType = $('.pw-aug-type');
    $$('[data-agency-required]').forEach(el=>{
      const isExpiry = el.name === 'aug_expiry';
      const unlimited = augType && augType.value === 'unlimited';
      el.required = isAgency && (!isExpiry || !unlimited);
    });
  }

  function initRoleSelect(){
    const radios = $$('input[name="role"]');
    if (!radios.length) return;
    const update = () => {
      const checked = $('input[name="role"]:checked');
      document.body.classList.toggle('pw-register-agency', !!checked && checked.value === 'agency');
      refreshAgencyRequirements();
    };
    radios.forEach(r=>r.addEventListener('change',update)); update();
  }

  function initTargetMode(){
    const el = $('.pw-target-mode');
    if (!el) return;
    const block = $('.pw-target-agencies');
    const update = ()=>{ if(block) block.style.display = el.value === 'selected' ? '' : 'none'; };
    el.addEventListener('change',update); update();
  }

  function initModals(){
    $$('[data-modal-open]').forEach(btn=>btn.addEventListener('click',()=>{
      const m = document.getElementById(btn.dataset.modalOpen);
      if(m){ m.classList.add('open'); m.setAttribute('aria-hidden','false'); document.body.classList.add('pw-modal-open'); }
    }));
    $$('[data-modal-close]').forEach(btn=>btn.addEventListener('click',()=>{
      const m = btn.closest('.pw-modal');
      if(m){ m.classList.remove('open'); m.setAttribute('aria-hidden','true'); document.body.classList.remove('pw-modal-open'); }
    }));
    $$('.pw-modal-x').forEach(btn=>btn.addEventListener('click',()=>{
      const m=btn.closest('.pw-modal'); if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true');document.body.classList.remove('pw-modal-open');}
    }));
  }

  function initConfirms(){
    $$('.pw-confirm').forEach(el=>el.addEventListener('click',e=>{
      if(!window.confirm(PW_APP.i18n.confirmDelete)) e.preventDefault();
    }));
  }

  function initStatusButtons(){
    $$('.pw-status-btn').forEach(btn=>btn.addEventListener('click',async()=>{
      const old = btn.textContent;
      btn.disabled = true; btn.textContent = PW_APP.i18n.saving;
      try {
        const data = await ajax('pw_submission_status',{submission_id:btn.dataset.submission,status:btn.dataset.status});
        $$('.pw-status-btn').forEach(b=>b.classList.toggle('active', b===btn));
        btn.textContent = data.label;
        const headBadge = $('.pw-page-head-inline > .pw-badge');
        if(headBadge){ const temp=document.createElement('div'); temp.innerHTML=data.badge; headBadge.replaceWith(temp.firstElementChild); }
        toast((document.body.classList.contains('pw-lang-en') ? 'Status changed to “' : 'Status auf „')+data.label+(document.body.classList.contains('pw-lang-en') ? '”.' : '“ geändert.'));
        if(data.chat_open && btn.dataset.status === 'accepted'){
          window.setTimeout(()=>{ window.location.href = (PW_APP.messages || '') + ((PW_APP.messages||'').includes('?')?'&':'?') + 'thread=' + encodeURIComponent(btn.dataset.submission); },450);
        }
      } catch(err) { btn.textContent=old; toast(err.message,'error'); }
      finally { btn.disabled=false; }
    }));
  }

  /* Pure Work 5.2.0 – Live-Chat -------------------------------------------
     Adaptive Abfrage statt starrer 3 Sekunden, Lesebestätigung, Tippen-Hinweis,
     Anhänge, Angebote und Textbausteine. */
  async function ajaxForm(action, formData){
    formData.set('action', action);
    formData.set('nonce', PW_APP.nonce);
    const res = await fetch(PW_APP.ajax, {method:'POST', credentials:'same-origin', body:formData});
    const json = await res.json();
    if(!json.success) throw new Error((json.data && json.data.message) || PW_APP.i18n.error);
    return json.data;
  }

  function initChat(){
    const form = $('[data-chat-form]');
    const messages = $('.pw-chat-messages');
    if(!form || !messages) return;
    const en = document.body.classList.contains('pw-lang-en');
    const textarea = $('textarea[name="message"]', form);
    const fileInput = $('input[name="attachment"]', form);
    const preview = $('[data-attach-preview]');
    const typingLine = $('[data-typing]');
    const thread = $('input[name="submission_id"]', form)?.value || messages.dataset.thread || '';
    const baseTitle = document.title;
    let stopped = false, polling = false, idleSince = Date.now(), timer = null, delay = 900;

    const scrollBottom = () => { messages.scrollTop = messages.scrollHeight; };
    const maxId = () => $$('[data-message-id]', messages)
      .reduce((m, el) => Math.max(m, parseInt(el.dataset.messageId || '0', 10) || 0), 0);

    function renderOffer(o, id, mine){
      const box = document.createElement('div');
      box.className = 'pw-offer-card pw-offer-' + (o.status || 'open');
      box.dataset.offerMessage = id;
      const facts = [
        [en ? 'Charge rate' : 'Verrechnungssatz', o.rate ? o.rate + ' €/h' : ''],
        [en ? 'Start' : 'Start', o.start || ''],
        [en ? 'Shift' : 'Schicht', o.shift || ''],
        [en ? 'Hrs/week' : 'Std./Woche', o.hours || '']
      ].filter(f => f[1]);
      const kicker = document.createElement('span');
      kicker.className = 'pw-kicker';
      kicker.textContent = en ? 'BINDING OFFER' : 'VERBINDLICHES ANGEBOT';
      box.appendChild(kicker);
      const wrap = document.createElement('div');
      wrap.className = 'pw-offer-facts';
      facts.forEach(([label, value]) => {
        const d = document.createElement('div');
        const s = document.createElement('small'); s.textContent = label;
        const b = document.createElement('b'); b.textContent = value;
        d.appendChild(s); d.appendChild(b); wrap.appendChild(d);
      });
      box.appendChild(wrap);
      if(o.note){ const p = document.createElement('p'); p.className = 'pw-offer-note'; p.textContent = o.note; box.appendChild(p); }
      if((o.status || 'open') === 'open' && !mine && (PW_APP.role || '') === 'client'){
        const actions = document.createElement('div');
        actions.className = 'pw-offer-actions';
        [['accepted', en ? 'Accept' : 'Annehmen', 'primary'], ['declined', en ? 'Decline' : 'Ablehnen', 'ghost']].forEach(([d, label, cls]) => {
          const b = document.createElement('button');
          b.type = 'button'; b.className = 'pw-btn ' + cls + ' small';
          b.dataset.offerDecide = d; b.textContent = label;
          actions.appendChild(b);
        });
        box.appendChild(actions);
      }
      return box;
    }

    function renderBusinessCard(card){
      const wrap=document.createElement('article'); wrap.className='pw-v543-business-card';
      const head=document.createElement('header');
      const avatar=document.createElement('span'); avatar.className='pw-v543-card-avatar'; avatar.textContent=card.initials||'PW';
      const info=document.createElement('div');
      const badge=document.createElement('small'); badge.textContent=card.badge||(en?'Pure Work contact':'Pure Work Kontakt');
      const h=document.createElement('h4'); h.textContent=card.company||'';
      const role=document.createElement('p'); role.textContent=card.role||'';
      info.append(badge,h,role);
      const mark=document.createElement('span'); mark.className='pw-v543-card-mark'; mark.textContent='PW';
      head.append(avatar,info,mark); wrap.appendChild(head);
      const body=document.createElement('div'); body.className='pw-v543-card-contact';
      const add=(icon,label,value)=>{ if(!value)return; const d=document.createElement('div'); d.innerHTML='<span class="pw-v543-mini-icon">'+icon+'</span>'; const span=document.createElement('span'); const sm=document.createElement('small');sm.textContent=label;const b=document.createElement('b');b.textContent=value;span.append(sm,b);d.appendChild(span);body.appendChild(d); };
      add('👤',en?'Contact':'Ansprechpartner',card.contact); add('☎',en?'Phone':'Telefon',card.phone); add('✉',en?'Email':'E-Mail',card.email); add('⌖',en?'Location':'Standort',[card.zip,card.city].filter(Boolean).join(' '));
      wrap.appendChild(body);
      if(card.industry){const p=document.createElement('p');p.className='pw-v543-card-industry';p.textContent=card.industry;wrap.appendChild(p);}
      const foot=document.createElement('footer');
      if(card.phone){const a=document.createElement('a');a.href='tel:'+card.phone.replace(/[^0-9+]/g,'');a.textContent=en?'Call':'Anrufen';foot.appendChild(a);}
      if(card.email){const a=document.createElement('a');a.href='mailto:'+card.email;a.textContent='E-Mail';foot.appendChild(a);}
      if(card.download_url){const a=document.createElement('a');a.href=card.download_url;a.textContent=en?'Save contact':'Kontakt speichern';foot.appendChild(a);}
      wrap.appendChild(foot); return wrap;
    }

    function appendMessage(item){
      if(!item || messages.querySelector('[data-message-id="' + item.id + '"]')) return;
      const nearBottom = messages.scrollHeight - messages.scrollTop - messages.clientHeight < 120;

      if(item.system){
        const sys = document.createElement('div');
        sys.className = 'pw-chat-system'; sys.dataset.messageId = item.id;
        const s = document.createElement('span'); s.textContent = 'System';
        const p = document.createElement('p'); p.textContent = item.message;
        sys.appendChild(s); sys.appendChild(p); messages.appendChild(sys);
      } else {
        const row = document.createElement('div');
        row.className = 'pw-message ' + (item.mine ? 'mine' : 'theirs') + (item.offer ? ' has-offer' : '') + (item.business_card ? ' has-business-card' : '');
        row.dataset.messageId = item.id;
        const bubble = document.createElement('div');
        if(item.business_card){
          bubble.appendChild(renderBusinessCard(item.business_card));
        } else if(item.offer){
          bubble.appendChild(renderOffer(item.offer, item.id, item.mine));
        } else {
          const text = document.createElement('span');
          text.style.whiteSpace = 'pre-wrap';
          text.textContent = item.message;   // kein doppeltes Escaping
          bubble.appendChild(text);
        }
        if(item.attachment){
          const a = document.createElement('a');
          a.className = 'pw-chat-attachment'; a.href = item.attachment.url;
          a.target = '_blank'; a.rel = 'noopener noreferrer';
          a.textContent = item.attachment.name + (item.attachment.size ? ' · ' + item.attachment.size : '');
          bubble.appendChild(a);
        }
        const meta = document.createElement('small');
        meta.className = 'pw-message-meta'; meta.textContent = item.time;
        if(item.mine){
          const tick = document.createElement('i');
          tick.className = 'pw-read-state' + (item.read ? ' read' : '');
          tick.textContent = item.read ? '✓✓' : '✓';
          meta.appendChild(tick);
        }
        bubble.appendChild(meta); row.appendChild(bubble); messages.appendChild(row);
      }
      if(nearBottom || item.mine) scrollBottom();
    }

    function markRead(ids){
      (ids || []).forEach(id => {
        const tick = messages.querySelector('[data-message-id="' + id + '"] .pw-read-state');
        if(tick && !tick.classList.contains('read')){ tick.classList.add('read'); tick.textContent = '✓✓'; }
      });
    }

    function schedule(){
      window.clearTimeout(timer);
      const idle = Date.now() - idleSince;
      delay = idle < 120000 ? 900 : (idle < 600000 ? 1800 : 4500);
      timer = window.setTimeout(poll, delay);
    }

    async function poll(){
      if(stopped || polling || !thread){ schedule(); return; }
      if(document.hidden){ schedule(); return; }
      polling = true;
      try{
        const data = await ajax('pw_v520_updates', {submission_id: thread, last_id: maxId()});
        const fresh = (data.items || []).filter(i => !i.mine);
        (data.items || []).forEach(appendMessage);
        markRead(data.read_ids);
        if(typingLine) typingLine.hidden = !data.typing;
        if(fresh.length){
          idleSince = Date.now();
          if(document.hidden) document.title = '(' + fresh.length + ') ' + baseTitle;
        }
        $$('[data-pw-live-messages]').forEach(el => { el.textContent = data.unread; el.hidden = !data.unread; });
      }catch(err){ /* Netzaussetzer bleiben still, der nächste Versuch folgt */ }
      finally{ polling = false; schedule(); }
    }

    let typingSent = 0;
    if(textarea){
      textarea.addEventListener('input', () => {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(140, textarea.scrollHeight) + 'px';
        idleSince = Date.now();
        const now = Date.now();
        if(now - typingSent > 4000){ typingSent = now; ajax('pw_v520_typing', {submission_id: thread}).catch(()=>{}); }
      });
      textarea.addEventListener('keydown', e => {
        if(e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); form.requestSubmit(); }
      });
    }

    if(fileInput && preview){
      fileInput.addEventListener('change', () => {
        const f = fileInput.files[0];
        if(!f){ preview.hidden = true; preview.textContent = ''; return; }
        if(f.size > 5 * 1024 * 1024){
          toast(en ? 'Maximum 5 MB per file.' : 'Maximal 5 MB pro Datei.', 'error');
          fileInput.value = ''; preview.hidden = true; return;
        }
        preview.hidden = false;
        preview.textContent = (en ? 'Attached: ' : 'Angehängt: ') + f.name;
      });
    }

    form.addEventListener('submit', async e => {
      e.preventDefault();
      const btn = $('button[type="submit"]', form);
      const text = (textarea.value || '').trim();
      const hasFile = fileInput && fileInput.files.length;
      if(!text && !hasFile) return;
      btn.disabled = true;
      try{
        const fd = new FormData();
        fd.set('submission_id', thread);
        fd.set('message', text);
        if(hasFile) fd.set('attachment', fileInput.files[0]);
        const data = await ajaxForm('pw_v520_send', fd);
        appendMessage(data.item);
        textarea.value = ''; textarea.style.height = '';
        if(fileInput){ fileInput.value = ''; }
        if(preview){ preview.hidden = true; preview.textContent = ''; }
        idleSince = Date.now();
        scrollBottom();
      }catch(err){ toast(err.message, 'error'); }
      finally{ btn.disabled = false; textarea.focus(); }
    });

    $$('[data-quick-reply]').forEach(b => b.addEventListener('click', () => {
      if(!textarea) return;
      textarea.value = textarea.value ? textarea.value + ' ' + b.dataset.quickReply : b.dataset.quickReply;
      textarea.focus();
      textarea.dispatchEvent(new Event('input'));
    }));

    const offerBtn = $('[data-offer-send]');
    if(offerBtn){
      offerBtn.addEventListener('click', async () => {
        const box = $('[data-offer-form]');
        const val = n => ($('[name="' + n + '"]', box)?.value || '').trim();
        if(!val('rate')){ toast(en ? 'Please enter a charge rate.' : 'Bitte einen Verrechnungssatz angeben.', 'error'); return; }
        offerBtn.disabled = true;
        try{
          const data = await ajax('pw_v520_offer_send', {
            submission_id: thread, rate: val('rate'), start: val('start'),
            shift: val('shift'), hours: val('hours'), note: val('note')
          });
          appendMessage(data.item);
          const composer = offerBtn.closest('details'); if(composer) composer.open = false;
          toast(en ? 'Offer sent.' : 'Angebot gesendet.');
        }catch(err){ toast(err.message, 'error'); }
        finally{ offerBtn.disabled = false; }
      });
    }

    messages.addEventListener('click', async e => {
      const btn = e.target.closest('[data-offer-decide]');
      if(!btn) return;
      const card = btn.closest('[data-offer-message]');
      const mid = card?.dataset.offerMessage;
      if(!mid) return;
      btn.disabled = true;
      try{
        const data = await ajax('pw_v520_offer_decide', {submission_id: thread, message_id: mid, decision: btn.dataset.offerDecide});
        card.classList.remove('pw-offer-open');
        card.classList.add('pw-offer-' + data.status);
        const actions = card.querySelector('.pw-offer-actions');
        if(actions){
          const state = document.createElement('span');
          state.className = 'pw-offer-state';
          state.textContent = data.status === 'accepted' ? (en ? 'Accepted' : 'Angenommen') : (en ? 'Declined' : 'Abgelehnt');
          actions.replaceWith(state);
        }
        if(data.item) appendMessage(data.item);
      }catch(err){ toast(err.message, 'error'); btn.disabled = false; }
    });

    document.addEventListener('visibilitychange', () => {
      if(!document.hidden){ document.title = baseTitle; idleSince = Date.now(); poll(); }
    });
    window.addEventListener('pagehide', () => { stopped = true; window.clearTimeout(timer); }, {once: true});
    scrollBottom();
    window.setTimeout(poll, 180);
  }


  /* Pure Work 5.4.0 – Mitarbeiter-Assistent -------------------------------
     Drei echte Schritte statt einer Wand aus Feldern, dazu eine Vorschau,
     die zeigt, was der Auftraggeber tatsächlich zu sehen bekommt. */
  function initWorkerWizard(){
    const form = $('[data-worker-wizard]');
    if(!form) return;
    const en = (PW_APP.role||'') && document.documentElement.lang === 'en';
    const steps = $$('.pw-w540-step', form);
    const navs  = $$('[data-step-nav]', form);
    const back  = $('[data-wizard-back]', form);
    const next  = $('[data-wizard-next]', form);
    const save  = $('[data-wizard-save]', form);
    let current = 1;
    const total = steps.length;

    function show(n){
      current = Math.min(Math.max(n,1), total);
      steps.forEach(s => s.classList.toggle('active', parseInt(s.dataset.step,10) === current));
      navs.forEach(li => {
        const i = parseInt(li.dataset.stepNav,10);
        li.classList.toggle('active', i === current);
        li.classList.toggle('done', i < current);
      });
      back.hidden = current === 1;
      next.hidden = current === total;
      save.hidden = current !== total;
      const head = $('.pw-w540-steps', form);
      if(head) head.scrollIntoView({behavior:'smooth', block:'nearest'});
    }

    /* Pflichtfelder gehören zum Schritt, in dem sie stehen. Sonst blockiert
       ein leeres Feld aus Schritt 2 das Speichern in Schritt 3, ohne dass
       sichtbar wird, woran es liegt. */
    function validate(step){
      const missing = $$('[data-required-step="'+step+'"]', form).filter(el => !el.value.trim());
      missing.forEach(el => {
        el.classList.add('pw-invalid');
        el.addEventListener('input', () => el.classList.remove('pw-invalid'), {once:true});
      });
      if(missing.length){
        missing[0].focus();
        toast(missing[0].closest('label')?.childNodes[0]?.textContent?.trim()
          ? (missing[0].closest('label').childNodes[0].textContent.trim() + ' ' + (en ? 'is required.' : 'wird noch gebraucht.'))
          : (en ? 'Please complete this field.' : 'Bitte dieses Feld ausfüllen.'), 'error');
        return false;
      }
      return true;
    }

    next.addEventListener('click', () => { if(validate(current)) show(current+1); });
    back.addEventListener('click', () => show(current-1));
    navs.forEach(li => li.addEventListener('click', () => {
      const target = parseInt(li.dataset.stepNav,10);
      if(target <= current || validate(current)) show(target);
    }));
    form.addEventListener('submit', e => {
      for(let i=1;i<=total;i++){
        if(!validate(i)){ e.preventDefault(); show(i); return; }
      }
    });

    /* ---- Live-Vorschau ---- */
    const out = n => $('[data-preview-out="'+n+'"]', form);
    const field = n => $('[data-preview="'+n+'"]', form);

    function initials(text){
      const parts = (text||'').trim().split(/\s+/).filter(Boolean);
      if(!parts.length) return '––';
      return (parts[0][0] + (parts[1] ? parts[1][0] : '')).toUpperCase();
    }

    function renderPreview(){
      const role = field('role')?.value.trim() || '';
      const loc  = field('location')?.value.trim() || '';
      const exp  = field('experience')?.value.trim() || '';
      const av   = field('available')?.value || '';

      if(out('code')) out('code').textContent = initials(role);
      if(out('role')) out('role').textContent = role || (en ? 'Role still missing' : 'Tätigkeit fehlt noch');
      if(out('meta')) out('meta').textContent = [loc || '—', exp ? exp + (en ? ' years' : ' Jahre') : ''].filter(Boolean).join(' · ');
      if(out('available')) out('available').textContent = av
        ? new Date(av).toLocaleDateString(en ? 'en-GB' : 'de-DE')
        : (en ? 'immediately' : 'sofort');

      const chips = out('chips');
      if(chips){
        chips.textContent = '';
        ['qualifications','shifts','languages','industries'].forEach(key => {
          (field(key)?.value || '').split(',').map(v=>v.trim()).filter(Boolean).slice(0,3).forEach(v => {
            const s = document.createElement('span'); s.textContent = v; chips.appendChild(s);
          });
        });
      }

      const flags = out('flags');
      if(flags){
        flags.textContent = '';
        [['driver', en ? 'Driving licence' : 'Führerschein'], ['car', en ? 'Own car' : 'Eigener PKW']].forEach(([k,label]) => {
          const cb = $('[data-preview-toggle="'+k+'"]', form);
          if(cb && cb.checked){ const s = document.createElement('span'); s.textContent = '✓ ' + label; flags.appendChild(s); }
        });
      }

      /* Profilstärke: gewichtet nach dem, was einem Auftraggeber wirklich
         bei der Entscheidung hilft. Tätigkeit allein bringt keinen Einsatz. */
      const weights = [
        [role, 26], [loc, 14], [exp, 12], [av, 12],
        [field('qualifications')?.value, 18],
        [field('shifts')?.value, 8],
        [field('industries')?.value, 6],
        [field('languages')?.value, 4]
      ];
      const pct = Math.min(100, weights.reduce((sum,[v,w]) => sum + ((v||'').trim() ? w : 0), 0));
      if(out('fillbar')) out('fillbar').style.width = pct + '%';
      if(out('fillnum')) out('fillnum').textContent = pct + ' %';
      const bar = out('fillbar');
      if(bar) bar.className = pct >= 80 ? 'strong' : (pct >= 50 ? 'ok' : 'weak');
    }

    form.addEventListener('input', renderPreview);
    form.addEventListener('change', e => {
      const t = e.target.closest('.pw-w540-toggle');
      if(t) t.classList.toggle('on', t.querySelector('input').checked);
      const r = e.target.closest('.pw-w540-radio-row');
      if(r) $$('label', r).forEach(l => l.classList.toggle('checked', l.querySelector('input').checked));
      renderPreview();
    });
    renderPreview();
    show(1);
  }

  function initFavorites(){
    $$('.pw-favorite-btn').forEach(btn=>btn.addEventListener('click',async e=>{
      e.preventDefault(); e.stopPropagation(); btn.disabled=true;
      try{const data=await ajax('pw_toggle_favorite',{company_id:btn.dataset.company});btn.classList.toggle('primary',data.active);btn.classList.toggle('ghost',!data.active);btn.textContent=data.label;toast(data.active?'Als Favorit gespeichert.':'Favorit entfernt.');}
      catch(err){toast(err.message,'error');} finally{btn.disabled=false;}
    }));
    $$('.pw-block-btn').forEach(btn=>btn.addEventListener('click',async e=>{
      e.preventDefault();e.stopPropagation();btn.disabled=true;
      try{const data=await ajax('pw_toggle_block',{company_id:btn.dataset.company});const card=btn.closest('.pw-company-card');if(card)card.classList.toggle('blocked',data.active);toast(data.active?'Unternehmen stummgeschaltet.':'Stummschaltung aufgehoben.');}
      catch(err){toast(err.message,'error');}finally{btn.disabled=false;}
    }));
  }

  function initThreadFilter(){
    const input=$('[data-thread-filter]');if(!input)return;
    input.addEventListener('input',()=>{const q=input.value.toLowerCase().trim();$$('.pw-thread').forEach(t=>t.style.display=!q||t.textContent.toLowerCase().includes(q)?'':'none');});
  }

  function initSmoothAnchors(){
    $$('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{
      const id=a.getAttribute('href'); if(id==='#')return; const target=$(id); if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth',block:'start'});}
    }));
  }

  function initAugType(){
    $$('.pw-aug-type').forEach(select=>{
      const scope = select.closest('.pw-form-grid') || select.closest('form') || document;
      const expiryField = $('.pw-aug-expiry-field', scope);
      const note = $('.pw-aug-unlimited-note', scope);
      const expiry = expiryField ? $('input[name="aug_expiry"]', expiryField) : null;
      const update = ()=>{
        const unlimited = select.value === 'unlimited';
        if(expiryField) expiryField.hidden = unlimited;
        if(note) note.hidden = !unlimited;
        if(expiry){
          expiry.disabled = unlimited;
          if(unlimited) expiry.value = '';
          if(expiry.hasAttribute('data-agency-required')){
            const role = $('input[name="role"]:checked');
            expiry.required = !unlimited && (!role || role.value === 'agency');
          }
        }
        refreshAgencyRequirements();
      };
      select.addEventListener('change', update);
      update();
    });
  }

  function initOccupationSearch(){
    $$('[data-pw-occupation]').forEach(input=>{
      const label = input.closest('label');
      if(!label) return;
      label.classList.add('pw-occupation-field');
      input.removeAttribute('list');
      const menu = document.createElement('div');
      menu.className = 'pw-occupation-menu';
      menu.hidden = true;
      label.appendChild(menu);
      let timer = null;
      let requestId = 0;

      const close = ()=>{ menu.hidden = true; menu.innerHTML=''; };
      const render = items=>{
        menu.innerHTML='';
        if(!items || !items.length){ close(); return; }
        items.forEach(item=>{
          const button=document.createElement('button');
          button.type='button';
          button.className='pw-occupation-item';
          const text=document.createElement('span'); text.textContent=item.label;
          const code=document.createElement('small'); code.textContent='KldB '+item.code;
          button.append(text,code);
          button.addEventListener('mousedown',e=>{
            e.preventDefault();
            input.value=item.label;
            input.dispatchEvent(new Event('change',{bubbles:true}));
            close();
          });
          menu.appendChild(button);
        });
        menu.hidden=false;
      };

      input.addEventListener('input',()=>{
        clearTimeout(timer);
        const q=input.value.trim();
        if(q.length<2){close();return;}
        timer=setTimeout(async()=>{
          const id=++requestId;
          try{
            const data=await ajax('pw_occupation_search',{q});
            if(id!==requestId)return;
            render(data.items||[]);
          }catch(err){close();}
        },220);
      });
      input.addEventListener('focus',()=>{ if(input.value.trim().length>=2) input.dispatchEvent(new Event('input')); });
      document.addEventListener('click',e=>{ if(!label.contains(e.target)) close(); });
    });
  }


  function initLoader(){
    const loader = document.getElementById('pw-page-loader');
    if(!loader) return;
    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const started = performance.now();
    const hide = ()=> {
      // Give the brand animation enough time to feel intentional instead of
      // flashing for a few milliseconds. Reduced-motion users are never held.
      const elapsed = performance.now() - started;
      const wait = reduced ? 0 : Math.max(0, 1180 - elapsed);
      window.setTimeout(()=>{
        loader.classList.add('is-done');
        window.setTimeout(()=>loader.setAttribute('hidden','hidden'), reduced ? 0 : 460);
      }, wait);
    };
    if(document.readyState === 'complete') hide();
    else window.addEventListener('load',hide,{once:true});

    document.addEventListener('click',e=>{
      const a=e.target.closest('a');
      if(!a || a.target==='_blank' || a.hasAttribute('download') || a.getAttribute('href')?.startsWith('#')) return;
      let url;
      try{ url=new URL(a.href,window.location.href); }catch(_){ return; }
      if(url.origin!==window.location.origin || url.href===window.location.href) return;
      loader.removeAttribute('hidden');
      requestAnimationFrame(()=>loader.classList.remove('is-done'));
    });
    document.addEventListener('submit',e=>{
      const form=e.target;
      if(!(form instanceof HTMLFormElement) || form.dataset.chatForm!==undefined) return;
      loader.removeAttribute('hidden');
      requestAnimationFrame(()=>loader.classList.remove('is-done'));
    },true);
  }

  function initReveal(){
    const nodes=$$('.pw-section, .pw-card, .pw-metric, .pw-vacancy-card, .pw-company-card, .pw-live-job');
    if(!nodes.length) return;
    const reduced=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    nodes.forEach(n=>n.classList.add('pw-reveal'));
    if(reduced || !('IntersectionObserver' in window)){
      nodes.forEach(n=>n.classList.add('is-visible')); return;
    }
    const io=new IntersectionObserver(entries=>{
      entries.forEach(entry=>{
        if(entry.isIntersecting){ entry.target.classList.add('is-visible'); io.unobserve(entry.target); }
      });
    },{threshold:.08,rootMargin:'0px 0px -24px 0px'});
    nodes.forEach(n=>io.observe(n));
  }

  function initSmartDescription(){
    $$('[data-pw-smart-description]').forEach(btn=>{
      btn.addEventListener('click',()=>{
        const form=btn.closest('form'); if(!form) return;
        const get=name=>{ const el=$(`[name="${name}"]`,form); return el ? String(el.value||'').trim() : ''; };
        const title=get('title')||'Mitarbeiter';
        const qty=get('qty')||'1';
        const location=get('location');
        const start=get('start_date');
        const duration=get('duration');
        const hours=get('hours');
        const shift=get('shift');
        const industry=get('industry');
        const must=get('must_quals');
        const nice=get('nice_quals');
        const language=get('language');
        const driver=$('[name="driver"]',form)?.checked;
        const lines=[
          `Gesucht werden ${qty} ${title}${location ? ` für einen Einsatz in ${location}` : ''}.`,
          `${start ? `Geplanter Start: ${start}. ` : ''}${duration ? `Voraussichtliche Einsatzdauer: ${duration}. ` : ''}${hours ? `Umfang: ${hours} Wochenstunden.` : ''}`.trim(),
          `${industry ? `Einsatzbereich: ${industry}. ` : ''}${shift ? `Arbeitszeit/Schichtmodell: ${shift}.` : ''}`.trim(),
          must ? `Erforderliche Qualifikationen: ${must}.` : '',
          nice ? `Wünschenswerte Zusatzqualifikationen: ${nice}.` : '',
          `${language ? `Sprachkenntnisse: ${language}. ` : ''}${driver ? 'Führerschein ist erforderlich.' : ''}`.trim(),
          'Bitte reichen Sie ausschließlich aktuell verfügbare und passende Profile über Pure Work ein.'
        ].filter(Boolean);
        const area=$('textarea[name="description"]',form);
        if(area){ area.value=lines.join('\\n\\n'); area.focus(); toast('Pure Assist hat einen strukturierten Vorschlag erstellt.'); }
      });
    });
  }

  function initMetricCounters(){
    const reduced=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(reduced) return;
    $$('.pw-metric b').forEach(el=>{
      const raw=el.textContent.trim();
      if(!/^\\d+$/.test(raw)) return;
      const target=parseInt(raw,10);
      if(target<=0 || target>99999) return;
      const start=performance.now(), duration=650;
      const step=now=>{
        const t=Math.min(1,(now-start)/duration);
        el.textContent=String(Math.round(target*(1-Math.pow(1-t,3))));
        if(t<1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }


  function initCopyButtons(){
    $$('[data-copy-target]').forEach(btn=>{
      btn.addEventListener('click',async()=>{
        const target=$(btn.dataset.copyTarget || '');
        if(!target) return;
        const value=('value' in target) ? target.value : target.textContent;
        try{
          if(navigator.clipboard && window.isSecureContext){ await navigator.clipboard.writeText(value); }
          else{
            const tmp=document.createElement('textarea'); tmp.value=value; tmp.setAttribute('readonly',''); tmp.style.position='fixed'; tmp.style.opacity='0'; document.body.appendChild(tmp); tmp.select(); document.execCommand('copy'); tmp.remove();
          }
          toast(document.body.classList.contains('pw-lang-en') ? 'Copied to clipboard.' : 'Text kopiert.');
        }catch(_){ toast(document.body.classList.contains('pw-lang-en') ? 'Could not copy the text.' : 'Text konnte nicht kopiert werden.','error'); }
      });
    });
  }

  function initCopyNearest(){
    $$('[data-copy-nearest]').forEach(btn=>{
      btn.addEventListener('click',async()=>{
        const wrap=btn.closest('.pw-id-share-card');
        const target=wrap ? wrap.querySelector('[data-copy-value]') : null;
        const value=target ? (target.dataset.copyValue || target.textContent || '').trim() : '';
        if(!value) return;
        try{
          if(navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(value);
          else { const t=document.createElement('textarea');t.value=value;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();document.execCommand('copy');t.remove(); }
          toast(document.body.classList.contains('pw-lang-en')?'ID copied.':'ID kopiert.');
        }catch(_){ toast(document.body.classList.contains('pw-lang-en')?'Could not copy ID.':'ID konnte nicht kopiert werden.','error'); }
      });
    });
  }

  function initLivePulse(){
    if(!document.querySelector('[data-pw-live-root]') || !PW_APP.ajax || !PW_APP.nonce) return;
    let busy=false;
    const poll=async()=>{
      if(busy || document.hidden) return;
      busy=true;
      try{
        const data=await ajax('pw_live_pulse',{});
        $$('[data-pw-live-notices]').forEach(el=>{el.textContent=data.notices||0;el.hidden=!(data.notices>0);});
        $$('[data-pw-live-messages]').forEach(el=>{el.textContent=data.messages||0;el.hidden=!(data.messages>0);});
        $$('[data-pw-live-open-vacancies]').forEach(el=>el.textContent=data.open_vacancies??el.textContent);
        $$('[data-pw-live-workers]').forEach(el=>el.textContent=data.workers??el.textContent);
        document.documentElement.style.setProperty('--pw-live-flash',String(Date.now()));
      }catch(_){ /* network hiccups should never interrupt the workflow */ }
      finally{busy=false;}
    };
    window.setTimeout(poll,1800);
    window.setInterval(poll,20000);
    document.addEventListener('visibilitychange',()=>{ if(!document.hidden) poll(); });
  }

  function initWizardProgress(){
    $$('.pw-wizard-form').forEach(form=>{
      const cards=$$('.pw-form-card',form), dots=$$('.pw-form-progress i',form);
      if(cards.length<2||!dots.length)return;
      const activate=idx=>dots.forEach((d,i)=>d.classList.toggle('active',i<=idx));
      cards.forEach((card,idx)=>{
        card.addEventListener('focusin',()=>activate(idx));
        card.addEventListener('pointerdown',()=>activate(idx));
      });
    });
  }

  function initCrmPitch(){
    const area=$('#pw-crm-pitch-text');
    if(!area) return;
    const mail=$('#pw-crm-mailto');
    const company=String(area.dataset.baseCompany || '').trim();
    const job=String(area.dataset.baseJob || '').trim();
    const isEn=document.body.classList.contains('pw-lang-en');
    const checks=$$('[data-pitch-worker]');
    const render=()=>{
      const selected=checks.filter(c=>c.checked).map(c=>({code:c.dataset.code||'',role:c.dataset.role||'',exp:c.dataset.exp||'',date:c.dataset.date||''}));
      let text='';
      if(isEn){
        text=`Hello${company ? ' ' + company : ''},\n\n${job ? `we noticed your current staffing demand for “${job}”. ` : ''}Pure Work helps us match currently available staff with concrete assignments quickly and in a structured way.\n\n`;
        if(selected.length){
          text+='We can currently offer the following anonymised profiles:\n';
          selected.forEach(w=>{ text+=`• ${w.code} · ${w.role}${w.exp ? ` · ${w.exp} years experience` : ''}${w.date ? ` · available ${w.date}` : ''}\n`; });
          text+='\n';
        } else text+='We can check our current Talent Pool immediately and send matching anonymised profiles.\n\n';
        text+='If the demand is still current, we would be happy to coordinate the requirements and possible start dates directly.\n\nKind regards';
      } else {
        text=`Guten Tag${company ? ' ' + company : ''},\n\n${job ? `wir sind auf Ihren aktuellen Personalbedarf „${job}“ aufmerksam geworden. ` : ''}Über Pure Work gleichen wir aktuell verfügbares Personal schnell und strukturiert mit konkreten Einsätzen ab.\n\n`;
        if(selected.length){
          text+='Aktuell können wir Ihnen folgende anonymisierte Profile anbieten:\n';
          selected.forEach(w=>{ text+=`• ${w.code} · ${w.role}${w.exp ? ` · ${w.exp} Jahre Erfahrung` : ''}${w.date ? ` · verfügbar ${w.date}` : ''}\n`; });
          text+='\n';
        } else text+='Gerne prüfen wir unseren aktuellen Talent Pool sofort und reichen passende anonymisierte Profile ein.\n\n';
        text+='Falls der Bedarf noch aktuell ist, stimmen wir Anforderungen und mögliche Starttermine gerne direkt mit Ihnen ab.\n\nFreundliche Grüße';
      }
      area.value=text;
      if(mail){
        const raw=mail.getAttribute('href') || '';
        const email=(raw.match(/^mailto:([^?]+)/i)||[])[1] || '';
        const subject=isEn ? `Staffing proposal${job ? ' – '+job : ''}` : `Personalvorschlag${job ? ' – '+job : ''}`;
        mail.href=`mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
      }
    };
    checks.forEach(c=>c.addEventListener('change',render));
    render();
  }


  function initPremiumMotion(){
    const reduced=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(reduced) return;
    const targets=$$('.pw-hero-product, .pw-network-pulse, .pw-dashboard-smart-row .pw-card');
    targets.forEach(el=>{
      el.addEventListener('pointermove',e=>{
        if(window.innerWidth<900) return;
        const r=el.getBoundingClientRect();
        const x=(e.clientX-r.left)/r.width-.5;
        const y=(e.clientY-r.top)/r.height-.5;
        el.style.setProperty('--pw-mx',`${(x*7).toFixed(2)}px`);
        el.style.setProperty('--pw-my',`${(y*7).toFixed(2)}px`);
      });
      el.addEventListener('pointerleave',()=>{el.style.setProperty('--pw-mx','0px');el.style.setProperty('--pw-my','0px');});
    });
  }


  /* Pure Work 4.9.3 -------------------------------------------------------
     Password usability: a show/hide switch and a plain-language strength hint.
     Purely additive - no existing markup or styling is altered. */
  function initPasswordToggles(){
    $$('input[data-pw-toggle]').forEach(input=>{
      if(input.dataset.pwToggleReady) return;
      input.dataset.pwToggleReady = '1';
      const wrap = document.createElement('span');
      wrap.className = 'pw-pass-field';
      input.parentNode.insertBefore(wrap, input);
      wrap.appendChild(input);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'pw-pass-eye';
      const en = document.body.classList.contains('pw-lang-en');
      btn.textContent = en ? 'Show' : 'Anzeigen';
      btn.setAttribute('aria-label', en ? 'Show password' : 'Passwort anzeigen');
      btn.addEventListener('click',()=>{
        const shown = input.type === 'text';
        input.type = shown ? 'password' : 'text';
        btn.textContent = shown ? (en?'Show':'Anzeigen') : (en?'Hide':'Verbergen');
        input.focus();
      });
      wrap.appendChild(btn);
    });
  }

  function initPasswordStrength(){
    const en = document.body.classList.contains('pw-lang-en');
    const labels = en ? ['Too short','Weak','Okay','Strong'] : ['Zu kurz','Schwach','Gut','Stark'];
    $$('input[data-pw-strength]').forEach(input=>{
      if(input.dataset.pwStrengthReady) return;
      input.dataset.pwStrengthReady = '1';
      const meter = document.createElement('span');
      meter.className = 'pw-pass-meter';
      meter.innerHTML = '<i></i><b></b>';
      (input.closest('.pw-pass-field') || input).insertAdjacentElement('afterend', meter);
      const bar = meter.querySelector('i');
      const text = meter.querySelector('b');
      input.addEventListener('input',()=>{
        const v = input.value;
        if(!v){ meter.classList.remove('show'); return; }
        meter.classList.add('show');
        let score = 0;
        if(v.length >= 8) score++;
        if(v.length >= 12) score++;
        if(/[^A-Za-z0-9]/.test(v) || (/[A-Z]/.test(v) && /[0-9]/.test(v))) score++;
        if(v.length < 8) score = 0;
        meter.dataset.level = String(score);
        bar.style.width = ((score + 1) * 25) + '%';
        text.textContent = labels[Math.min(score, 3)];
      });
    });
  }



  /* Pure Work 4.9.7 -------------------------------------------------------
     Pure Assist: Freitext einfügen, Formular füllt sich. Gefüllte Felder werden
     kurz hervorgehoben, damit sofort sichtbar ist, was übernommen wurde. */
  function initAssistIntake(){
    const input = $('[data-pw-assist-input]');
    const btn = $('[data-pw-assist-run]');
    const result = $('[data-pw-assist-result]');
    if(!input || !btn) return;
    const en = document.body.classList.contains('pw-lang-en');

    const setField = (name, value) => {
      if(value === '' || value === null || typeof value === 'undefined') return false;
      const el = document.querySelector('[name="' + name + '"]');
      if(!el) return false;
      if(el.type === 'checkbox'){
        if(!value) return false;
        el.checked = true;
      } else {
        if(el.value && el.value !== '0') return false; // nichts überschreiben, was schon dasteht
        el.value = value;
      }
      const host = el.closest('label') || el;
      host.classList.add('pw-assist-filled');
      setTimeout(()=>host.classList.remove('pw-assist-filled'), 2600);
      return true;
    };

    btn.addEventListener('click', async () => {
      const text = input.value.trim();
      if(text.length < 12){ toast(en ? 'Please paste a bit more text.' : 'Bitte etwas mehr Text einfügen.', 'error'); return; }
      btn.disabled = true;
      const label = btn.innerHTML;
      btn.textContent = PW_APP.i18n.saving;
      try {
        const d = await ajax('pw_assist_parse_worker', {text: text});
        let n = 0;
        [['role', d.role], ['experience', d.experience], ['location', d.location],
         ['available_from', d.available_from], ['full_name', d.full_name],
         ['worker_email', d.email], ['worker_phone', d.phone]].forEach(([k, v]) => { if(setField(k, v)) n++; });
        [['qualifications', d.qualifications], ['languages', d.languages], ['shifts', d.shifts]]
          .forEach(([k, v]) => { if(v && v.length && setField(k, v.join(', '))) n++; });
        if(d.driver && setField('driver', true)) n++;
        if(d.car && setField('car', true)) n++;

        if(result){
          const notes = (d.notes || []).join(' ');
          result.textContent = (en ? n + ' fields filled. ' : n + ' Felder ausgefüllt. ') + notes;
          result.classList.add('show');
        }
        toast(en ? n + ' fields filled – please review.' : n + ' Felder ausgefüllt – bitte kurz prüfen.');
        const first = $('.pw-assist-filled');
        if(first) first.scrollIntoView({block:'center', behavior:'smooth'});
      } catch(err){
        toast(err.message, 'error');
      } finally {
        btn.disabled = false;
        btn.innerHTML = label;
      }
    });
  }



  function initV498CommandPalette(){
    const overlay = $('[data-pw-command-overlay]');
    if(!overlay) return;
    const input = $('[data-pw-command-input]', overlay);
    const items = $$('[data-pw-command-item]', overlay);
    const open = ()=>{
      overlay.classList.add('is-open');
      overlay.setAttribute('aria-hidden','false');
      document.body.classList.add('pw-overlay-open');
      window.setTimeout(()=>{ if(input){ input.value=''; filter(); input.focus(); } },40);
    };
    const close = ()=>{
      overlay.classList.remove('is-open');
      overlay.setAttribute('aria-hidden','true');
      document.body.classList.remove('pw-overlay-open');
    };
    const filter = ()=>{
      const q=(input ? input.value : '').toLowerCase().trim();
      let first=null;
      items.forEach(item=>{
        const ok=!q || item.textContent.toLowerCase().includes(q);
        item.hidden=!ok;
        if(ok && !first) first=item;
      });
      items.forEach(i=>i.classList.remove('is-selected'));
      if(first) first.classList.add('is-selected');
    };
    $$('[data-pw-command-open]').forEach(btn=>btn.addEventListener('click',open));
    $$('[data-pw-command-close]',overlay).forEach(btn=>btn.addEventListener('click',close));
    if(input){
      input.addEventListener('input',filter);
      input.addEventListener('keydown',e=>{
        const visible=items.filter(i=>!i.hidden);
        let idx=visible.findIndex(i=>i.classList.contains('is-selected'));
        if(e.key==='ArrowDown'){e.preventDefault(); if(visible.length){idx=(idx+1)%visible.length;visible.forEach(i=>i.classList.remove('is-selected'));visible[idx].classList.add('is-selected');visible[idx].scrollIntoView({block:'nearest'});}}
        if(e.key==='ArrowUp'){e.preventDefault(); if(visible.length){idx=idx<=0?visible.length-1:idx-1;visible.forEach(i=>i.classList.remove('is-selected'));visible[idx].classList.add('is-selected');visible[idx].scrollIntoView({block:'nearest'});}}
        if(e.key==='Enter'){const chosen=visible.find(i=>i.classList.contains('is-selected'))||visible[0];if(chosen) window.location.href=chosen.href;}
      });
    }
    document.addEventListener('keydown',e=>{
      if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='k'){e.preventDefault(); overlay.classList.contains('is-open')?close():open();}
      if(e.key==='Escape'&&overlay.classList.contains('is-open')) close();
    });
  }

  function initV498Copilot(){
    const drawer=$('[data-pw-copilot-drawer]');
    if(!drawer) return;
    const answer=$('[data-pw-copilot-answer]',drawer);
    const action=$('[data-pw-copilot-action]',drawer);
    let preset='';
    const open=prompt=>{
      preset=prompt||'';
      drawer.classList.add('is-open');
      drawer.setAttribute('aria-hidden','false');
      document.body.classList.add('pw-overlay-open');
      if(preset){ const btn=$('[data-pw-copilot-prompt="'+preset+'"]',drawer); if(btn) window.setTimeout(()=>btn.click(),80); }
    };
    const close=()=>{drawer.classList.remove('is-open');drawer.setAttribute('aria-hidden','true');document.body.classList.remove('pw-overlay-open');};
    $$('[data-pw-copilot-open]').forEach(btn=>btn.addEventListener('click',()=>open(btn.dataset.pwCopilotPrompt||'')));
    $$('[data-pw-copilot-close]',drawer).forEach(btn=>btn.addEventListener('click',close));
    $$('[data-pw-copilot-prompt]',drawer).forEach(btn=>btn.addEventListener('click',async()=>{
      $$('[data-pw-copilot-prompt]',drawer).forEach(b=>b.classList.remove('is-active'));
      btn.classList.add('is-active');
      if(answer){answer.classList.add('is-loading'); const b=$('b',answer); const p=$('p',answer); if(b)b.textContent=document.body.classList.contains('pw-lang-en')?'Thinking…':'Analysiere…'; if(p)p.textContent=document.body.classList.contains('pw-lang-en')?'Using your portal data.':'Nutze deine Portal-Daten.';}
      if(action){action.hidden=true;action.removeAttribute('href');}
      try{
        const d=await ajax('pw_v498_copilot',{prompt:btn.dataset.pwCopilotPrompt||'help',context:window.PW_V498_CONTEXT||'dashboard'});
        if(answer){const b=$('b',answer),p=$('p',answer);if(b)b.textContent=d.title||'Pure Assist';if(p)p.textContent=d.body||'';}
        if(action && d.url){action.hidden=false;action.href=d.url;action.textContent=d.cta||'Öffnen';}
      }catch(err){
        if(answer){const b=$('b',answer),p=$('p',answer);if(b)b.textContent='Pure Assist';if(p)p.textContent=err.message;}
      }finally{if(answer)answer.classList.remove('is-loading');}
    }));
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&drawer.classList.contains('is-open'))close();});
  }

  function initV498AutoCards(){
    $$('.pw-v498-auto-card input[type="checkbox"]').forEach(input=>{
      input.addEventListener('change',()=>input.closest('.pw-v498-auto-card')?.classList.toggle('is-on',input.checked));
      input.closest('.pw-v498-auto-card')?.classList.toggle('is-on',input.checked);
    });
  }

  document.addEventListener('DOMContentLoaded',()=>{
    initRoleSelect();
    initTargetMode();
    initModals();
    initConfirms();
    initStatusButtons();
    initChat();
    initWorkerWizard();
    initFavorites();
    initThreadFilter();
    initSmoothAnchors();
    initAugType();
    initOccupationSearch();
    initLoader();
    initReveal();
    initSmartDescription();
    initMetricCounters();
    initCopyButtons();
    initCopyNearest();
    initLivePulse();
    initWizardProgress();
    initCrmPitch();
    initPremiumMotion();
    initPasswordToggles();
    initPasswordStrength();
    initAssistIntake();
    initV498CommandPalette();
    initV498Copilot();
    initV498AutoCards();
  });
})();

/* Pure Work 4.9.9 – calculators / copy helpers */
(() => {
  const q=(s,r=document)=>r.querySelector(s);
  const qa=(s,r=document)=>[...r.querySelectorAll(s)];
  const euro=n=>new Intl.NumberFormat(document.documentElement.lang==='en-US'?'en-US':'de-DE',{style:'currency',currency:'EUR'}).format(Number.isFinite(n)?n:0);
  qa('[data-pw-rate-calc]').forEach(calc=>{
    const wage=q('[data-rate-wage]',calc),factor=q('[data-rate-factor]',calc),overhead=q('[data-rate-overhead]',calc),margin=q('[data-rate-margin]',calc);
    const costOut=q('[data-rate-cost]',calc),rateOut=q('[data-rate-result]',calc),profitOut=q('[data-rate-profit]',calc);
    const run=()=>{
      const w=parseFloat(wage?.value||0),f=Math.max(1,parseFloat(factor?.value||1)),o=parseFloat(overhead?.value||0),m=Math.min(80,Math.max(0,parseFloat(margin?.value||0)))/100;
      const cost=w*f+o; const rate=m>=.99?cost:cost/(1-m); const profit=rate-cost;
      if(costOut) costOut.textContent=euro(cost); if(rateOut) rateOut.textContent=euro(rate); if(profitOut) profitOut.textContent=euro(profit);
    };
    [wage,factor,overhead,margin].forEach(el=>el&&el.addEventListener('input',run)); run();
  });
  qa('[data-pw-copy-report]').forEach(btn=>btn.addEventListener('click',async()=>{
    const text=btn.dataset.report||''; if(!text) return;
    try{await navigator.clipboard.writeText(text); const old=btn.innerHTML; btn.textContent=document.documentElement.lang.startsWith('en')?'Copied':'Kopiert'; setTimeout(()=>btn.innerHTML=old,1300);}catch(e){}
  }));
})();

/* Pure Work 5.0.0 – e-invoice assistant, tariff UI and language guard */
(() => {
  const q=(s,r=document)=>r.querySelector(s);
  const qa=(s,r=document)=>[...r.querySelectorAll(s)];
  const cfg=window.PW_V500||{};
  const lang=(cfg.lang||document.documentElement.lang||'de').toLowerCase().startsWith('en')?'en':'de';

  const translateExact=()=>{
    const map=cfg.ui||{};
    if(!Object.keys(map).length)return;
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(node){
      if(!node.parentElement||['SCRIPT','STYLE','TEXTAREA','INPUT','OPTION'].includes(node.parentElement.tagName))return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }});
    const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
    nodes.forEach(n=>{const raw=n.nodeValue||'';const trim=raw.trim();if(map[trim])n.nodeValue=raw.replace(trim,map[trim]);});
  };
  translateExact();

  qa('[data-pw-einvoice-form]').forEach(form=>{
    const assist=q('[data-pw-invoice-assist]')||form.closest('.pw-v500-invoice-compose')?.querySelector('[data-pw-invoice-assist]');
    if(!assist)return;
    const score=q('[data-invoice-score]',assist),bar=q('[data-invoice-bar]',assist),list=q('[data-invoice-checks]',assist),focus=q('[data-pw-invoice-focus]',assist);
    const fields=cfg.invoice?.fields||{};
    const required=qa('[data-invoice-field]',form);
    const senderReady=form.dataset.senderReady==='1';
    const render=()=>{
      let ok=senderReady?1:0,total=required.length+1,missing=[];
      if(!senderReady)missing.push(lang==='en'?'Own invoice master data':'Eigene Rechnungsstammdaten');
      required.forEach(el=>{const valid=(el.value||'').trim()!=='' && (!el.matches('[type="number"]') || parseFloat(el.value)>0);if(valid)ok++;else missing.push(fields[el.dataset.invoiceField]||el.dataset.invoiceField);});
      const pct=Math.round(ok*100/Math.max(1,total));if(score)score.textContent=pct+'%';if(bar)bar.style.width=pct+'%';
      if(list){list.innerHTML='';const shown=missing.slice(0,7);if(!shown.length){const li=document.createElement('li');li.className='is-ready';li.innerHTML='<span>✓</span><b>'+(lang==='en'?'Required information complete':'Pflichtangaben vollständig')+'</b>';list.appendChild(li);}else shown.forEach(name=>{const li=document.createElement('li');li.innerHTML='<span>!</span><b>'+name+'</b><small>'+(cfg.invoice?.missing||(lang==='en'?'missing':'fehlt'))+'</small>';list.appendChild(li);});}
      assist.classList.toggle('is-ready',pct===100);
    };
    required.forEach(el=>el.addEventListener('input',render));render();
    focus?.addEventListener('click',()=>{const el=required.find(x=>(x.value||'').trim()==='' || (x.matches('[type="number"]')&&parseFloat(x.value)<=0));if(el){el.scrollIntoView({behavior:'smooth',block:'center'});setTimeout(()=>el.focus(),350);}else if(!senderReady){document.querySelector('.pw-v500-billing-profile')?.scrollIntoView({behavior:'smooth',block:'start'});}});
  });

  qa('[data-pw-rate-to-invoice]').forEach(btn=>btn.addEventListener('click',()=>{
    const calc=btn.closest('[data-pw-rate-calc]');const out=q('[data-rate-result]',calc);const rateField=q('[data-pw-einvoice-form] [name="rate"]');
    if(!out||!rateField)return;const normalized=(out.textContent||'').replace(/[^0-9,\.]/g,'').replace(/\./g,'').replace(',','.');const n=parseFloat(normalized);if(Number.isFinite(n)){rateField.value=n.toFixed(2);rateField.dispatchEvent(new Event('input',{bubbles:true}));rateField.scrollIntoView({behavior:'smooth',block:'center'});}
  }));
})();

/* Pure Work 5.0.1 – standalone calculator handoff */
(() => {
  const q=(s,r=document)=>r.querySelector(s);
  document.addEventListener('click',(e)=>{
    const btn=e.target.closest('[data-pw-rate-to-invoice]');
    if(!btn) return;
    const root=btn.closest('[data-pw-rate-calc]');
    if(!root) return;
    const invoiceRate=q('[name="rate"]');
    if(invoiceRate) return; // the existing handler takes over inside an invoice form.
    const out=q('[data-rate-result]',root) || q('[data-rate-bill]',root);
    const raw=out ? String(out.textContent||'').replace(/[^0-9,\.]/g,'').replace(',','.') : '';
    const rate=parseFloat(raw);
    if(!rate || !window.PW_V501 || !window.PW_V501.invoiceNew) return;
    e.preventDefault();
    const u=new URL(window.PW_V501.invoiceNew,window.location.origin);
    u.searchParams.set('rate',rate.toFixed(2));
    window.location.href=u.toString();
  },true);
})();

