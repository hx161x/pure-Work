PURE WORK 5.4.4

NEU IN 5.4.4 — PURE CONNECT
- Pure Office kann jetzt direkt aus Pure Work heraus verbunden werden.
- Kompatibel mit Pure Office 1.0.0: Workspace-ID PO-XXXX-XXXX + einmaliger Verbindungscode.
- Kein separates Pure-Connect-Bridge-Plugin mehr erforderlich.
- Verbindung wird pro Unternehmensaccount gespeichert.
- Gemeinsame Pure ID nach erfolgreicher Kopplung sichtbar.
- Verbindungstoken wird verschlüsselt gespeichert.
- Verbindung prüfen, Pure Office öffnen und Verbindung trennen.
- REST-Statusschnittstelle für spätere bidirektionale Pure-Produktübergaben vorbereitet.

BEIBEHALTEN AUS 5.4.3
- Digitaler Firmenkontakt / Visitenkarte direkt im Live-Chat
- Live-Chat ohne Seitenreload
- Mitarbeiter-Cockpit, Kunden-Cockpit, Einsatzübersicht
- Stripe-Zahlungsmethoden und Tarifverwaltung
- Gebrandete System-E-Mails und Reminder

Pure Work und Pure Office bleiben eigenständige Produkte. Pure Connect koppelt die Unternehmensidentität sicher, ohne Benutzerkonten oder Datenbanken technisch zusammenzulegen.
