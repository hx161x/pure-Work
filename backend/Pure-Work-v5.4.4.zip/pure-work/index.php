<?php get_header(); ?>
<main class="pw-plain-page">
  <div class="pw-public-wrap">
    <?php if (have_posts()): while (have_posts()): the_post(); ?>
      <article <?php post_class('pw-content-card'); ?>>
        <h1><?php the_title(); ?></h1>
        <?php the_content(); ?>
      </article>
    <?php endwhile; endif; ?>
  </div>
</main>
<?php get_footer(); ?>
